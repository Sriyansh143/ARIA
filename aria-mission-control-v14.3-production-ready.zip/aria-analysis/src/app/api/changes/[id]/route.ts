import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const change = await db.changeRequest.findUnique({ where: { id } });
  if (!change) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ change });
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { action, decidedBy, decisionNote } = await req.json().catch(() => ({}));
  if (!action || !decidedBy) return NextResponse.json({ error: 'action and decidedBy required' }, { status: 400 });
  const status = action === 'approve' ? 'approved' : action === 'reject' ? 'rejected' : action === 'deploy' ? 'deployed' : null;
  if (!status) return NextResponse.json({ error: 'action must be approve|reject|deploy' }, { status: 400 });
  const data: Record<string, unknown> = { status, decidedBy: decidedBy ?? null };
  if (status === 'approved') data.approvalId = decidedBy;
  if (status === 'deployed') data.deployedAt = new Date();
  await db.changeRequest.update({ where: { id }, data });
  return NextResponse.json({ ok: true, id, status });
}
