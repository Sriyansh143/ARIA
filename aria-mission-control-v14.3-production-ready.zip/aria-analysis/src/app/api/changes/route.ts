import { NextRequest, NextResponse } from 'next/server';
import { requestChange, listChanges, getChangeStats } from '@/lib/change-gate';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  if (req.nextUrl.searchParams.get('stats') === '1') return NextResponse.json(await getChangeStats());
  const status = req.nextUrl.searchParams.get('status') ?? undefined;
  const changeType = req.nextUrl.searchParams.get('changeType') ?? undefined;
  return NextResponse.json({ rows: await listChanges({ status, changeType }) });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (!body.title || !body.description || !body.changeType) {
    return NextResponse.json({ error: 'title, description, changeType required' }, { status: 400 });
  }
  const id = await requestChange(body);
  return NextResponse.json({ id });
}
