import { NextRequest, NextResponse } from 'next/server';
import { executeActionsFromResponse, formatResultsForAgent } from '@/lib/agent-exec';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/agent-exec — execute action blocks from an LLM response.
 *
 * Body: { response: string } — the LLM's full text response.
 *
 * The system parses ```action blocks from the response, executes each
 * against the real API, and returns the results.
 *
 * This is the fix for the "simulated execution" problem — agents can
 * now ACTUALLY create tasks, save artifacts, make payments, etc.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { response } = body as { response?: string };

  if (!response || typeof response !== 'string') {
    return NextResponse.json(
      { error: 'response (string) is required — the LLM output to parse for action blocks' },
      { status: 400 },
    );
  }

  const { actions, results, summary } = await executeActionsFromResponse(response);
  const agentContext = formatResultsForAgent(results);

  return NextResponse.json({
    actionsFound: actions.length,
    results,
    summary,
    agentContext,
  });
}
