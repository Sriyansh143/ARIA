import { NextRequest, NextResponse } from 'next/server';
import { reverseAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { reversedBy, force } = await req.json().catch(() => ({}));
  const result = await reverseAction(id, { reversedBy: reversedBy ?? 'operator', force: force === true });
  if (!result.ok && result.detail.includes('force')) {
    return NextResponse.json({ result, error: result.detail }, { status: 403 });
  }
  return NextResponse.json({ result });
}
