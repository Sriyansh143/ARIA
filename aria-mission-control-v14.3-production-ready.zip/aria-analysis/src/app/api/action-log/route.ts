import { NextRequest, NextResponse } from 'next/server';
import { listActions, getActionStats } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  if (req.nextUrl.searchParams.get('stats') === '1') return NextResponse.json(await getActionStats());
  const actor = req.nextUrl.searchParams.get('actor') ?? undefined;
  const action = req.nextUrl.searchParams.get('action') ?? undefined;
  const category = req.nextUrl.searchParams.get('category') ?? undefined;
  const reversed = req.nextUrl.searchParams.get('reversed');
  const result = await listActions({
    actor, action, category,
    reversed: reversed === 'true' ? true : reversed === 'false' ? false : undefined,
  });
  return NextResponse.json(result);
}
