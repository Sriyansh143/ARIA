import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Decision Log — surfaces every autonomous decision ARIA has made (autopilot
// ticks, briefings, standups) for operator auditability. Reads from ActionLog
// where category='autonomous'. Supports filtering by action type + a limit.

interface Decision {
  id: string;
  action: string;          // autopilot.dispatch | autopilot.queue | briefing.generated | standup.generated
  actor: string;           // autopilot | aria
  summary: string;         // afterState (the decided goal / headline)
  meta: Record<string, unknown>;
  createdAt: string;
  reversible: boolean;
  reversed: boolean;
}

const ACTION_META: Record<string, { label: string; color: string; icon: string }> = {
  'autopilot.dispatch': { label: 'Autopilot · Dispatched', color: 'green', icon: 'rocket' },
  'autopilot.queue': { label: 'Autopilot · Queued', color: 'amber', icon: 'clock' },
  'briefing.generated': { label: 'Briefing Generated', color: 'cyan', icon: 'satellite' },
  'standup.generated': { label: 'Standup Generated', color: 'violet', icon: 'sunrise' },
};

export async function GET(req: NextRequest) {
  const type = req.nextUrl.searchParams.get('type'); // autopilot | briefing | standup
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 60), 200);

  // ── Auto-pruning: keep only the most recent KEEP decisions to prevent
  // unbounded growth (the autopilot runs every 60s, so entries accumulate
  // fast). Prune opportunistically — only when the total exceeds the
  // threshold — so the common path stays fast.
  const KEEP = 200;
  try {
    const total = await db.actionLog.count({ where: { category: 'autonomous' } });
    if (total > KEEP + 50) {
      const cutoffRows = await db.actionLog.findMany({
        where: { category: 'autonomous' },
        orderBy: { createdAt: 'desc' },
        skip: KEEP,
        take: 100,
        select: { id: true },
      });
      if (cutoffRows.length > 0) {
        await db.actionLog.deleteMany({ where: { id: { in: cutoffRows.map((r) => r.id) } } });
      }
    }
  } catch { /* best-effort — never block the read on prune */ }

  const where: Record<string, unknown> = { category: 'autonomous' };
  if (type === 'autopilot') {
    where.action = { in: ['autopilot.dispatch', 'autopilot.queue'] };
  } else if (type === 'briefing') {
    where.action = 'briefing.generated';
  } else if (type === 'standup') {
    where.action = 'standup.generated';
  }

  const rows = await db.actionLog.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    select: { id: true, action: true, actor: true, afterState: true, meta: true, createdAt: true, reversible: true, reversed: true },
  });

  const decisions: Decision[] = rows.map((r) => {
    let meta: Record<string, unknown> = {};
    try { meta = JSON.parse(r.meta || '{}'); } catch { /* ignore */ }
    return {
      id: r.id,
      action: r.action,
      actor: r.actor,
      summary: r.afterState ?? '',
      meta,
      createdAt: r.createdAt.toISOString(),
      reversible: r.reversible,
      reversed: r.reversed,
    };
  });

  // Tally counts per type for the filter chips.
  const counts = {
    all: await db.actionLog.count({ where: { category: 'autonomous' } }),
    autopilot: await db.actionLog.count({ where: { category: 'autonomous', action: { in: ['autopilot.dispatch', 'autopilot.queue'] } } }),
    briefing: await db.actionLog.count({ where: { category: 'autonomous', action: 'briefing.generated' } }),
    standup: await db.actionLog.count({ where: { category: 'autonomous', action: 'standup.generated' } }),
  };

  return NextResponse.json({ decisions, counts, actionMeta: ACTION_META });
}
