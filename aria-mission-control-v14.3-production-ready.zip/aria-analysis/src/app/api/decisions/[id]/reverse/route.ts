import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { reverseAction } from '@/lib/action-log';
import { autoAdjustKpis } from '@/lib/kpi-engine';
import { logAction } from '@/lib/action-log';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// POST — Quick-reverse an autonomous decision (ActionLog entry) directly
// from the Decision Log timeline. This makes auditing faster — the
// operator can undo a decision with one click instead of navigating to
// the Action Log tab. After reversal, KPI targets are auto-adjusted
// based on the outcome.
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { reversedBy, force } = await req.json().catch(() => ({}));

  const result = await reverseAction(id, { reversedBy: reversedBy ?? 'operator', force: force === true });

  if (!result.ok && result.detail.includes('force')) {
    return NextResponse.json({ result, error: result.detail }, { status: 403 });
  }

  // Log the quick-reverse as an auditable action itself.
  try {
    await logAction({
      actor: reversedBy ?? 'operator',
      action: 'decision.quick-reverse',
      category: 'audit',
      target: `action-log:${id}`,
      afterState: result.detail,
      reversible: false,
      meta: { originalId: id, ok: result.ok },
    });
  } catch { /* best-effort */ }

  // Trigger automatic KPI adjustment based on the logged outcome.
  try {
    const kpis = await autoAdjustKpis(`quick-reverse:${id}`);
    logger.info({ id, kpisAdjusted: kpis.filter((k) => k.autoAdjusted).length }, 'decisions: quick-reverse triggered KPI auto-adjustment');
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'decisions: KPI auto-adjustment failed (non-blocking)');
  }

  return NextResponse.json({ result });
}
