import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/forecasts/history — time-series of fleet forecasts for trend charts.
// Returns the last N forecast snapshots per metric (default 48, max 200).
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 48), 200);
  const metric = req.nextUrl.searchParams.get('metric');

  const where = metric ? { metric } : {};
  const rows = await db.fleetForecast.findMany({
    where,
    orderBy: { generatedAt: 'desc' },
    take: limit,
    select: { id: true, metric: true, horizon: true, current: true, forecast: true, confidence: true, trend: true, riskLevel: true, generatedAt: true },
  });

  const reversed = [...rows].reverse();
  const byMetric: Record<string, Array<{
    generatedAt: string;
    current: number;
    forecast: number;
    confidence: number;
    trend: string;
    riskLevel: string;
    horizon: string;
  }>> = {};
  for (const r of reversed) {
    if (!byMetric[r.metric]) byMetric[r.metric] = [];
    byMetric[r.metric].push({
      generatedAt: r.generatedAt.toISOString(),
      current: r.current,
      forecast: r.forecast,
      confidence: r.confidence,
      trend: r.trend,
      riskLevel: r.riskLevel,
      horizon: r.horizon,
    });
  }

  return NextResponse.json({
    series: byMetric,
    count: reversed.length,
    metrics: Object.keys(byMetric),
  });
}
