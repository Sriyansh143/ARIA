import { NextRequest, NextResponse } from 'next/server';
import { generateFleetForecasts, getLatestForecasts } from '@/lib/predictive-analytics';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — latest fleet forecasts (or force-regenerate with ?refresh=1).
export async function GET(req: NextRequest) {
  const refresh = req.nextUrl.searchParams.get('refresh') === '1';
  const forecasts = refresh ? await generateFleetForecasts() : await getLatestForecasts();
  return NextResponse.json({ forecasts, generatedAt: new Date().toISOString() });
}

// POST — force-regenerate forecasts.
export async function POST() {
  const forecasts = await generateFleetForecasts();
  return NextResponse.json({ ok: true, forecasts, generatedAt: new Date().toISOString() });
}
