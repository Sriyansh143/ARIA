import { NextResponse } from 'next/server';
import { startScheduler, getSchedulerStatus } from '@/lib/cron-scheduler';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json({ scheduler: getSchedulerStatus(), timestamp: new Date().toISOString() });
}

export async function POST() {
  startScheduler();
  try {
    const { startAutonomousLoop } = await import('@/lib/autonomous-loop');
    startAutonomousLoop();
  } catch {}
  return NextResponse.json({ ok: true, scheduler: getSchedulerStatus(), message: 'All background services started.' });
}
