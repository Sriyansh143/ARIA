import { NextRequest, NextResponse } from 'next/server';
import { researchBeforeAction, type PreActionContext } from '@/lib/agent-pre-action';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — research an action before executing it
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({})) as Partial<PreActionContext>;
  if (!body.action || !body.description) {
    return NextResponse.json({ error: 'action and description required' }, { status: 400 });
  }
  const result = await researchBeforeAction({
    agentCodename: body.agentCodename ?? 'UNKNOWN',
    agentRole: body.agentRole ?? 'agent',
    action: body.action,
    actionType: body.actionType ?? 'execute',
    target: body.target,
    description: body.description,
    currentContext: body.currentContext,
  });
  return NextResponse.json(result);
}
