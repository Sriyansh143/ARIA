import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/vision — analyze an image (base64 or URL) using vision LLM.
 *
 * Body: {
 *   image: string (base64 or URL),
 *   question: string (what to analyze about the image)
 * }
 *
 * v14.3 FIX: Was using ZAI.create() directly which fails on Windows
 * (".z-ai-config not found"). Now uses the same env-var-first init as
 * src/lib/llm.ts, and falls back to a graceful error instead of 500.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { image, question } = body as { image?: string; question?: string };

  if (!image) {
    return NextResponse.json({ error: 'image (base64 or URL) is required' }, { status: 400 });
  }

  const prompt = question || 'Describe what you see in this image. Identify any text, objects, people, UI elements, or notable features.';

  try {
    // Try Z-AI SDK with env-var-first init (same pattern as src/lib/llm.ts)
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    let zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

    // Try env var first (more reliable on Windows)
    const envKey = process.env.ZAI_API_KEY;
    if (envKey) {
      try {
        zai = await ZAI.create({ apiKey: envKey } as never);
      } catch {
        // fall through to default init
      }
    }
    if (!zai) {
      try {
        zai = await ZAI.create();
      } catch {
        // Both init paths failed
      }
    }

    if (!zai) {
      // Return 200 with error field (not 503) so postJson doesn't throw
      // and the client can handle it gracefully without spamming toasts.
      return NextResponse.json({
        error: 'Vision model unavailable. Check ZAI_API_KEY in .env or install Ollama locally.',
        description: '(vision analysis skipped — LLM provider unavailable)',
      });
    }

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url: image.startsWith('http') ? image : `data:image/jpeg;base64,${image}` } },
          ],
        } as never,
      ],
      thinking: { type: 'disabled' },
    });

    const content = completion.choices[0]?.message?.content ?? 'No response from vision model.';
    return NextResponse.json({ description: content, question: prompt });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Vision analysis failed';
    // Return 200 with error field (not 500) so the client handles gracefully.
    return NextResponse.json({
      error: msg,
      description: '(vision analysis failed — provider may be rate-limited)',
    });
  }
}
