import { NextRequest, NextResponse } from 'next/server';
import { scheduleCsatSurvey } from '@/lib/csat-engine';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST /api/csat/schedule
// body: { invoiceId?, clientEmail, clientName }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { invoiceId, clientEmail, clientName } = body as {
      invoiceId?: string | null;
      clientEmail?: string;
      clientName?: string;
    };
    if (!clientEmail || typeof clientEmail !== 'string' || clientEmail.trim().length === 0) {
      return NextResponse.json({ error: 'clientEmail required' }, { status: 400 });
    }
    if (!clientName || typeof clientName !== 'string' || clientName.trim().length === 0) {
      return NextResponse.json({ error: 'clientName required' }, { status: 400 });
    }
    const survey = await scheduleCsatSurvey(
      invoiceId && invoiceId.trim().length > 0 ? invoiceId.trim() : null,
      clientEmail.trim(),
      clientName.trim(),
    );
    return NextResponse.json({ survey });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'schedule failed' },
      { status: 500 },
    );
  }
}
