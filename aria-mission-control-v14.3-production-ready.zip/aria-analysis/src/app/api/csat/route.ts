import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCsatStats, getPendingCsatSurveys } from '@/lib/csat-engine';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/csat → { stats, recentSurveys, pending }
export async function GET() {
  try {
    const [stats, recentSurveys, pending] = await Promise.all([
      getCsatStats(),
      db.csatSurvey.findMany({
        orderBy: { createdAt: 'desc' },
        take: 50,
      }),
      getPendingCsatSurveys(),
    ]);
    return NextResponse.json({ stats, recentSurveys, pending });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'fetch failed' },
      { status: 500 },
    );
  }
}
