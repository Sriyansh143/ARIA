import { NextRequest, NextResponse } from 'next/server';
import { submitCsatResponse } from '@/lib/csat-engine';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST /api/csat/submit
// body: { surveyId, rating, npsScore?, feedback? }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { surveyId, rating, npsScore, feedback } = body as {
      surveyId?: string;
      rating?: number;
      npsScore?: number | null;
      feedback?: string | null;
    };
    if (!surveyId || typeof surveyId !== 'string') {
      return NextResponse.json({ error: 'surveyId required' }, { status: 400 });
    }
    if (rating == null || typeof rating !== 'number') {
      return NextResponse.json({ error: 'rating (number 1-5) required' }, { status: 400 });
    }
    const survey = await submitCsatResponse(
      surveyId,
      Math.round(rating),
      typeof npsScore === 'number' ? npsScore : null,
      typeof feedback === 'string' ? feedback : null,
    );
    return NextResponse.json({ survey });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'submit failed';
    const status = /not found|already completed|must be/i.test(message) ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
