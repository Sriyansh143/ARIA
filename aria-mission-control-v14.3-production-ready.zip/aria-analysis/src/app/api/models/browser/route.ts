import { NextRequest, NextResponse } from 'next/server';
import {
  BROWSER_MODELS,
  getBrowserModelStats,
  getBrowserModelsByCategory,
  getNoLoginBrowserModels,
  getAutomatableBrowserModels,
} from '@/lib/browser-models';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/models/browser — catalog of free browser-accessible model playgrounds.
// Supports ?category= and ?nolongin=1 and ?automatable=1 filters.
export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get('category');
  const noLogin = req.nextUrl.searchParams.get('nologin') === '1';
  const automatable = req.nextUrl.searchParams.get('automatable') === '1';

  let models = BROWSER_MODELS;
  if (category) models = getBrowserModelsByCategory(category);
  if (noLogin) models = models.filter((m) => !m.requiresLogin);
  if (automatable) models = models.filter((m) => m.automatable);

  return NextResponse.json({
    models,
    stats: getBrowserModelStats(),
    filters: { category, noLogin, automatable },
  });
}
