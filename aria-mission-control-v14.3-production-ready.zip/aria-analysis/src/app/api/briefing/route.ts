import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';
import { generateFleetForecasts, getLatestForecasts, type Forecast } from '@/lib/predictive-analytics';
import {
  computeStateHash,
  getCachedBriefing,
  getCachedStateHash,
  runSingleFlight,
  setCachedBriefing,
  invalidateBriefingCache,
  type BriefingPayload,
  type BriefingStateSnapshot,
} from '@/lib/briefing-cache';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Autonomous Mission Briefing — synthesizes live fleet state, telemetry, tasks,
// comms, and goals into a prioritized "what the AI company should focus on
// right now" briefing with actionable recommendations. Each recommendation is
// structured so the operator can one-click promote it into a Task.
//
// ── CACHING LAYERS (eliminates localhost ↔ network-IP desync) ─────────
//   1. TTL cache (30s) — every client within a 30s window gets identical JSON.
//   2. State-hash cache — if state hasn't changed since the last briefing,
//      the LLM is skipped entirely and the cached briefing is re-served
//      (with a fresh generatedAt timestamp).
//   3. Single-flight — N concurrent requests during a cache miss share one
//      in-flight LLM call instead of each triggering their own.
//
// Use `?force=1` to bypass the cache (used by the Briefing tab's Regenerate
// button — calls invalidateBriefingCache() then re-fetches).

interface Recommendation {
  title: string;
  rationale: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  suggestedAssignee?: string;
  category: 'performance' | 'revenue' | 'reliability' | 'capacity' | 'knowledge' | 'ops';
}

interface Briefing {
  generatedAt: string;
  headline: string;
  healthScore: number; // 0–100
  summary: string;
  metrics: {
    agents: number;
    activeAgents: number;
    overloadedAgents: string[];
    idleAgents: number;
    pendingTasks: number;
    inProgressTasks: number;
    blockedTasks: number;
    unreadComms: number;
    openApprovals: number;
    criticalFindings: number;
    cpu: number;
    memPct: number;
    confirmedRevenue: number;
    pendingRevenue: number;
    successRate: number;
  };
  topRisks: string[];
  recommendations: Recommendation[];
  forecasts: Forecast[];
}

export async function GET(req: NextRequest) {
  const force = req.nextUrl.searchParams.get('force') === '1';
  if (force) {
    invalidateBriefingCache();
  }

  // Layer 1: TTL cache hit — serve immediately. This is the hot path:
  // all clients within a 30s window hit this branch and get byte-identical
  // JSON, regardless of which origin (localhost / network IP) they came from.
  const cached = getCachedBriefing();
  if (cached && !force) {
    // Mark the served payload as a cache hit (the cached __meta has cacheHit=false
    // from when it was first computed). We update __meta on the served copy so
    // clients can distinguish "freshly computed" from "served from cache" for
    // diagnostics — without invalidating the cached payload itself.
    const served: BriefingPayload = {
      briefing: cached.briefing,
      __meta: {
        ...cached.__meta,
        cacheHit: true,
        llmCalled: false,
        durationMs: 0,
      },
    };
    return NextResponse.json(served);
  }

  // Gather the raw state ONCE — we need it both for the hash and for the
  // briefing computation. This is the only DB round-trip on a cache miss.
  const [
    agents,
    tasks,
    telemetry,
    payments,
    unreadComms,
    openApprovals,
    criticalFindings,
    recentLogs,
  ] = await Promise.all([
    db.agent.findMany({ select: { codename: true, name: true, status: true, load: true, successRate: true, role: true } }),
    db.task.findMany({ select: { status: true, priority: true, assigneeId: true, assignee: { select: { codename: true } } }, take: 200 }),
    db.telemetry.findMany({ orderBy: { createdAt: 'desc' }, take: 1 }),
    db.payment.groupBy({ by: ['status'], _sum: { amount: true } }),
    db.agentMessage.count({ where: { read: false } }),
    db.approvalRequest.count({ where: { status: 'pending' } }),
    db.agentMonitorFinding.count({ where: { severity: 'critical', status: 'open' } }),
    db.agentLog.findMany({ orderBy: { createdAt: 'desc' }, take: 12, select: { agentId: true, level: true, message: true, createdAt: true, agent: { select: { codename: true } } } }),
  ]);

  // Layer 2: state-hash cache. If the state hasn't changed since the last
  // briefing, we skip the LLM entirely and re-serve the cached briefing.
  // The cached payload's `generatedAt` is updated so clients see a fresh
  // timestamp (proves the server is alive and the cache is being checked).
  const snapshot: BriefingStateSnapshot = {
    agents: agents.map((a) => ({ codename: a.codename, status: a.status, load: a.load, successRate: a.successRate })),
    tasks: tasks.map((t) => ({ status: t.status, priority: t.priority, assigneeId: t.assigneeId })),
    telemetry: telemetry.map((t) => ({ cpu: t.cpu, mem: t.mem, disk: t.disk, latency: t.latency, tokens: t.tokens })),
    payments: payments.map((p) => ({ status: p.status, _sum: { amount: p._sum.amount } })),
    unreadComms,
    openApprovals,
    criticalFindings,
    recentLogs: recentLogs.map((l) => ({ agentId: l.agentId, level: l.level, message: l.message })),
  };
  const stateHash = computeStateHash(snapshot);
  const lastHash = getCachedStateHash();

  // If hashes match AND we have a cached briefing (even if TTL expired),
  // re-serve it with a fresh timestamp. This is the "nothing changed, just
  // refresh the timestamp" path — zero LLM cost.
  if (stateHash === lastHash && !force) {
    const prevCached = getCachedBriefing();
    if (prevCached) {
      const refreshed: BriefingPayload = {
        briefing: prevCached.briefing,
        __meta: {
          ...prevCached.__meta,
          generatedAt: new Date().toISOString(),
          cacheHit: true,
          llmCalled: false,
          durationMs: 0,
        },
      };
      setCachedBriefing(refreshed, stateHash);
      return NextResponse.json(refreshed);
    }
  }

  // Layer 3: single-flight. If another request is already computing the
  // briefing, await its promise instead of starting a second LLM call.
  const skipLlm = false; // hash mismatch (or force) → must call LLM
  const payload = await runSingleFlight(async () => {
    const start = Date.now();
    const briefing = await computeBriefing({
      agents, tasks, telemetry, payments, unreadComms, openApprovals, criticalFindings, recentLogs,
    });
    const result: BriefingPayload = {
      briefing,
      __meta: {
        generatedAt: new Date().toISOString(),
        stateHash,
        cacheHit: false,
        llmCalled: true,
        durationMs: Date.now() - start,
      },
    };
    setCachedBriefing(result, stateHash);
    return result;
  }, skipLlm);

  return NextResponse.json(payload);
}

// ─── Briefing computation (extracted from GET for single-flight use) ──

async function computeBriefing(input: {
  agents: Array<{ codename: string; name: string; status: string; load: number; successRate: number; role: string }>;
  tasks: Array<{ status: string; priority: string; assigneeId: string | null; assignee?: { codename: string } | null }>;
  telemetry: Array<{ cpu: number; mem: number; disk: number; latency: number; tokens: number }>;
  payments: Array<{ status: string; _sum: { amount: number | null } }>;
  unreadComms: number;
  openApprovals: number;
  criticalFindings: number;
  recentLogs: Array<{ agentId: string; level: string; message: string; createdAt: Date; agent?: { codename: string } | null }>;
}): Promise<Briefing> {
  const { agents, tasks, telemetry, payments, unreadComms, openApprovals, criticalFindings, recentLogs } = input;

  // ── Predictive analytics: generate forecasts (best-effort, ~50ms) ──
  // Throttled to once per 5 min via the FleetForecast table timestamp.
  let forecasts: Forecast[] = [];
  try {
    const latest = await db.fleetForecast.findFirst({ orderBy: { generatedAt: 'desc' } });
    const stale = !latest || (Date.now() - latest.generatedAt.getTime() > 5 * 60 * 1000);
    if (stale) {
      forecasts = await generateFleetForecasts();
    } else {
      forecasts = await getLatestForecasts();
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'briefing: forecast generation failed');
  }

  const working = agents.filter((a) => a.status === 'working').length;
  const idle = agents.filter((a) => a.status === 'idle').length;
  const overloaded = agents.filter((a) => a.load > 70).map((a) => a.codename);
  const errorAgents = agents.filter((a) => a.status === 'error').map((a) => a.codename);
  const pending = tasks.filter((t) => t.status === 'pending').length;
  const inProgress = tasks.filter((t) => t.status === 'in_progress').length;
  const blocked = tasks.filter((t) => t.status === 'blocked').length;
  const t = telemetry[0] as any;
  const cpu = Math.round(t?.cpu ?? 0);
  const memPct = Math.max(0, Math.min(100, Math.round(t?.mem ?? 0)));
  const confirmedRev = payments.filter((p) => p.status === 'confirmed').reduce((s, p) => s + (p._sum.amount ?? 0), 0);
  const pendingRev = payments.filter((p) => p.status === 'pending').reduce((s, p) => s + (p._sum.amount ?? 0), 0);
  const avgSuccess = Math.round((agents.reduce((s, a) => s + a.successRate, 0) / (agents.length || 1)) * 10) / 10;

  // ── Heuristic health score (0–100) ────────────────────────────────────
  let health = 100;
  health -= Math.min(30, cpu > 85 ? 30 : cpu > 70 ? 18 : cpu > 55 ? 8 : 0);
  health -= Math.min(20, overloaded.length * 6);
  health -= Math.min(20, errorAgents.length * 12);
  health -= Math.min(15, blocked * 5);
  health -= Math.min(10, criticalFindings * 4);
  health -= Math.min(10, openApprovals * 2);
  health = Math.max(10, Math.round(health));

  // ── Top risks (deterministic, from heuristics) ────────────────────────
  const topRisks: string[] = [];
  if (errorAgents.length) topRisks.push(`${errorAgents.length} agent(s) in error state: ${errorAgents.join(', ')}`);
  if (overloaded.length) topRisks.push(`${overloaded.length} agent(s) over 70% load: ${overloaded.join(', ')}`);
  if (cpu > 85) topRisks.push(`CPU at ${cpu}% — near saturation; throttle non-critical work`);
  if (blocked) topRisks.push(`${blocked} task(s) blocked — may stall the work pipeline`);
  if (criticalFindings) topRisks.push(`${criticalFindings} critical monitor finding(s) open`);
  if (openApprovals) topRisks.push(`${openApprovals} approval request(s) awaiting review`);
  if (pendingRev > 0) topRisks.push(`₹${pendingRev.toLocaleString()} in pending payments — follow up to realize revenue`);
  if (topRisks.length === 0) topRisks.push('No active risks detected — fleet operating within nominal parameters.');

  // ── Deterministic recommendations (always present, fast) ──────────────
  const recs: Recommendation[] = [];
  const idleAgentNames = agents.filter((a) => a.status === 'idle' && a.load < 20).map((a) => a.codename);
  if (pending > 0 && idleAgentNames.length > 0) {
    recs.push({
      title: `Assign ${Math.min(pending, idleAgentNames.length)} pending task(s) to idle agents`,
      rationale: `${pending} tasks are pending while ${idleAgentNames.length} agents are idle (${idleAgentNames.slice(0, 4).join(', ')}${idleAgentNames.length > 4 ? '…' : ''}). Dispatching now maximizes throughput.`,
      priority: pending > 8 ? 'high' : 'medium',
      suggestedAssignee: idleAgentNames[0],
      category: 'capacity',
    });
  }
  if (overloaded.length > 0) {
    recs.push({
      title: `Rebalance load away from ${overloaded.slice(0, 3).join(', ')}`,
      rationale: `${overloaded.length} agent(s) above 70% load risk saturation. Redistribute pending work or scale out.`,
      priority: 'high',
      category: 'performance',
    });
  }
  if (errorAgents.length > 0) {
    recs.push({
      title: `Investigate & restart ${errorAgents.slice(0, 3).join(', ')}`,
      rationale: `${errorAgents.length} agent(s) in error state. Run diagnostics and re-initialize to restore fleet capacity.`,
      priority: 'critical',
      category: 'reliability',
    });
  }
  if (pendingRev > 0) {
    recs.push({
      title: `Follow up ₹${pendingRev.toLocaleString()} in pending payments`,
      rationale: `Pending revenue represents unrealized income. A nudge to payers could convert a portion to confirmed.`,
      priority: 'medium',
      category: 'revenue',
    });
  }
  if (unreadComms > 0) {
    recs.push({
      title: `Triage ${unreadComms} unread inter-agent message(s)`,
      rationale: `Unread comms may contain escalations or handoff requests blocking other agents.`,
      priority: unreadComms > 5 ? 'high' : 'low',
      category: 'ops',
    });
  }

  // ── LLM synthesis: headline + strategic summary + extra recommendations ─
  const contextForLLM = `FLEET SNAPSHOT (live):
- agents: ${agents.length} total, ${working} working, ${idle} idle, ${errorAgents.length} error
- overloaded (>70% load): ${overloaded.join(', ') || 'none'}
- tasks: ${pending} pending, ${inProgress} in_progress, ${blocked} blocked
- unread comms: ${unreadComms}, open approvals: ${openApprovals}, critical findings: ${criticalFindings}
- system: cpu ${cpu}%, mem ${memPct}%, avg success ${avgSuccess}%
- revenue: ₹${confirmedRev} confirmed, ₹${pendingRev} pending
- health score: ${health}/100
- recent logs: ${recentLogs.map((l) => `[${l.agent?.codename ?? '?'}:${l.level}] ${l.message}`).join(' | ').slice(0, 800)}`;

  let headline = health >= 85 ? 'Fleet nominal — operating at peak efficiency' : health >= 60 ? 'Fleet stable with attention areas' : 'Fleet degraded — immediate action advised';
  let summary = `ARIA is coordinating ${agents.length} agents across ${pending + inProgress} active work items. Health score is ${health}/100. ${topRisks[0]}`;
  let llmRecs: Recommendation[] = [];

  try {
    const sys = `You are ARIA, the autonomous mission-control AI for an AI company. Given the live fleet snapshot, produce:
1. A crisp HEADLINE (max 14 words) summarizing the company's current operational state.
2. A strategic SUMMARY (2-3 sentences, max 60 words) of what matters most right now.
3. Up to 3 additional RECOMMENDATIONS the operator should act on (beyond the obvious ones already captured).

Respond as STRICT JSON: {"headline": string, "summary": string, "recommendations": [{"title": string, "rationale": string, "priority": "critical"|"high"|"medium"|"low", "category": "performance"|"revenue"|"reliability"|"capacity"|"knowledge"|"ops", "suggestedAssignee"?: string}]}
No markdown, no prose outside the JSON.`;
    const raw = await quickChat(`${contextForLLM}\n\nProduce the JSON briefing now.`, sys);
    const json = extractJson(raw);
    if (json) {
      if (typeof json.headline === 'string' && json.headline.trim()) headline = json.headline.trim().slice(0, 140);
      if (typeof json.summary === 'string' && json.summary.trim()) summary = json.summary.trim().slice(0, 600);
      if (Array.isArray(json.recommendations)) {
        llmRecs = json.recommendations
          .filter((r: any) => r && typeof r.title === 'string')
          .slice(0, 3)
          .map((r: any) => ({
            title: String(r.title).slice(0, 200),
            rationale: String(r.rationale ?? '').slice(0, 400),
            priority: (['critical', 'high', 'medium', 'low'].includes(r.priority) ? r.priority : 'medium') as Recommendation['priority'],
            category: (['performance', 'revenue', 'reliability', 'capacity', 'knowledge', 'ops'].includes(r.category) ? r.category : 'ops') as Recommendation['category'],
            suggestedAssignee: typeof r.suggestedAssignee === 'string' ? r.suggestedAssignee.slice(0, 40) : undefined,
          }));
      }
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'briefing: LLM synthesis failed, using heuristics');
  }

  // Merge LLM recs (dedup by title prefix) after heuristic recs.
  const seen = new Set(recs.map((r) => r.title.slice(0, 30).toLowerCase()));
  for (const r of llmRecs) {
    const key = r.title.slice(0, 30).toLowerCase();
    if (!seen.has(key)) { recs.push(r); seen.add(key); }
  }
  const prioRank = { critical: 0, high: 1, medium: 2, low: 3 };
  recs.sort((a, b) => prioRank[a.priority] - prioRank[b.priority]);

  // ── Predictive recommendations (from forecasts) ──────────────────────
  const fleetLoadFc = forecasts.find((f) => f.metric === 'fleet-load');
  if (fleetLoadFc && fleetLoadFc.riskLevel === 'critical' && fleetLoadFc.forecast > 85) {
    recs.push({
      title: `Pre-emptive scale-out: fleet load forecast to hit ${Math.round(fleetLoadFc.forecast)}% in 1h`,
      rationale: `Predictive analytics indicates fleet load will exceed 85% within the hour (current ${Math.round(fleetLoadFc.current)}%, trend ${fleetLoadFc.trend}, confidence ${Math.round(fleetLoadFc.confidence * 100)}%). Scale out or shed non-critical work now to avoid saturation.`,
      priority: 'critical',
      category: 'performance',
    });
  }
  const errorFc = forecasts.find((f) => f.metric === 'error-rate');
  if (errorFc && errorFc.riskLevel === 'high' && errorFc.trend === 'up') {
    recs.push({
      title: `Error rate trending up — forecast ${Math.round(errorFc.forecast)}% in 1h`,
      rationale: `Error rate is climbing (current ${Math.round(errorFc.current)}%, forecast ${Math.round(errorFc.forecast)}%). Investigate recent agent logs for the root cause before it cascades.`,
      priority: 'high',
      category: 'reliability',
    });
  }
  const revFc = forecasts.find((f) => f.metric === 'revenue');
  if (revFc && revFc.trend === 'down') {
    recs.push({
      title: `Revenue forecast declining — projected ₹${Math.round(revFc.forecast)}/day next week`,
      rationale: `7-day revenue trend is downward (current ₹${Math.round(revFc.current)}/day, forecast ₹${Math.round(revFc.forecast)}/day). Activate outreach or follow up on pending payments to reverse the trend.`,
      priority: 'medium',
      category: 'revenue',
    });
  }

  // Re-sort with predictive recs included.
  const prioRank2 = { critical: 0, high: 1, medium: 2, low: 3 };
  recs.sort((a, b) => prioRank2[a.priority] - prioRank2[b.priority]);

  const briefing: Briefing = {
    generatedAt: new Date().toISOString(),
    headline,
    healthScore: health,
    summary,
    metrics: {
      agents: agents.length,
      activeAgents: working,
      overloadedAgents: overloaded,
      idleAgents: idle,
      pendingTasks: pending,
      inProgressTasks: inProgress,
      blockedTasks: blocked,
      unreadComms,
      openApprovals,
      criticalFindings,
      cpu,
      memPct,
      confirmedRevenue: confirmedRev,
      pendingRevenue: pendingRev,
      successRate: avgSuccess,
    },
    topRisks,
    recommendations: recs.slice(0, 10),
    forecasts,
  };

  // Persist the latest briefing to memory (best-effort).
  try {
    await db.memoryItem.upsert({
      where: { key_scope: { key: 'latest-briefing', scope: 'system' } },
      update: { value: JSON.stringify({ headline, health, summary, generatedAt: briefing.generatedAt }) },
      create: { key: 'latest-briefing', scope: 'system', value: JSON.stringify({ headline, health, summary, generatedAt: briefing.generatedAt }), pinned: true },
    });
  } catch { /* memoryItem unique constraint shape may vary; ignore */ }

  // Record an ActionLog entry for the Decision Log (throttled — only when health
  // changes or every ~10 min, to avoid flooding). We compare against the last
  // briefing's health stored in memory.
  try {
    const last = await db.actionLog.findFirst({ where: { action: 'briefing.generated' }, orderBy: { createdAt: 'desc' } });
    const lastHealth = last ? (JSON.parse(last.meta || '{}').health ?? null) : null;
    const stale = !last || (Date.now() - last.createdAt.getTime() > 10 * 60 * 1000);
    if (stale || lastHealth !== health) {
      await db.actionLog.create({
        data: {
          actor: 'aria',
          action: 'briefing.generated',
          category: 'autonomous',
          afterState: headline.slice(0, 300),
          reversible: false,
          meta: JSON.stringify({ health, headline: headline.slice(0, 140), recommendationCount: briefing.recommendations.length, topRisk: topRisks[0]?.slice(0, 120) }),
        },
      });
    }
  } catch { /* ignore */ }

  return briefing;
}

function extractJson(text: string): any | null {
  if (!text) return null;
  let s = text.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) return null;
  try {
    return JSON.parse(s.slice(start, end + 1));
  } catch {
    return null;
  }
}
