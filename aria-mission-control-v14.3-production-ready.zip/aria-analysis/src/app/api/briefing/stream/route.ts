import { NextRequest } from 'next/server';
import { onEvent } from '@/lib/event-bus';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * GET /api/briefing/stream
 *
 * Server-Sent Events (SSE) stream that pushes a notification every time the
 * briefing is recomputed on the server. Clients subscribe to this instead
 * of polling /api/briefing every 30s — they get sub-second updates with
 * zero wasted requests.
 *
 * Protocol:
 *   event: ping
 *   data: {"t":"2026-07-24T..."}
 *
 *   event: briefing:updated
 *   data: {"generatedAt":"...","stateHash":"abc12345","cacheHit":false}
 *
 *   event: briefing:invalidated
 *   data: {"at":"2026-07-24T..."}
 *
 * The client receives the event, then issues a one-shot GET /api/briefing
 * to fetch the fresh payload (which will be a cache hit, so no LLM cost).
 * We don't push the full payload over SSE because:
 *   1. SSE has no per-message backpressure — large payloads could buffer.
 *   2. New subscribers would miss the initial payload anyway and need a
 *      one-shot fetch, so we keep the model uniform.
 *
 * The connection auto-pings every 25s to keep the stream alive through
 * proxies that close idle connections.
 */
export async function GET(req: NextRequest) {
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      let closed = false;
      const safeEnqueue = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      // Initial hello — also serves as the SSE protocol validation.
      safeEnqueue(`event: ping\ndata: ${JSON.stringify({ t: new Date().toISOString(), hello: true })}\n\n`);

      // Subscribe to briefing events.
      const offUpdated = onEvent('briefing:updated', (payload) => {
        const meta = (payload as { __meta?: { generatedAt?: string; stateHash?: string; cacheHit?: boolean } })?.__meta ?? {};
        safeEnqueue(
          `event: briefing:updated\ndata: ${JSON.stringify({
            generatedAt: meta.generatedAt ?? new Date().toISOString(),
            stateHash: meta.stateHash ?? '',
            cacheHit: meta.cacheHit ?? false,
          })}\n\n`,
        );
      });

      const offInvalidated = onEvent('briefing:invalidated', (payload) => {
        safeEnqueue(
          `event: briefing:invalidated\ndata: ${JSON.stringify(payload ?? {})}\n\n`,
        );
      });

      // Heartbeat — keeps the connection alive through idle-killing proxies.
      const pingTimer = setInterval(() => {
        safeEnqueue(`event: ping\ndata: ${JSON.stringify({ t: new Date().toISOString() })}\n\n`);
      }, 25_000);

      // Clean up on client disconnect.
      const cleanup = () => {
        if (closed) return;
        closed = true;
        try { offUpdated(); } catch { /* ignore */ }
        try { offInvalidated(); } catch { /* ignore */ }
        try { clearInterval(pingTimer); } catch { /* ignore */ }
        try { controller.close(); } catch { /* already closed */ }
      };

      // req.signal is the AbortSignal fired when the client disconnects.
      if (req.signal) {
        if (req.signal.aborted) cleanup();
        else req.signal.addEventListener('abort', cleanup, { once: true });
      }

      // Safety net — also clean up after 10 minutes (clients reconnect).
      setTimeout(cleanup, 10 * 60 * 1000).unref?.();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      // Disable Next.js buffering — critical for SSE to work.
      'X-Accel-Buffering': 'no',
    },
  });
}
