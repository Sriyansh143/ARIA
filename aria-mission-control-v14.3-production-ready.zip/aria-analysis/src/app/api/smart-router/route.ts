import { NextRequest, NextResponse } from 'next/server';
import {
  recommendModel, detectTaskType, getModelStatsByTask,
  proactiveRoute, getConfiguredProviders, type TaskType,
} from '@/lib/smart-model-router';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — model stats by task type + configured providers (v11 enhancement)
export async function GET() {
  const [stats, providers] = await Promise.all([
    getModelStatsByTask(),
    Promise.resolve(getConfiguredProviders()),
  ]);
  const configuredCount = providers.filter((p) => p.configured).length;
  return NextResponse.json({
    taskTypeStats: stats,
    totalModels: Object.values(stats).reduce((a, b) => a + b, 0),
    configuredProviders: providers,
    configuredProviderCount: configuredCount,
  });
}

// POST — recommend best model for a task.
// ?proactive=1 uses the rate-limit-resilient proactive router (spreads load across providers).
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { prompt, taskType } = body as { prompt?: string; taskType?: TaskType };
  const proactive = req.nextUrl.searchParams.get('proactive') === '1';

  let tt: TaskType;
  if (taskType) {
    tt = taskType;
  } else if (prompt) {
    tt = detectTaskType(prompt);
  } else {
    return NextResponse.json({ error: 'Provide either prompt or taskType' }, { status: 400 });
  }

  if (proactive) {
    const recommendation = await proactiveRoute(tt);
    return NextResponse.json({
      taskType: tt,
      detectedFromPrompt: !taskType && !!prompt,
      recommendation,
      proactive: true,
    });
  }

  const recommendation = await recommendModel(tt);
  return NextResponse.json({
    taskType: tt,
    detectedFromPrompt: !taskType && !!prompt,
    recommendation,
    proactive: false,
  });
}
