import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get('status');
  const project = req.nextUrl.searchParams.get('project');
  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  // Task 2-c (Teamly PMS) — filter by project. "unassigned" → empty string.
  if (project === 'unassigned') where.project = '';
  else if (project) where.project = project;
  const tasks = await db.task.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { assignee: { select: { codename: true, name: true } } },
  });
  return NextResponse.json({ tasks });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { title, description, priority, assigneeId, tags, project } = body;
  // Validate title — non-empty string within max length.
  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    return NextResponse.json({ error: 'title required' }, { status: 400 });
  }
  if (title.length > 500) {
    return NextResponse.json({ error: 'title must be 500 characters or fewer' }, { status: 400 });
  }
  if (description != null && typeof description === 'string' && description.length > 5000) {
    return NextResponse.json({ error: 'description must be 5000 characters or fewer' }, { status: 400 });
  }
  // Validate priority against allowed enum (prevents prototype pollution + invalid values).
  const ALLOWED_PRIORITIES = new Set(['low', 'medium', 'high', 'critical']);
  const resolvedPriority = typeof priority === 'string' && ALLOWED_PRIORITIES.has(priority) ? priority : 'medium';
  // Validate tags is an array of strings (reject objects, prototypes).
  const sanitizedTags = Array.isArray(tags) ? tags.filter((t) => typeof t === 'string').slice(0, 20) : [];
  // Validate project is a string.
  const sanitizedProject = typeof project === 'string' ? project.slice(0, 100) : '';
  // Validate assigneeId is a string if provided.
  const sanitizedAssigneeId = typeof assigneeId === 'string' && assigneeId.length > 0 ? assigneeId : null;
  const task = await db.task.create({
    data: {
      title: title.trim(),
      description: typeof description === 'string' ? description : null,
      priority: resolvedPriority,
      assigneeId: sanitizedAssigneeId,
      tags: JSON.stringify(sanitizedTags),
      project: sanitizedProject,
    },
  });
  return NextResponse.json({ task });
}
