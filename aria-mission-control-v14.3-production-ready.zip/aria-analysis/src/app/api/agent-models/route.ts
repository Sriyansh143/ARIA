import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { seedAgentModelAssignments, resolveAgentModel } from '@/lib/agent-model-resolver';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — list all per-agent model assignments (model diversity view).
export async function GET(req: NextRequest) {
  const includeAgents = req.nextUrl.searchParams.get('includeAgents') === '1';
  const assignments = await db.agentModelAssignment.findMany({
    orderBy: { agentCodename: 'asc' },
  });
  let agents: Array<{ codename: string; name: string; role: string; status: string }> = [];
  if (includeAgents) {
    agents = await db.agent.findMany({
      select: { codename: true, name: true, role: true, status: true },
      orderBy: { codename: 'asc' },
    });
  }
  // Tally model diversity
  const byModel: Record<string, number> = {};
  const byProvider: Record<string, number> = {};
  for (const a of assignments) {
    byModel[a.modelId] = (byModel[a.modelId] ?? 0) + 1;
    byProvider[a.providerKey] = (byProvider[a.providerKey] ?? 0) + 1;
  }
  return NextResponse.json({
    assignments,
    agents,
    diversity: {
      uniqueModels: Object.keys(byModel).length,
      uniqueProviders: Object.keys(byProvider).length,
      byModel,
      byProvider,
    },
  });
}

// POST — seed role-based model assignments for all agents (idempotent),
// or pin a specific agent to a model.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = (body as { action?: string }).action;

  if (action === 'seed') {
    const result = await seedAgentModelAssignments();
    return NextResponse.json({ ok: true, ...result });
  }

  if (action === 'pin') {
    const { agentCodename, modelId, providerKey, reason } = body as {
      agentCodename: string; modelId: string; providerKey: string; reason?: string;
    };
    if (!agentCodename || !modelId || !providerKey) {
      return NextResponse.json({ error: 'agentCodename, modelId, providerKey required' }, { status: 400 });
    }
    const updated = await db.agentModelAssignment.upsert({
      where: { agentCodename },
      update: { modelId, providerKey, taskRouting: 'pinned', reason: reason ?? 'Manually pinned', enabled: true },
      create: { agentCodename, modelId, providerKey, taskRouting: 'pinned', reason: reason ?? 'Manually pinned' },
    });
    return NextResponse.json({ ok: true, assignment: updated });
  }

  if (action === 'resolve') {
    const { agentCodename, role } = body as { agentCodename: string; role?: string };
    const resolved = await resolveAgentModel(agentCodename, role);
    return NextResponse.json({ ok: true, resolved });
  }

  return NextResponse.json({ error: 'unknown action. Use action=seed|pin|resolve' }, { status: 400 });
}
