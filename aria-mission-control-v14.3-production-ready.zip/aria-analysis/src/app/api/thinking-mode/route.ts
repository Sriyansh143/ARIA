import { NextRequest, NextResponse } from 'next/server';
import { getGlobalThinkingMode, setGlobalThinkingMode } from '@/lib/llm';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — current global thinking mode state.
export async function GET() {
  return NextResponse.json({ enabled: getGlobalThinkingMode() });
}

// POST — toggle global thinking mode. Body: { enabled: boolean }
// When ON (default), every LLM call uses extended reasoning.
// When OFF, only complex tasks (reasoning/plan/code/research/vision) get thinking.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const enabled = Boolean(body.enabled);
  setGlobalThinkingMode(enabled);
  return NextResponse.json({ enabled: getGlobalThinkingMode() });
}
