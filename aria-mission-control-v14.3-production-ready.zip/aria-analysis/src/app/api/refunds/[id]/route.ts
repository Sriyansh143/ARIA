import { NextRequest, NextResponse } from 'next/server';
import { processRefund, rejectRefund } from '@/lib/refund-system';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { action, reviewer, reviewNote, gatewayRef } = await req.json().catch(() => ({}));
  if (!action || !reviewer) return NextResponse.json({ error: 'action and reviewer required' }, { status: 400 });
  if (action === 'process') return NextResponse.json(await processRefund(id, reviewer, gatewayRef));
  if (action === 'reject') return NextResponse.json(await rejectRefund(id, reviewer, reviewNote ?? ''));
  return NextResponse.json({ error: 'action must be process|reject' }, { status: 400 });
}
