import { NextRequest, NextResponse } from 'next/server';
import { createRefund, listRefunds, getRefundStats } from '@/lib/refund-system';
import { sanitizeString, sanitizeNumber } from '@/lib/sanitize';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  if (req.nextUrl.searchParams.get('stats') === '1') return NextResponse.json(await getRefundStats());
  const status = req.nextUrl.searchParams.get('status') ?? undefined;
  const paymentId = req.nextUrl.searchParams.get('paymentId') ?? undefined;
  return NextResponse.json({ refunds: await listRefunds({ status, paymentId }) });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));

  // ── Required: paymentId (string, max 100) ──
  const paymentId = sanitizeString((body as { paymentId?: unknown }).paymentId, 100);
  if (!paymentId) {
    return NextResponse.json(
      { error: 'paymentId required (non-empty string, max 100 chars)' },
      { status: 400 },
    );
  }

  // ── Required: amount (finite, > 0) ──
  const amount = sanitizeNumber((body as { amount?: unknown }).amount, { min: 0.01 });
  if (amount === null) {
    return NextResponse.json(
      { error: 'amount must be a positive, finite number' },
      { status: 400 },
    );
  }

  // ── Required: reason (string, max 500) ──
  const reason = sanitizeString((body as { reason?: unknown }).reason, 500);
  if (!reason) {
    return NextResponse.json(
      { error: 'reason required (non-empty string, max 500 chars)' },
      { status: 400 },
    );
  }

  // ── Optional: reasonNote (string, max 2000) ──
  let reasonNote: string | undefined;
  const rawNote = (body as { reasonNote?: unknown }).reasonNote;
  if (rawNote != null) {
    reasonNote = sanitizeString(rawNote, 2000) ?? undefined;
    if (reasonNote === undefined) {
      return NextResponse.json(
        { error: 'reasonNote must be a non-empty string (max 2000 chars)' },
        { status: 400 },
      );
    }
  }

  // ── Optional: requestedBy (string, max 100) — preserved from old behavior ──
  let requestedBy: string | undefined;
  const rawBy = (body as { requestedBy?: unknown }).requestedBy;
  if (rawBy != null) {
    requestedBy = sanitizeString(rawBy, 100) ?? undefined;
    if (requestedBy === undefined) {
      return NextResponse.json(
        { error: 'requestedBy must be a non-empty string (max 100 chars)' },
        { status: 400 },
      );
    }
  }

  const result = await createRefund({
    paymentId,
    amount,
    reason,
    reasonNote,
    requestedBy,
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json(result);
}
