import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — embedding cache stats
export async function GET() {
  return NextResponse.json({ size: 0, max: 10000, hits: 0, misses: 0, hitRate: 'n/a' });
}
