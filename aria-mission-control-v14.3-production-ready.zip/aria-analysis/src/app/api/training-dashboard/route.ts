import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/training-dashboard — aggregates the agent training lifecycle.
 *
 * Returns:
 *  - summary: total skills trained, agents with training, avg proficiency,
 *    agents on cooldown, agents ready to retrain, total training runs.
 *  - agents: per-agent training profile (skill count, avg proficiency, last
 *    trained, on-cooldown count, best proficiency).
 *  - recentTraining: the most recent training events (sorted by lastTrainedAt).
 *  - cooldowns: skills currently on cooldown (with cooldownUntil + proficiency).
 *  - readyToRetrain: skills whose cooldown has expired AND proficiency < mastery.
 */
export async function GET(req: NextRequest) {
  const now = new Date();
  const all = await db.skillLearning.findMany({
    orderBy: { lastTrainedAt: 'desc' },
    take: 500,
  });

  const MASTERY = 80;
  const total = all.length;
  const agentsSet = new Set(all.map((r) => r.agentCodename));
  const avgProficiency = total > 0 ? Math.round(all.reduce((s, r) => s + r.proficiency, 0) / total) : 0;
  const onCooldown = all.filter((r) => r.cooldownUntil && r.cooldownUntil > now);
  const readyToRetrain = all.filter(
    (r) => (!r.cooldownUntil || r.cooldownUntil <= now) && r.proficiency < MASTERY && r.proficiency > 0,
  );
  const totalTrainingRuns = all.reduce((s, r) => s + (r.trainingCount ?? 0), 0);
  const mastered = all.filter((r) => r.proficiency >= MASTERY).length;

  // Per-agent profile.
  const agentMap = new Map<string, {
    agentCodename: string;
    skillCount: number;
    avgProficiency: number;
    bestProficiency: number;
    lastTrainedAt: Date | null;
    onCooldownCount: number;
    totalTrainingRuns: number;
    masteredCount: number;
  }>();
  for (const r of all) {
    const cur = agentMap.get(r.agentCodename) ?? {
      agentCodename: r.agentCodename,
      skillCount: 0,
      avgProficiency: 0,
      bestProficiency: 0,
      lastTrainedAt: null as Date | null,
      onCooldownCount: 0,
      totalTrainingRuns: 0,
      masteredCount: 0,
    };
    cur.skillCount++;
    cur.avgProficiency += r.proficiency;
    cur.bestProficiency = Math.max(cur.bestProficiency, r.bestProficiency ?? r.proficiency);
    if (r.lastTrainedAt && (!cur.lastTrainedAt || r.lastTrainedAt > cur.lastTrainedAt)) {
      cur.lastTrainedAt = r.lastTrainedAt;
    }
    if (r.cooldownUntil && r.cooldownUntil > now) cur.onCooldownCount++;
    cur.totalTrainingRuns += r.trainingCount ?? 0;
    if (r.proficiency >= MASTERY) cur.masteredCount++;
    agentMap.set(r.agentCodename, cur);
  }
  const agents = Array.from(agentMap.values()).map((a) => ({
    ...a,
    avgProficiency: a.skillCount > 0 ? Math.round(a.avgProficiency / a.skillCount) : 0,
  })).sort((a, b) => b.avgProficiency - a.avgProficiency);

  // Recent training events (last 20 by lastTrainedAt).
  const recentTraining = all
    .filter((r) => r.lastTrainedAt)
    .slice(0, 20)
    .map((r) => ({
      agentCodename: r.agentCodename,
      skillKey: r.skillKey,
      proficiency: r.proficiency,
      preProficiency: r.preProficiency,
      bestProficiency: r.bestProficiency,
      trainingCount: r.trainingCount,
      lastTrainedAt: r.lastTrainedAt,
      cooldownUntil: r.cooldownUntil,
      lastRunSuccess: r.lastRunSuccess,
      learnedFrom: r.learnedFrom,
      improvement: r.proficiency - r.preProficiency,
      onCooldown: r.cooldownUntil ? r.cooldownUntil > now : false,
    }));

  // Skills currently on cooldown.
  const cooldowns = onCooldown
    .map((r) => ({
      agentCodename: r.agentCodename,
      skillKey: r.skillKey,
      proficiency: r.proficiency,
      cooldownUntil: r.cooldownUntil,
      lastTrainedAt: r.lastTrainedAt,
      trainingCount: r.trainingCount,
    }))
    .sort((a, b) => (a.cooldownUntil!.getTime() - b.cooldownUntil!.getTime()));

  return NextResponse.json({
    summary: {
      total,
      agentsWithTraining: agentsSet.size,
      avgProficiency,
      mastered,
      onCooldown: onCooldown.length,
      readyToRetrain: readyToRetrain.length,
      totalTrainingRuns,
    },
    agents,
    recentTraining,
    cooldowns,
    readyToRetrain: readyToRetrain.map((r) => ({
      agentCodename: r.agentCodename,
      skillKey: r.skillKey,
      proficiency: r.proficiency,
      lastTrainedAt: r.lastTrainedAt,
      trainingCount: r.trainingCount,
    })),
  });
}
