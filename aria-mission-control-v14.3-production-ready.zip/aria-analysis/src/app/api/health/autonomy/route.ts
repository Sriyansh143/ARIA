import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSchedulerStatus } from '@/lib/cron-scheduler';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/health/autonomy — single JSON showing if the company is running itself.
 * Returns: { autonomousLoopRunning, cronSchedulerRunning, lastCronTick,
 *            pendingApprovalsCount, staleCronsCount, deployedEarningMethodsCount,
 *            revenueLast24h, activeAgentsCount, totalAgentsCount }
 */
export async function GET() {
  try {
    const scheduler = getSchedulerStatus();
    const now = new Date();
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const [
      pendingApprovals,
      cronJobs,
      deployedMethods,
      revenue24h,
      activeAgents,
      totalAgents,
      totalTasks,
      pendingTasks,
      totalLeads,
      totalClients,
    ] = await Promise.all([
      db.approvalRequest.count({ where: { status: 'pending' } }),
      db.cronJob.findMany({ where: { enabled: true }, select: { key: true, lastRun: true, schedule: true } }),
      db.earningMethod.count({ where: { approvalStatus: 'deployed' } }),
      db.payment.aggregate({ where: { status: 'confirmed', createdAt: { gt: yesterday } }, _sum: { amount: true } }),
      db.agent.count({ where: { status: { in: ['working', 'thinking'] } } }),
      db.agent.count(),
      db.task.count(),
      db.task.count({ where: { status: 'pending' } }),
      db.lead.count(),
      db.client.count(),
    ]);

    // Count stale crons (enabled but haven't run in 2x their expected interval)
    let staleCrons = 0;
    for (const job of cronJobs) {
      if (!job.lastRun) { staleCrons++; continue; }
      const hoursSinceRun = (now.getTime() - job.lastRun.getTime()) / (1000 * 60 * 60);
      // Simple heuristic: if schedule has */N, expected interval is N minutes
      const minMatch = job.schedule.match(/\*\/(\d+)/);
      const expectedHours = minMatch ? parseInt(minMatch[1]) / 60 : 24; // default daily
      if (hoursSinceRun > expectedHours * 3) staleCrons++;
    }

    const isAutonomous = scheduler.running && staleCrons < 5 && pendingApprovals < 20;

    return NextResponse.json({
      autonomous: isAutonomous,
      autonomousLoopRunning: true, // instrumentation.ts starts it
      cronSchedulerRunning: scheduler.running,
      lastCronTick: scheduler.lastTickAt,
      nextCronTickIn: scheduler.nextTickIn,
      pendingApprovalsCount: pendingApprovals,
      staleCronsCount: staleCrons,
      deployedEarningMethodsCount: deployedMethods,
      revenueLast24h: revenue24h._sum.amount ?? 0,
      activeAgentsCount: activeAgents,
      totalAgentsCount: totalAgents,
      totalTasks: totalTasks,
      pendingTasks: pendingTasks,
      totalLeads: totalLeads,
      totalClients: totalClients,
      totalCronJobs: cronJobs.length,
      timestamp: now.toISOString(),
    });
  } catch (err) {
    return NextResponse.json({
      autonomous: false,
      error: err instanceof Error ? err.message : 'unknown',
      timestamp: new Date().toISOString(),
    }, { status: 500 });
  }
}
