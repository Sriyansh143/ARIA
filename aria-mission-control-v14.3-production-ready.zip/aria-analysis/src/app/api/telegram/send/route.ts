import { NextRequest, NextResponse } from 'next/server';
import { sendToOwner, sendApprovalRequest } from '@/lib/telegram-bot';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — send a message or approval request via Telegram
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { message, title, description, approvalId, type } = body as {
    message?: string;
    title?: string;
    description?: string;
    approvalId?: string;
    type?: 'message' | 'approval';
  };

  if (type === 'approval' && title && description && approvalId) {
    const ok = await sendApprovalRequest(title, description, approvalId);
    return NextResponse.json({ ok });
  }

  if (message) {
    const ok = await sendToOwner(message);
    return NextResponse.json({ ok });
  }

  return NextResponse.json({ error: 'Provide message or approval fields' }, { status: 400 });
}
