import { NextRequest, NextResponse } from 'next/server';
import { handleTelegramUpdate } from '@/lib/telegram-bot';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — receive Telegram webhook updates
export async function POST(req: NextRequest) {
  const update = await req.json().catch(() => ({}));
  const result = await handleTelegramUpdate(update);
  return NextResponse.json(result);
}

// GET — webhook status check
export async function GET() {
  return NextResponse.json({ status: 'active', configured: !!process.env.TELEGRAM_BOT_TOKEN });
}
