import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * PATCH /api/skills/[key]
 *
 * Toggle a skill's enabled status or update its config.
 * Body: { enabled?: boolean, config?: object }
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ key: string }> },
) {
  try {
    const { key } = await params;
    const body = await req.json().catch(() => ({}));
    const { enabled, config } = body as { enabled?: boolean; config?: Record<string, unknown> };

    const data: Record<string, unknown> = {};
    if (typeof enabled === 'boolean') data.enabled = enabled;
    if (config !== undefined) data.config = JSON.stringify(config);

    const updated = await db.skill.update({
      where: { key },
      data,
    });
    return NextResponse.json({ skill: updated });
  } catch (err) {
    console.error('[api/skills/[key]] PATCH failed:', err);
    return NextResponse.json(
      { error: 'Failed to update skill' },
      { status: 500 },
    );
  }
}

/**
 * POST /api/skills/[key]
 *
 * Run a skill (increment the run count + return the skill details).
 * The actual skill execution happens via /api/agent-exec or /api/code-exec.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ key: string }> },
) {
  try {
    const { key } = await params;
    const skill = await db.skill.update({
      where: { key },
      data: { runs: { increment: 1 } },
    });
    return NextResponse.json({ skill, ok: true });
  } catch (err) {
    console.error('[api/skills/[key]] POST failed:', err);
    return NextResponse.json(
      { error: 'Failed to run skill' },
      { status: 500 },
    );
  }
}
