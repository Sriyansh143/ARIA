import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * GET /api/skills
 *
 * Returns the skill catalog (all skills from the Skill table).
 * The SkillsTab component calls this endpoint to render the 65-skill grid.
 *
 * Previously this route was missing — the SkillsTab was half-wired (it
 * called /api/skills but no route existed, resulting in a 404). This
 * route fixes that gap.
 */
export async function GET() {
  try {
    const skills = await db.skill.findMany({
      orderBy: { category: 'asc' },
    });
    return NextResponse.json({ skills });
  } catch (err) {
    console.error('[api/skills] GET failed:', err);
    return NextResponse.json(
      { error: 'Failed to fetch skills', skills: [] },
      { status: 500 },
    );
  }
}
