import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/comms/graph — aggregated inter-agent message flows for the collaboration graph.
// Returns nodes (agents) + edges (message flows) with counts + last-message time.
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 500), 2000);

  const messages = await db.agentMessage.findMany({
    orderBy: { createdAt: 'desc' },
    take: limit,
    select: { fromAgent: true, toAgent: true, priority: true, thread: true, read: true, createdAt: true },
  });

  // Aggregate edges: from→to with count + lastAt + priority breakdown
  const edgeMap = new Map<string, { from: string; to: string; count: number; lastAt: Date; urgent: number; high: number; normal: number }>();
  const nodeSet = new Set<string>();

  for (const m of messages) {
    const from = m.fromAgent;
    const to = m.toAgent === 'BROADCAST' ? 'BROADCAST' : m.toAgent;
    nodeSet.add(from);
    nodeSet.add(to);
    const key = `${from}→${to}`;
    const existing = edgeMap.get(key);
    if (existing) {
      existing.count += 1;
      if (m.createdAt > existing.lastAt) existing.lastAt = m.createdAt;
      if (m.priority === 'urgent') existing.urgent += 1;
      else if (m.priority === 'high') existing.high += 1;
      else existing.normal += 1;
    } else {
      edgeMap.set(key, {
        from, to, count: 1, lastAt: m.createdAt,
        urgent: m.priority === 'urgent' ? 1 : 0,
        high: m.priority === 'high' ? 1 : 0,
        normal: m.priority === 'normal' ? 1 : 0,
      });
    }
  }

  // Nodes: agent codename + total sent/received counts
  const sentCount = new Map<string, number>();
  const recvCount = new Map<string, number>();
  for (const m of messages) {
    sentCount.set(m.fromAgent, (sentCount.get(m.fromAgent) ?? 0) + 1);
    const to = m.toAgent === 'BROADCAST' ? 'BROADCAST' : m.toAgent;
    recvCount.set(to, (recvCount.get(to) ?? 0) + 1);
  }

  const nodes = Array.from(nodeSet).map((id) => {
    const sent = sentCount.get(id) ?? 0;
    const received = recvCount.get(id) ?? 0;
    const total = sent + received;
    return {
      id,
      sent,
      received,
      total,
      size: Math.max(12, Math.min(40, 12 + total * 2)),
    };
  }).sort((a, b) => b.total - a.total);

  const edges = Array.from(edgeMap.values()).map((e) => ({
    ...e,
    lastAt: e.lastAt.toISOString(),
    weight: Math.max(1, Math.min(8, Math.sqrt(e.count))),
  })).sort((a, b) => b.count - a.count);

  // Stats
  const stats = {
    totalMessages: messages.length,
    totalEdges: edges.length,
    totalNodes: nodes.length,
    broadcasts: messages.filter((m) => m.toAgent === 'BROADCAST').length,
    urgent: messages.filter((m) => m.priority === 'urgent').length,
    high: messages.filter((m) => m.priority === 'high').length,
    unread: messages.filter((m) => !m.read).length,
    topTalkers: nodes.slice(0, 5).map((n) => ({ agent: n.id, total: n.total })),
    busiestEdge: edges[0] ?? null,
  };

  return NextResponse.json({ nodes, edges, stats });
}
