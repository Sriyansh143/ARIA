import { NextRequest, NextResponse } from 'next/server';
import { logRequestAsGoal } from '@/lib/request-logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// POST /api/request-log — log a user request as a Goal (Rule 62).
// Body: { request: string, source?: string }
// Returns: { logged: boolean, key?: string, created?: boolean }
//
// This endpoint is called by the chat API (and any other entry point) to
// ensure every user request is recorded as an auditable Goal.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { request, source } = body as { request?: string; source?: string };
  if (!request || !request.trim()) {
    return NextResponse.json({ error: 'request required' }, { status: 400 });
  }
  try {
    const result = await logRequestAsGoal(request, source ?? 'api');
    return NextResponse.json({ logged: result != null, key: result?.key, created: result?.created });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'unknown error';
    return NextResponse.json({ error: msg, logged: false }, { status: 500 });
  }
}
