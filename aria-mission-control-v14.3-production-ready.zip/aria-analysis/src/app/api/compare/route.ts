import { NextRequest, NextResponse } from 'next/server';
import { quickChat } from '@/lib/llm';
import { withProScaffold } from '@/lib/pro-scaffold';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface CompareResponse {
  model: string;
  content: string;
  latencyMs: number;
  error: string | null;
}

/**
 * POST /api/compare — A/B/C/D model comparison.
 * Sends the same prompt to 2-4 models in parallel and returns
 * structured per-model results for side-by-side display.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body?.prompt || typeof body.prompt !== 'string') {
    return NextResponse.json({ error: 'prompt is required' }, { status: 400 });
  }
  if (!Array.isArray(body.models) || body.models.length < 2 || body.models.length > 4) {
    return NextResponse.json({ error: 'models must be an array of 2-4 model IDs' }, { status: 400 });
  }

  const prompt = body.prompt as string;
  const systemPrompt = typeof body.systemPrompt === 'string' ? body.systemPrompt : undefined;
  const models = Array.from(new Set(body.models as string[]));

  const settled = await Promise.allSettled(
    models.map(async (modelId): Promise<CompareResponse> => {
      const start = Date.now();
      try {
        const enhancedSystem = withProScaffold(
          systemPrompt ?? 'You are a concise assistant. Reply clearly and accurately.',
          'reasoning',
        );
        const content = await quickChat(prompt, enhancedSystem);
        return { model: modelId, content, latencyMs: Date.now() - start, error: null };
      } catch (err) {
        return {
          model: modelId,
          content: '',
          latencyMs: Date.now() - start,
          error: err instanceof Error ? err.message : String(err),
        };
      }
    }),
  );

  const responses: CompareResponse[] = settled.map((r, i) =>
    r.status === 'fulfilled'
      ? r.value
      : { model: models[i], content: '', latencyMs: 0, error: r.reason?.message || 'Rejected' },
  );

  return NextResponse.json({ prompt, models, responses });
}
