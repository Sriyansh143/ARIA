import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRealSystemMetrics } from '@/lib/system-metrics';

export const dynamic = 'force-dynamic';

// Live system metrics + recent telemetry series + agent load distribution.
// `current` is REAL live data from `systeminformation` (CPU, mem, disk, net,
// uptime, loadAvg). `series` is the historical chart data from the
// `Telemetry` table — written by the `health-check` cron dispatcher.
// `tokens` is REAL — pulled from the Provider row (tracks API token usage).
export async function GET() {
  const [recent, metrics, agents, provider] = await Promise.all([
    db.telemetry.findMany({ orderBy: { createdAt: 'desc' }, take: 30 }),
    getRealSystemMetrics(),
    db.agent.findMany({ select: { codename: true, load: true, status: true } }),
    db.provider.findUnique({ where: { key: 'zai' } }),
  ]);

  const series = recent.reverse();

  return NextResponse.json({
    current: {
      // Real live OS metrics — see src/lib/system-metrics.ts
      cpu: metrics.cpu,
      mem: metrics.mem,
      memTotal: metrics.memTotal,
      disk: metrics.disk,
      diskTotal: metrics.diskTotal,
      netRx: metrics.netRx,
      netTx: metrics.netTx,
      uptime: metrics.uptime,
      loadAvg: metrics.loadAvg,
      // Backwards-compat fields kept for the Overview tab / Telemetry tab:
      //   net    — combined net rate (rx + tx) in bytes/sec, rounded
      //   latency — provider latency (real, from DB) or last telemetry sample
      //   tokens  — REAL API token usage from the Provider row
      net: metrics.netRx + metrics.netTx,
      latency: series[series.length - 1]?.latency ?? provider?.latency ?? 620,
      tokens: provider?.tokens ?? 0,
    },
    series: series.map((t) => ({
      time: t.createdAt.toISOString(),
      cpu: Math.round(t.cpu * 10) / 10,
      mem: Math.round(t.mem * 10) / 10,
      disk: Math.round(t.disk * 10) / 10,
      latency: t.latency,
      tokens: t.tokens,
    })),
    agents: agents.map((a) => ({ name: a.codename, load: a.load, status: a.status })),
  });
}
