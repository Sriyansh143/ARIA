import { NextResponse } from 'next/server';
import { getAppOverview, getAppOverviewSummary } from '@/lib/app-overview';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/app-overview — comprehensive app overview for monitor agents.
 *
 * Returns every tab, its purpose, what it shows, best use cases,
 * related APIs, monitoring tips, and potential improvements.
 *
 * Monitor agents use this to understand the full system and
 * identify opportunities to improve flows.
 */
export async function GET() {
  return NextResponse.json({
    tabs: getAppOverview(),
    summary: getAppOverviewSummary(),
    totalFeatures: getAppOverview().length,
  });
}
