import { NextRequest, NextResponse } from 'next/server';
import { sendEmail, sendToOwnerEmail, isEmailConfigured } from '@/lib/email-sender';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — send an email
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { to, subject, body: emailBody, useOwner } = body as {
    to?: string;
    subject?: string;
    body?: string;
    useOwner?: boolean;
  };

  if (!subject || !emailBody) {
    return NextResponse.json({ error: 'subject and body required' }, { status: 400 });
  }

  if (!isEmailConfigured()) {
    return NextResponse.json({ error: 'SMTP not configured. Set SMTP_USER + SMTP_PASS in .env' }, { status: 503 });
  }

  const result = useOwner ? await sendToOwnerEmail(subject, emailBody) : await sendEmail(to!, subject, emailBody);
  return NextResponse.json(result);
}

// GET — email config status
export async function GET() {
  return NextResponse.json({ configured: isEmailConfigured() });
}
