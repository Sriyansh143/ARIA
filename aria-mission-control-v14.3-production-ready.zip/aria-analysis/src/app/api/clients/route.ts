import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  sanitizeString,
  sanitizeEnum,
  sanitizeNumber,
  sanitizeEmail,
  sanitizePhone,
} from '@/lib/sanitize';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Statuses that count as "active deals" in the pipeline (not yet won/lost).
const ACTIVE_STATUSES = ['contacted', 'qualified', 'proposal', 'negotiation'];

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get('status');
    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    const clients = await db.client.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
    // ── Stats ──────────────────────────────────────────────────────────
    const byStatus = await db.client.groupBy({
      by: ['status'],
      _count: true,
      _sum: { value: true },
    });
    const statusCounts: Record<string, number> = {};
    const statusValue: Record<string, number> = {};
    for (const row of byStatus) {
      statusCounts[row.status] = row._count;
      statusValue[row.status] = row._sum.value ?? 0;
    }
    const totalValue = Object.values(statusValue).reduce((a, b) => a + b, 0);
    const pipelineValue = ACTIVE_STATUSES.reduce(
      (sum, s) => sum + (statusValue[s] ?? 0),
      0,
    );
    // Won-this-month: clients whose status === 'won' and createdAt is in the
    // current calendar month.
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const wonThisMonth = await db.client.count({
      where: { status: 'won', createdAt: { gte: monthStart } },
    });
    const activeDeals = ACTIVE_STATUSES.reduce(
      (sum, s) => sum + (statusCounts[s] ?? 0),
      0,
    );
    return NextResponse.json({
      clients,
      stats: {
        total: clients.length,
        totalValue,
        pipelineValue,
        wonThisMonth,
        activeDeals,
        statusCounts,
        statusValue,
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'fetch failed' },
      { status: 500 },
    );
  }
}

const ALLOWED_STATUSES = new Set([
  'lead',
  'contacted',
  'qualified',
  'proposal',
  'negotiation',
  'won',
  'lost',
]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { name, company, email, phone, status, source, value, notes, assignee } = body as {
      name?: string;
      company?: string;
      email?: string;
      phone?: string;
      status?: string;
      source?: string;
      value?: number | string;
      notes?: string;
      assignee?: string;
    };

    // ── Validate required + optional fields via centralized sanitizers ──
    const safeName = sanitizeString(name, 200);
    if (!safeName) {
      return NextResponse.json(
        { error: 'name required (non-empty string, max 200 chars)' },
        { status: 400 },
      );
    }

    const safeStatus = sanitizeEnum(status, ALLOWED_STATUSES, 'lead');

    // Optional string fields — only validate when explicitly provided.
    const safeCompany = company != null ? sanitizeString(company, 200) : null;
    if (company != null && safeCompany === null) {
      return NextResponse.json({ error: 'company must be a non-empty string' }, { status: 400 });
    }
    const safeSource = source != null ? sanitizeString(source, 100) : null;
    if (source != null && safeSource === null) {
      return NextResponse.json({ error: 'source must be a non-empty string' }, { status: 400 });
    }
    const safeNotes = notes != null ? sanitizeString(notes, 2000) : null;
    if (notes != null && safeNotes === null) {
      return NextResponse.json(
        { error: 'notes must be a non-empty string (max 2000 chars)' },
        { status: 400 },
      );
    }
    const safeAssignee = assignee != null ? sanitizeString(assignee, 100) : null;
    if (assignee != null && safeAssignee === null) {
      return NextResponse.json({ error: 'assignee must be a non-empty string' }, { status: 400 });
    }

    // Email — validate format only when a non-empty value is provided
    // (whitespace/empty strings fall through to null, matching old behavior).
    let safeEmail: string | null = null;
    if (typeof email === 'string' && email.trim().length > 0) {
      safeEmail = sanitizeEmail(email);
      if (!safeEmail) {
        return NextResponse.json({ error: 'email format is invalid' }, { status: 400 });
      }
    } else if (email != null && typeof email !== 'string') {
      return NextResponse.json({ error: 'email must be a string' }, { status: 400 });
    }

    // Phone — validate format only when a non-empty value is provided.
    let safePhone: string | null = null;
    if (typeof phone === 'string' && phone.trim().length > 0) {
      safePhone = sanitizePhone(phone);
      if (!safePhone) {
        return NextResponse.json({ error: 'phone format is invalid' }, { status: 400 });
      }
    } else if (phone != null && typeof phone !== 'string') {
      return NextResponse.json({ error: 'phone must be a string' }, { status: 400 });
    }

    // Value — must be a finite non-negative number when provided.
    let finalValue = 0;
    if (value != null) {
      const rawValue = typeof value === 'string' ? Number(value) : value;
      const safeValue = sanitizeNumber(rawValue, { min: 0, allowZero: true });
      if (safeValue === null) {
        return NextResponse.json(
          { error: 'value must be a non-negative number' },
          { status: 400 },
        );
      }
      finalValue = safeValue;
    }

    const client = await db.client.create({
      data: {
        name: safeName,
        company: safeCompany,
        email: safeEmail,
        phone: safePhone,
        status: safeStatus,
        source: safeSource,
        value: finalValue,
        notes: safeNotes,
        assignee: safeAssignee,
      },
    });
    return NextResponse.json({ client });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'create failed' },
      { status: 500 },
    );
  }
}
