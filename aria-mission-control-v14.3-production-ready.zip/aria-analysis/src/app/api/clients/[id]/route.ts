import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_STATUSES = new Set([
  'lead',
  'contacted',
  'qualified',
  'proposal',
  'negotiation',
  'won',
  'lost',
]);

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const client = await db.client.findUnique({ where: { id } });
    if (!client) return NextResponse.json({ error: 'not found' }, { status: 404 });
    return NextResponse.json({ client });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'fetch failed' },
      { status: 500 },
    );
  }
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json().catch(() => ({}));
    const data: Record<string, unknown> = {};
    if (typeof body.name === 'string') {
      if (body.name.trim().length === 0) {
        return NextResponse.json({ error: 'name cannot be empty' }, { status: 400 });
      }
      data.name = body.name.trim();
    }
    if (body.company !== undefined) data.company = body.company?.trim() || null;
    if (body.email !== undefined) data.email = body.email?.trim() || null;
    if (body.phone !== undefined) data.phone = body.phone?.trim() || null;
    if (body.status !== undefined) {
      if (!ALLOWED_STATUSES.has(body.status)) {
        return NextResponse.json({ error: `invalid status: ${body.status}` }, { status: 400 });
      }
      data.status = body.status;
    }
    if (body.source !== undefined) data.source = body.source?.trim() || null;
    if (body.value !== undefined) {
      const v = typeof body.value === 'string' ? Number(body.value) : body.value;
      if (typeof v !== 'number' || Number.isNaN(v)) {
        return NextResponse.json({ error: 'value must be a number' }, { status: 400 });
      }
      data.value = v;
    }
    if (body.notes !== undefined) data.notes = body.notes?.trim() || null;
    if (body.assignee !== undefined) data.assignee = body.assignee?.trim() || null;
    const client = await db.client.update({ where: { id }, data });
    return NextResponse.json({ client });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'update failed' },
      { status: 500 },
    );
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    await db.client.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'delete failed' },
      { status: 500 },
    );
  }
}
