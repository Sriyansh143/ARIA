import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import {
  fetchRazorpayPayment,
  fetchStripePaymentIntent,
} from '@/lib/payment-gateways';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/payments/order/[id]
//
// Fetches a PaymentOrder from the DB and refreshes its status from the
// underlying gateway. If the gateway reports `paid` and the PaymentOrder
// doesn't yet have a linked `Payment` row, we create one so the rest of
// ARIA (Payments tab, KPI rollups, refunds) treats the transaction as real.
//
// Response:
//   { ok: true, order: PaymentOrder, live: { status, paymentId?, error? } }
//   404 if the order id is unknown.
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!id) {
    return NextResponse.json({ ok: false, error: 'id required' }, { status: 400 });
  }

  const order = await db.paymentOrder.findUnique({ where: { id } }).catch((err) => {
    logger.error({ route: 'order/[id]', id, err }, 'db lookup failed');
    return null;
  });

  if (!order) {
    return NextResponse.json({ ok: false, error: 'order not found' }, { status: 404 });
  }

  // If the order is already terminal, skip the live fetch — saves API quota.
  const terminal = order.status === 'paid' || order.status === 'failed' || order.status === 'refunded';
  if (terminal) {
    return NextResponse.json({
      ok: true,
      order,
      live: { status: order.status, paymentId: order.paymentId ?? undefined, cached: true },
    });
  }

  // Bump attempts — every GET on a non-terminal order counts as a poll.
  await db.paymentOrder
    .update({ where: { id: order.id }, data: { attempts: { increment: 1 } } })
    .catch((err) => logger.warn({ route: 'order/[id]', id, err }, 'failed to bump attempts'));

  // --- Live status fetch -----------------------------------------------------
  let live: { status?: string; paymentId?: string; error?: string };

  if (order.gateway === 'razorpay') {
    if (!order.gatewayOrderId) {
      return NextResponse.json({ ok: false, error: 'order has no gatewayOrderId' }, { status: 400 });
    }
    const r = await fetchRazorpayPayment(order.gatewayOrderId);
    live = { status: r.status, paymentId: r.paymentId, error: r.error };
  } else if (order.gateway === 'stripe') {
    if (!order.gatewayOrderId) {
      return NextResponse.json({ ok: false, error: 'order has no gatewayOrderId' }, { status: 400 });
    }
    const r = await fetchStripePaymentIntent(order.gatewayOrderId);
    live = { status: r.status, error: r.error };
  } else {
    return NextResponse.json(
      { ok: false, error: `unknown gateway: ${order.gateway}` },
      { status: 400 },
    );
  }

  if (!live.status) {
    // Gateway fetch failed — return what we have without modifying DB.
    return NextResponse.json({ ok: true, order, live });
  }

  // --- Sync DB if changed ----------------------------------------------------
  if (live.status !== order.status) {
    await db.paymentOrder
      .update({
        where: { id: order.id },
        data: {
          status: live.status,
          ...(live.paymentId ? { paymentId: live.paymentId } : {}),
        },
      })
      .catch((err) =>
        logger.warn({ route: 'order/[id]', id, err }, 'failed to update PaymentOrder status'),
      );
    logger.info(
      { route: 'order/[id]', id, from: order.status, to: live.status },
      'payment order status updated',
    );
  }

  // --- On `paid`, link / create a Payment row --------------------------------
  if (live.status === 'paid' && !order.paymentId) {
    try {
      // First, see if a webhook already created the Payment (matched by the
      // gateway order id stored in the `payer` field — see webhook routes).
      const existing = await db.payment.findFirst({
        where: { payer: { contains: order.gatewayOrderId ?? '' } },
      });

      let paymentId: string;
      if (existing) {
        await db.payment.update({
          where: { id: existing.id },
          data: { status: 'confirmed' },
        });
        paymentId = existing.id;
      } else {
        // No webhook record — create one now and link it.
        const created = await db.payment.create({
          data: {
            method: order.gateway, // 'razorpay' | 'stripe'
            amount: order.amount,
            currency: order.currency,
            status: 'confirmed',
            payer: order.gatewayOrderId ?? null, // store the gateway ref
            note: order.purpose ?? 'auto-created from order poll',
          },
        });
        paymentId = created.id;
      }

      await db.paymentOrder.update({
        where: { id: order.id },
        data: { paymentId },
      });

      logger.info(
        { route: 'order/[id]', id, paymentId, gateway: order.gateway },
        'payment row linked to order',
      );
    } catch (err) {
      // Non-fatal: the order status itself is already correct; we'll retry
      // the Payment row linkage on the next poll.
      logger.warn({ route: 'order/[id]', id, err }, 'failed to link Payment row');
    }
  }

  // Re-read so the response reflects the updated row.
  const refreshed = await db.paymentOrder.findUnique({ where: { id: order.id } });

  return NextResponse.json({
    ok: true,
    order: refreshed ?? order,
    live,
  });
}
