import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import {
  createRazorpayOrder,
  createStripePaymentIntent,
  getPaymentGatewayStatus,
} from '@/lib/payment-gateways';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Allowed gateway identifiers — narrowed here so a typo doesn't quietly land
// in the DB as `gateway: "razoray"`.
const ALLOWED_GATEWAYS = new Set(['razorpay', 'stripe']);

interface CreateOrderBody {
  amount?: number;
  currency?: string;
  gateway?: string;
  purpose?: string;
  payerName?: string;
  payerEmail?: string;
  payerContact?: string;
  notes?: Record<string, string>;
}

// POST /api/payments/create-order
//
// Body:
//   { amount, currency?, gateway: 'razorpay'|'stripe', purpose?, payerName?,
//     payerEmail?, payerContact?, notes? }
//
// Response 200:
//   { ok: true, order: { id, gatewayOrderId, amount, currency, gateway,
//                        clientSecret? /* stripe only */ } }
// Response 400:
//   { ok: false, error: string }
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as CreateOrderBody;
  const {
    amount,
    currency,
    gateway,
    purpose,
    payerName,
    payerEmail,
    payerContact,
    notes,
  } = body;

  // --- Validate gateway ------------------------------------------------------
  if (!gateway || !ALLOWED_GATEWAYS.has(gateway)) {
    return NextResponse.json(
      { ok: false, error: "gateway must be 'razorpay' or 'stripe'" },
      { status: 400 },
    );
  }

  // --- Validate amount -------------------------------------------------------
  if (typeof amount !== 'number' || !isFinite(amount) || amount <= 0) {
    return NextResponse.json(
      { ok: false, error: 'amount must be a positive number' },
      { status: 400 },
    );
  }

  // Default currency: Razorpay ⇒ INR, Stripe ⇒ USD. Caller may override.
  const resolvedCurrency =
    (currency ?? '').toUpperCase() || (gateway === 'razorpay' ? 'INR' : 'USD');

  // --- Short-circuit if gateway not configured -------------------------------
  const status = getPaymentGatewayStatus();
  if (gateway === 'razorpay' && !status.razorpay.configured) {
    return NextResponse.json(
      { ok: false, error: 'Razorpay is not configured on the server' },
      { status: 400 },
    );
  }
  if (gateway === 'stripe' && !status.stripe.configured) {
    return NextResponse.json(
      { ok: false, error: 'Stripe is not configured on the server' },
      { status: 400 },
    );
  }

  // --- Call the gateway ------------------------------------------------------
  let gatewayOrderId: string | undefined;
  let clientSecret: string | undefined;

  if (gateway === 'razorpay') {
    // Receipt must be ≤40 chars; generate one if caller didn't.
    const receipt = (purpose ?? `aria_${Date.now()}`).slice(0, 40);
    const result = await createRazorpayOrder({
      amount,
      currency: resolvedCurrency,
      receipt,
      notes,
    });
    if (!result.ok || !result.orderId) {
      return NextResponse.json(
        { ok: false, error: result.error ?? 'razorpay order creation failed' },
        { status: 400 },
      );
    }
    gatewayOrderId = result.orderId;
  } else {
    // stripe
    const result = await createStripePaymentIntent({
      amount,
      currency: resolvedCurrency,
      description: purpose,
      receiptEmail: payerEmail,
    });
    if (!result.ok || !result.paymentIntentId || !result.clientSecret) {
      return NextResponse.json(
        { ok: false, error: result.error ?? 'stripe paymentintent creation failed' },
        { status: 400 },
      );
    }
    gatewayOrderId = result.paymentIntentId;
    clientSecret = result.clientSecret;
  }

  // --- Persist the PaymentOrder ---------------------------------------------
  let order;
  try {
    order = await db.paymentOrder.create({
      data: {
        gateway,
        gatewayOrderId,
        amount,
        currency: resolvedCurrency,
        purpose: purpose ?? null,
        payerName: payerName ?? null,
        payerEmail: payerEmail ?? null,
        payerContact: payerContact ?? null,
        status: 'created',
        receipt: gateway === 'razorpay' ? (purpose ?? `aria_${Date.now()}`).slice(0, 40) : null,
        notes: notes ? JSON.stringify(notes) : '{}',
        attempts: 0,
      },
    });
  } catch (err) {
    // The gateway order was created but we couldn't persist locally. Log it
    // so ops can reconcile; return a structured error so the client knows the
    // order id was lost (caller should treat this as a hard failure).
    logger.error(
      { route: 'create-order', gateway, gatewayOrderId, err },
      'failed to persist PaymentOrder after gateway order creation',
    );
    return NextResponse.json(
      {
        ok: false,
        error: 'order created at gateway but failed to persist locally',
        gatewayOrderId,
      },
      { status: 500 },
    );
  }

  logger.info(
    { route: 'create-order', gateway, orderId: order.id, gatewayOrderId, amount, currency: resolvedCurrency },
    'payment order created',
  );

  return NextResponse.json({
    ok: true,
    order: {
      id: order.id,
      gatewayOrderId: order.gatewayOrderId,
      amount: order.amount,
      currency: order.currency,
      gateway: order.gateway,
      ...(clientSecret ? { clientSecret } : {}),
    },
  });
}
