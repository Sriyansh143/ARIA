import { NextResponse } from 'next/server';
import { getPaymentGatewayStatus, getWebhookConfigStatus } from '@/lib/payment-gateways';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/payments/gateway-status
//
// Returns the configuration state of each gateway — whether it has keys
// configured and whether those keys are live/test. Also surfaces webhook
// secret presence so the UI can show a complete picture of the gateway
// setup (order API + webhook receiver both need to be in place for an
// end-to-end checkout flow).
export async function GET() {
  const gateway = getPaymentGatewayStatus();
  const webhook = getWebhookConfigStatus();
  return NextResponse.json({
    ok: true,
    razorpay: {
      configured: gateway.razorpay.configured,
      mode: gateway.razorpay.mode,
      webhook: webhook.razorpay,
    },
    stripe: {
      configured: gateway.stripe.configured,
      mode: gateway.stripe.mode,
      webhook: webhook.stripe,
    },
  });
}
