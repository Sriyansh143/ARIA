import { NextResponse } from 'next/server';
import { getWebhookConfigStatus } from '@/lib/payment-gateways';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — webhook configuration status
export async function GET() {
  return NextResponse.json(getWebhookConfigStatus());
}
