import { NextRequest, NextResponse } from 'next/server';
import { verifyRazorpaySignature } from '@/lib/payment-gateways';
import { db } from '@/lib/db';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — Razorpay webhook receiver
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('x-razorpay-signature') ?? '';
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET ?? '';

  if (!secret) {
    return NextResponse.json({ ok: false, reason: 'webhook secret not configured' });
  }

  if (!verifyRazorpaySignature(rawBody, signature, secret)) {
    return NextResponse.json({ ok: false, error: 'invalid signature' }, { status: 400 });
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ ok: false, error: 'invalid JSON' }, { status: 400 });
  }

  const event = payload.event as string;
  const paymentEntity = (payload.payload as { payment?: { entity?: Record<string, unknown> } })?.payment?.entity;

  if (!paymentEntity) {
    return NextResponse.json({ ok: true, event, note: 'no payment entity' });
  }

  const gatewayPaymentId = paymentEntity.id as string;
  const amount = (paymentEntity.amount as number) / 100; // paise → rupees
  const status = paymentEntity.status as string;

  // Find matching payment by gateway ref (stored in payer field)
  const payment = await db.payment.findFirst({
    where: { payer: { contains: gatewayPaymentId } },
  }).catch(() => null);

  if (payment) {
    if (event === 'payment.captured' || event === 'payment.authorized') {
      const before = { status: payment.status };
      await db.payment.update({ where: { id: payment.id }, data: { status: 'confirmed' } });
      await logAction({
        action: 'payment.confirm',
        target: `payment:${payment.id}`,
        beforeState: before,
        afterState: { status: 'confirmed' },
        actor: 'webhook:razorpay',
        meta: { event, gatewayPaymentId, amount },
      });
    } else if (event === 'payment.failed') {
      await db.payment.update({ where: { id: payment.id }, data: { status: 'failed' } });
    }
  }

  // Handle refund events
  if (event === 'refund.processed') {
    const refund = await db.refund.findFirst({
      where: { gatewayRef: gatewayPaymentId },
    }).catch(() => null);
    if (refund) {
      await db.refund.update({
        where: { id: refund.id },
        data: { status: 'processed', processedAt: new Date(), reviewedBy: 'webhook:razorpay' },
      });
    }
  }

  return NextResponse.json({ ok: true, event, paymentId: gatewayPaymentId, amount, status });
}
