import { NextRequest, NextResponse } from 'next/server';
import { verifyStripeSignature } from '@/lib/payment-gateways';
import { db } from '@/lib/db';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — Stripe webhook receiver
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const sigHeader = req.headers.get('stripe-signature') ?? '';
  const secret = process.env.STRIPE_WEBHOOK_SECRET ?? '';

  if (!secret) {
    return NextResponse.json({ ok: false, reason: 'webhook secret not configured' });
  }

  if (!verifyStripeSignature(rawBody, sigHeader, secret)) {
    return NextResponse.json({ ok: false, error: 'invalid signature' }, { status: 400 });
  }

  let payload: { type?: string; data?: { object?: Record<string, unknown> } };
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ ok: false, error: 'invalid JSON' }, { status: 400 });
  }

  const eventType = payload.type ?? '';
  const data = payload.data?.object ?? {};

  if (eventType === 'payment_intent.succeeded' || eventType === 'charge.succeeded') {
    const paymentIntentId = (data.id as string) ?? '';
    const amount = ((data.amount as number) ?? 0) / 100; // cents → dollars

    const payment = await db.payment.findFirst({
      where: { payer: { contains: paymentIntentId } },
    }).catch(() => null);

    if (payment) {
      const before = { status: payment.status };
      await db.payment.update({ where: { id: payment.id }, data: { status: 'confirmed' } });
      await logAction({
        action: 'payment.confirm',
        target: `payment:${payment.id}`,
        beforeState: before,
        afterState: { status: 'confirmed' },
        actor: 'webhook:stripe',
        meta: { event: eventType, paymentIntentId, amount },
      });
    }
  } else if (eventType === 'payment_intent.payment_failed') {
    const paymentIntentId = (data.id as string) ?? '';
    const payment = await db.payment.findFirst({
      where: { payer: { contains: paymentIntentId } },
    }).catch(() => null);
    if (payment) {
      await db.payment.update({ where: { id: payment.id }, data: { status: 'failed' } });
    }
  } else if (eventType === 'charge.refunded') {
    const refundId = (data.id as string) ?? '';
    const refund = await db.refund.findFirst({
      where: { gatewayRef: refundId },
    }).catch(() => null);
    if (refund) {
      await db.refund.update({
        where: { id: refund.id },
        data: { status: 'processed', processedAt: new Date(), reviewedBy: 'webhook:stripe' },
      });
    }
  }

  return NextResponse.json({ ok: true, event: eventType });
}
