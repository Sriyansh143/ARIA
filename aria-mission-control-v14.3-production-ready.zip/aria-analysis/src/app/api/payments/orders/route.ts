import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/payments/orders
//
// Query params:
//   ?status=created|paid|failed|processing|authorized|...  (optional filter)
//
// Returns the most recent 50 PaymentOrders (newest first) with the fields a
// list UI typically needs. Heavier fields (notes JSON) are omitted to keep
// the payload small for the dashboard.
export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get('status')?.trim();

  const where: Record<string, unknown> = {};
  if (status) where.status = status;

  const orders = await db.paymentOrder.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 50,
    select: {
      id: true,
      gateway: true,
      gatewayOrderId: true,
      paymentId: true,
      amount: true,
      currency: true,
      purpose: true,
      payerName: true,
      payerEmail: true,
      payerContact: true,
      status: true,
      receipt: true,
      attempts: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  return NextResponse.json({ ok: true, count: orders.length, orders });
}
