import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get('status');
  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  const payments = await db.payment.findMany({ where, orderBy: { createdAt: 'desc' }, take: 100 });
  const confirmed = await db.payment.aggregate({ where: { status: 'confirmed' }, _sum: { amount: true } });
  const pending = await db.payment.aggregate({ where: { status: 'pending' }, _sum: { amount: true } });
  const count = await db.payment.count();
  return NextResponse.json({
    payments,
    stats: {
      confirmedTotal: confirmed._sum.amount ?? 0,
      pendingTotal: pending._sum.amount ?? 0,
      count,
    },
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { method, amount, payer, note, status, currency } = body;
  // Validate method is a known payment method.
  const ALLOWED_METHODS = new Set(['upi', 'card', 'netbanking', 'qr', 'wallet']);
  if (!method || !ALLOWED_METHODS.has(method)) {
    return NextResponse.json({ error: 'method must be one of: upi, card, netbanking, qr, wallet' }, { status: 400 });
  }
  // Validate amount is a finite positive number (reject negative, zero, NaN, Infinity).
  if (typeof amount !== 'number' || !isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: 'amount must be a positive number' }, { status: 400 });
  }
  // Validate amount is within a sane range (reject > 10 crore to catch typos/abuse).
  if (amount > 100_000_000) {
    return NextResponse.json({ error: 'amount exceeds maximum allowed (₹10,00,00,000)' }, { status: 400 });
  }
  // Validate status if provided.
  const ALLOWED_STATUS = new Set(['pending', 'confirmed', 'failed', 'refunded']);
  const resolvedStatus = status ?? 'pending';
  if (!ALLOWED_STATUS.has(resolvedStatus)) {
    return NextResponse.json({ error: 'status must be one of: pending, confirmed, failed, refunded' }, { status: 400 });
  }
  // Sanitize string fields (trim + cap length to prevent abuse).
  const sanitizedPayer = typeof payer === 'string' ? payer.trim().slice(0, 200) : null;
  const sanitizedNote = typeof note === 'string' ? note.trim().slice(0, 1000) : null;
  const sanitizedCurrency = typeof currency === 'string' && /^[A-Z]{3}$/.test(currency) ? currency : 'INR';
  const payment = await db.payment.create({
    data: { method, amount, payer: sanitizedPayer, note: sanitizedNote, status: resolvedStatus, currency: sanitizedCurrency },
  });
  return NextResponse.json({ payment });
}
