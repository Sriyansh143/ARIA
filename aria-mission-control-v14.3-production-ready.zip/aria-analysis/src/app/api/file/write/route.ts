import { NextRequest, NextResponse } from 'next/server';
import { writeFileSync, mkdirSync } from 'fs';
import { resolve, relative, isAbsolute, sep, dirname } from 'path';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// File write endpoint.
//
// Writes content to a path inside the workspace root.
//   - 10MB cap
//   - Path MUST resolve inside workspace (no ../ escapes)
//   - Creates parent directories if needed
// ─────────────────────────────────────────────────────────────────────

const WORKSPACE_ROOT = resolve(process.cwd());
const MAX_WRITE_BYTES = 10 * 1024 * 1024; // 10MB
const MAX_PATH_LEN = 1024;

function isInsideWorkspace(target: string): boolean {
  const rel = relative(WORKSPACE_ROOT, target);
  if (rel === '') return true;
  return !rel.startsWith('..' + sep) && !isAbsolute(rel);
}

export async function POST(req: NextRequest) {
  let path = '';
  let content = '';
  try {
    const body = await req.json().catch(() => ({}));
    path = typeof body?.path === 'string' ? body.path : '';
    content = typeof body?.content === 'string' ? body.content : '';
  } catch {
    // ignore
  }

  if (!path.trim()) {
    return NextResponse.json({ error: 'path required' }, { status: 400 });
  }
  if (path.length > MAX_PATH_LEN) {
    return NextResponse.json({ error: 'path too long' }, { status: 400 });
  }

  // Byte length (utf-8) cap check.
  const byteLen = Buffer.byteLength(content, 'utf-8');
  if (byteLen > MAX_WRITE_BYTES) {
    return NextResponse.json(
      { error: `content exceeds ${MAX_WRITE_BYTES} bytes (${byteLen})` },
      { status: 413 },
    );
  }

  const resolved = resolve(WORKSPACE_ROOT, path);
  if (!isInsideWorkspace(resolved)) {
    await logAction({
      actor: 'operator',
      action: 'file.write.blocked',
      category: 'security',
      target: path,
      afterState: { reason: 'path outside workspace' },
      reversible: false,
    }).catch(() => {});
    return NextResponse.json(
      { error: 'path must be within workspace root' },
      { status: 403 },
    );
  }

  // Block writes to sensitive paths (.env, prisma/dev.db, etc.)
  const SENSITIVE_PATTERNS = [
    /(^|\/)\.env(\.|$)/i,
    /dev\.db$/i,
    /\/node_modules\//i,
    /\/\.git\//i,
  ];
  if (SENSITIVE_PATTERNS.some((re) => re.test(path))) {
    return NextResponse.json(
      { error: 'writes to sensitive paths are blocked' },
      { status: 403 },
    );
  }

  try {
    mkdirSync(dirname(resolved), { recursive: true });
    writeFileSync(resolved, content, 'utf-8');
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'write failed' },
      { status: 500 },
    );
  }

  await logAction({
    actor: 'operator',
    action: 'file.write',
    category: 'mutation',
    target: path,
    afterState: { size: byteLen },
    reversible: true,
    meta: { bytes: byteLen },
  }).catch(() => {});

  return NextResponse.json({
    ok: true,
    path,
    resolvedPath: resolved,
    bytes: byteLen,
  });
}
