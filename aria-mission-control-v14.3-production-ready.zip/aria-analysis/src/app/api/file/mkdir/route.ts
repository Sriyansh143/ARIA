import { NextRequest, NextResponse } from 'next/server';
import { mkdirSync, statSync } from 'fs';
import { resolve, relative, isAbsolute, sep } from 'path';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Directory create (mkdir) endpoint.
//
// Creates a directory at the given path (and any intermediate parents)
// inside the workspace root.
//   - Path MUST resolve inside the workspace (no ../ escapes)
//   - Refuses to overwrite an existing file (returns 409 if a non-dir
//     exists at the target path)
// ─────────────────────────────────────────────────────────────────────

const WORKSPACE_ROOT = resolve(process.cwd());

function isInsideWorkspace(target: string): boolean {
  const rel = relative(WORKSPACE_ROOT, target);
  if (rel === '') return true;
  return !rel.startsWith('..' + sep) && !isAbsolute(rel);
}

export async function POST(req: NextRequest) {
  let path = '';
  try {
    const body = await req.json().catch(() => ({}));
    path = typeof body?.path === 'string' ? body.path : '';
  } catch {
    // ignore
  }

  if (!path.trim()) {
    return NextResponse.json({ error: 'path required' }, { status: 400 });
  }

  const resolved = resolve(WORKSPACE_ROOT, path);
  if (!isInsideWorkspace(resolved)) {
    await logAction({
      actor: 'operator',
      action: 'file.mkdir.blocked',
      category: 'security',
      target: path,
      afterState: { reason: 'path outside workspace' },
      reversible: false,
    }).catch(() => {});
    return NextResponse.json(
      { error: 'path must be within workspace root' },
      { status: 403 },
    );
  }

  // Refuse to mkdir inside node_modules / .git / .next.
  const SENSITIVE_PATTERNS = [
    /\/node_modules\//i,
    /\/\.git\//i,
    /\/\.next\//i,
  ];
  if (SENSITIVE_PATTERNS.some((re) => re.test(path))) {
    return NextResponse.json(
      { error: 'creating folders in sensitive paths is blocked' },
      { status: 403 },
    );
  }

  // If something already exists, refuse unless it's already a directory.
  try {
    const existing = statSync(resolved);
    if (!existing.isDirectory()) {
      return NextResponse.json(
        { error: 'a non-directory file already exists at this path' },
        { status: 409 },
      );
    }
    // Already a directory — idempotent success.
    return NextResponse.json({ ok: true, path, resolvedPath: resolved, existed: true });
  } catch {
    // doesn't exist — fall through to create.
  }

  try {
    mkdirSync(resolved, { recursive: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'mkdir failed' },
      { status: 500 },
    );
  }

  await logAction({
    actor: 'operator',
    action: 'file.mkdir',
    category: 'mutation',
    target: path,
    afterState: { created: true },
    reversible: true,
  }).catch(() => {});

  return NextResponse.json({
    ok: true,
    path,
    resolvedPath: resolved,
    existed: false,
  });
}
