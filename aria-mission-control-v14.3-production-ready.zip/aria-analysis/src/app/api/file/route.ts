import { NextRequest, NextResponse } from 'next/server';
import { unlinkSync, statSync } from 'fs';
import { resolve, relative, isAbsolute, sep } from 'path';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// File delete endpoint.
//
// Deletes a single file (not a directory) from inside the workspace root.
//   - Path MUST resolve inside the workspace (no ../ escapes)
//   - Refuses to delete directories (use a dedicated rmdir route)
//   - Blocks sensitive paths (.env, dev.db, node_modules, .git)
// ─────────────────────────────────────────────────────────────────────

const WORKSPACE_ROOT = resolve(process.cwd());

function isInsideWorkspace(target: string): boolean {
  const rel = relative(WORKSPACE_ROOT, target);
  if (rel === '') return true;
  return !rel.startsWith('..' + sep) && !isAbsolute(rel);
}

export async function DELETE(req: NextRequest) {
  let path = '';
  try {
    const body = await req.json().catch(() => ({}));
    path = typeof body?.path === 'string' ? body.path : '';
  } catch {
    // ignore
  }

  if (!path.trim()) {
    return NextResponse.json({ error: 'path required' }, { status: 400 });
  }

  const resolved = resolve(WORKSPACE_ROOT, path);
  if (!isInsideWorkspace(resolved)) {
    await logAction({
      actor: 'operator',
      action: 'file.delete.blocked',
      category: 'security',
      target: path,
      afterState: { reason: 'path outside workspace' },
      reversible: false,
    }).catch(() => {});
    return NextResponse.json(
      { error: 'path must be within workspace root' },
      { status: 403 },
    );
  }

  // Block deletes to sensitive paths.
  const SENSITIVE_PATTERNS = [
    /(^|\/)\.env(\.|$)/i,
    /dev\.db$/i,
    /\/node_modules\//i,
    /\/\.git\//i,
    /(^|\/)package\.json$/i,
    /(^|\/)tsconfig\.json$/i,
    /(^|\/)next\.config/i,
    /(^|\/)prisma\/schema\.prisma$/i,
  ];
  if (SENSITIVE_PATTERNS.some((re) => re.test(path))) {
    return NextResponse.json(
      { error: 'deleting sensitive paths is blocked' },
      { status: 403 },
    );
  }

  let stats;
  try {
    stats = statSync(resolved);
  } catch {
    return NextResponse.json({ error: 'file not found' }, { status: 404 });
  }
  if (stats.isDirectory()) {
    return NextResponse.json(
      { error: 'refusing to delete a directory; use the folder API' },
      { status: 400 },
    );
  }

  try {
    unlinkSync(resolved);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'delete failed' },
      { status: 500 },
    );
  }

  await logAction({
    actor: 'operator',
    action: 'file.delete',
    category: 'mutation',
    target: path,
    afterState: { deleted: true, previousSize: stats.size },
    reversible: true,
    meta: { previousSize: stats.size },
  }).catch(() => {});

  return NextResponse.json({
    ok: true,
    path,
    resolvedPath: resolved,
    deletedBytes: stats.size,
  });
}
