import { NextRequest, NextResponse } from 'next/server';
import { readFileSync, statSync } from 'fs';
import { resolve, relative, isAbsolute, sep } from 'path';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// File read endpoint.
//
// Reads a file from the workspace root (the Next.js project dir).
//   - 1MB cap
//   - Path MUST resolve inside the workspace root (no ../ escapes)
//   - Returns content + size + encoding hint
// ─────────────────────────────────────────────────────────────────────

const WORKSPACE_ROOT = resolve(process.cwd());
const MAX_READ_BYTES = 1 * 1024 * 1024; // 1MB

function isInsideWorkspace(target: string): boolean {
  const rel = relative(WORKSPACE_ROOT, target);
  if (rel === '') return true; // exact root
  return !rel.startsWith('..' + sep) && !isAbsolute(rel);
}

export async function POST(req: NextRequest) {
  let path = '';
  try {
    const body = await req.json().catch(() => ({}));
    path = typeof body?.path === 'string' ? body.path : '';
  } catch {
    // ignore
  }

  if (!path.trim()) {
    return NextResponse.json({ error: 'path required' }, { status: 400 });
  }

  const resolved = resolve(WORKSPACE_ROOT, path);
  if (!isInsideWorkspace(resolved)) {
    await logAction({
      actor: 'operator',
      action: 'file.read.blocked',
      category: 'security',
      target: path,
      afterState: { reason: 'path outside workspace' },
      reversible: false,
    }).catch(() => {});
    return NextResponse.json(
      { error: 'path must be within workspace root' },
      { status: 403 },
    );
  }

  let stats;
  try {
    stats = statSync(resolved);
  } catch {
    return NextResponse.json({ error: 'file not found' }, { status: 404 });
  }
  if (!stats.isFile()) {
    return NextResponse.json({ error: 'path is not a file' }, { status: 400 });
  }
  if (stats.size > MAX_READ_BYTES) {
    return NextResponse.json(
      { error: `file exceeds ${MAX_READ_BYTES} bytes (${stats.size})` },
      { status: 413 },
    );
  }

  let content: string;
  try {
    content = readFileSync(resolved, 'utf-8');
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'read failed' },
      { status: 500 },
    );
  }

  await logAction({
    actor: 'operator',
    action: 'file.read',
    category: 'read',
    target: path,
    afterState: { size: stats.size },
    reversible: false,
  }).catch(() => {});

  return NextResponse.json({
    path,
    resolvedPath: resolved,
    content,
    size: stats.size,
    truncated: false,
  });
}
