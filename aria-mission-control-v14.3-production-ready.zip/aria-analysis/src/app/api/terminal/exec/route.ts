import { NextRequest, NextResponse } from 'next/server';
import { execSync } from 'child_process';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Interactive shell execution endpoint.
//
// Sandboxed command runner used by the Terminal tab:
//   - 30-second hard timeout
//   - Block-list of destructive / privilege-escalating patterns
//   - Captures stdout, stderr, exit code, duration
//   - Every invocation is recorded in the ActionLog for audit
// ─────────────────────────────────────────────────────────────────────

const BLOCKED_PATTERNS = [
  'rm -rf /',
  'sudo',
  'mkfs',
  'dd if=',
  ':(){:|:&};:', // fork bomb
];

const TIMEOUT_MS = 30_000;
const MAX_COMMAND_LEN = 4000;

interface ExecResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  blocked?: boolean;
  blockReason?: string;
  command: string;
}

function isBlocked(command: string): { blocked: boolean; reason?: string } {
  const lower = command.toLowerCase();
  for (const pattern of BLOCKED_PATTERNS) {
    if (lower.includes(pattern.toLowerCase())) {
      return { blocked: true, reason: `Blocked pattern detected: "${pattern}"` };
    }
  }
  return { blocked: false };
}

export async function POST(req: NextRequest) {
  let command = '';
  try {
    const body = await req.json().catch(() => ({}));
    command = typeof body?.command === 'string' ? body.command : '';
  } catch {
    // ignore parse error — command stays empty
  }

  if (!command.trim()) {
    return NextResponse.json(
      { error: 'command required' },
      { status: 400 },
    );
  }
  if (command.length > MAX_COMMAND_LEN) {
    return NextResponse.json(
      { error: `command exceeds ${MAX_COMMAND_LEN} chars` },
      { status: 400 },
    );
  }

  // ─── Block-list check ───
  const { blocked, reason } = isBlocked(command);
  if (blocked) {
    const result: ExecResult = {
      stdout: '',
      stderr: '',
      exitCode: -1,
      durationMs: 0,
      blocked: true,
      blockReason: reason,
      command,
    };
    // Audit the blocked attempt
    await logAction({
      actor: 'operator',
      action: 'terminal.exec.blocked',
      category: 'security',
      target: command.slice(0, 200),
      afterState: { reason },
      reversible: false,
    }).catch(() => {});
    return NextResponse.json(result);
  }

  const started = Date.now();
  let stdout = '';
  let stderr = '';
  let exitCode = 0;

  try {
    // execSync throws on non-zero exit codes — capture via try/catch.
    stdout = execSync(command, {
      timeout: TIMEOUT_MS,
      maxBuffer: 2 * 1024 * 1024, // 2MB output cap
      encoding: 'utf-8',
      cwd: process.cwd(),
      stdio: ['pipe', 'pipe', 'pipe'],
    });
  } catch (err: unknown) {
    const e = err as {
      stdout?: string;
      stderr?: string;
      status?: number;
      signal?: string;
      message?: string;
      killed?: boolean;
    };
    stdout = typeof e.stdout === 'string' ? e.stdout : '';
    stderr = typeof e.stderr === 'string' ? e.stderr : '';
    if (e.killed && e.signal === 'SIGTERM') {
      stderr += `\n[timeout — exceeded ${TIMEOUT_MS}ms]`;
      exitCode = 124; // standard timeout exit code
    } else {
      exitCode = typeof e.status === 'number' ? e.status : 1;
    }
    if (!stderr && e.message) stderr = e.message;
  }

  const durationMs = Date.now() - started;

  // Audit successful execution
  await logAction({
    actor: 'operator',
    action: 'terminal.exec',
    category: 'mutation',
    target: command.slice(0, 200),
    afterState: { exitCode, durationMs, stdoutLen: stdout.length, stderrLen: stderr.length },
    reversible: false,
    meta: { command, exitCode, durationMs },
  }).catch(() => {});

  const result: ExecResult = {
    stdout,
    stderr,
    exitCode,
    durationMs,
    command,
  };

  return NextResponse.json(result);
}
