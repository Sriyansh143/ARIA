import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  listProposals,
  approveProposal,
  rejectProposal,
  type ImprovementProposal,
} from '@/lib/self-improve-engine';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * GET /api/strategy/proposals — list agent self-improvement proposals.
 * These are proposals the self-improve engine auto-generates when an agent's
 * 7-day success rate drops below 70%, plus any operator-created proposals.
 * They represent "how agents propose to improvise the app/company".
 *
 * Query: ?status=pending|approved|rejected|all  (default: all)
 */
export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get('status') || 'all';
  const proposals = await listProposals(
    status && status !== 'all' ? { status: status as ImprovementProposal['status'], limit: 100 } : { limit: 100 },
  );
  // Also count by status for the header chips.
  const all = await listProposals({ limit: 500 });
  const counts = {
    total: all.length,
    pending: all.filter((p) => p.status === 'pending').length,
    approved: all.filter((p) => p.status === 'approved').length,
    rejected: all.filter((p) => p.status === 'rejected').length,
  };
  return NextResponse.json({ proposals, counts });
}

/**
 * POST /api/strategy/proposals — act on a proposal.
 * Body: { proposalId, action: 'approve'|'reject'|'promote', note? }
 *
 * 'approve' / 'reject' update the proposal status.
 * 'promote' creates a Task from the proposal (so the autonomous loop / an
 *   on-call agent picks it up) AND approves it. The operator STAYS on the
 *   Strategy tab — no navigation.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { proposalId, action, note } = body as { proposalId?: string; action?: string; note?: string };
  if (!proposalId || !action) {
    return NextResponse.json({ error: 'proposalId and action required' }, { status: 400 });
  }

  if (action === 'approve') {
    const p = await approveProposal(proposalId, 'operator', note);
    return NextResponse.json({ proposal: p });
  }
  if (action === 'reject') {
    const p = await rejectProposal(proposalId, 'operator', note);
    return NextResponse.json({ proposal: p });
  }
  if (action === 'promote') {
    // Approve + create a Task from the proposal.
    const all = await listProposals({ limit: 500 });
    const proposal = all.find((p) => p.id === proposalId);
    if (!proposal) return NextResponse.json({ error: 'proposal not found' }, { status: 404 });
    await approveProposal(proposalId, 'operator', note || 'Promoted to task from AI Strategy tab');
    try {
      const task = await db.task.create({
        data: {
          title: `[strategy] ${proposal.title}`.slice(0, 200),
          description:
            `Self-improvement proposal promoted from the AI Strategy tab.\n\n` +
            `Intent: ${proposal.intent}\n` +
            `Proposal ID: ${proposal.id}\n\n` +
            `Description:\n${proposal.description}\n\n` +
            `Plan (${proposal.plan?.steps?.length ?? 0} steps):\n` +
            (proposal.plan?.steps?.map((s) => `  ${s.order}. ${s.title} — ${s.description}`).join('\n') ?? ''),
          status: 'pending',
          priority: 'medium',
          assigneeId: null,
          tags: JSON.stringify(['self-improve', 'strategy', proposal.intent]),
        },
      });
      return NextResponse.json({ proposal, task });
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'strategy/proposals: promote task create failed');
      return NextResponse.json({ error: 'failed to create task', proposal }, { status: 500 });
    }
  }
  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}
