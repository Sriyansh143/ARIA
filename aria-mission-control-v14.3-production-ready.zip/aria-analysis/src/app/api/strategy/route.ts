import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// AI Strategy Advisor — GLM-4.6 analyzes the company's goals, fleet state,
// revenue, and recent activity to produce a strategic recommendation for the
// next planning horizon. Unlike the Mission Briefing (real-time situational),
// this is long-horizon strategic planning: SWOT-style analysis + a prioritized
// strategic initiative + KPI targets.

interface Strategy {
  generatedAt: string;
  horizon: string;
  headline: string;
  swot: { strengths: string[]; weaknesses: string[]; opportunities: string[]; threats: string[] };
  strategicInitiative: { title: string; rationale: string; steps: string[]; kpiTargets: string[] };
  focusAreas: string[];
}

export async function GET() {
  // Gather company state for the LLM.
  const [goals, agents, payments, tasks, earningMethods] = await Promise.all([
    db.goal.findMany({ select: { title: true, status: true, progress: true, category: true, horizon: true, priority: true }, take: 20, orderBy: { updatedAt: 'desc' } }),
    db.agent.findMany({ select: { codename: true, status: true, load: true, successRate: true, role: true } }),
    db.payment.groupBy({ by: ['status'], _sum: { amount: true } }),
    db.task.groupBy({ by: ['status'], _count: true }),
    db.earningMethod.findMany({ select: { name: true, category: true, approved: true, estimatedMonthly: true }, take: 10 }),
  ]);

  const confirmedRev = payments.filter((p) => p.status === 'confirmed').reduce((s, p) => s + (p._sum.amount ?? 0), 0);
  const pendingRev = payments.filter((p) => p.status === 'pending').reduce((s, p) => s + (p._sum.amount ?? 0), 0);
  const activeGoals = goals.filter((g) => g.status === 'in-progress').length;
  const completedGoals = goals.filter((g) => g.status === 'completed').length;
  const workingAgents = agents.filter((a) => a.status === 'working').length;
  const idleAgents = agents.filter((a) => a.status === 'idle').length;
  const avgSuccess = agents.length ? Math.round(agents.reduce((s, a) => s + a.successRate, 0) / agents.length * 10) / 10 : 0;
  const taskCounts = tasks.reduce((acc, t) => { acc[t.status] = t._count; return acc; }, {} as Record<string, number>);

  const context = `COMPANY STATE:
- Goals: ${goals.length} total (${activeGoals} in-progress, ${completedGoals} completed)
  Top goals: ${goals.slice(0, 5).map((g) => `${g.title.slice(0, 40)} (${g.progress}%)`).join(' | ') || 'none'}
- Fleet: ${agents.length} agents (${workingAgents} working, ${idleAgents} idle), avg success ${avgSuccess}%
- Revenue: ₹${confirmedRev} confirmed, ₹${pendingRev} pending
- Tasks: ${taskCounts['completed'] ?? 0} completed, ${taskCounts['in_progress'] ?? 0} in_progress, ${taskCounts['pending'] ?? 0} pending
- Earning methods: ${earningMethods.length} (${earningMethods.filter((e) => e.approved).length} approved)`;

  // Heuristic defaults.
  let headline = `Strategic focus: ${activeGoals > 0 ? 'advance the ' + activeGoals + ' active goal(s)' : 'define and pursue new revenue goals'}`;
  let swot: Strategy['swot'] = {
    strengths: [`${agents.length}-agent fleet with ${avgSuccess}% avg success rate`, `₹${confirmedRev} confirmed revenue`],
    weaknesses: idleAgents > 5 ? [`${idleAgents} agents idle — underutilized capacity`] : ['Limited goal tracking maturity'],
    opportunities: pendingRev > 0 ? [`₹${pendingRev} in pending revenue to convert`] : ['Expand earning-method portfolio'],
    threats: ['z-ai API rate-limiting may constrain autonomous operations'],
  };
  let strategicInitiative: Strategy['strategicInitiative'] = {
    title: 'Accelerate revenue realization + fleet utilization',
    rationale: `${idleAgents} idle agents + ₹${pendingRev} pending revenue = untapped capacity. Dispatch idle agents to follow up on pending payments and research new earning methods.`,
    steps: ['Follow up on all pending payments', 'Research 3 new earning methods', 'Assign idle agents to the highest-priority goal'],
    kpiTargets: ['Convert 50% of pending revenue to confirmed', 'Reduce idle agents to <5', 'Complete 2 goals this cycle'],
  };
  let focusAreas = ['Revenue conversion', 'Fleet utilization', 'Goal completion'];

  // LLM strategic synthesis.
  try {
    const sys = `You are ARIA, the strategic AI advisor for an autonomous AI company. Analyze the company state and produce a strategic recommendation. Respond as STRICT JSON:
{"headline": string (max 20 words), "swot": {"strengths": string[3-5], "weaknesses": string[2-4], "opportunities": string[2-4], "threats": string[2-3]}, "strategicInitiative": {"title": string, "rationale": string (max 100 words), "steps": string[3-5], "kpiTargets": string[2-4]}, "focusAreas": string[3-4]}
Each bullet max 12 words. No markdown, no prose outside JSON.`;
    const raw = await quickChat(`${context}\n\nProduce the strategic analysis.`, sys);
    const j = extractJson(raw);
    if (j) {
      if (typeof j.headline === 'string' && j.headline.trim()) headline = j.headline.trim().slice(0, 250);
      if (j.swot && typeof j.swot === 'object') {
        const arr = (v: unknown) => Array.isArray(v) ? v.filter((x) => typeof x === 'string').map((x) => String(x).slice(0, 160)).slice(0, 6) : [];
        swot = { strengths: arr(j.swot.strengths).length ? arr(j.swot.strengths) : swot.strengths, weaknesses: arr(j.swot.weaknesses).length ? arr(j.swot.weaknesses) : swot.weaknesses, opportunities: arr(j.swot.opportunities).length ? arr(j.swot.opportunities) : swot.opportunities, threats: arr(j.swot.threats).length ? arr(j.swot.threats) : swot.threats };
      }
      if (j.strategicInitiative && typeof j.strategicInitiative === 'object') {
        const arr = (v: unknown) => Array.isArray(v) ? v.filter((x) => typeof x === 'string').map((x) => String(x).slice(0, 160)).slice(0, 6) : [];
        strategicInitiative = {
          title: typeof j.strategicInitiative.title === 'string' ? j.strategicInitiative.title.slice(0, 200) : strategicInitiative.title,
          rationale: typeof j.strategicInitiative.rationale === 'string' ? j.strategicInitiative.rationale.slice(0, 500) : strategicInitiative.rationale,
          steps: arr(j.strategicInitiative.steps).length ? arr(j.strategicInitiative.steps) : strategicInitiative.steps,
          kpiTargets: arr(j.strategicInitiative.kpiTargets).length ? arr(j.strategicInitiative.kpiTargets) : strategicInitiative.kpiTargets,
        };
      }
      if (Array.isArray(j.focusAreas)) focusAreas = j.focusAreas.filter((x) => typeof x === 'string').map((x) => String(x).slice(0, 80)).slice(0, 5);
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'strategy: LLM synthesis failed, using heuristics');
  }

  const strategy: Strategy = {
    generatedAt: new Date().toISOString(),
    horizon: 'next cycle',
    headline,
    swot,
    strategicInitiative,
    focusAreas,
  };

  // Record to ActionLog for the Decision Log.
  try {
    await db.actionLog.create({
      data: {
        actor: 'aria',
        action: 'strategy.generated',
        category: 'autonomous',
        afterState: headline.slice(0, 300),
        reversible: false,
        meta: JSON.stringify({ headline: headline.slice(0, 140), focusAreas }),
      },
    });
  } catch { /* ignore */ }

  return NextResponse.json({ strategy });
}

function extractJson(text: string): any | null {
  if (!text) return null;
  let s = text.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) return null;
  try { return JSON.parse(s.slice(start, end + 1)); } catch { return null; }
}
