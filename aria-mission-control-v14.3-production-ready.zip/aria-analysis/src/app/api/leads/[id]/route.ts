import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { computeLeadScore } from '../route';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_STATUSES = new Set(['new', 'contacted', 'qualified', 'converted', 'lost']);

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const lead = await db.lead.findUnique({ where: { id } });
    if (!lead) return NextResponse.json({ error: 'not found' }, { status: 404 });
    return NextResponse.json({ lead: { ...lead, score: computeLeadScore(lead) } });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'fetch failed' },
      { status: 500 },
    );
  }
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json().catch(() => ({}));
    const data: Record<string, unknown> = {};
    if (typeof body.clientName === 'string') {
      if (body.clientName.trim().length === 0) {
        return NextResponse.json({ error: 'clientName cannot be empty' }, { status: 400 });
      }
      data.clientName = body.clientName.trim();
    }
    if (body.company !== undefined) data.company = body.company?.trim() || null;
    if (body.email !== undefined) data.email = body.email?.trim() || null;
    if (body.phone !== undefined) data.phone = body.phone?.trim() || null;
    if (body.source !== undefined) data.source = body.source?.trim() || 'web';
    if (body.notes !== undefined) data.notes = body.notes?.trim() || null;
    if (body.status !== undefined) {
      if (!ALLOWED_STATUSES.has(body.status)) {
        return NextResponse.json({ error: `invalid status: ${body.status}` }, { status: 400 });
      }
      data.status = body.status;
    }
    // Re-compute score from the merged fields so it stays accurate.
    const existing = await db.lead.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'not found' }, { status: 404 });
    const merged = { ...existing, ...data } as Record<string, unknown>;
    data.score = computeLeadScore({
      source: String(merged.source ?? 'web'),
      email: (merged.email as string | null) ?? null,
      phone: (merged.phone as string | null) ?? null,
      company: (merged.company as string | null) ?? null,
      notes: (merged.notes as string | null) ?? null,
    });
    const lead = await db.lead.update({ where: { id }, data });
    return NextResponse.json({ lead });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'update failed' },
      { status: 500 },
    );
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    await db.lead.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'delete failed' },
      { status: 500 },
    );
  }
}

/**
 * POST ?action=convert — promote a lead to a Client record.
 * Pulls contact details from the lead, creates a Client with status='lead'
 * (so the pipeline picks it up fresh) and marks the lead as 'converted'.
 */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const action = req.nextUrl.searchParams.get('action');
    if (action !== 'convert') {
      return NextResponse.json({ error: 'unknown action' }, { status: 400 });
    }
    const lead = await db.lead.findUnique({ where: { id } });
    if (!lead) return NextResponse.json({ error: 'not found' }, { status: 404 });
    if (lead.status === 'converted') {
      return NextResponse.json({ error: 'lead already converted' }, { status: 400 });
    }
    // Create the Client record from the lead's contact details.
    const client = await db.client.create({
      data: {
        name: lead.clientName,
        company: lead.company,
        email: lead.email,
        phone: lead.phone,
        status: 'lead',
        source: lead.source,
        value: 0,
        notes: lead.notes,
      },
    });
    // Mark the lead as converted.
    const updated = await db.lead.update({
      where: { id },
      data: { status: 'converted' },
    });
    return NextResponse.json({ client, lead: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'convert failed' },
      { status: 500 },
    );
  }
}
