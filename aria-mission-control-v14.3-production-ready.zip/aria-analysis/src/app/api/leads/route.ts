import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  sanitizeString,
  sanitizeEmail,
  sanitizePhone,
} from '@/lib/sanitize';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─── Lead scoring heuristic ──────────────────────────────────────────
// Score combines a "source weight" (referrals tend to convert higher than
// cold web traffic) with a "profile completeness" bonus for having email,
// phone, company and notes filled in. Clamped to 0..100.
const SOURCE_WEIGHTS: Record<string, number> = {
  referral: 70,
  outreach: 60,
  event: 55,
  ads: 45,
  social: 40,
  web: 35,
};

export function computeLeadScore(opts: {
  source: string;
  email?: string | null;
  phone?: string | null;
  company?: string | null;
  notes?: string | null;
}): number {
  const base = SOURCE_WEIGHTS[opts.source] ?? 35;
  let bonus = 0;
  if (opts.email && opts.email.trim().length > 0) bonus += 12;
  if (opts.phone && opts.phone.trim().length > 0) bonus += 10;
  if (opts.company && opts.company.trim().length > 0) bonus += 8;
  if (opts.notes && opts.notes.trim().length > 0) bonus += 5;
  return Math.max(0, Math.min(100, base + bonus));
}

const ALLOWED_STATUSES = new Set(['new', 'contacted', 'qualified', 'converted', 'lost']);

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get('status');
    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    const leads = await db.lead.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
    // Re-score every lead on read — source/profile may have changed since
    // creation, so we keep the persisted score in sync opportunistically.
    const scored = leads.map((l) => {
      const score = computeLeadScore(l);
      return { ...l, score };
    });
    // Stats
    const byStatus = await db.lead.groupBy({ by: ['status'], _count: true });
    const counts: Record<string, number> = {};
    for (const row of byStatus) counts[row.status] = row._count;
    const newCount = counts['new'] ?? 0;
    const qualifiedCount = counts['qualified'] ?? 0;
    const convertedCount = counts['converted'] ?? 0;
    const totalLeads = Object.values(counts).reduce((a, b) => a + b, 0);
    // Conversion rate = converted / (converted + lost) — leads that have
    // reached a terminal state. If none yet, fall back to converted/total.
    const lostCount = counts['lost'] ?? 0;
    const terminal = convertedCount + lostCount;
    const conversionRate = terminal > 0
      ? Math.round((convertedCount / terminal) * 100)
      : totalLeads > 0
        ? Math.round((convertedCount / totalLeads) * 100)
        : 0;
    return NextResponse.json({
      leads: scored,
      stats: {
        total: totalLeads,
        newCount,
        qualifiedCount,
        convertedCount,
        lostCount,
        conversionRate,
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'fetch failed' },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { clientName, company, email, phone, source, notes } = body as {
      clientName?: string;
      company?: string;
      email?: string;
      phone?: string;
      source?: string;
      notes?: string;
    };

    // ── Required field: clientName ──
    const safeClientName = sanitizeString(clientName, 200);
    if (!safeClientName) {
      return NextResponse.json(
        { error: 'clientName required (non-empty string, max 200 chars)' },
        { status: 400 },
      );
    }

    // ── Optional string fields ──
    const safeCompany = company != null ? sanitizeString(company, 200) : null;
    if (company != null && safeCompany === null) {
      return NextResponse.json({ error: 'company must be a non-empty string' }, { status: 400 });
    }
    const safeSource = source != null ? sanitizeString(source, 100) : null;
    if (source != null && safeSource === null) {
      return NextResponse.json({ error: 'source must be a non-empty string' }, { status: 400 });
    }
    const finalSource = safeSource ?? 'web';
    const safeNotes = notes != null ? sanitizeString(notes, 2000) : null;
    if (notes != null && safeNotes === null) {
      return NextResponse.json(
        { error: 'notes must be a non-empty string (max 2000 chars)' },
        { status: 400 },
      );
    }

    // ── Email — validate format only when non-empty value is provided ──
    let safeEmail: string | null = null;
    if (typeof email === 'string' && email.trim().length > 0) {
      safeEmail = sanitizeEmail(email);
      if (!safeEmail) {
        return NextResponse.json({ error: 'email format is invalid' }, { status: 400 });
      }
    } else if (email != null && typeof email !== 'string') {
      return NextResponse.json({ error: 'email must be a string' }, { status: 400 });
    }

    // ── Phone — validate format only when non-empty value is provided ──
    let safePhone: string | null = null;
    if (typeof phone === 'string' && phone.trim().length > 0) {
      safePhone = sanitizePhone(phone);
      if (!safePhone) {
        return NextResponse.json({ error: 'phone format is invalid' }, { status: 400 });
      }
    } else if (phone != null && typeof phone !== 'string') {
      return NextResponse.json({ error: 'phone must be a string' }, { status: 400 });
    }

    // Defensive enum check on `status` — existing behavior always persists
    // 'new' on creation; this just rejects obviously-abusive values.
    if (
      'status' in body &&
      body.status != null &&
      typeof body.status === 'string' &&
      body.status.trim().length > 0 &&
      !ALLOWED_STATUSES.has(body.status)
    ) {
      return NextResponse.json(
        { error: `invalid status: ${body.status}` },
        { status: 400 },
      );
    }

    const score = computeLeadScore({
      source: finalSource,
      email: safeEmail,
      phone: safePhone,
      company: safeCompany,
      notes: safeNotes,
    });
    const lead = await db.lead.create({
      data: {
        clientName: safeClientName,
        company: safeCompany,
        email: safeEmail,
        phone: safePhone,
        source: finalSource,
        notes: safeNotes,
        score,
        status: 'new',
      },
    });
    return NextResponse.json({ lead });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'create failed' },
      { status: 500 },
    );
  }
}
