import { NextRequest, NextResponse } from 'next/server';
import { readdirSync, statSync } from 'fs';
import { resolve, relative, isAbsolute, sep } from 'path';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Workspace listing endpoint.
//
// Lists directory entries inside the workspace root.
// Returns each entry with: name, type (dir|file), size (bytes).
// ─────────────────────────────────────────────────────────────────────

const WORKSPACE_ROOT = resolve(process.cwd());

// Hidden / build artifact directories we hide from the listing for clarity.
const HIDDEN_DIRS = new Set([
  'node_modules',
  '.git',
  '.next',
  '.cache',
  'dist',
  'build',
]);

function isInsideWorkspace(target: string): boolean {
  const rel = relative(WORKSPACE_ROOT, target);
  if (rel === '') return true;
  return !rel.startsWith('..' + sep) && !isAbsolute(rel);
}

export async function POST(req: NextRequest) {
  let path = '';
  try {
    const body = await req.json().catch(() => ({}));
    path = typeof body?.path === 'string' ? body.path : '';
  } catch {
    // ignore
  }

  // Default to workspace root.
  if (!path.trim()) path = '.';

  const resolved = resolve(WORKSPACE_ROOT, path);
  if (!isInsideWorkspace(resolved)) {
    return NextResponse.json(
      { error: 'path must be within workspace root' },
      { status: 403 },
    );
  }

  let entries: import('fs').Dirent[];
  try {
    entries = readdirSync(resolved, { withFileTypes: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'list failed' },
      { status: 500 },
    );
  }

  const items = entries
    .filter((e) => {
      // Hide noisy directories.
      if (e.isDirectory() && HIDDEN_DIRS.has(e.name)) return false;
      // Hide dotfiles from the listing root for clarity.
      if (e.name.startsWith('.')) return false;
      return true;
    })
    .map((e) => {
      let size = 0;
      try {
        if (e.isFile()) size = statSync(resolve(resolved, e.name)).size;
      } catch {
        size = 0;
      }
      return {
        name: e.name,
        type: e.isDirectory() ? 'dir' : 'file',
        size,
      };
    })
    .sort((a, b) => {
      // Directories first, then alphabetical.
      if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

  await logAction({
    actor: 'operator',
    action: 'workspace.list',
    category: 'read',
    target: path,
    afterState: { count: items.length },
    reversible: false,
  }).catch(() => {});

  return NextResponse.json({
    path,
    resolvedPath: resolved,
    items,
    count: items.length,
  });
}
