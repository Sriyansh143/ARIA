import { NextRequest, NextResponse } from 'next/server';
import { checkService, SERVICE_REGISTRY, type ServiceHealth } from '@/lib/service-health-checks';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─── POST /api/service-health/check ──────────────────────────────────
// Body: { service: string }
// Re-probes ONE service and returns the fresh ServiceHealth record.
// Used by the per-card "Re-check" buttons on the ServiceHealth tab.
export async function POST(req: NextRequest) {
  let body: { service?: string } = {};
  try {
    body = await req.json();
  } catch {
    // ignore — body is optional
  }

  const service = (body.service ?? '').trim();
  if (!service) {
    return NextResponse.json(
      { error: 'Missing "service" in request body' },
      { status: 400 },
    );
  }

  const known = (SERVICE_REGISTRY as readonly string[]).includes(service);
  if (!known) {
    return NextResponse.json(
      {
        health: {
          service,
          status: 'unknown',
          latencyMs: 0,
          lastCheckedAt: new Date().toISOString(),
          error: `Unknown service: ${service}`,
        } satisfies ServiceHealth,
      },
      { status: 404 },
    );
  }

  try {
    const health = await checkService(service);
    return NextResponse.json({ health });
  } catch (err) {
    const health: ServiceHealth = {
      service,
      status: 'down',
      latencyMs: 0,
      lastCheckedAt: new Date().toISOString(),
      error: err instanceof Error ? err.message : String(err),
    };
    return NextResponse.json({ health }, { status: 500 });
  }
}
