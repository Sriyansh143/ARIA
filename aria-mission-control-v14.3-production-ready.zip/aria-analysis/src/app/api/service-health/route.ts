import { NextResponse } from 'next/server';
import {
  checkAllServices,
  getHealthHistory,
  SERVICE_REGISTRY,
  type ServiceHealth,
} from '@/lib/service-health-checks';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─── GET /api/service-health ─────────────────────────────────────────
// Returns the current health of all 8 services + the last 20 history
// records per service (for sparklines). Probes run on every GET so the
// dashboard sees fresh data on each 15s poll.
export async function GET() {
  try {
    const services: ServiceHealth[] = await checkAllServices();
    const history: Record<string, ServiceHealth[]> = {};
    for (const svc of SERVICE_REGISTRY) {
      history[svc] = getHealthHistory(svc, 20);
    }
    return NextResponse.json({
      services,
      history,
      sampledAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json(
      {
        services: [],
        history: {},
        error: err instanceof Error ? err.message : String(err),
      },
      { status: 500 },
    );
  }
}
