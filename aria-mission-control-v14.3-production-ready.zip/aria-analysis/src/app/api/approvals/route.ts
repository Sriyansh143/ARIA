import { NextRequest, NextResponse } from 'next/server';
import {
  createApproval,
  listApprovals,
  getApprovalStats,
} from '@/lib/approval-escalation';
import {
  sanitizeString,
  sanitizeNumber,
  stripDangerousKeys,
} from '@/lib/sanitize';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Approvals collection endpoint.
//
// GET  — list approvals (optional ?status=pending|approved|rejected|expired)
//        + aggregate stats (calls getApprovalStats).
// POST — create a new approval request (calls createApproval).
// ─────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || undefined;
  const category = searchParams.get('category') || undefined;

  const [approvals, stats] = await Promise.all([
    listApprovals({ status, category, limit: 100 }),
    getApprovalStats(),
  ]);

  // Avg response time (over resolved approvals in last 7 days).
  // Computed in JS because SQLite date math via Prisma is awkward.
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const resolvedRows = (approvals as Array<{
    status: string;
    resolvedAt: Date | null;
    createdAt: Date;
  }>).filter(
    (a) =>
      (a.status === 'approved' || a.status === 'rejected') &&
      a.resolvedAt &&
      a.resolvedAt >= sevenDaysAgo,
  );
  const avgResponseMs = resolvedRows.length
    ? resolvedRows.reduce((s, a) => s + (a.resolvedAt!.getTime() - a.createdAt.getTime()), 0) /
      resolvedRows.length
    : 0;

  // Approved / rejected today counts.
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const approvedToday = (approvals as Array<{ status: string; resolvedAt: Date | null }>).filter(
    (a) => a.status === 'approved' && a.resolvedAt && a.resolvedAt >= startOfToday,
  ).length;
  const rejectedToday = (approvals as Array<{ status: string; resolvedAt: Date | null }>).filter(
    (a) => a.status === 'rejected' && a.resolvedAt && a.resolvedAt >= startOfToday,
  ).length;

  return NextResponse.json({
    approvals,
    stats,
    derived: {
      approvedToday,
      rejectedToday,
      avgResponseMs,
      avgResponseMin: Math.round(avgResponseMs / 60000),
    },
  });
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown> = {};
  try {
    body = await req.json().catch(() => ({}));
  } catch {
    // ignore
  }

  // ── Required: title (max 200), description (max 5000) ──
  const title = sanitizeString(body.title, 200);
  if (!title) {
    return NextResponse.json(
      { error: 'title required (non-empty string, max 200 chars)' },
      { status: 400 },
    );
  }
  const description = sanitizeString(body.description, 5000);
  if (!description) {
    return NextResponse.json(
      { error: 'description required (non-empty string, max 5000 chars)' },
      { status: 400 },
    );
  }

  // ── Optional: category (string) ──
  let category: string | undefined;
  if (body.category != null) {
    category = sanitizeString(body.category, 100) ?? undefined;
    if (body.category != null && category === undefined) {
      return NextResponse.json(
        { error: 'category must be a non-empty string (max 100 chars)' },
        { status: 400 },
      );
    }
  }

  // ── Optional: requestedBy (string) ──
  let requestedBy: string | undefined;
  if (body.requestedBy != null) {
    requestedBy = sanitizeString(body.requestedBy, 100) ?? undefined;
    if (body.requestedBy != null && requestedBy === undefined) {
      return NextResponse.json(
        { error: 'requestedBy must be a non-empty string (max 100 chars)' },
        { status: 400 },
      );
    }
  }

  // ── Optional: payload (object) — strip dangerous keys (__proto__, etc.) ──
  let payload: Record<string, unknown> | undefined;
  if (body.payload != null) {
    if (
      typeof body.payload !== 'object' ||
      Array.isArray(body.payload) ||
      body.payload === null
    ) {
      return NextResponse.json(
        { error: 'payload must be an object' },
        { status: 400 },
      );
    }
    payload = stripDangerousKeys(body.payload as Record<string, unknown>);
  }

  // ── Optional: timeoutMinutes (number, defensive bounds) ──
  let timeoutMinutes: number | undefined;
  if (body.timeoutMinutes != null) {
    const safe = sanitizeNumber(body.timeoutMinutes, { min: 1, max: 1440 });
    if (safe === null) {
      return NextResponse.json(
        { error: 'timeoutMinutes must be a number between 1 and 1440' },
        { status: 400 },
      );
    }
    timeoutMinutes = safe;
  }

  const id = await createApproval({
    title,
    description,
    category,
    requestedBy,
    payload,
    timeoutMinutes,
  });

  return NextResponse.json({ id, ok: true });
}
