import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { resolveApproval } from '@/lib/approval-escalation';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Single-approval endpoints.
//
// GET  — fetch a single approval by ID.
// POST — resolve an approval (decision: approved|rejected) — also logs
//        the action to the ActionLog for audit.
// ─────────────────────────────────────────────────────────────────────

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 });

  const approval = await db.approvalRequest.findUnique({ where: { id } });
  if (!approval) return NextResponse.json({ error: 'not found' }, { status: 404 });

  return NextResponse.json({ approval });
}

export async function POST(req: NextRequest, { params }: Params) {
  const { id } = await params;
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 });

  let body: Record<string, unknown> = {};
  try {
    body = await req.json().catch(() => ({}));
  } catch {
    // ignore
  }

  const decision = body.decision;
  if (decision !== 'approved' && decision !== 'rejected') {
    return NextResponse.json(
      { error: 'decision must be "approved" or "rejected"' },
      { status: 400 },
    );
  }
  const decidedBy = typeof body.decidedBy === 'string' ? body.decidedBy.trim() : '';
  if (!decidedBy) {
    return NextResponse.json({ error: 'decidedBy required' }, { status: 400 });
  }
  const decisionNote =
    typeof body.decisionNote === 'string' ? body.decisionNote.trim() : undefined;

  // Capture before state for audit log.
  const before = await db.approvalRequest.findUnique({ where: { id } });
  if (!before) return NextResponse.json({ error: 'not found' }, { status: 404 });
  if (before.status !== 'pending') {
    return NextResponse.json(
      { error: `approval already ${before.status}` },
      { status: 409 },
    );
  }

  const result = await resolveApproval(id, decision, decidedBy, decisionNote);

  await logAction({
    actor: decidedBy,
    action: `approval.${decision}`,
    category: 'mutation',
    target: id,
    beforeState: { status: before.status, escalationLevel: before.escalationLevel },
    afterState: { decision, note: decisionNote ?? null },
    reversible: false,
    meta: { title: before.title, category: before.category },
  }).catch(() => {});

  return NextResponse.json(result);
}
