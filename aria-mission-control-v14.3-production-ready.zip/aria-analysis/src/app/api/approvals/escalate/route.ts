import { NextRequest, NextResponse } from 'next/server';
import { escalatePendingApprovals } from '@/lib/approval-escalation';
import { logAction } from '@/lib/action-log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ─────────────────────────────────────────────────────────────────────
// Manual escalation sweep.
//
// POST — runs escalatePendingApprovals() to advance any pending
//        approvals whose nextEscalateAt has passed. Returns the count
//        of escalated requests + per-approval channel details.
// ─────────────────────────────────────────────────────────────────────

export async function POST(_req: NextRequest) {
  const result = await escalatePendingApprovals();

  await logAction({
    actor: 'operator',
    action: 'approval.escalate.manual',
    category: 'mutation',
    target: 'approval-queue',
    afterState: { escalated: result.escalated, details: result.details },
    reversible: false,
  }).catch(() => {});

  return NextResponse.json({
    ok: true,
    escalated: result.escalated,
    details: result.details,
  });
}
