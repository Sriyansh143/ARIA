import { NextRequest, NextResponse } from 'next/server';
import { listRecentThinkingSessions } from '@/lib/llm';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — recent thinking/reasoning sessions (the AI's thought trail).
// Query: ?limit=20
export async function GET(req: NextRequest) {
  const limit = Number(req.nextUrl.searchParams.get('limit') ?? 20);
  const sessions = await listRecentThinkingSessions(limit);
  return NextResponse.json({ sessions, count: sessions.length });
}
