import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/revenue/dashboard — consolidated revenue + cost + profit dashboard.
// Aggregates: confirmed payments, skill-learning earnings, earning-method projections,
// estimated LLM costs (based on token usage + model pricing), and net profit.
export async function GET() {
  const [payments, skillLearnings, earningMethods, telemetry, agents] = await Promise.all([
    db.payment.findMany({
      select: { amount: true, status: true, method: true, currency: true, createdAt: true },
      take: 500,
    }),
    db.skillLearning.findMany({
      select: { earnings: true, agentCodename: true, skillKey: true, proficiency: true },
    }),
    db.earningMethod.findMany({
      where: { approved: true },
      select: { key: true, name: true, category: true, estimatedMonthly: true, earningPotential: true, totalEarnings: true, executionCount: true },
    }),
    db.telemetry.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { tokens: true, createdAt: true },
    }),
    db.agent.findMany({
      select: { codename: true, taskCount: true, successRate: true, load: true },
    }),
  ]);

  // ── Revenue ──
  const confirmedPayments = payments.filter((p) => p.status === 'confirmed');
  const pendingPayments = payments.filter((p) => p.status === 'pending');
  const failedPayments = payments.filter((p) => p.status === 'failed');
  const refundedPayments = payments.filter((p) => p.status === 'refunded');

  const confirmedRevenue = confirmedPayments.reduce((s, p) => s + p.amount, 0);
  const pendingRevenue = pendingPayments.reduce((s, p) => s + p.amount, 0);
  const refundedAmount = refundedPayments.reduce((s, p) => s + p.amount, 0);

  // Skill-learning earnings (agent output value)
  const skillEarningsTotal = skillLearnings.reduce((s, sl) => s + sl.earnings, 0);

  // Earning method projections (monthly)
  const projectedMonthly = earningMethods.reduce((s, m) => s + (m.estimatedMonthly || 0), 0);
  const earningMethodTotalEarnings = earningMethods.reduce((s, m) => s + (m.totalEarnings || 0), 0);

  // Revenue by method
  const revenueByMethod: Record<string, number> = {};
  for (const p of confirmedPayments) {
    revenueByMethod[p.method] = (revenueByMethod[p.method] ?? 0) + p.amount;
  }

  // Revenue by day (last 7 days)
  const now = new Date();
  const dailyRevenue: Array<{ day: string; revenue: number; count: number }> = [];
  for (let d = 6; d >= 0; d--) {
    const dayStart = new Date(now.getTime() - d * 24 * 60 * 60 * 1000);
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
    const dayPayments = confirmedPayments.filter((p) => {
      const pd = new Date(p.createdAt);
      return pd >= dayStart && pd < dayEnd;
    });
    dailyRevenue.push({
      day: dayStart.toLocaleDateString('en-US', { weekday: 'short' }),
      revenue: Math.round(dayPayments.reduce((s, p) => s + p.amount, 0)),
      count: dayPayments.length,
    });
  }

  // ── Costs (estimated) ──
  // LLM token cost: GLM-4.6 pricing ≈ ₹0.5 per 1K tokens (rough estimate).
  // Sum recent token usage × rate.
  const TOKEN_RATE_PER_1K = 0.5; // ₹ per 1K tokens
  const recentTokens = telemetry.reduce((s, t) => s + (t.tokens || 0), 0);
  const llmCost = Math.round((recentTokens / 1000) * TOKEN_RATE_PER_1K);

  // Infrastructure cost: estimated ₹5000/month for sandbox + DB + realtime.
  const infraCostMonthly = 5000;
  // Prorate to daily
  const infraCostDaily = Math.round(infraCostMonthly / 30);

  // Agent cost: each working agent consumes ~₹50/day in LLM calls
  const workingAgents = agents.filter((a) => a.load > 20).length;
  const agentCostDaily = workingAgents * 50;

  const totalDailyCost = infraCostDaily + agentCostDaily + Math.round(llmCost / 30);

  // ── Profit ──
  const totalRevenue = confirmedRevenue + skillEarningsTotal;
  const totalCost = totalDailyCost * 30; // monthly cost projection
  const netProfit = totalRevenue - totalCost;
  const profitMargin = totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0;

  // ── Earning method breakdown ──
  const earningMethodBreakdown = earningMethods.map((m) => ({
    key: m.key,
    name: m.name,
    category: m.category,
    estimatedMonthly: m.estimatedMonthly,
    earningPotential: m.earningPotential,
    totalEarnings: m.totalEarnings,
    executionCount: m.executionCount,
  })).sort((a, b) => (b.estimatedMonthly ?? 0) - (a.estimatedMonthly ?? 0));

  // ── Top earning agents ──
  const agentEarningsMap = new Map<string, number>();
  for (const sl of skillLearnings) {
    agentEarningsMap.set(sl.agentCodename, (agentEarningsMap.get(sl.agentCodename) ?? 0) + sl.earnings);
  }
  const topEarningAgents = Array.from(agentEarningsMap.entries())
    .map(([agent, earnings]) => ({ agent, earnings: Math.round(earnings) }))
    .sort((a, b) => b.earnings - a.earnings)
    .slice(0, 10);

  return NextResponse.json({
    revenue: {
      confirmed: Math.round(confirmedRevenue),
      pending: Math.round(pendingRevenue),
      refunded: Math.round(refundedAmount),
      skillEarnings: Math.round(skillEarningsTotal),
      projectedMonthly: Math.round(projectedMonthly),
      earningMethodTotal: Math.round(earningMethodTotalEarnings),
      total: Math.round(totalRevenue),
      byMethod: Object.fromEntries(Object.entries(revenueByMethod).map(([k, v]) => [k, Math.round(v)])),
      daily: dailyRevenue,
    },
    costs: {
      llmCost: Math.round(llmCost),
      infraMonthly: infraCostMonthly,
      infraDaily: infraCostDaily,
      agentDaily: agentCostDaily,
      workingAgents,
      totalDaily: totalDailyCost,
      totalMonthly: totalCost,
    },
    profit: {
      netProfit: Math.round(netProfit),
      margin: profitMargin,
      totalRevenue: Math.round(totalRevenue),
      totalCost: Math.round(totalCost),
    },
    earningMethods: earningMethodBreakdown,
    topEarningAgents,
    paymentCounts: {
      confirmed: confirmedPayments.length,
      pending: pendingPayments.length,
      failed: failedPayments.length,
      refunded: refundedPayments.length,
      total: payments.length,
    },
  });
}
