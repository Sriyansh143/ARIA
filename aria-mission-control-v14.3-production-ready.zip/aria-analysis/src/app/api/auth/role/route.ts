import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — returns the current role (default: owner)
export async function GET() {
  return NextResponse.json({ role: 'owner', isOwner: true });
}
