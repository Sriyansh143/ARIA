import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { runScheduledAutonomyById } from '@/lib/scheduled-autonomy-runner';

export const dynamic = 'force-dynamic';
export const maxDuration = 120;

// PATCH — toggle enabled / update interval / set skillKey.
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const data: Record<string, unknown> = {};
  if (typeof body.enabled === 'boolean') data.enabled = body.enabled;
  if (typeof body.intervalMin === 'number') data.intervalMin = body.intervalMin;
  if (typeof body.skillKey === 'string') data.skillKey = body.skillKey || null;
  const schedule = await db.scheduledAutonomy.update({ where: { id }, data });
  return NextResponse.json({ schedule });
}

// DELETE — remove a scheduled autonomy loop.
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.scheduledAutonomy.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

// POST — trigger the scheduled autonomy loop NOW (run it immediately).
// This is also the "agent training" executor: the shared runner honors the
// training cooldown (no repetitive training) and records a training run
// (proficiency bump, agent skills update, successRate nudge) on success.
export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const result = await runScheduledAutonomyById(id);
    if ('error' in result) {
      return NextResponse.json({ error: result.error }, { status: result.status });
    }
    return NextResponse.json(result);
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'scheduled-autonomy POST failed');
    return NextResponse.json({ error: err instanceof Error ? err.message : 'run failed' }, { status: 500 });
  }
}
