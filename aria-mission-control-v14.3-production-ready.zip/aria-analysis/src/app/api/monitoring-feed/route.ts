import { NextResponse } from 'next/server';
import { getTabInventoryForAgents, getTabInventorySummary } from '@/lib/monitoring-agent-feed';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — returns the full tab inventory for monitor agents
export async function GET() {
  return NextResponse.json({
    tabs: getTabInventoryForAgents(),
    summary: getTabInventorySummary(),
    totalTabs: getTabInventoryForAgents().length,
  });
}
