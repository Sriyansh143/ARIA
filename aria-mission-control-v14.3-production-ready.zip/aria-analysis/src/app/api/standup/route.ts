import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Daily Standup — ARIA writes a concise narrative standup of the autonomous
// company's last 24h: what was accomplished, what's in progress, what's
// blocked, and the next priorities. Uses quickChat (reliable, no pro-scaffold
// overhead) so it works even under rate-limit pressure.

interface Standup {
  generatedAt: string;
  windowHours: number;
  headline: string;
  sections: { accomplished: string[]; inProgress: string[]; blocked: string[]; nextPriorities: string[] };
  stats: {
    tasksCompleted: number;
    tasksCreated: number;
    agentLogs: number;
    paymentsConfirmed: number;
    revenueConfirmed: number;
    autopilotCycles: number;
  };
}

export async function GET() {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [completedTasks, createdTasks, agentLogs, payments, autopilotLogs] = await Promise.all([
    db.task.findMany({ where: { status: 'completed', updatedAt: { gte: since } }, select: { title: true, priority: true, assignee: { select: { codename: true } } }, take: 12, orderBy: { updatedAt: 'desc' } }),
    db.task.findMany({ where: { createdAt: { gte: since } }, select: { title: true, status: true, priority: true }, take: 12, orderBy: { createdAt: 'desc' } }),
    db.agentLog.findMany({ where: { createdAt: { gte: since } }, select: { message: true, level: true, agent: { select: { codename: true } } }, take: 20, orderBy: { createdAt: 'desc' } }),
    db.payment.findMany({ where: { status: 'confirmed', createdAt: { gte: since } }, select: { amount: true, method: true, payer: true } }),
    db.agentLog.findMany({ where: { createdAt: { gte: since }, message: { contains: 'Autopilot' } }, select: { message: true, createdAt: true } }),
  ]);

  const revenueConfirmed = payments.reduce((s, p) => s + p.amount, 0);
  const inProgressTasks = createdTasks.filter((t) => t.status === 'in_progress');
  const pendingTasks = createdTasks.filter((t) => t.status === 'pending');
  const blockedTasks = createdTasks.filter((t) => t.status === 'blocked');

  const stats: Standup['stats'] = {
    tasksCompleted: completedTasks.length,
    tasksCreated: createdTasks.length,
    agentLogs: agentLogs.length,
    paymentsConfirmed: payments.length,
    revenueConfirmed,
    autopilotCycles: autopilotLogs.length,
  };

  // Build a compact context block for the LLM.
  const ctx = `LAST 24h COMPANY ACTIVITY:
- Tasks completed: ${completedTasks.length} — ${completedTasks.slice(0, 6).map((t) => t.title.slice(0, 50)).join(' | ') || 'none'}
- Tasks created: ${createdTasks.length} — ${createdTasks.slice(0, 6).map((t) => t.title.slice(0, 50)).join(' | ') || 'none'}
- In progress: ${inProgressTasks.length}, Pending: ${pendingTasks.length}, Blocked: ${blockedTasks.length}
- Payments confirmed: ${payments.length} (₹${revenueConfirmed}) — ${payments.slice(0, 4).map((p) => `₹${p.amount} ${p.payer}`).join(', ') || 'none'}
- Autopilot cycles run: ${autopilotLogs.length}
- Recent agent logs (${agentLogs.length}): ${agentLogs.slice(0, 8).map((l) => `[${l.agent?.codename ?? '?'}:${l.level}] ${l.message.slice(0, 60)}`).join(' | ').slice(0, 700)}`;

  // ── Heuristic defaults (always present) ─────────────────────────────
  const accomplished = completedTasks.slice(0, 4).map((t) => `${t.title}${t.assignee?.codename ? ` (${t.assignee.codename})` : ''}`);
  if (payments.length) accomplished.push(`Confirmed ₹${revenueConfirmed.toLocaleString()} across ${payments.length} payment(s)`);
  if (autopilotLogs.length) accomplished.push(`Ran ${autopilotLogs.length} autopilot cycle(s)`);
  const inProgress = inProgressTasks.slice(0, 4).map((t) => t.title);
  if (!inProgress.length && pendingTasks.length) inProgress.push(`${pendingTasks.length} task(s) queued for dispatch`);
  const blocked = blockedTasks.slice(0, 3).map((t) => t.title);
  const nextPriorities: string[] = [];
  if (pendingTasks.length) nextPriorities.push(`Dispatch ${pendingTasks.length} pending task(s) to idle agents`);
  if (revenueConfirmed === 0) nextPriorities.push('No revenue confirmed in 24h — pursue earning methods');
  if (!nextPriorities.length) nextPriorities.push('Continue autonomous execution and monitor fleet health');

  let headline = `24h summary: ${completedTasks.length} tasks completed, ₹${revenueConfirmed} revenue, ${autopilotLogs.length} autopilot cycles`;
  let sections: Standup['sections'] = { accomplished, inProgress, blocked, nextPriorities };

  // ── LLM narrative enhancement (best-effort, 15s timeout) ───────────
  // If the LLM takes >15s (rate-limited / overloaded), fall back to heuristics
  // so the standup route always returns within a reasonable time.
  try {
    const sys = `You are ARIA, the autonomous company's AI. Write a crisp daily standup based on the last 24h of activity. Respond as STRICT JSON:
{"headline": string (max 18 words, one sentence summarizing the day), "accomplished": string[] (3-5 bullet items, each max 12 words), "inProgress": string[] (2-4 items), "blocked": string[] (0-3 items, empty if none), "nextPriorities": string[] (2-3 items)}
Be concrete and specific. No markdown, no prose outside the JSON.`;
    // Race the LLM call against a 15s timeout — prevents the route from
    // hanging for 60s+ under rate-limit pressure.
    const raw = await Promise.race([
      quickChat(`${ctx}\n\nWrite today's standup.`, sys),
      new Promise<string>((_, reject) => setTimeout(() => reject(new Error('LLM timeout')), 15_000)),
    ]);
    const j = extractJson(raw);
    if (j) {
      if (typeof j.headline === 'string' && j.headline.trim()) headline = j.headline.trim().slice(0, 200);
      const arr = (v: unknown) => Array.isArray(v) ? v.filter((x) => typeof x === 'string').map((x) => String(x).slice(0, 160)) : [];
      const llmSections = {
        accomplished: arr(j.accomplished).length ? arr(j.accomplished) : accomplished,
        inProgress: arr(j.inProgress).length ? arr(j.inProgress) : inProgress,
        blocked: arr(j.blocked).length ? arr(j.blocked) : blocked,
        nextPriorities: arr(j.nextPriorities).length ? arr(j.nextPriorities) : nextPriorities,
      };
      sections = llmSections;
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'standup: LLM enhancement failed/timed out, using heuristics');
  }

  const standup: Standup = {
    generatedAt: new Date().toISOString(),
    windowHours: 24,
    headline,
    sections,
    stats,
  };

  // Record an ActionLog entry for the Decision Log (one per standup generation).
  try {
    await db.actionLog.create({
      data: {
        actor: 'aria',
        action: 'standup.generated',
        category: 'autonomous',
        afterState: headline.slice(0, 300),
        reversible: false,
        meta: JSON.stringify({
          headline: headline.slice(0, 140),
          accomplished: sections.accomplished.length,
          inProgress: sections.inProgress.length,
          blocked: sections.blocked.length,
          nextPriorities: sections.nextPriorities.length,
          stats,
        }),
      },
    });
  } catch { /* ignore */ }

  return NextResponse.json({ standup });
}

function extractJson(text: string): any | null {
  if (!text) return null;
  let s = text.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) return null;
  try { return JSON.parse(s.slice(start, end + 1)); } catch { return null; }
}
