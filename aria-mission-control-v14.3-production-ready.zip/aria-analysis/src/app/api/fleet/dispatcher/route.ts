import { NextResponse } from 'next/server';
import { getDispatcherStatus } from '@/lib/idle-agent-dispatcher';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/fleet/dispatcher — idle-agent dispatcher status (5s ticker).
export async function GET() {
  const status = getDispatcherStatus();
  return NextResponse.json({ ...status, description: 'Detects idle agents every 5s, creates tasks from earning methods, dispatches pending tasks.' });
}
