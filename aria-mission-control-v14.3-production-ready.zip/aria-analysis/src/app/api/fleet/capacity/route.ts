import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/fleet/capacity — fleet capacity analysis for the planner.
// Returns current utilization, headroom, rebalancing recommendations, and
// what-if scenarios for scaling.
export async function GET(req: NextRequest) {
  const [agents, tasks, telemetry] = await Promise.all([
    db.agent.findMany({
      select: {
        codename: true, name: true, role: true, status: true,
        load: true, successRate: true, taskCount: true, logCount: true,
      },
    }),
    db.task.findMany({
      select: { status: true, priority: true, assigneeId: true },
      take: 500,
    }),
    db.telemetry.findMany({ orderBy: { createdAt: 'desc' }, take: 1 }),
  ]);

  const totalAgents = agents.length;
  const idle = agents.filter((a) => a.status === 'idle' && a.load < 20);
  const active = agents.filter((a) => a.status === 'working' || a.status === 'thinking');
  const errorAgents = agents.filter((a) => a.status === 'error');
  const overloaded = agents.filter((a) => a.load > 70);
  const nearCapacity = agents.filter((a) => a.load > 50 && a.load <= 70);

  // Total fleet capacity: each agent can handle ~100 load units.
  const totalCapacity = totalAgents * 100;
  const usedCapacity = agents.reduce((s, a) => s + a.load, 0);
  const utilizationPct = totalCapacity > 0 ? (usedCapacity / totalCapacity) * 100 : 0;
  const headroom = totalCapacity - usedCapacity;

  // Task backlog
  const pendingTasks = tasks.filter((t) => t.status === 'pending');
  const inProgressTasks = tasks.filter((t) => t.status === 'in_progress');
  const blockedTasks = tasks.filter((t) => t.status === 'blocked');
  const criticalPending = pendingTasks.filter((t) => t.priority === 'critical');
  const highPending = pendingTasks.filter((t) => t.priority === 'high');

  // Estimated dispatch capacity: each idle agent can take ~3 tasks
  const dispatchCapacity = idle.length * 3;
  const backlogRatio = pendingTasks.length / Math.max(1, dispatchCapacity);

  // Rebalancing recommendations
  const recommendations: Array<{
    type: 'rebalance' | 'scale-out' | 'scale-in' | 'dispatch' | 'investigate';
    title: string;
    detail: string;
    impact: 'low' | 'medium' | 'high';
    agents?: string[];
  }> = [];

  if (overloaded.length > 0) {
    recommendations.push({
      type: 'rebalance',
      title: `Rebalance load from ${overloaded.length} overloaded agent(s)`,
      detail: `${overloaded.map((a) => a.codename).join(', ')} are above 70% load. Redistribute pending work to ${idle.length} idle agents to prevent saturation.`,
      impact: 'high',
      agents: overloaded.map((a) => a.codename),
    });
  }
  if (idle.length > 5 && pendingTasks.length > 0) {
    recommendations.push({
      type: 'dispatch',
      title: `Dispatch ${Math.min(pendingTasks.length, idle.length)} pending task(s) to idle agents`,
      detail: `${pendingTasks.length} pending tasks while ${idle.length} agents are idle. Dispatching now maximizes throughput.`,
      impact: 'medium',
    });
  }
  if (errorAgents.length > 0) {
    recommendations.push({
      type: 'investigate',
      title: `Investigate ${errorAgents.length} agent(s) in error state`,
      detail: `${errorAgents.map((a) => a.codename).join(', ')} are in error. Run diagnostics and restart to restore capacity.`,
      impact: 'high',
      agents: errorAgents.map((a) => a.codename),
    });
  }
  if (utilizationPct > 75) {
    recommendations.push({
      type: 'scale-out',
      title: 'Consider scaling out the fleet',
      detail: `Fleet utilization is at ${utilizationPct.toFixed(0)}%. Adding agents would provide headroom for burst loads.`,
      impact: 'medium',
    });
  }
  if (utilizationPct < 30 && idle.length > totalAgents * 0.6) {
    recommendations.push({
      type: 'scale-in',
      title: 'Consider scaling in the fleet',
      detail: `Fleet utilization is only ${utilizationPct.toFixed(0)}% with ${idle.length} idle agents. Scaling in saves resources.`,
      impact: 'low',
    });
  }

  // What-if scenarios
  const scenarios = [
    {
      name: 'Current',
      agents: totalAgents,
      capacity: totalCapacity,
      utilized: Math.round(usedCapacity),
      headroom: Math.round(headroom),
      utilizationPct: Math.round(utilizationPct * 10) / 10,
    },
    {
      name: 'Scale +25%',
      agents: Math.round(totalAgents * 1.25),
      capacity: Math.round(totalCapacity * 1.25),
      utilized: Math.round(usedCapacity),
      headroom: Math.round(totalCapacity * 1.25 - usedCapacity),
      utilizationPct: Math.round((usedCapacity / (totalCapacity * 1.25)) * 1000) / 10,
    },
    {
      name: 'Scale +50%',
      agents: Math.round(totalAgents * 1.5),
      capacity: Math.round(totalCapacity * 1.5),
      utilized: Math.round(usedCapacity),
      headroom: Math.round(totalCapacity * 1.5 - usedCapacity),
      utilizationPct: Math.round((usedCapacity / (totalCapacity * 1.5)) * 1000) / 10,
    },
    {
      name: 'Scale -25%',
      agents: Math.round(totalAgents * 0.75),
      capacity: Math.round(totalCapacity * 0.75),
      utilized: Math.round(usedCapacity),
      headroom: Math.round(totalCapacity * 0.75 - usedCapacity),
      utilizationPct: Math.round((usedCapacity / (totalCapacity * 0.75)) * 1000) / 10,
    },
  ];

  // Load distribution buckets
  const buckets = [
    { range: '0-20%', count: agents.filter((a) => a.load <= 20).length, color: 'green' },
    { range: '21-40%', count: agents.filter((a) => a.load > 20 && a.load <= 40).length, color: 'cyan' },
    { range: '41-60%', count: agents.filter((a) => a.load > 40 && a.load <= 60).length, color: 'amber' },
    { range: '61-80%', count: agents.filter((a) => a.load > 60 && a.load <= 80).length, color: 'orange' },
    { range: '81-100%', count: agents.filter((a) => a.load > 80).length, color: 'red' },
  ];

  // Top loaded + most idle
  const topLoaded = [...agents].sort((a, b) => b.load - a.load).slice(0, 10);
  const mostIdle = [...agents].sort((a, b) => a.load - b.load).slice(0, 10);

  const t = telemetry[0] as { cpu?: number; mem?: number } | undefined;

  return NextResponse.json({
    summary: {
      totalAgents,
      idle: idle.length,
      active: active.length,
      error: errorAgents.length,
      overloaded: overloaded.length,
      nearCapacity: nearCapacity.length,
      totalCapacity,
      usedCapacity: Math.round(usedCapacity),
      headroom: Math.round(headroom),
      utilizationPct: Math.round(utilizationPct * 10) / 10,
      avgLoad: Math.round((usedCapacity / totalAgents) * 10) / 10,
      avgSuccessRate: Math.round((agents.reduce((s, a) => s + a.successRate, 0) / totalAgents) * 10) / 10,
      systemCpu: t?.cpu ?? 0,
      systemMem: t?.mem ?? 0,
    },
    backlog: {
      pending: pendingTasks.length,
      inProgress: inProgressTasks.length,
      blocked: blockedTasks.length,
      critical: criticalPending.length,
      high: highPending.length,
      dispatchCapacity,
      backlogRatio: Math.round(backlogRatio * 100) / 100,
    },
    recommendations,
    scenarios,
    buckets,
    topLoaded: topLoaded.map((a) => ({ codename: a.codename, role: a.role, load: a.load, status: a.status, successRate: a.successRate })),
    mostIdle: mostIdle.map((a) => ({ codename: a.codename, role: a.role, load: a.load, status: a.status, successRate: a.successRate })),
    overloadedAgents: overloaded.map((a) => ({ codename: a.codename, role: a.role, load: a.load, successRate: a.successRate })),
    idleAgents: idle.map((a) => ({ codename: a.codename, role: a.role, load: a.load, successRate: a.successRate })),
  });
}
