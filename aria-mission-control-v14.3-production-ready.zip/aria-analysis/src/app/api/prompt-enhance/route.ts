import { NextRequest, NextResponse } from 'next/server';
import { enhancePrompt } from '@/lib/prompt-enhancer';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const { prompt, context } = await req.json().catch(() => ({}));
  if (!prompt) return NextResponse.json({ error: 'prompt required' }, { status: 400 });
  const enhanced = await enhancePrompt(prompt, context);
  return NextResponse.json({ original: prompt, enhanced, originalLen: prompt.length, enhancedLen: enhanced.length });
}
