import { NextResponse } from 'next/server';
import { getEnvWatcherStatus } from '@/lib/env-watcher';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/env-watcher — env watcher status (is it watching, how many providers, last sync)
export async function GET() {
  const status = getEnvWatcherStatus();
  return NextResponse.json(status);
}
