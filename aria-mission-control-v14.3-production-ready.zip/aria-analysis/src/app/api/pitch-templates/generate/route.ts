import { NextRequest, NextResponse } from 'next/server';
import {
  coerceTemplateId,
  generate3DScrollWebsite,
} from '@/lib/pitch-templates';
import { SALES_INDUSTRY_KEYS } from '@/lib/sales-playbook';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface GenerateBody {
  businessName?: string;
  industry?: string;
  headline?: string;
  templateId?: string;
}

/**
 * POST /api/pitch-templates/generate
 * Body: { businessName, industry, headline, templateId }
 * Returns: { html, metadata }
 *
 * Generates a complete standalone HTML string for a 3D scroll-animation
 * pitch website. The HTML uses only vanilla JS + Tailwind CDN (no build
 * step) — suitable for cold-outreach pitch emails.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as GenerateBody;

  const businessName = (body.businessName ?? '').trim();
  const industry = (body.industry ?? '').trim().toLowerCase();
  const headline = (body.headline ?? '').trim();
  const templateId = coerceTemplateId(body.templateId);

  if (!businessName) {
    return NextResponse.json(
      { error: 'businessName is required' },
      { status: 400 },
    );
  }
  if (!industry) {
    return NextResponse.json(
      { error: 'industry is required' },
      { status: 400 },
    );
  }
  if (!SALES_INDUSTRY_KEYS.includes(industry)) {
    return NextResponse.json(
      {
        error: 'Unknown industry: ' + industry,
        validIndustries: SALES_INDUSTRY_KEYS,
      },
      { status: 400 },
    );
  }
  if (!headline) {
    return NextResponse.json(
      { error: 'headline is required' },
      { status: 400 },
    );
  }

  try {
    const { html, metadata } = generate3DScrollWebsite(
      businessName,
      industry,
      headline,
      templateId,
    );
    return NextResponse.json({
      html,
      metadata,
      businessName,
      industry,
      headline,
      templateId,
      sizeBytes: html.length,
      sizeKb: Math.round((html.length / 1024) * 10) / 10,
    });
  } catch (e) {
    return NextResponse.json(
      {
        error: e instanceof Error ? e.message : 'Generation failed',
      },
      { status: 500 },
    );
  }
}
