import { NextResponse } from 'next/server';
import { getAllTemplates, getTemplatePreview } from '@/lib/pitch-templates';
import { SALES_INDUSTRY_KEYS, industryLabel } from '@/lib/sales-playbook';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/pitch-templates
 * Returns the list of all available 3D scroll pitch templates plus the
 * full industry dropdown (12 industries) used by the Pitch Templates tab.
 */
export async function GET() {
  const templates = getAllTemplates();
  const industries = SALES_INDUSTRY_KEYS.map((key) => ({
    key,
    label: industryLabel(key),
  }));
  return NextResponse.json({
    templates,
    industries,
    defaultTemplateId: 'aurora-3d',
    defaultIndustry: 'restaurant',
  });
}

/** POST /api/pitch-templates — convenience preview lookup for a single template. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { templateId?: string };
  const id = body.templateId ?? 'aurora-3d';
  const metadata = getTemplatePreview(id);
  return NextResponse.json({ metadata });
}
