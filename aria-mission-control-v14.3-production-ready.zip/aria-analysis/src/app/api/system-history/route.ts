import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/system-history — returns telemetry history for charting.
 *
 * Query params:
 *   - hours: number (default 1, max 24) — how far back to look
 *   - limit: number (default 60, max 500) — max data points
 *
 * Returns:
 *   - points: [{ time, cpu, memPct, disk, latency, loadAvg }] sampled over the window
 *   - summary: { avgCpu, maxCpu, avgMem, maxMem, avgLatency, maxLatency, alertMinutes }
 *     where alertMinutes = number of minutes where any metric crossed warn thresholds
 *     (CPU≥70, MEM≥75, LAT≥800, DISK≥80).
 *   - thresholds: the warn/crit values used (for chart reference lines).
 */
export async function GET(req: NextRequest) {
  const hours = Math.min(24, Math.max(1, parseInt(req.nextUrl.searchParams.get('hours') || '1', 10)));
  const limit = Math.min(500, Math.max(10, parseInt(req.nextUrl.searchParams.get('limit') || '60', 10)));

  const since = new Date(Date.now() - hours * 60 * 60 * 1000);
  const rows = await db.telemetry.findMany({
    where: { createdAt: { gte: since } },
    orderBy: { createdAt: 'asc' },
    take: limit * 2, // over-fetch then sample down
  });

  if (rows.length === 0) {
    return NextResponse.json({
      points: [],
      summary: { avgCpu: 0, maxCpu: 0, avgMem: 0, maxMem: 0, avgLatency: 0, maxLatency: 0, alertMinutes: 0 },
      thresholds: { cpuWarn: 70, cpuCrit: 85, memWarn: 75, memCrit: 90, latWarn: 800, latCrit: 1500, diskWarn: 80, diskCrit: 92 },
    });
  }

  // Sample down to `limit` points if we over-fetched.
  const step = Math.max(1, Math.floor(rows.length / limit));
  const sampled = rows.filter((_, i) => i % step === 0);

  // Mem in the DB is in MB (absolute). Convert to % using the latest memTotal
  // from /api/metrics (we don't have a memTotal column historically, so use
  // a reasonable approximation: the max mem seen as the "total").
  const maxMemSeen = rows.reduce((m, r) => Math.max(m, r.mem), 0);
  const memTotalApprox = Math.max(maxMemSeen, 4096); // floor at 4GB

  const points = sampled.map((r) => ({
    time: r.createdAt.toISOString(),
    cpu: Math.round(r.cpu * 10) / 10,
    memPct: Math.round((r.mem / memTotalApprox) * 100 * 10) / 10,
    disk: Math.round(r.disk * 10) / 10,
    latency: r.latency,
  }));

  // Summary stats.
  const avgCpu = Math.round(rows.reduce((s, r) => s + r.cpu, 0) / rows.length);
  const maxCpu = Math.round(rows.reduce((m, r) => Math.max(m, r.cpu), 0));
  const memPcts = rows.map((r) => (r.mem / memTotalApprox) * 100);
  const avgMem = Math.round(memPcts.reduce((s, m) => s + m, 0) / memPcts.length);
  const maxMem = Math.round(Math.max(...memPcts));
  const avgLatency = Math.round(rows.reduce((s, r) => s + r.latency, 0) / rows.length);
  const maxLatency = rows.reduce((m, r) => Math.max(m, r.latency), 0);

  // Alert minutes: count distinct minute-buckets where any metric crossed warn.
  const alertMinutes = new Set<string>();
  for (const r of rows) {
    const memP = (r.mem / memTotalApprox) * 100;
    if (r.cpu >= 70 || memP >= 75 || r.latency >= 800 || r.disk >= 80) {
      alertMinutes.add(r.createdAt.toISOString().slice(0, 16)); // YYYY-MM-DDTHH:MM
    }
  }

  return NextResponse.json({
    points,
    summary: {
      avgCpu,
      maxCpu,
      avgMem,
      maxMem,
      avgLatency,
      maxLatency,
      alertMinutes: alertMinutes.size,
    },
    thresholds: {
      cpuWarn: 70, cpuCrit: 85,
      memWarn: 75, memCrit: 90,
      latWarn: 800, latCrit: 1500,
      diskWarn: 80, diskCrit: 92,
    },
  });
}
