import { NextRequest, NextResponse } from 'next/server';
import { questionClaim } from '@/lib/verification';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { questionNote, improvedVersion } = await req.json().catch(() => ({}));
  if (!questionNote) return NextResponse.json({ error: 'questionNote required' }, { status: 400 });
  return NextResponse.json(await questionClaim(id, questionNote, improvedVersion));
}
