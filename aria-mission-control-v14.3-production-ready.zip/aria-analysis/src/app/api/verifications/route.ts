import { NextRequest, NextResponse } from 'next/server';
import { verifyClaim, listVerifications, getVerificationStats, type ClaimType } from '@/lib/verification';
import { sanitizeString } from '@/lib/sanitize';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const statsOnly = req.nextUrl.searchParams.get('stats') === '1';
  if (statsOnly) return NextResponse.json(await getVerificationStats());
  const claimType = req.nextUrl.searchParams.get('claimType') as ClaimType | null;
  const status = req.nextUrl.searchParams.get('status');
  const questioned = req.nextUrl.searchParams.get('questioned');
  const result = await listVerifications({
    claimType: claimType ?? undefined,
    status: status ?? undefined,
    questioned: questioned === 'true' ? true : questioned === 'false' ? false : undefined,
  });
  return NextResponse.json(result);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { claimType, claimText, claimSource, evidence, crossCheck } = body as {
    claimType?: unknown;
    claimText?: unknown;
    claimSource?: unknown;
    evidence?: unknown;
    crossCheck?: unknown;
  };

  // ── Required: claimType (string, max 100) ──
  const safeClaimType = sanitizeString(claimType, 100);
  if (!safeClaimType) {
    return NextResponse.json(
      { error: 'claimType required (non-empty string, max 100 chars)' },
      { status: 400 },
    );
  }

  // ── Required: claimText (string, max 5000) ──
  const safeClaimText = sanitizeString(claimText, 5000);
  if (!safeClaimText) {
    return NextResponse.json(
      { error: 'claimText required (non-empty string, max 5000 chars)' },
      { status: 400 },
    );
  }

  // ── Optional: claimSource (string, max 500) ──
  let safeClaimSource: string | undefined;
  if (claimSource != null) {
    safeClaimSource = sanitizeString(claimSource, 500) ?? undefined;
    if (safeClaimSource === undefined) {
      return NextResponse.json(
        { error: 'claimSource must be a non-empty string (max 500 chars)' },
        { status: 400 },
      );
    }
  }

  const result = await verifyClaim(
    {
      claimType: safeClaimType as ClaimType,
      claimText: safeClaimText,
      claimSource: safeClaimSource,
      evidence: evidence as { type: string; url?: string; quote?: string }[] | undefined,
    },
    { crossCheck: crossCheck !== false },
  );
  return NextResponse.json(result);
}
