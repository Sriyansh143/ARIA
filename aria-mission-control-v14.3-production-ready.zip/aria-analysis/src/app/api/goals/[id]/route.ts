import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

// PATCH /api/goals/[id] — update a first-class Goal.
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));

  // Try the first-class Goal model first.
  const existing = await db.goal.findUnique({ where: { id } }).catch(() => null);
  if (existing) {
    const data: Record<string, unknown> = {};
    if (body.title != null) data.title = body.title;
    if (body.description != null) data.description = body.description;
    if (body.category != null) data.category = body.category;
    if (body.horizon != null) data.horizon = body.horizon;
    if (body.status != null) data.status = body.status;
    if (body.priority != null) data.priority = body.priority;
    if (typeof body.progress === 'number') data.progress = body.progress;
    if (typeof body.targetValue === 'number') data.targetValue = body.targetValue;
    if (typeof body.currentValue === 'number') data.currentValue = body.currentValue;
    if (body.unit != null) data.unit = body.unit;
    if (body.owner != null) data.owner = body.owner;
    if (body.dueDate != null) data.dueDate = body.dueDate ? new Date(body.dueDate) : null;
    if (body.tags != null) data.tags = JSON.stringify(body.tags);
    if (body.status === 'completed') data.completedAt = new Date();
    // Task 2-c (Teamly PMS) — update parent for milestone / sub-goal tracking.
    if (body.parentId !== undefined) data.parentId = typeof body.parentId === 'string' ? body.parentId : '';
    const updated = await db.goal.update({ where: { id }, data });
    return NextResponse.json({ goal: updated });
  }

  // Fallback: try legacy MemoryItem (scope='goal').
  const legacy = await db.memoryItem.findUnique({ where: { id } }).catch(() => null);
  if (legacy) {
    let parsed: Record<string, unknown> = {};
    try { parsed = JSON.parse(legacy.value); } catch { parsed = { description: legacy.value }; }
    const merged: Record<string, unknown> = {
      title: parsed.title ?? legacy.key,
      description: parsed.description ?? legacy.value,
      status: body.status ?? parsed.status ?? 'pending',
      priority: body.priority ?? parsed.priority ?? 'medium',
      progress: typeof body.progress === 'number' ? body.progress : (parsed.progress ?? 0),
      owner: parsed.owner ?? 'ORION',
      dueDate: parsed.dueDate ?? null,
    };
    const updated = await db.memoryItem.update({
      where: { id },
      data: { value: JSON.stringify(merged), pinned: typeof body.pinned === 'boolean' ? body.pinned : legacy.pinned },
    });
    return NextResponse.json({ goal: updated });
  }

  return NextResponse.json({ error: 'not found' }, { status: 404 });
}

// DELETE /api/goals/[id] — delete a Goal (first-class or legacy).
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  // Try first-class Goal model.
  const goal = await db.goal.findUnique({ where: { id } }).catch(() => null);
  if (goal) {
    // Task 2-c (Teamly PMS) — cascade: re-parent children to grandparent (or
    // detach to top-level) so we don't orphan sub-goals when a parent is deleted.
    await db.goal.updateMany({ where: { parentId: id }, data: { parentId: goal.parentId ?? '' } }).catch(() => {});
    await db.goal.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  }
  // Fallback: legacy MemoryItem.
  await db.memoryItem.delete({ where: { id } }).catch(() => {});
  return NextResponse.json({ ok: true });
}
