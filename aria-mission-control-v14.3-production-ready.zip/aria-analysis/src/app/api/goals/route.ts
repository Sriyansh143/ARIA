import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET /api/goals — list goals from the first-class Goal model.
// Query params: ?status=all&priority=all&horizon=all&category=all
export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get('status');
  const priority = req.nextUrl.searchParams.get('priority');
  const horizon = req.nextUrl.searchParams.get('horizon');
  const category = req.nextUrl.searchParams.get('category');

  const where: Record<string, string> = {};
  if (status && status !== 'all') where.status = status;
  if (priority && priority !== 'all') where.priority = priority;
  if (horizon && horizon !== 'all') where.horizon = horizon;
  if (category && category !== 'all') where.category = category;
  // Task 2-c (Teamly PMS) — filter by parent. 'top' = top-level goals only.
  // 'all' (default) = both top-level + sub-goals. A specific parentId filters to
  // children of that goal.
  const parent = req.nextUrl.searchParams.get('parent');
  if (parent === 'top') where.parentId = '';
  else if (parent) where.parentId = parent;

  const goals = await db.goal.findMany({
    where,
    orderBy: [{ priority: 'desc' }, { updatedAt: 'desc' }],
    take: 200,
  });

  // Task 2-c (Teamly PMS) — for each top-level goal, count its sub-goals (milestones).
  const childCounts = await db.goal.groupBy({
    by: ['parentId'],
    where: { parentId: { not: '' } },
    _count: { _all: true },
  }).catch(() => []);
  const childCountMap = new Map<string, number>();
  for (const r of childCounts) {
    if (r.parentId) childCountMap.set(r.parentId, r._count._all);
  }

  // Also fetch legacy goals from MemoryItem (scope='goal') for backward compat.
  const legacyItems = await db.memoryItem.findMany({
    where: { scope: 'goal' },
    orderBy: { updatedAt: 'desc' },
    take: 50,
  }).catch(() => []);

  const legacyGoals = legacyItems.map((m) => {
    let parsed: Record<string, unknown> = {};
    try { parsed = JSON.parse(m.value); } catch { parsed = { description: m.value }; }
    return {
      id: m.id,
      title: (parsed.title as string) ?? m.key,
      description: (parsed.description as string) ?? m.value,
      category: 'general',
      horizon: 'monthly',
      status: (parsed.status as string) ?? 'pending',
      priority: (parsed.priority as string) ?? 'medium',
      progress: (parsed.progress as number) ?? 0,
      targetValue: 0,
      currentValue: 0,
      unit: '',
      owner: (parsed.owner as string) ?? 'ORION',
      dueDate: (parsed.dueDate as string) ?? null,
      tags: (() => { try { return JSON.parse(m.tags || '[]'); } catch { return []; } })(),
      source: 'legacy',
      createdAt: m.createdAt,
      updatedAt: m.updatedAt,
    };
  });

  return NextResponse.json({ goals: [...goals, ...legacyGoals].map((g) => ({ ...g, childCount: childCountMap.get((g as { id: string }).id) ?? 0 })) });
}

// POST /api/goals — create or update a first-class Goal.
// Body: { id?, title, description?, category?, horizon?, status?, priority?, progress?, targetValue?, currentValue?, unit?, owner?, dueDate?, tags?, source? }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const {
    id, title, description, category, horizon, status, priority, progress,
    targetValue, currentValue, unit, owner, dueDate, tags, source, parentId,
  } = body;

  if (!title) {
    return NextResponse.json({ error: 'title required' }, { status: 400 });
  }

  const data = {
    title,
    description: description ?? '',
    category: category ?? 'general',
    horizon: horizon ?? 'monthly',
    status: status ?? 'pending',
    priority: priority ?? 'medium',
    progress: typeof progress === 'number' ? progress : 0,
    targetValue: typeof targetValue === 'number' ? targetValue : 0,
    currentValue: typeof currentValue === 'number' ? currentValue : 0,
    unit: unit ?? '',
    owner: owner ?? 'ORION',
    dueDate: dueDate ? new Date(dueDate) : null,
    tags: JSON.stringify(tags ?? []),
    source: source ?? 'manual',
    // Task 2-c (Teamly PMS) — optional parent goal for milestone / sub-goal tracking.
    parentId: typeof parentId === 'string' ? parentId : '',
  };

  if (id) {
    const updated = await db.goal.update({ where: { id }, data });
    return NextResponse.json({ goal: updated });
  }

  const goal = await db.goal.create({ data });
  return NextResponse.json({ goal });
}
