import { NextResponse } from 'next/server';
import { getApiRegistry, getApiRegistrySummary, getEndpointsByCategory } from '@/lib/api-registry';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/agent-registry — returns the full API endpoint registry.
 *
 * Agents call this to discover REAL endpoints (instead of inventing
 * hypothetical clients like kanban_client or artifacts_client).
 *
 * This is the fix for the "simulated execution" problem where Forge
 * generated code with placeholder clients that never actually wrote
 * to the Artifacts module.
 */
export async function GET() {
  return NextResponse.json({
    endpoints: getApiRegistry(),
    summary: getApiRegistrySummary(),
    total: getApiRegistry().length,
    categories: [...new Set(getApiRegistry().map((e) => e.category))],
  });
}
