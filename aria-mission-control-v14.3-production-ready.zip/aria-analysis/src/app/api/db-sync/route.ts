import { NextRequest, NextResponse } from 'next/server';
import { syncToPostgres, getSyncStatus } from '@/lib/db-sync';
import { getPgStatus, resetPgPool, isPostgresConfigured } from '@/lib/db-postgres';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — current dual-DB sync status (SQLite primary + PostgreSQL mirror).
export async function GET() {
  const sync = getSyncStatus();
  const pg = getPgStatus();
  return NextResponse.json({
    primary: {
      provider: 'sqlite',
      url: process.env.DATABASE_URL?.startsWith('file:')
        ? process.env.DATABASE_URL
        : 'in-memory / ephemeral',
    },
    mirror: {
      provider: 'postgresql',
      configured: pg.configured,
      reachable: pg.reachable,
      error: pg.error,
      poolActive: pg.poolActive,
    },
    sync: {
      syncing: sync.syncing,
      lastSyncAt: sync.lastSyncAt,
      lastResult: sync.lastResult,
      autoSyncEnabled: isPostgresConfigured(),
    },
  });
}

// POST — trigger a manual sync (or reset the connection pool).
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = (body as { action?: string }).action;

  if (action === 'reset') {
    resetPgPool();
    return NextResponse.json({ ok: true, message: 'PostgreSQL connection pool reset. Next sync will reconnect.' });
  }

  const result = await syncToPostgres('manual');
  return NextResponse.json({ ok: result.ok, result });
}
