import { NextRequest, NextResponse } from 'next/server';
import { getAutopilotState, setAutopilotActive } from '@/lib/autopilot-scheduler';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * GET /api/autopilot/state
 *
 * Returns the current server-side autopilot scheduler state. All browsers
 * polling this endpoint see the SAME state — `active`, `lastTickAt`,
 * `nextTickIn`, `cycleCount`, `errorCount`, `schedulerHealthy`.
 *
 * This replaces the per-browser `localStorage['aria-autopilot-active']`
 * flag that previously caused the localhost ↔ network-IP briefing desync.
 */
export async function GET() {
  return NextResponse.json(getAutopilotState());
}

/**
 * POST /api/autopilot/state
 *
 * Body: { active: boolean }
 *
 * Toggles the server-side autopilot scheduler. Idempotent — multiple
 * browsers calling POST { active: true } simultaneously result in exactly
 * one scheduler loop running. The new state is broadcast via the
 * `autopilot:state` event so all subscribed clients update their UI.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { active } = body as { active?: boolean };

  if (typeof active !== 'boolean') {
    return NextResponse.json(
      { error: 'active (boolean) required' },
      { status: 400 },
    );
  }

  try {
    await setAutopilotActive(active);
    return NextResponse.json(getAutopilotState());
  } catch (err) {
    logger.error(
      { err: err instanceof Error ? err.message : String(err) },
      'autopilot/state: failed to toggle',
    );
    return NextResponse.json(
      { error: 'failed to toggle autopilot' },
      { status: 500 },
    );
  }
}
