import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Autopilot tick — one self-running cycle of the autonomous company.
// 1. Read the live fleet state + recent activity.
// 2. GLM-4.6 picks the single highest-leverage next action (a concrete goal).
// 3. POST that goal to the parallel orchestrator (which decomposes + dispatches
//    to idle agents) — or, if no agents are idle, create a task for later.
// 4. Return a concise summary of what was decided + dispatched.
// This closes the loop: briefing → decision → execution, hands-free.

interface TickResult {
  cycle: number;
  decidedGoal: string;
  rationale: string;
  dispatched: boolean;
  runId?: string;
  taskCreated?: string;
  agentsDispatched?: number;
  durationMs: number;
  error?: string;
}

export async function POST() {
  const start = Date.now();
  try {
    const [agents, pendingTasks, inProgressTasks, recentLogs] = await Promise.all([
      db.agent.findMany({ select: { codename: true, status: true, load: true, role: true } }),
      db.task.count({ where: { status: 'pending' } }),
      db.task.count({ where: { status: 'in_progress' } }),
      db.agentLog.findMany({ orderBy: { createdAt: 'desc' }, take: 6, select: { message: true, level: true, agent: { select: { codename: true } } } }),
    ]);

    const idleAgents = agents.filter((a) => a.status === 'idle' && a.load < 25).map((a) => a.codename);
    const working = agents.filter((a) => a.status === 'working').length;
    const overloaded = agents.filter((a) => a.load > 70).map((a) => a.codename);
    const errorAgents = agents.filter((a) => a.status === 'error').map((a) => a.codename);

    // ── Decide the next goal via GLM-4.6 ──────────────────────────────
    // The LLM sees the live state and names ONE concrete, actionable goal
    // that advances the company. Falls back to a heuristic goal on error.
    const state = `Fleet: ${agents.length} agents, ${working} working, ${idleAgents.length} idle (${idleAgents.slice(0, 5).join(', ')}${idleAgents.length > 5 ? '…' : ''}), ${overloaded.length} overloaded, ${errorAgents.length} in error.
Tasks: ${pendingTasks} pending, ${inProgressTasks} in_progress.
Recent: ${recentLogs.map((l) => `[${l.agent?.codename}] ${l.message}`).join(' | ').slice(0, 500) || 'n/a'}`;

    let goal = '';
    let rationale = '';
    try {
      const sys = `You are ARIA's autopilot. Given the live company state, decide the SINGLE highest-leverage next action to advance the autonomous AI company right now. It must be a concrete, dispatchable goal an agent can execute in one cycle (e.g. "Research 3 new earning methods for the Indian SMB market", "Refactor the telemetry polling to halve CPU", "Draft an outreach email to the 2 pending-payment clients"). Respond as STRICT JSON: {"goal": string (max 120 chars), "rationale": string (max 160 chars)}. No markdown.`;
      const raw = await quickChat(`${state}\n\nDecide the next autopilot goal.`, sys);
      const j = extractJson(raw);
      if (j?.goal) { goal = String(j.goal).slice(0, 200); rationale = String(j.rationale ?? '').slice(0, 300); }
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'autopilot: LLM decide failed');
    }
    if (!goal || goal.startsWith('I am unable to respond')) {
      // Heuristic fallback when the LLM is unavailable/rate-limited.
      goal = idleAgents.length > 0
        ? 'Process the next pending task and report the outcome'
        : 'Monitor fleet health and log a status summary';
      rationale = 'Heuristic fallback: LLM unavailable or rate-limited.';
    }

    // ── Execute: dispatch to the orchestrator if agents are idle ──────
    // Use a 60s timeout so a hung orchestrator doesn't block the autopilot
    // cycle indefinitely. If the dispatch fails, fall back to creating a task.
    let dispatched = false;
    let runId: string | undefined;
    let taskCreated: string | undefined;
    let agentsDispatched = 0;

    if (idleAgents.length > 0) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 60_000);
        // Use DASHBOARD_BASE (defaults to 127.0.0.1:3000) — never hardcode
        // localhost:3000 because the server may not be on localhost in prod
        // (e.g. when hosted on a network IP or behind a reverse proxy).
        const baseUrl = process.env.DASHBOARD_BASE || 'http://127.0.0.1:3000';
        const res = await fetch(`${baseUrl}/api/orchestrate/parallel`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ goal, maxParallel: Math.min(3, idleAgents.length) }),
          cache: 'no-store',
          signal: controller.signal,
        });
        clearTimeout(timeout);
        if (res.ok) {
          const data = await res.json().catch(() => ({}));
          runId = data?.runId;
          agentsDispatched = data?.agentsDispatched ?? data?.stepsDispatched ?? Math.min(3, idleAgents.length);
          dispatched = true;
        }
      } catch (err) {
        logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'autopilot: dispatch failed');
      }
    }

    // Always record a task so the work is tracked even if no agents were idle.
    if (!dispatched) {
      const t = await db.task.create({
        data: {
          title: goal.slice(0, 200),
          description: rationale,
          priority: 'medium',
          tags: JSON.stringify(['autopilot']),
        },
      });
      taskCreated = t.id;
    }

    // Record an agent log so the activity feed reflects the autopilot cycle.
    try {
      const orion = await db.agent.findFirst({ where: { codename: 'ORION' } });
      if (orion) {
        await db.agentLog.create({
          data: {
            agentId: orion.id,
            level: dispatched ? 'success' : 'info',
            message: `Autopilot: ${goal.slice(0, 100)}${dispatched ? ` → dispatched ${agentsDispatched} agent(s)` : ' → queued as task'}`,
          },
        });
      }
    } catch { /* ignore log failure */ }

    // Record an ActionLog entry so the Decision Log can surface this autonomous decision.
    try {
      await db.actionLog.create({
        data: {
          actor: 'autopilot',
          action: dispatched ? 'autopilot.dispatch' : 'autopilot.queue',
          category: 'autonomous',
          target: runId ?? taskCreated ?? undefined,
          afterState: goal.slice(0, 500),
          reversible: false,
          meta: JSON.stringify({ rationale: rationale.slice(0, 400), dispatched, agentsDispatched, runId, taskCreated, durationMs: Date.now() - start }),
        },
      });
    } catch { /* ignore */ }

    const result: TickResult = {
      cycle: Date.now(),
      decidedGoal: goal,
      rationale,
      dispatched,
      runId,
      taskCreated,
      agentsDispatched,
      durationMs: Date.now() - start,
    };
    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json({
      cycle: Date.now(),
      decidedGoal: '',
      rationale: '',
      dispatched: false,
      durationMs: Date.now() - start,
      error: err instanceof Error ? err.message : 'unknown error',
    } satisfies TickResult, { status: 500 });
  }
}

function extractJson(text: string): any | null {
  if (!text) return null;
  let s = text.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) return null;
  try { return JSON.parse(s.slice(start, end + 1)); } catch { return null; }
}
