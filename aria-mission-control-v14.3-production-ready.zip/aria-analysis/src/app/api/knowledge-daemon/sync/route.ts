import { NextResponse } from 'next/server';
import { syncWithPeers, getKnowledgeStats } from '@/lib/knowledge-daemon';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/knowledge-daemon/sync
 * Triggers a bidirectional sync round and returns a detailed report plus
 * updated stats.
 *
 * The report includes:
 *   • entriesSent[]       — outbound: local entries queued for conceptual
 *                            peer fan-out (entries were already persisted
 *                            to DB at contribute time)
 *   • entriesReceived[]   — inbound: REAL DB rows pulled into the daemon
 *                            store (MemoryItem scope='knowledge-shared')
 *   • conflictsResolved[] — duplicate titles resolved by confidence
 *   • nodesContacted / nodesSucceeded — honest peer reachability counts
 *                            (always 0/4 in this sandbox — peers offline)
 *   • persistenceLayer    — 'db' if real DB retrieval succeeded,
 *                            'memory-only' if DB unavailable (fallback)
 *   • note                — explains the conceptual vs real distinction
 *
 * Each call also appends an entry to the in-memory sync history ring
 * buffer (see getSyncHistory()).
 *
 * Body: (none)
 * Returns: { report, stats }
 */
export async function POST() {
  const report = await syncWithPeers();
  const stats = getKnowledgeStats();
  return NextResponse.json({ report, stats });
}
