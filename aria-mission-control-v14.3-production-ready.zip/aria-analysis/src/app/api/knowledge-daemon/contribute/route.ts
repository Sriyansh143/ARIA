import { NextRequest, NextResponse } from 'next/server';
import { contributeKnowledge } from '@/lib/knowledge-daemon';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface ContributeBody {
  title?: string;
  content?: string;
  tags?: string[];
}

/**
 * POST /api/knowledge-daemon/contribute
 * Body: { title, content, tags }
 * Returns: { entry }
 *
 * Adds a knowledge entry to the local in-memory store AND persists it as a
 * MemoryItem (scope='knowledge-shared') in the DB. The DB write is
 * best-effort: if the DB is unavailable (read-only sandbox), the entry is
 * still added to the in-memory store and a warning is logged.
 *
 * The entry is marked `shared: false` — it will be flipped to true on the
 * next syncWithPeers() round (which also pulls it back from the DB as the
 * REAL inbound direction of the bidirectional flow).
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as ContributeBody;

  const title = (body.title ?? '').trim();
  const content = (body.content ?? '').trim();
  const tags = Array.isArray(body.tags)
    ? body.tags.filter((t): t is string => typeof t === 'string')
    : [];

  if (!title) {
    return NextResponse.json(
      { error: 'title is required' },
      { status: 400 },
    );
  }
  if (!content) {
    return NextResponse.json(
      { error: 'content is required' },
      { status: 400 },
    );
  }

  const entry = await contributeKnowledge(title, content, tags);
  return NextResponse.json({ entry });
}
