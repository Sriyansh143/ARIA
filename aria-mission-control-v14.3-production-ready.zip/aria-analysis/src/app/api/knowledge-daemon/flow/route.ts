import { NextResponse } from 'next/server';
import { getKnowledgeFlow, getSyncHistory } from '@/lib/knowledge-daemon';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/knowledge-daemon/flow
 * Returns the bidirectional flow summary + the 10 most recent sync
 * attempts (from the in-memory ring buffer).
 *
 * Response:
 *   {
 *     flow: {
 *       outboundPending:  number,  // local entries waiting to be sent
 *       inboundAvailable: number,  // DB entries not yet pulled into store
 *                                  // (real count when DB available, falls
 *                                  //  back to conceptual REMOTE_AVAILABLE
 *                                  //  count on DB failure)
 *       lastSync:         string | null,
 *       flowDirection:    'bidirectional',
 *     },
 *     history: SyncHistoryEntry[],  // last 10 syncs, newest first
 *   }
 */
export async function GET() {
  const flow = await getKnowledgeFlow();
  const history = getSyncHistory(10);
  return NextResponse.json({ flow, history });
}
