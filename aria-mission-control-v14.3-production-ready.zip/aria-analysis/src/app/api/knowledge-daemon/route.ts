import { NextResponse } from 'next/server';
import {
  getKnowledgeNodes,
  getKnowledgeEntries,
  getKnowledgeStats,
} from '@/lib/knowledge-daemon';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/knowledge-daemon
 * Returns the full state of the conceptual knowledge daemon: nodes
 * (local + remote + daemon), recent entries, and aggregate stats.
 */
export async function GET() {
  const nodes = getKnowledgeNodes();
  const entries = getKnowledgeEntries(50);
  const stats = getKnowledgeStats();
  return NextResponse.json({ nodes, entries, stats });
}
