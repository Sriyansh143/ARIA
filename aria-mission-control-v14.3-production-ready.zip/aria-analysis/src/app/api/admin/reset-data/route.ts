import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// POST /api/admin/reset-data — clears all demo/runtime data so the app starts fresh.
// KEEPS: Agent roster, Skills, Rules, Providers, Branding, Goals (user-created), Memory (config).
// CLEARS: Tasks, ChatMessages, Notifications, ActivityLogs, AgentLogs, AgentHeartbeats,
//         Telemetry, CronHistory, Artifacts, Payments, CSAT, ThinkingSessions,
//         SpawnedAgents, MonitorFindings, EarningMethods (demo), Reports, etc.
//
// Body: { confirm: "RESET" } — safety gate to prevent accidental calls.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (body.confirm !== 'RESET') {
    return NextResponse.json(
      { error: 'Confirmation required. Send { confirm: "RESET" } to proceed.' },
      { status: 400 },
    );
  }

  const cleared: Record<string, number> = {};
  const modelsToClear: Array<[string, keyof typeof db]> = [
    ['task', 'task'],
    ['chatMessage', 'chatMessage'],
    ['notification', 'notification'],
    ['actionLog', 'actionLog'],
    ['agentLog', 'agentLog'],
    ['agentHeartbeat', 'agentHeartbeat'],
    ['telemetry', 'telemetry'],
    ['cronHistory', 'cronHistory'],
    ['artifact', 'artifact'],
    ['payment', 'payment'],
    ['csatSurvey', 'csatSurvey'],
    ['thinkingSession', 'thinkingSession'],
    ['spawnedAgent', 'spawnedAgent'],
    ['spawnedAgentLog', 'spawnedAgentLog'],
    ['monitorFinding', 'monitorFinding'],
    ['earningMethod', 'earningMethod'],
    ['reportDiff', 'reportDiff'],
    ['skillRun', 'skillRun'],
    ['agentMessage', 'agentMessage'],
    ['fallbackEvent', 'fallbackEvent'],
    ['autonomyRun', 'autonomyRun'],
    ['pipeline', 'pipeline'],
    ['scheduledAutonomy', 'scheduledAutonomy'],
    ['taskLink', 'taskLink'],
    ['invoice', 'invoice'],
    ['service', 'service'],
  ];

  for (const [name, model] of modelsToClear) {
    try {
      const result = await (db[model] as { deleteMany: () => Promise<{ count: number }> }).deleteMany();
      cleared[name] = result.count;
    } catch {
      // Model may not exist in this schema version — skip.
    }
  }

  // Reset all agents to idle status + zero load + zero task count.
  try {
    const agentReset = await db.agent.updateMany({
      data: { status: 'idle', load: 0, taskCount: 0, successRate: 100 },
    });
    cleared['agentReset'] = agentReset.count;
  } catch {
    // best-effort
  }

  return NextResponse.json({
    ok: true,
    message: 'All demo/runtime data cleared. Agents reset to idle. Starting fresh.',
    cleared,
  });
}
