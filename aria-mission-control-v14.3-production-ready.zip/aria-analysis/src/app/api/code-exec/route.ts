import { NextRequest, NextResponse } from 'next/server';
import { executeCode, extractAndExecuteCode } from '@/lib/code-sandbox';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// POST — execute code directly OR extract+execute code blocks from an LLM response
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { code, language, response } = body as {
    code?: string;
    language?: 'python' | 'javascript' | 'typescript';
    response?: string;
  };

  // Mode 1: Execute a single code snippet
  if (code) {
    const result = executeCode(code, language);
    return NextResponse.json({ result });
  }

  // Mode 2: Extract + execute all code blocks from an LLM response
  if (response) {
    const results = extractAndExecuteCode(response);
    return NextResponse.json({
      blocksFound: results.length,
      results: results.map((r) => ({
        language: r.language,
        codePreview: r.code.slice(0, 200),
        ok: r.result.ok,
        output: r.result.output,
        exitCode: r.result.exitCode,
        durationMs: r.result.durationMs,
      })),
    });
  }

  return NextResponse.json({ error: 'Provide either "code" or "response"' }, { status: 400 });
}
