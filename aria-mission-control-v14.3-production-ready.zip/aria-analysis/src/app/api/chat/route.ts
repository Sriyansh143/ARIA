import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chat, type ChatTurn } from '@/lib/llm';
import { executeActionsFromResponse, formatResultsForAgent } from '@/lib/agent-exec';
import { extractAndExecuteCode } from '@/lib/code-sandbox';
import { logRequestAsGoal } from '@/lib/request-logger';
import { rateLimit, sanitizeString } from '@/lib/sanitize';

export const dynamic = 'force-dynamic';

// GET — recent chat history.
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 50), 200);
  const messages = await db.chatMessage.findMany({ orderBy: { createdAt: 'desc' }, take: limit });
  return NextResponse.json({ messages: messages.reverse() });
}

// POST — generate a completion via GLM-4.6 and persist both turns.
// AUTO-EXECUTES:
//   1. ```action blocks → real API calls (creates tasks, artifacts, etc.)
//   2. ```python/javascript/typescript blocks → real code execution
// Results are appended to the response so the user sees what happened.
// When thinking mode is enabled (default for complex tasks), the model's
// reasoning trace is persisted as `reasoning` and returned to the UI.
export async function POST(req: NextRequest) {
  // Rate limit: 30 chat requests per minute per IP (prevents LLM cost abuse).
  const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0] ?? 'local';
  if (!rateLimit(`chat:${clientIp}`, 30, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded. Max 30 messages per minute.' }, { status: 429 });
  }
  const body = await req.json().catch(() => ({}));
  const { message, history, enableThinking } = body as { message?: string; history?: ChatTurn[]; enableThinking?: boolean };
  // Sanitize + validate the message (max 10,000 chars to prevent LLM cost abuse).
  const sanitizedMessage = sanitizeString(message, 10_000);
  if (!sanitizedMessage) {
    return NextResponse.json({ error: 'message required (must be a non-empty string, max 10000 chars)' }, { status: 400 });
  }
  // Cap history length to prevent context-window abuse (max 20 turns, max 50KB total).
  const cappedHistory = Array.isArray(history) ? history.slice(-20).filter((h) => {
    const c = h?.content;
    return typeof c === 'string' && c.length < 5000;
  }) : [];
  // Rule 62: Log every user request as a Goal (audit trail). Best-effort,
  // never blocks the chat response if logging fails.
  logRequestAsGoal(sanitizedMessage, 'chat').catch(() => { /* best-effort */ });
  try {
    const { content, reasoning, model, latencyMs } = await chat(sanitizedMessage, cappedHistory, undefined, undefined, enableThinking === true);

    // ── AUTO-EXECUTE action blocks (API calls) ──
    const { actions, results, summary } = await executeActionsFromResponse(content);
    let finalContent = content;
    let actionsExecuted = 0;
    if (actions.length > 0) {
      actionsExecuted = results.filter((r) => r.ok).length;
      const resultsBlock = formatResultsForAgent(results);
      finalContent = `${finalContent}\n\n---\n**⚙️ Actions Executed:** ${summary}\n${resultsBlock}`;
    }

    // ── AUTO-EXECUTE code blocks (Python/JS/TS) ──
    const codeResults = extractAndExecuteCode(content);
    let codeExecuted = 0;
    if (codeResults.length > 0) {
      codeExecuted = codeResults.filter((r) => r.result.ok).length;
      const codeBlock = codeResults
        .map((r, i) => {
          const status = r.result.ok ? '✓ SUCCESS' : '✗ FAILED';
          return `  ${i + 1}. ${status} ${r.language} (${r.result.exitCode}, ${r.result.durationMs}ms)\n     Output: ${r.result.output.slice(0, 500)}`;
        })
        .join('\n');
      finalContent = `${finalContent}\n\n---\n**▶️ Code Executed:** ${codeExecuted}/${codeResults.length} blocks succeeded\n${codeBlock}`;
    }

    await db.chatMessage.create({ data: { role: 'user', content: sanitizedMessage } });
    const saved = await db.chatMessage.create({
      data: {
        role: 'assistant',
        content: finalContent,
        reasoning: reasoning ?? null,
        latency: latencyMs,
        model: model || 'glm-4.6',
      },
    });
    return NextResponse.json({
      message: saved,
      reasoning: reasoning,
      thinkingEnabled: reasoning != null,
      actionsExecuted,
      actionResults: results.length > 0 ? results : undefined,
      codeBlocksExecuted: codeExecuted,
      codeResults: codeResults.length > 0
        ? codeResults.map((r) => ({ language: r.language, ok: r.result.ok, output: r.result.output, exitCode: r.result.exitCode }))
        : undefined,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
