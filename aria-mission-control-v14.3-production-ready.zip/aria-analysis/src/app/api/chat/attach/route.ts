import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// POST /api/chat/attach — process a file attachment for the chat.
// Body: { filename, mimeType, base64 }
// Returns: { type: 'text'|'image'|'binary', content: string, filename, sizeBytes }
//
// For text files: decodes base64 → returns text content.
// For images: uses the z-ai SDK vision API to describe the image.
// For binary files: returns metadata only (can't parse in chat).
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { filename, mimeType, base64 } = body as {
    filename?: string;
    mimeType?: string;
    base64?: string;
  };

  if (!filename || !base64) {
    return NextResponse.json({ error: 'filename and base64 required' }, { status: 400 });
  }

  const sizeBytes = Math.ceil((base64.length * 3) / 4);
  const lowerName = filename.toLowerCase();
  const mime = (mimeType ?? '').toLowerCase();

  // Text-readable files
  const textExtensions = ['.txt', '.md', '.json', '.js', '.ts', '.tsx', '.jsx', '.py', '.csv', '.xml', '.yaml', '.yml', '.html', '.css', '.sh', '.sql', '.env', '.gitignore', '.prisma'];
  const textMimes = ['text/', 'application/json', 'application/xml', 'application/javascript', 'application/x-yaml'];
  const isText = textExtensions.some((ext) => lowerName.endsWith(ext)) || textMimes.some((m) => mime.startsWith(m));

  if (isText) {
    try {
      const text = Buffer.from(base64, 'base64').toString('utf-8');
      return NextResponse.json({
        type: 'text',
        content: text.slice(0, 10000), // cap at 10k chars
        filename,
        sizeBytes,
        truncated: text.length > 10000,
      });
    } catch {
      return NextResponse.json({ type: 'binary', content: `[Could not decode ${filename}]`, filename, sizeBytes });
    }
  }

  // Image files — use VLM to describe
  const imageMimes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
  const imageExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp'];
  const isImage = imageMimes.includes(mime) || imageExtensions.some((ext) => lowerName.endsWith(ext));

  if (isImage) {
    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default;
      const zai = await ZAI.create();
      const dataUrl = `data:${mime || 'image/png'};base64,${base64}`;
      const completion = await zai.chat.completions.createVision({
        model: 'glm-4v-flash',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: `Describe this image concisely for the user. Filename: ${filename}` },
              { type: 'image_url', image_url: { url: dataUrl } },
            ],
          },
        ] as never,
      });
      const desc = completion?.choices?.[0]?.message?.content ?? 'Could not analyze image';
      return NextResponse.json({
        type: 'image',
        content: desc,
        filename,
        sizeBytes,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'VLM failed';
      return NextResponse.json({
        type: 'image',
        content: `[Image analysis unavailable: ${msg}. File: ${filename}, ${sizeBytes} bytes]`,
        filename,
        sizeBytes,
      });
    }
  }

  // Binary files — return metadata only
  return NextResponse.json({
    type: 'binary',
    content: `[Binary file: ${filename} — ${sizeBytes} bytes. Cannot parse in chat. The AI will acknowledge the attachment but cannot read its contents.]`,
    filename,
    sizeBytes,
  });
}
