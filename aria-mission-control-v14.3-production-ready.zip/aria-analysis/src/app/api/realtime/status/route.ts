/**
 * GET /api/realtime/status
 * ------------------------
 * Liveness proxy for the ARIA real-time socket.io mini-service.
 *
 * Hits `http://127.0.0.1:3003/health` (server-to-server, so we CAN use the
 * absolute localhost URL here — this is NOT a client request) with a 2s
 * timeout. Returns 200 with `{ running, connections, uptime, port }` whether
 * the service is up or down — never 500 — so the dashboard can render the
 * real-time status pill without try/catching HTTP errors.
 *
 * This route is server-side only (nodejs runtime, force-dynamic) so the
 * fetch happens on the server, not in the browser.
 */

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const revalidate = 0;

const REALTIME_PORT = 3003;
const HEALTH_URL = `http://127.0.0.1:${REALTIME_PORT}/health`;
const HEALTH_TIMEOUT_MS = 2000;

interface RealtimeStatus {
  running: boolean;
  connections: number;
  uptime: number;
  port: number;
  /** Present only when the service is up — opaque passthrough of channels. */
  channels?: string[];
  /** Present only when the service is down — short error reason. */
  error?: string;
}

export async function GET(): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);

  try {
    const res = await fetch(HEALTH_URL, {
      method: 'GET',
      signal: controller.signal,
      cache: 'no-store',
      headers: { Accept: 'application/json' },
    });

    if (!res.ok) {
      // Service responded but with an error status — treat as down.
      const body: RealtimeStatus = {
        running: false,
        connections: 0,
        uptime: 0,
        port: REALTIME_PORT,
        error: `health check HTTP ${res.status}`,
      };
      return Response.json(body, { status: 200 });
    }

    const json = (await res.json()) as {
      ok?: boolean;
      connections?: number;
      uptime?: number;
      port?: number;
      channels?: string[];
    };

    const body: RealtimeStatus = {
      running: Boolean(json?.ok),
      connections: Number(json?.connections ?? 0) || 0,
      uptime: Number(json?.uptime ?? 0) || 0,
      port: REALTIME_PORT,
      channels: Array.isArray(json?.channels) ? json.channels : undefined,
    };
    return Response.json(body, { status: 200 });
  } catch (err) {
    // Fetch failed (timeout, connection refused, DNS, etc.) — the service is
    // considered down. We still return HTTP 200 so clients don't have to
    // handle a separate error path.
    const reason =
      err instanceof Error
        ? err.name === 'AbortError'
          ? 'timeout'
          : err.message
        : 'fetch failed';
    const body: RealtimeStatus = {
      running: false,
      connections: 0,
      uptime: 0,
      port: REALTIME_PORT,
      error: reason,
    };
    return Response.json(body, { status: 200 });
  } finally {
    clearTimeout(timer);
  }
}
