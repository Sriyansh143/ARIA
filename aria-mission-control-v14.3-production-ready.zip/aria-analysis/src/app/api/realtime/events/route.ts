import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/realtime/events — recent realtime broadcast events (from RealtimeEvent table).
// Returns the last N events, newest-first. Supports ?channel= and ?limit= filters.
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 100), 500);
  const channel = req.nextUrl.searchParams.get('channel');

  const where = channel ? { channel } : {};
  const events = await db.realtimeEvent.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    select: {
      id: true,
      channel: true,
      event: true,
      payload: true,
      broadcastTo: true,
      createdAt: true,
    },
  });

  // Tally counts per channel for the filter chips.
  const allCounts = await db.realtimeEvent.groupBy({
    by: ['channel'],
    _count: true,
  }).catch(() => []);
  const counts: Record<string, number> = {};
  for (const c of allCounts) counts[c.channel] = c._count;
  const total = await db.realtimeEvent.count().catch(() => 0);

  return NextResponse.json({
    events: events.map((e) => {
      let payload: unknown = null;
      try { payload = JSON.parse(e.payload); } catch { payload = e.payload; }
      return {
        ...e,
        payload,
        createdAt: e.createdAt.toISOString(),
      };
    }),
    counts,
    total,
  });
}

// POST /api/realtime/events — manually log a realtime event (for testing/replay).
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { channel, event, payload, broadcastTo } = body as {
    channel?: string;
    event?: string;
    payload?: unknown;
    broadcastTo?: string;
  };
  if (!channel || !event) {
    return NextResponse.json({ error: 'channel and event required' }, { status: 400 });
  }
  const row = await db.realtimeEvent.create({
    data: {
      channel,
      event,
      payload: typeof payload === 'string' ? payload : JSON.stringify(payload ?? {}),
      broadcastTo: broadcastTo ?? 'all',
    },
  });
  return NextResponse.json({ ok: true, id: row.id });
}
