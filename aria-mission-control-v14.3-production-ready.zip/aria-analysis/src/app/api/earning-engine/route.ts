import { NextRequest, NextResponse } from 'next/server';
import { getEarningStats, findEarningOpportunities, runEarningPipeline, qualifyOpportunity, type EarningOpportunity } from '@/lib/earning-engine';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET — earning dashboard stats
export async function GET() {
  const stats = await getEarningStats();
  return NextResponse.json(stats);
}

// POST — run earning pipeline (find → qualify → create)
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { action, opportunity, count } = body as {
    action?: 'find' | 'qualify' | 'pipeline';
    opportunity?: EarningOpportunity;
    count?: number;
  };

  if (action === 'find') {
    const opportunities = await findEarningOpportunities(count ?? 5);
    return NextResponse.json({ opportunities, count: opportunities.length });
  }

  if (action === 'qualify' && opportunity) {
    const result = await qualifyOpportunity(opportunity);
    return NextResponse.json(result);
  }

  if (action === 'pipeline' || !action) {
    const result = await runEarningPipeline(count ?? 3);
    return NextResponse.json(result);
  }

  return NextResponse.json({ error: 'Specify action: find, qualify, or pipeline' }, { status: 400 });
}
