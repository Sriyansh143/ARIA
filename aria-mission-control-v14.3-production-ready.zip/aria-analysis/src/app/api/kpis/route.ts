import { NextResponse } from 'next/server';
import { getLatestKpis, autoAdjustKpis } from '@/lib/kpi-engine';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET — latest KPI status with auto-adjusted targets.
export async function GET() {
  const kpis = await getLatestKpis();
  return NextResponse.json({ kpis, generatedAt: new Date().toISOString() });
}

// POST — trigger a manual KPI re-evaluation + auto-adjustment.
export async function POST() {
  const kpis = await autoAdjustKpis('manual');
  return NextResponse.json({ ok: true, kpis, adjustedAt: new Date().toISOString() });
}
