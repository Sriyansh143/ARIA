import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// GET /api/kpis/history — time-series of KPI snapshots for trend charts.
// Returns the last N snapshots (default 48, max 200) for each KPI, oldest-first.
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 48), 200);
  const kpi = req.nextUrl.searchParams.get('kpi'); // optional filter

  const where = kpi ? { kpi } : {};
  const rows = await db.kpiSnapshot.findMany({
    where,
    orderBy: { snapshotAt: 'desc' },
    take: limit,
    select: { id: true, kpi: true, value: true, target: true, status: true, autoAdjusted: true, adjustmentNote: true, snapshotAt: true },
  });

  // Reverse to oldest-first for charting + group by KPI.
  const reversed = [...rows].reverse();
  const byKpi: Record<string, Array<{
    snapshotAt: string;
    value: number;
    target: number;
    status: string;
    autoAdjusted: boolean;
  }>> = {};
  for (const r of reversed) {
    if (!byKpi[r.kpi]) byKpi[r.kpi] = [];
    byKpi[r.kpi].push({
      snapshotAt: r.snapshotAt.toISOString(),
      value: r.value,
      target: r.target,
      status: r.status,
      autoAdjusted: r.autoAdjusted,
    });
  }

  return NextResponse.json({
    series: byKpi,
    count: reversed.length,
    kpis: Object.keys(byKpi),
  });
}
