import { NextRequest, NextResponse } from 'next/server';
import {
  generate3DWebsite,
  website3dSizeKb,
  coerceTemplateId,
  getWebsite3DTemplates,
} from '@/lib/website-3d-builder';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface GenerateBody {
  templateId?: string;
  title?: string;
  description?: string;
  colorScheme?: string;
}

/**
 * POST /api/website-3d/generate
 * Body: { templateId, title, description, colorScheme }
 * Returns: { html, sizeKb, template }
 *
 * Generates a complete standalone HTML string containing a Three.js (r128)
 * interactive 3D scene. The HTML loads Three.js + OrbitControls from CDN,
 * renders a responsive canvas filling the viewport, and overlays the title +
 * description as a UI panel. Single self-contained file — no build step.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as GenerateBody;

  const templateId = coerceTemplateId(body.templateId);
  const title = (body.title ?? '').trim();
  const description = (body.description ?? '').trim();
  const colorScheme = body.colorScheme ?? 'dark';

  if (!title) {
    return NextResponse.json(
      { error: 'title is required' },
      { status: 400 },
    );
  }

  try {
    const html = generate3DWebsite({
      templateId,
      title,
      description,
      colorScheme,
    });
    const template = getWebsite3DTemplates().find((t) => t.id === templateId);
    return NextResponse.json({
      html,
      sizeKb: website3dSizeKb(html),
      sizeBytes: html.length,
      template,
      templateId,
      colorScheme,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Generation failed' },
      { status: 500 },
    );
  }
}
