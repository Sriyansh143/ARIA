import { NextResponse } from 'next/server';
import {
  WEBSITE_3D_TEMPLATES,
  WEBSITE_3D_COLOR_SCHEMES,
} from '@/lib/website-3d-builder';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/website-3d
 * Returns the catalog of 3D website templates + color schemes used by the
 * 3D Website Builder tab.
 */
export async function GET() {
  return NextResponse.json({
    templates: WEBSITE_3D_TEMPLATES,
    colorSchemes: WEBSITE_3D_COLOR_SCHEMES.map((s) => ({
      id: s.id,
      label: s.label,
    })),
    defaultTemplateId: 'product-showcase',
    defaultColorScheme: 'dark',
  });
}
