// multi-agent-discuss.ts — Multi-agent consensus and debate engine
import { db } from '@/lib/db';
import { chat, extractJson } from '@/lib/llm';
import { createApproval } from '@/lib/approval-escalation';

export interface DiscussionResult {
  success: boolean; topic: string; participants: string[];
  consensusSummary: string; tasksCreated: number; approvalsRequested: number;
  artifactsCreated: string[]; durationMs: number;
}

export async function runMultiAgentDiscussion(topic: string, agentKeys?: string[], rounds?: number): Promise<DiscussionResult> {
  const start = Date.now();
  const participants = agentKeys?.length ? agentKeys : ['ORION', 'ATLAS', 'SAGE'];
  const numRounds = rounds ?? 3;

  try {
    const agents = await db.agent.findMany({ where: { codename: { in: participants } } });
    if (agents.length === 0) return { success: false, topic, participants, consensusSummary: 'No agents found', tasksCreated: 0, approvalsRequested: 0, artifactsCreated: [], durationMs: Date.now() - start };

    const turns: Array<{ round: number; agent: string; content: string }> = [];
    for (let round = 1; round <= numRounds; round++) {
      for (const agent of agents) {
        if (Date.now() - start > 30000) break;
        try {
          let prompt: string;
          if (round === 1) prompt = `Topic: "${topic}". As ${agent.name} (${agent.role}), provide your initial proposal.`;
          else if (round === 2) {
            const prev = turns.filter(t => t.round === 1).map(t => `${t.agent}: ${t.content}`).join('\n');
            prompt = `Topic: "${topic}". Previous proposals:\n${prev}\n\nAs ${agent.name}, critique and suggest improvements.`;
          } else {
            if (agent.codename !== 'ORION') continue;
            const all = turns.map(t => `[R${t.round}] ${t.agent}: ${t.content}`).join('\n');
            prompt = `Topic: "${topic}". All discussion:\n${all}\n\nAs CEO, synthesize into an actionable plan.`;
          }
          const res = await chat(prompt, [], `You are ${agent.name}, a ${agent.role}. Be concise (under 200 words).`);
          turns.push({ round, agent: agent.codename, content: res.content });
          await db.agentMessage.create({ data: { fromAgent: agent.codename, toAgent: 'BROADCAST', subject: `Discussion R${round}`, body: res.content.slice(0, 2000), thread: `discussion-${start}` } }).catch(() => {});
        } catch {}
      }
    }

    const consensus = turns.find(t => t.round === numRounds)?.content ?? 'No consensus';
    let tasksCreated = 0, approvalsRequested = 0;
    const artifactsCreated: string[] = [];

    try {
      const transcript = turns.map(t => `## R${t.round} — ${t.agent}\n${t.content}`).join('\n\n');
      const artifact = await db.artifact.create({ data: { name: `discussion-${Date.now()}.md`, type: 'discussion_transcript', size: transcript.length, meta: JSON.stringify({ topic, participants }) } });
      artifactsCreated.push(artifact.id);
    } catch {}

    try {
      const actionRes = await chat(`Extract tasks from: ${consensus}\nOutput JSON: {"tasks":[{"title":"...","priority":"medium"}],"needsApproval":false}`);
      const actions = extractJson<{ tasks?: Array<{ title: string; priority?: string }>; needsApproval?: boolean }>(actionRes.content);
      if (actions?.tasks) for (const t of actions.tasks) { await db.task.create({ data: { title: t.title, status: 'pending', priority: t.priority ?? 'medium' } }).catch(() => {}); tasksCreated++; }
      if (actions?.needsApproval) { await createApproval({ category: 'app-change', title: `Discussion: ${topic.slice(0, 60)}`, description: consensus.slice(0, 500), requestedBy: 'multi-agent-discuss' }).catch(() => {}); approvalsRequested++; }
    } catch {}

    return { success: true, topic, participants, consensusSummary: consensus, tasksCreated, approvalsRequested, artifactsCreated, durationMs: Date.now() - start };
  } catch (err) {
    return { success: false, topic, participants, consensusSummary: `Failed: ${err instanceof Error ? err.message : 'error'}`, tasksCreated: 0, approvalsRequested: 0, artifactsCreated: [], durationMs: Date.now() - start };
  }
}
