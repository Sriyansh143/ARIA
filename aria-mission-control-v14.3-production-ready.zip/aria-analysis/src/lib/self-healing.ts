// =====================================================================
// self-healing.ts -- Auto-retry wrapper for agent tasks.
// =====================================================================
// Adapted for v10: our chat() returns { content, latencyMs } (no
// tokensIn/tokensOut/model kwargs). Token usage is estimated from the
// content length so the budget gate still works. AgentMetric doesn't
// exist in our Prisma schema, so we log outcomes to Notification +
// keep an in-memory ring buffer for callers that want recent history.
// =====================================================================

import { chat } from '@/lib/llm'
import { db } from '@/lib/db'

const MAX_RETRIES = 3
const MAX_TOKENS_PER_TASK = 50_000 // hard cap to prevent runaway token burn

/** In-memory ring of recent self-healing outcomes (for dashboards). */
export interface SelfHealingOutcome {
  id: string
  task: string
  success: boolean
  attempts: number
  totalTokens: number
  durationMs: number
  errorHistory: string[]
  createdAt: Date
}
const RECENT_OUTCOMES_LIMIT = 50
const recentOutcomes: SelfHealingOutcome[] = []

export function getRecentSelfHealingOutcomes(): SelfHealingOutcome[] {
  return [...recentOutcomes]
}

export interface SelfHealingResult {
  success: boolean
  result: string
  attempts: number
  totalTokens: number
  durationMs: number
  errorHistory: string[]
}

/** Crude token estimate: ~4 chars per token, summed across prompt+output. */
function estimateTokens(text: string): number {
  return Math.ceil((text?.length ?? 0) / 4)
}

/** Persist an outcome as a Notification (best-effort) + in-memory ring. */
async function recordOutcome(outcome: SelfHealingOutcome): Promise<void> {
  recentOutcomes.unshift(outcome)
  if (recentOutcomes.length > RECENT_OUTCOMES_LIMIT) recentOutcomes.pop()
  try {
    await db.notification.create({
      data: {
        type: outcome.success ? 'success' : 'warn',
        title: `Self-healing ${outcome.success ? 'succeeded' : 'failed'} (${outcome.attempts} attempts)`,
        message: outcome.task.slice(0, 180),
        read: false,
      },
    })
  } catch {
    /* best-effort — never block on audit log */
  }
}

// ─── Execute a task with self-healing ────────────────────────────────
export async function executeWithSelfHealing(opts: {
  task: string
  systemPrompt?: string
  maxTokens?: number
}): Promise<SelfHealingResult> {
  const start = Date.now()
  const errors: string[] = []
  let totalTokens = 0
  let lastResult = ''

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    // Check token budget
    if (totalTokens >= MAX_TOKENS_PER_TASK) {
      console.warn(
        `[self-healing] token budget exhausted (used ${totalTokens} of ${MAX_TOKENS_PER_TASK})`,
      )
      errors.push(`Token budget exhausted (${totalTokens} >= ${MAX_TOKENS_PER_TASK})`)
      break
    }

    // Build prompt — include error history on retries
    let prompt = opts.task
    if (attempt > 1 && errors.length > 0) {
      const lastError = errors[errors.length - 1]
      prompt = `Previous attempt failed with error:
${lastError}

Fix the issue and retry the original task:
${opts.task}

Common fixes:
- If "module not found" → check import paths
- If "timeout" → simplify the approach
- If "syntax error" → check for typos
- If "permission denied" → check file permissions`
    }

    try {
      const result = await chat(prompt, [], opts.systemPrompt)
      totalTokens += estimateTokens(prompt) + estimateTokens(result.content)
      lastResult = result.content

      // Check if the result indicates success
      if (!result.content.startsWith('[error]') && !result.content.includes('Error:')) {
        const outcome: SelfHealingOutcome = {
          id: crypto.randomUUID(),
          task: opts.task,
          success: true,
          attempts: attempt,
          totalTokens,
          durationMs: Date.now() - start,
          errorHistory: errors,
          createdAt: new Date(),
        }
        await recordOutcome(outcome)

        return {
          success: true,
          result: lastResult,
          attempts: attempt,
          totalTokens,
          durationMs: Date.now() - start,
          errorHistory: errors,
        }
      }

      // Result contains an error
      errors.push(result.content.slice(0, 500))
      console.warn(
        `[self-healing] attempt ${attempt} failed, retrying. Error: ${errors[errors.length - 1]}`,
      )
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      errors.push(msg)
      console.warn(`[self-healing] attempt ${attempt} threw, retrying. Error: ${msg}`)
    }
  }

  // All retries exhausted — escalate
  console.warn(
    `[self-healing] all ${MAX_RETRIES} retries failed, escalating. Errors: ${errors.join(' | ')}`,
  )

  const failedOutcome: SelfHealingOutcome = {
    id: crypto.randomUUID(),
    task: opts.task,
    success: false,
    attempts: MAX_RETRIES,
    totalTokens,
    durationMs: Date.now() - start,
    errorHistory: errors,
    createdAt: new Date(),
  }
  await recordOutcome(failedOutcome)

  return {
    success: false,
    result: `Task failed after ${MAX_RETRIES} attempts.\n\nError history:\n${errors
      .map((e, i) => `${i + 1}. ${e}`)
      .join('\n')}\n\nLast result:\n${lastResult}`,
    attempts: MAX_RETRIES,
    totalTokens,
    durationMs: Date.now() - start,
    errorHistory: errors,
  }
}

// ─── Escalate to CTO agent ───────────────────────────────────────────
export async function escalateToCTO(task: string, errorHistory: string[]): Promise<string> {
  const prompt = `As CTO, a task has been escalated to you after ${errorHistory.length} failed attempts.

ORIGINAL TASK: ${task}

ERROR HISTORY:
${errorHistory.map((e, i) => `${i + 1}. ${e}`).join('\n')}

Analyze the errors, identify the root cause, and provide a definitive solution.`

  try {
    const result = await chat(
      prompt,
      [],
      'You are the CTO. Be decisive — give the single most likely root cause and the exact fix.',
    )
    return result.content
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return `CTO escalation also failed: ${msg}`
  }
}

// =====================================================================
// Self-healing scanner — scans recent AgentLog errors and creates a Task
// for each unique error so the autonomous loop / an engineer agent can
// pick it up. Designed to be called by the `self-heal` cron job.
//
// Flow:
//   1. Pull AgentLog rows where level='error' AND createdAt > 1h ago.
//   2. Dedupe by message prefix (first 80 chars) so we don't spam tasks
//      for the same error logged repeatedly.
//   3. Skip errors that already have an open Task with the same title
//      (best-effort — keeps the task queue tidy).
//   4. For each new unique error, create a Task (priority='high',
//      tags=['self-heal','auto-created'], assigneeId=null so any agent
//      can pick it up). The autonomous loop's checkPendingTasks() will
//      route it to an LLM agent.
//
// NEVER throws — the cron tick must stay alive. All DB calls are wrapped
// in try/catch and return a structured result.
// =====================================================================

export interface SelfHealScanResult {
  ok: boolean
  scanned: number
  tasksCreated: number
  deduped: number
  errors?: string
}

export async function scanForErrorsAndCreateTasks(opts?: {
  lookbackMs?: number
  maxTasks?: number
}): Promise<SelfHealScanResult> {
  const lookbackMs = opts?.lookbackMs ?? 60 * 60 * 1000 // 1 hour
  const maxTasks = opts?.maxTasks ?? 10
  const since = new Date(Date.now() - lookbackMs)

  try {
    // 1. Pull recent error-level AgentLog entries.
    const errorLogs = await db.agentLog.findMany({
      where: { level: 'error', createdAt: { gte: since } },
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { id: true, agentId: true, message: true, meta: true, createdAt: true },
    })

    if (errorLogs.length === 0) {
      return { ok: true, scanned: 0, tasksCreated: 0, deduped: 0 }
    }

    // 2. Dedupe by message prefix (first 80 chars).
    const seenPrefixes = new Set<string>()
    const uniqueErrors: Array<{ agentId: string; message: string; createdAt: Date }> = []
    for (const log of errorLogs) {
      const prefix = log.message.slice(0, 80).trim()
      if (!prefix || seenPrefixes.has(prefix)) continue
      seenPrefixes.add(prefix)
      uniqueErrors.push({ agentId: log.agentId, message: log.message, createdAt: log.createdAt })
    }

    // 3. Pull existing open tasks with title prefix '[self-heal]' so we
    //    don't recreate tasks for errors that are already queued.
    let existingTitles: Set<string> = new Set()
    try {
      const existing = await db.task.findMany({
        where: { tags: { contains: 'self-heal' }, status: { in: ['pending', 'in_progress'] } },
        select: { title: true },
        take: 200,
      })
      existingTitles = new Set(existing.map((t) => t.title))
    } catch {
      /* best-effort — assume no existing tasks */
    }

    // 4. Create a Task for each unique error (up to maxTasks).
    let tasksCreated = 0
    let deduped = 0
    for (const err of uniqueErrors) {
      if (tasksCreated >= maxTasks) break
      const title = `[self-heal] ${err.message.slice(0, 100)}`
      if (existingTitles.has(title)) {
        deduped++
        continue
      }
      try {
        await db.task.create({
          data: {
            title,
            description:
              `Auto-created by the self-healing scanner.\n\n` +
              `Source: AgentLog (agentId=${err.agentId}, level=error)\n` +
              `Logged at: ${err.createdAt.toISOString()}\n\n` +
              `Full error message:\n${err.message.slice(0, 2000)}`,
            status: 'pending',
            priority: 'high',
            assigneeId: null, // any agent can pick it up via autonomous loop
            tags: JSON.stringify(['self-heal', 'auto-created', 'error-recovery']),
          },
        })
        existingTitles.add(title)
        tasksCreated++
      } catch {
        /* best-effort — skip this one if the create fails */
      }
    }

    return {
      ok: true,
      scanned: errorLogs.length,
      tasksCreated,
      deduped: deduped + (uniqueErrors.length - tasksCreated - deduped),
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    console.warn(`[self-healing] scanForErrorsAndCreateTasks failed: ${msg}`)
    return { ok: false, scanned: 0, tasksCreated: 0, deduped: 0, errors: msg }
  }
}
