// =====================================================================
// env-watcher.ts — Watches .env for changes + auto-syncs models
// =====================================================================
// PRODUCTION ENHANCEMENT (v11.4): Watches the .env file for modifications.
// When new provider API keys are added, automatically triggers a model sync
// so the new provider's models are loaded into the catalog immediately.
//
// Also runs an initial sync on startup if any configured provider has 0
// models in the catalog (meaning models haven't been synced yet).
// =====================================================================

import * as fs from 'fs';
import * as path from 'path';
import { logger } from '@/lib/logger';

const ENV_FILE = path.join(process.cwd(), '.env');
const CHECK_INTERVAL_MS = 300_000; // check every 5min (was 30s — too aggressive, added CPU load)

let _watcherStarted = false;
let _lastMtime = 0;
let _lastSyncTime = 0;
let _lastKeyHash = '';

// Provider env var names to watch for changes.
// When any of these change in .env, the watcher triggers a model catalog sync.
const PROVIDER_ENV_KEYS = [
  'ZAI_API_KEY', 'GROQ_API_KEY', 'NVIDIA_API_KEY', 'SILICONFLOW_API_KEY',
  'QWEN_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GEMINI_API_KEY',
  'GOOGLE_API_KEY', 'OPENROUTER_API_KEY', 'DEEPSEEK_API_KEY', 'COHERE_API_KEY',
  'MISTRAL_API_KEY', 'TOGETHER_API_KEY', 'HUGGINGFACE_API_KEY', 'BYTEZ_API_KEY',
  'OMNIROUTE_API_KEY', 'OLLAMA_HOST', 'HIGGSFIELD_API_KEY', 'GITHUB_TOKEN',
  'SARVAM_API_KEY', 'DOGRAH_API_KEY',
];

/**
 * Read the current provider keys from .env and compute a hash.
 * If the hash changes, we know a provider key was added/changed.
 */
function getProviderKeyHash(): string {
  try {
    if (!fs.existsSync(ENV_FILE)) return '';
    const content = fs.readFileSync(ENV_FILE, 'utf-8');
    const lines = content.split('\n');
    const keyParts: string[] = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      if (PROVIDER_ENV_KEYS.includes(key)) {
        const value = trimmed.slice(eqIdx + 1).trim();
        // Only include non-empty values (has a key configured)
        if (value) {
          keyParts.push(`${key}=yes`);
        }
      }
    }
    return keyParts.sort().join('|');
  } catch {
    return '';
  }
}

/**
 * Check if .env was modified and provider keys changed.
 * If so, trigger a model sync.
 */
async function checkAndSync(): Promise<void> {
  try {
    // Check file modification time
    if (!fs.existsSync(ENV_FILE)) return;
    const stat = fs.statSync(ENV_FILE);
    if (stat.mtimeMs <= _lastMtime) return; // no change

    _lastMtime = stat.mtimeMs;

    // Check if provider keys changed
    const currentHash = getProviderKeyHash();
    if (currentHash === _lastKeyHash) return; // no provider key change
    if (!_lastKeyHash) {
      // First run — just store the hash, don't sync (startup sync handles it)
      _lastKeyHash = currentHash;
      return;
    }

    _lastKeyHash = currentHash;

    // Throttle: don't sync more than once per 60s
    if (Date.now() - _lastSyncTime < 60_000) return;

    logger.info({ hash: currentHash }, 'env-watcher: provider keys changed — triggering model sync');

    // Trigger model sync
    try {
      const { syncAll } = await import('./model-sync');
      const { seedAgentModelAssignments } = await import('./agent-model-resolver');
      const { discoverModelsFromMemory } = await import('./model-discovery');

      const report = await syncAll();
      await seedAgentModelAssignments();
      await discoverModelsFromMemory();

      _lastSyncTime = Date.now();
      logger.info({
        added: report.totalAdded,
        providers: report.providers.length,
      }, 'env-watcher: model sync complete');
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'env-watcher: model sync failed');
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'env-watcher: check failed');
  }
}

/**
 * Start the env file watcher. Checks every 30s for .env changes.
 * If provider keys are added/changed, auto-triggers a model sync.
 */
export function startEnvWatcher(): void {
  if (_watcherStarted) return;
  _watcherStarted = true;

  // Initialize hash + mtime
  _lastMtime = fs.existsSync(ENV_FILE) ? fs.statSync(ENV_FILE).mtimeMs : 0;
  _lastKeyHash = getProviderKeyHash();

  logger.info({ intervalMs: CHECK_INTERVAL_MS }, 'env-watcher: started — watching .env for provider key changes');

  setInterval(() => {
    checkAndSync().catch(() => { /* best-effort */ });
  }, CHECK_INTERVAL_MS);
}

/**
 * Run an initial model sync on startup if any configured provider has 0 models.
 * This ensures models are loaded even if the user just added API keys.
 */
export async function syncOnStartupIfNeeded(): Promise<void> {
  try {
    const { db } = await import('./db');
    const modelCount = await db.model.count();
    const configuredProviders = getProviderKeyHash().split('|').filter(Boolean).length;

    if (modelCount === 0 && configuredProviders > 0) {
      logger.info({ modelCount, configuredProviders }, 'env-watcher: no models in catalog — running startup sync');
      const { syncAll } = await import('./model-sync');
      const { seedAgentModelAssignments } = await import('./agent-model-resolver');
      const report = await syncAll();
      await seedAgentModelAssignments();
      logger.info({ added: report.totalAdded }, 'env-watcher: startup sync complete');
    } else {
      logger.info({ modelCount, configuredProviders }, 'env-watcher: catalog already has models — skipping startup sync');
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'env-watcher: startup sync failed');
  }
}

/**
 * Get the current watcher status (for the System Health tab).
 */
export function getEnvWatcherStatus(): {
  running: boolean;
  lastMtime: string;
  lastSyncTime: string;
  providerKeyHash: string;
  configuredProviderCount: number;
} {
  const hash = _lastKeyHash;
  const count = hash ? hash.split('|').filter(Boolean).length : 0;
  return {
    running: _watcherStarted,
    lastMtime: _lastMtime ? new Date(_lastMtime).toISOString() : null,
    lastSyncTime: _lastSyncTime ? new Date(_lastSyncTime).toISOString() : null,
    providerKeyHash: hash,
    configuredProviderCount: count,
  };
}
