// =====================================================================
// csat-engine.ts — Customer Satisfaction (CSAT) survey scheduling +
// submission + stats. Server-side only (uses db + LLM).
// =====================================================================
// Surveys are created in status='pending' immediately after an invoice is
// paid. Seven days later the cron-driven `processDueCsatSurveys()` flips
// them to status='sent' (in a real system this also emails the client a
// survey link). The client submits their 1-5 star rating + optional NPS
// (0-10) + free-text feedback; we use `quickChat()` to label the
// feedback as positive | neutral | negative so the dashboard can show a
// live sentiment split.
// =====================================================================

import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';

const DAY_MS = 24 * 60 * 60 * 1000;
/** Days after a survey is created before it's eligible to be sent. */
export const CSAT_SEND_DELAY_DAYS = 7;
/** Days after creation before an unsent/uncompleted survey is marked expired. */
export const CSAT_EXPIRY_DAYS = 14;

export type CsatSentiment = 'positive' | 'neutral' | 'negative';
const VALID_SENTIMENTS = new Set<CsatSentiment>(['positive', 'neutral', 'negative']);

/* ─── scheduleCsatSurvey ──────────────────────────────────────────────
 * Creates a CsatSurvey in status='pending' with expiresAt = now + 14d.
 * `invoiceId` and `clientId` are optional (a survey can be ad-hoc).
 * Returns the created survey row.
 * ──────────────────────────────────────────────────────────────────── */
export async function scheduleCsatSurvey(
  invoiceId: string | null | undefined,
  clientEmail: string,
  clientName: string,
  clientId?: string | null,
): Promise<{ id: string; status: string; expiresAt: Date | string }> {
  if (!clientEmail || typeof clientEmail !== 'string') {
    throw new Error('clientEmail is required');
  }
  if (!clientName || typeof clientName !== 'string') {
    throw new Error('clientName is required');
  }
  const now = new Date();
  const survey = await db.csatSurvey.create({
    data: {
      invoiceId: invoiceId ?? null,
      clientId: clientId ?? null,
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim(),
      rating: 0, // placeholder — set on submit
      status: 'pending',
      expiresAt: new Date(now.getTime() + CSAT_EXPIRY_DAYS * DAY_MS),
    },
  });
  logger.info({ surveyId: survey.id, invoiceId: invoiceId ?? null }, 'csat: survey scheduled');
  return survey;
}

/* ─── sendCsatSurvey ──────────────────────────────────────────────────
 * Marks a survey status='sent' + sentAt=now. In a real system this is
 * where the email to the client would be dispatched. Idempotent — a
 * survey already sent/completed is returned unchanged.
 * ──────────────────────────────────────────────────────────────────── */
export async function sendCsatSurvey(
  surveyId: string,
): Promise<{ id: string; status: string; sentAt: Date | string | null }> {
  const existing = await db.csatSurvey.findUnique({ where: { id: surveyId } });
  if (!existing) throw new Error(`CSAT survey not found: ${surveyId}`);
  if (existing.status === 'sent' || existing.status === 'completed') {
    return existing;
  }
  const now = new Date();
  const updated = await db.csatSurvey.update({
    where: { id: surveyId },
    data: { status: 'sent', sentAt: now },
  });
  logger.info({ surveyId }, 'csat: survey marked sent (email stub)');
  return updated;
}

/* ─── analyzeSentiment (internal) ─────────────────────────────────────
 * Uses `quickChat()` to label feedback as positive | neutral | negative.
 * Returns 'neutral' on any error so submission never fails because of
 * the LLM step.
 * ──────────────────────────────────────────────────────────────────── */
async function analyzeSentiment(feedback: string): Promise<CsatSentiment> {
  const text = feedback?.trim();
  if (!text) return 'neutral';
  try {
    const system =
      'You classify customer feedback sentiment. Reply with exactly ONE word: ' +
      '"positive", "neutral", or "negative". No other text, no punctuation.';
    const raw = await quickChat(
      `Classify this customer feedback:\n\n"""${text.slice(0, 1200)}"""`,
      system,
      false,
    );
    const cleaned = (raw || '').trim().toLowerCase().split(/[^a-z]+/)[0] as CsatSentiment;
    if (VALID_SENTIMENTS.has(cleaned)) return cleaned;
    // Fallback heuristic based on rating.
    return 'neutral';
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'csat: sentiment LLM failed, defaulting to neutral');
    return 'neutral';
  }
}

/* ─── submitCsatResponse ──────────────────────────────────────────────
 * Records the client's response. Sets status='completed', completedAt=now,
 * stores rating (1-5) + optional npsScore (0-10) + optional feedback,
 * and runs sentiment analysis on the feedback via `quickChat()`.
 * Returns the updated survey.
 * ──────────────────────────────────────────────────────────────────── */
export async function submitCsatResponse(
  surveyId: string,
  rating: number,
  npsScore?: number | null,
  feedback?: string | null,
): Promise<{
  id: string;
  status: string;
  rating: number;
  npsScore: number | null;
  feedback: string | null;
  sentiment: string | null;
  completedAt: Date | string | null;
}> {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    throw new Error('rating must be an integer between 1 and 5');
  }
  if (npsScore != null && (typeof npsScore !== 'number' || npsScore < 0 || npsScore > 10)) {
    throw new Error('npsScore must be between 0 and 10');
  }
  const existing = await db.csatSurvey.findUnique({ where: { id: surveyId } });
  if (!existing) throw new Error(`CSAT survey not found: ${surveyId}`);
  if (existing.status === 'completed') {
    throw new Error('Survey already completed');
  }
  // Mark expired if past expiresAt (still allow submitting within grace).
  const now = new Date();
  const trimmedFeedback = feedback && typeof feedback === 'string' ? feedback.trim() : null;
  const sentiment = trimmedFeedback ? await analyzeSentiment(trimmedFeedback) : 'neutral';

  const updated = await db.csatSurvey.update({
    where: { id: surveyId },
    data: {
      status: 'completed',
      rating,
      npsScore: npsScore ?? null,
      feedback: trimmedFeedback,
      sentiment,
      completedAt: now,
    },
  });
  logger.info({ surveyId, rating, sentiment }, 'csat: response submitted');
  return updated;
}

/* ─── CsatStats shape ──────────────────────────────────────────────── */
export interface CsatStats {
  totalSent: number;
  totalCompleted: number;
  avgRating: number;
  avgNps: number;
  responseRate: number; // 0-100
  sentimentBreakdown: { positive: number; neutral: number; negative: number };
}

/* ─── getCsatStats ────────────────────────────────────────────────────
 * Aggregate metrics for the dashboard. totalSent counts surveys that have
 * been sent OR completed (pending surveys are not yet "sent"). responseRate
 * = totalCompleted / totalSent * 100.
 * ──────────────────────────────────────────────────────────────────── */
export async function getCsatStats(): Promise<CsatStats> {
  const [sent, completed, pending] = await Promise.all([
    db.csatSurvey.count({ where: { status: { in: ['sent', 'completed'] } } }),
    db.csatSurvey.count({ where: { status: 'completed' } }),
    db.csatSurvey.count({ where: { status: 'pending' } }),
  ]);

  // Average rating across completed surveys.
  const ratingAgg = await db.csatSurvey.aggregate({
    where: { status: 'completed' },
    _avg: { rating: true },
  });
  const avgRating = ratingAgg._avg.rating ?? 0;

  // Average NPS across completed surveys that have an npsScore.
  const npsAgg = await db.csatSurvey.aggregate({
    where: { status: 'completed', npsScore: { not: null } },
    _avg: { npsScore: true },
  });
  const avgNps = npsAgg._avg.npsScore ?? 0;

  // Sentiment breakdown — count completed surveys grouped by sentiment.
  const sentimentRows = await db.csatSurvey.groupBy({
    by: ['sentiment'],
    where: { status: 'completed' },
    _count: true,
  });
  const sentimentBreakdown = { positive: 0, neutral: 0, negative: 0 };
  for (const row of sentimentRows) {
    const key = (row.sentiment ?? 'neutral') as CsatSentiment;
    if (VALID_SENTIMENTS.has(key)) {
      sentimentBreakdown[key] = row._count;
    } else {
      sentimentBreakdown.neutral += row._count;
    }
  }

  const responseRate = sent > 0 ? Math.round((completed / sent) * 1000) / 10 : 0;

  return {
    totalSent: sent,
    totalCompleted: completed,
    avgRating: Math.round(avgRating * 100) / 100,
    avgNps: Math.round(avgNps * 100) / 100,
    responseRate,
    sentimentBreakdown,
  };
}

/* ─── getPendingCsatSurveys ───────────────────────────────────────────
 * Returns surveys due to be sent: status='pending' AND createdAt older
 * than 7 days. These are picked up by the next cron tick.
 * ──────────────────────────────────────────────────────────────────── */
export async function getPendingCsatSurveys() {
  const cutoff = new Date(Date.now() - CSAT_SEND_DELAY_DAYS * DAY_MS);
  return db.csatSurvey.findMany({
    where: { status: 'pending', createdAt: { lt: cutoff } },
    orderBy: { createdAt: 'asc' },
    take: 100,
  });
}

/* ─── processDueCsatSurveys ───────────────────────────────────────────
 * Cron entry point. Finds all pending surveys older than 7 days and
 * sends them. Also marks any pending surveys past their expiresAt as
 * 'expired'. Returns counts.
 * ──────────────────────────────────────────────────────────────────── */
export async function processDueCsatSurveys(): Promise<{
  sent: number;
  expired: number;
  checked: number;
}> {
  const due = await getPendingCsatSurveys();
  let sent = 0;
  let expired = 0;
  const now = new Date();
  for (const s of due) {
    try {
      // If past expiry window, mark expired instead of sending.
      if (s.expiresAt && s.expiresAt < now) {
        await db.csatSurvey.update({ where: { id: s.id }, data: { status: 'expired' } });
        expired++;
        continue;
      }
      await sendCsatSurvey(s.id);
      sent++;
    } catch (err) {
      logger.error(
        { err: err instanceof Error ? err.message : String(err), surveyId: s.id },
        'csat: processDueCsatSurveys — failed to send one survey',
      );
    }
  }
  logger.info({ sent, expired, checked: due.length }, 'csat: processDueCsatSurveys complete');
  return { sent, expired, checked: due.length };
}
