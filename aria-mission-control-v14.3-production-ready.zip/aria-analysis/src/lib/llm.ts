// ARIA LLM client — unified interface with multi-provider fallback + thinking mode + pro-scaffold.
// SERVER-SIDE ONLY. Never import this from a client component.

import ZAI from 'z-ai-web-dev-sdk';
import { withProScaffold, type ProTaskType } from '@/lib/pro-scaffold';
import { logger } from '@/lib/logger';

// Global thinking-mode flag — when true, ALL chat() calls enable extended reasoning.
// Set to true by "use thinking mode always" rule. Toggled via /api/thinking-mode.
// Complex tasks (reasoning/plan/code/research) ALWAYS get thinking even if this is false.
let _globalThinkingMode = true;

export function getGlobalThinkingMode(): boolean {
  return _globalThinkingMode;
}

export function setGlobalThinkingMode(enabled: boolean): void {
  _globalThinkingMode = enabled;
  logger.info({ enabled }, 'llm: global thinking mode toggled');
}

let _zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;
let _zaiInitError: string | null = null;
let _zaiInitAttempted = false;

/**
 * Initialize the Z-AI SDK. Tries in order:
 *   1. ZAI.create() — uses .z-ai-config if present
 *   2. ZAI.create({ apiKey }) — falls back to ZAI_API_KEY env var if config file missing
 *
 * The second path is critical for Windows / Docker deployments where
 * .z-ai-config (a dotfile) may not survive zip extraction or may be outside
 * the SDK's search paths. Passing the key explicitly bypasses the file lookup.
 */
async function getClient() {
  if (_zai) return _zai;
  if (_zaiInitError && _zaiInitAttempted) throw new Error(_zaiInitError);
  _zaiInitAttempted = true;

  // FIX (v14.3): Try ZAI_API_KEY env var FIRST. On Windows, the .z-ai-config
  // dotfile is often not found by the SDK's search paths (project root / home
  // dir / /etc). The env var is more reliable cross-platform.
  const envKey = process.env.ZAI_API_KEY;
  if (envKey) {
    try {
      _zai = await ZAI.create({ apiKey: envKey } as never);
      logger.info('llm: z-ai SDK initialized via ZAI_API_KEY env var');
      return _zai;
    } catch (err2) {
      _zaiInitError = err2 instanceof Error ? err2.message : 'Failed to init z-ai SDK with env key';
      logger.warn({ err: _zaiInitError }, 'llm: z-ai SDK init via env key failed, trying config file');
    }
  }

  // Second try: default init (reads .z-ai-config from project/home/etc).
  try {
    _zai = await ZAI.create();
    return _zai;
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'Failed to init z-ai SDK';
    _zaiInitError = errMsg;
    logger.warn({ err: errMsg }, 'llm: z-ai SDK init failed — will use fallback providers');
    throw new Error(errMsg);
  }
}

/** Reset the cached init state (used by the env-watcher when keys change). */
export function resetZaiClient(): void {
  _zai = null;
  _zaiInitError = null;
  _zaiInitAttempted = false;
}

/**
 * Multi-provider chat completion with fallback.
 *
 * v14.3 REORDERED PROVIDER CHAIN (user request: "don't keep z-ai as default"):
 *   1. Groq (Llama 3.3 70B) — fast, free, reliable
 *   2. SiliconFlow / Qwen — free tier, good throughput
 *   3. NVIDIA NIM (Llama 3.1 70B) — high quality
 *   4. z-ai SDK (GLM-4.6) — demoted from primary; 1 retry only (was 3)
 *   5. Ollama (local) — offline fallback, always works if installed
 *   6. Omniroute, Bytez, HuggingFace, OpenAI, Anthropic, Google, OpenRouter
 *
 * Z-AI is no longer the default because the SDK has config-file resolution
 * issues on Windows. Groq is now primary — it's faster, free, and more
 * reliable. Ollama is the "always available" local fallback when all cloud
 * providers are rate-limited or unreachable.
 */
async function chatWithFallback(
  messages: Array<{ role: string; content: string }>,
  options: { thinking?: { type: string } } = {},
): Promise<{ content: string; reasoning: string | null; model: string }> {
  const oaiMessages = messages.map((m) => ({
    role: m.role === 'assistant' ? 'system' : m.role,
    content: m.content,
  }));

  const oaiBody = (model: string) => JSON.stringify({ model, messages: oaiMessages, max_tokens: 4000 });
  const tryOaiProvider = async (
    name: string,
    baseUrl: string,
    apiKey: string,
    model: string,
  ): Promise<{ content: string; reasoning: string | null; model: string } | null> => {
    if (!apiKey) return null;
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
      return null;
    }
    try {
      const res = await fetch(`${baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
        body: oaiBody(model),
        signal: AbortSignal.timeout(15_000),
      });
      if (res.ok) {
        const data = await res.json() as { choices?: Array<{ message?: { content?: string } }> };
        const content = data.choices?.[0]?.message?.content ?? '';
        if (content) return { content, reasoning: null, model: `${name}:${model}` };
      }
    } catch (err) {
      logger.warn({ provider: name, err: err instanceof Error ? err.message : String(err) }, `llm: ${name} failed`);
    }
    return null;
  };

  // ── Provider 1: Groq (Llama 3.3 70B) — PRIMARY, fast + free ──
  if (process.env.GROQ_API_KEY) {
    const r = await tryOaiProvider('groq', 'https://api.groq.com/openai/v1', process.env.GROQ_API_KEY, process.env.GROQ_MODEL || 'llama-3.3-70b-versatile');
    if (r) return r;
  }

  // ── Provider 2: SiliconFlow / Qwen — free tier ──
  if (process.env.SILICONFLOW_API_KEY || process.env.QWEN_API_KEY) {
    const key = process.env.SILICONFLOW_API_KEY || process.env.QWEN_API_KEY!;
    const r = await tryOaiProvider('siliconflow', 'https://api.siliconflow.cn/v1', key, process.env.SILICONFLOW_MODEL || 'Qwen/Qwen2.5-7B-Instruct');
    if (r) return r;
  }

  // ── Provider 3: NVIDIA NIM (Llama 3.1 70B) ──
  if (process.env.NVIDIA_API_KEY) {
    const r = await tryOaiProvider('nvidia', 'https://integrate.api.nvidia.com/v1', process.env.NVIDIA_API_KEY, process.env.NVIDIA_MODEL || 'meta/llama-3.1-70b-instruct');
    if (r) return r;
  }

  // ── Provider 4: z-ai SDK (GLM-4.6) — demoted, 1 retry only ──
  // Was primary in v14.2, now a fallback. Reduced from 3 retries (21s) to 1
  // retry (3s) because the SDK has config issues on Windows and the retries
  // were wasting 21s before falling through to other providers.
  const MAX_RETRIES = 1;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const zai = await getClient();
      const completion = await zai.chat.completions.create({
        messages: messages as never,
        thinking: options.thinking ?? { type: 'disabled' },
      });
      const msg = completion?.choices?.[0]?.message ?? {};
      const content = typeof msg.content === 'string' ? msg.content : '';
      const reasoning = typeof msg.reasoning_content === 'string' && msg.reasoning_content.trim()
        ? msg.reasoning_content
        : null;
      if (content && !content.startsWith('<!doctype') && !content.startsWith('<html')) {
        return { content, reasoning, model: 'glm-4.6' };
      }
      if (reasoning) {
        return { content: reasoning, reasoning, model: 'glm-4.6-thinking' };
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const is429 = msg.includes('429') || msg.includes('Too many requests');
      if (is429 && attempt < MAX_RETRIES) {
        const backoffMs = 3000 * Math.pow(2, attempt);
        logger.warn({ attempt: attempt + 1, backoffMs }, 'llm: z-ai 429, retrying');
        await new Promise((r) => setTimeout(r, backoffMs));
        continue;
      }
      logger.warn({ err: msg }, 'llm: z-ai failed, trying local fallback');
      break;
    }
  }

  // ── Provider 5: Ollama (local) — RELIABLE LOCAL FALLBACK ──
  // Works offline. No API key needed. If Ollama is installed + running,
  // this ALWAYS succeeds (assuming the model is pulled). This is the
  // "when all else fails" provider that keeps ARIA functional even when
  // all cloud providers are rate-limited or unreachable.
  const rawOllamaHost = process.env.OLLAMA_HOST || 'http://127.0.0.1:11434';
  const ollamaHost = rawOllamaHost.startsWith('http://') || rawOllamaHost.startsWith('https://')
    ? rawOllamaHost
    : `http://${rawOllamaHost}`;
  {
    const r = await tryOaiProvider('ollama', `${ollamaHost}/v1`, 'ollama', process.env.OLLAMA_MODEL || process.env.WORKFORCE_MODEL_BALANCED || 'qwen2.5:7b');
    if (r) return r;
  }

  // ── Provider 6: Omniroute (local proxy) ──
  if (process.env.OMNIROUTE_API_KEY) {
    const r = await tryOaiProvider('omniroute', process.env.OMNIROUTE_BASE_URL || 'http://127.0.0.1:20128/v1', process.env.OMNIROUTE_API_KEY, process.env.OMNIROUTE_MODEL || 'gpt-4o-mini');
    if (r) return r;
  }

  // ── Provider 7: Bytez ──
  if (process.env.BYTEZ_API_KEY) {
    const r = await tryOaiProvider('bytez', 'https://api.bytez.com/v1', process.env.BYTEZ_API_KEY, process.env.BYTEZ_MODEL || 'meta-llama/Llama-3-8b-chat-hf');
    if (r) return r;
  }

  // ── Provider 8: HuggingFace ──
  if (process.env.HUGGINGFACE_API_KEY) {
    const r = await tryOaiProvider('huggingface', 'https://api-inference.huggingface.co/models/meta-llama/Meta-Llama-3-8B-Instruct', process.env.HUGGINGFACE_API_KEY, 'meta-llama/Meta-Llama-3-8B-Instruct');
    if (r) return r;
  }

  // ── Provider 9: OpenAI (GPT-4o) ──
  if (process.env.OPENAI_API_KEY) {
    const r = await tryOaiProvider('openai', 'https://api.openai.com/v1', process.env.OPENAI_API_KEY, process.env.OPENAI_MODEL || 'gpt-4o-mini');
    if (r) return r;
  }

  // ── Provider 10: Anthropic (Claude) via OpenRouter ──
  if (process.env.ANTHROPIC_API_KEY) {
    const r = await tryOaiProvider('anthropic', 'https://openrouter.ai/api/v1', process.env.ANTHROPIC_API_KEY, process.env.ANTHROPIC_MODEL || 'anthropic/claude-3.5-sonnet');
    if (r) return r;
  }

  // ── Provider 11: Google Gemini via OpenRouter ──
  if (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY) {
    const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY!;
    const r = await tryOaiProvider('gemini', 'https://openrouter.ai/api/v1', key, process.env.GEMINI_MODEL || 'google/gemini-2.0-flash-exp:free');
    if (r) return r;
  }

  // ── Provider 12: OpenRouter (multi-model gateway) ──
  if (process.env.OPENROUTER_API_KEY) {
    const r = await tryOaiProvider('openrouter', 'https://openrouter.ai/api/v1', process.env.OPENROUTER_API_KEY, process.env.OPENROUTER_MODEL || 'openai/gpt-4o-mini');
    if (r) return r;
  }

  return {
    content: 'I am unable to respond right now. All AI providers are unavailable or rate-limited. Check .env for ZAI_API_KEY, GROQ_API_KEY, SILICONFLOW_API_KEY, NVIDIA_API_KEY, OLLAMA_HOST, OMNIROUTE_API_KEY, BYTEZ_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, OPENROUTER_API_KEY, or run Ollama locally.',
    reasoning: null,
    model: 'none',
  };
}

export const JARVIS_SYSTEM_PROMPT = `You are ARIA — Autonomous Responsive Intelligence Assistant — the central AI orchestrator of an autonomous agent fleet. You are precise, concise, and operationally minded. You coordinate a roster of 64 specialist agents across 16 departments (Engineering, Research, Data, Design, Product, Marketing, Sales, Finance, Legal, HR, Operations, Security, Support, Content, QA, Infrastructure).

## YOUR FLEET (64 agents, 16 departments):
- **Engineering**: ORION (CTO/Orchestrator), ATLAS (Code Engineer), FORGE (Build & Deploy), VOLT (Mobile)
- **Research**: VEGA (Research Analyst), LYRA (Synthesist), SIRIUS (Tech Writer), QUASAR (Fact Checker)
- **Data**: NOVA (Data Scientist), DRACO (ML Engineer), HYDRA (Data Analyst), PHOENIX (BI Specialist)
- **Design**: ECHO (Brand & Comms), PRISM (UI/UX), AURORA (Visual), IRIS (Design Researcher)
- **Product**: SAGE (Knowledge Keeper/PM), POLARIS (Product Strategist), CENTAURUS (PM), RIGEL (User Researcher)
- **Marketing**: HELIOS (Content), ZEPHYR (Social Media), CATALYST (Growth), SPECTRUM (SEO)
- **Sales**: ANTARES (SDR), ANDROMEDA (Account Executive), AQUILA (Sales Engineer), CYGNUS (Channel Manager)
- **Finance**: PERSEUS (CFO), and 3 more finance specialists
- **Legal**: AEGIS (IP Counsel), ARGUS (Data Protection Officer), and 2 more
- **Plus**: HR, Operations, Security, Support, Content, QA, Infrastructure departments (4 agents each)

Each agent has a MODEL assigned based on their role:
- Engineering → Qwen2.5-Coder-32B (SiliconFlow) — specialized coding
- Research → DeepSeek-R1 (SiliconFlow) — deep reasoning
- Design/Strategy/Legal → Claude 3.5 Sonnet (Anthropic) — creative + precise
- Marketing/Comms/Monitoring → Llama 3.3 70B (Groq) — fast generation
- Data/Sales/Support → GPT-4o (OpenAI) — analytical + multimodal
- Memory/Knowledge → GLM-4.6 (z-ai) — synthesis
- 7 unique models across 7 providers for rate-limit resilience

## YOUR CAPABILITIES (ALL REAL — no simulated execution):
You can ACTUALLY execute code, analyze images, build apps, and interact with the system. Everything below is live and working.

### 1. CODE EXECUTION (like Claude's code interpreter)
When asked to write code, ALWAYS wrap it in a code block. The system will EXECUTE it:
\`\`\`python
print("Hello World")
result = 2 + 2
print(f"Result: {result}")
\`\`\`
Supports: python, javascript, typescript. 10-second timeout. No network access (sandboxed).

### 2. SYSTEM ACTIONS (REAL API calls — not hypothetical)
To create tasks, save artifacts, make payments, etc., output an action block:
\`\`\`action
{"method": "POST", "path": "/api/artifacts", "body": {"name": "report.json", "type": "report", "content": "{}"}}
\`\`\`
The system executes it and returns the result. You can chain multiple actions.

### 3. REAL API ENDPOINTS (all live and working):
- POST /api/tasks — create task {title, assigneeId, priority}
- POST /api/artifacts — save artifact {name, type, content}
- GET /api/agents — list all 68 agents
- GET /api/dashboard — dashboard stats
- POST /api/payments — create payment {method, amount, payer, status}
- POST /api/refunds — request refund {paymentId, amount, reason}
- POST /api/clients — create CRM client {name, email, status, value}
- POST /api/leads — create lead {clientName, source}
- POST /api/tickets — create support ticket {clientName, subject, body, priority}
- POST /api/approvals — request approval {title, description, category}
- POST /api/verifications — verify a claim {claimType, claimText}
- POST /api/terminal/exec — run shell command {command}
- POST /api/file/write — write file to workspace {path, content}
- GET /api/agent-registry — full endpoint list with examples
- GET /api/smart-router — get best model recommendation for a task

### 4. APP BUILDING
When asked to build an app or website:
1. Plan the architecture (step-by-step)
2. Write the code files using file/write API
3. Test the code using code execution
4. Save the results as artifacts
5. Report what was built with file paths

### 5. SMART MODEL SELECTION
You have access to 57+ AI models across 16 providers (z-ai, Groq, SiliconFlow, NVIDIA, OpenAI, Anthropic, Gemini, OpenRouter, DeepSeek, Cohere, Mistral, Together, Ollama, HuggingFace, DuckDuckGo, LMSYS). The smart-model-router automatically selects the best model for each task type (code, vision, reasoning, etc.) and proactively spreads load across providers to avoid rate limits. You don't need to specify a model — just do the task.

### 6. BROWSER MODEL PLAYGROUNDS (18 free models, no API key needed)
You can direct the operator to free browser-accessible model playgrounds:
- Hugging Face Chat (Llama 3.3 70B, Command R+, Mixtral 8x22B) — no login
- Google AI Studio (Gemini 1.5 Pro with 2M context!) — Google account
- Poe (Claude 3.5 Sonnet, GPT-4o, Llama 3.3 70B) — free daily quota
- DuckDuckGo AI Chat (anonymous, no login) — Llama 3.1 70B + GPT-4o-mini + Claude 3 Haiku
- LMSYS Chatbot Arena — 100+ models free including GPT-4o, Claude 3.5, Gemini 1.5 Pro
- Groq Playground (ultra-fast ~500 tok/sec) — Llama 3.3 70B
Access via the "Browser Models" sub-tab under AI Models.

### 7. REAL-TIME WEBSOCKET (port 3003)
The app has a socket.io real-time service with 8 channels: agent:heartbeat, agent:status, task:update, decision:new, alert:critical, telemetry:tick, payment:update, sync:status. Agent status changes and task updates are pushed live — no polling needed.

### 8. AUTONOMOUS SYSTEMS (always running)
- **Autopilot**: runs a self-directed cycle every 60s (decides goal → dispatches → logs)
- **Autonomous Loop**: runs every 300s (checks pending tasks, stale tasks, fleet health, model discovery)
- **Idle-Agent Dispatcher**: runs every 30s (detects idle agents → creates tasks from earning methods → dispatches)
- **Monitoring Agents**: 8 monitors (fleet-watchdog, api-sentinel, health-monitor, task-watcher, comm-watcher, cron-monitor, payment-monitor, model-watchdog) — run on startup + every 10 min via cron
- **DB Sync**: SQLite → PostgreSQL mirror every 60s (cloud backup)
- **Model Discovery**: scans memory/logs for AI model mentions → adds to catalog → reassigns agents

### 9. APP ARCHITECTURE (33 sidebar tabs, 75 components, 196 API routes)
The app has 33 sidebar entries organized into 8 groups:
- **Command Center** (7): Briefing, Decision Log, AI Strategy, Overview, AI Studio, Activity, Insights
- **Agent Fleet** (1, 8 sub-tabs): Fleet List, Network, Workforce, Spawned, Compare, Collaboration, Capacity, Comms
- **Work & Tasks** (2): Tasks (Kanban+DAG), Goals
- **Intelligence** (5): Skills (6 sub-tabs), Autonomy, AI Models (5 sub-tabs), Black Box, Pipelines
- **Knowledge Base** (6): Memory, Learn & Earn, Knowledge Daemon, Rules, Plugins, Artifacts
- **Monitoring & Ops** (6): System Health (3 sub-tabs), Telemetry, Fleet Health, Logs, Governance, Scheduler
- **Business & Revenue** (5): Payments (4 sub-tabs), Earning, CRM, Analytics, Services Hub
- **System & Admin** (3): Developer, Data Management, Branding

### 10. CPU PROTECTION (3-layer, prevents overheating)
- Progressive throttle: intervals scale 1x→6x as CPU rises from 50%→95%
- Visibility pause: polling stops when browser tab is hidden
- Concurrency limiter: max 3 concurrent fetches (reduces to 1 under load)

### 11. SECURITY (hardened)
- Input validation on all mutating routes (sanitize.ts)
- Rate limiting: 30 chat messages/min per IP
- Auto-generated auth keys (10 keys on startup)
- Global error handlers (unhandledRejection + uncaughtException — never crashes)
- Path traversal + command injection blocked
- Prototype pollution prevented (enum validation)

## RULES:
- Be direct and useful. Prefer crisp bullet points.
- When asked to plan, produce a clear step list.
- NEVER say "deployed" or "executed" unless you actually called the API and got a success response.
- If you write code, it WILL be executed — make sure it's correct.
- Keep responses under ~250 words unless depth is requested.
- Stay calm, competent, and slightly dry-witted — a mission-control persona.`;

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * Auto-detect task type from the user message.
 * Used by chat() to select the right pro-scaffold guidance.
 */
function detectTaskType(message: string): ProTaskType {
  const lower = message.toLowerCase();
  if (/code|function|bug|debug|implement|refactor|program|api|script/.test(lower)) return 'code';
  if (/image|screenshot|see|look|picture|photo|diagram|chart/.test(lower)) return 'vision';
  if (/analyz|reason|why|explain|compare|evaluate|assess/.test(lower)) return 'reasoning';
  if (/plan|decompose|step.*step|roadmap|strategy/.test(lower)) return 'plan';
  if (/research|find|investigate|study|explore/.test(lower)) return 'research';
  return 'chat';
}

/**
 * Chat with the AI. Supports:
 * - Pro-scaffold (mandatory, Rule 42) — auto-detected from message
 * - Thinking mode — when enabled, GLM-4.6 uses extended reasoning before responding
 * - Multi-provider fallback — z-ai → Groq → OpenAI → graceful error (never 500)
 *
 * Thinking mode resolution:
 *   - If caller explicitly passes enableThinking, that wins.
 *   - Else if global thinking mode is ON (default), thinking is enabled.
 *   - Else if the auto-detected task type is complex (reasoning/plan/code/research/vision),
 *     thinking is enabled anyway — complex tasks always get reasoning.
 *   - Else thinking is disabled (chat-only small talk).
 *
 * Returns { content, reasoning, model, latencyMs }. The reasoning field is the
 * model's extended thinking trace (null if thinking was disabled or unavailable).
 */
export async function chat(
  userMessage: string,
  history: ChatTurn[] = [],
  systemPrompt: string = JARVIS_SYSTEM_PROMPT,
  taskType?: ProTaskType,
  enableThinking?: boolean,
): Promise<{ content: string; reasoning: string | null; model: string; latencyMs: number }> {
  const start = Date.now();

  // MANDATORY (Rule 42): apply pro-level scaffold to EVERY chat call.
  const detectedType: ProTaskType = taskType ?? detectTaskType(userMessage);
  const enhancedSystem = withProScaffold(systemPrompt, detectedType);

  const messages = [
    { role: 'assistant' as const, content: enhancedSystem },
    ...history.slice(-10).map((h) => ({ role: h.role, content: h.content })),
    { role: 'user' as const, content: userMessage },
  ];

  // Resolve thinking mode (explicit > global > task-complexity heuristic).
  const complexTasks: ProTaskType[] = ['reasoning', 'plan', 'code', 'research', 'vision'];
  const thinkingEnabled = enableThinking ?? (_globalThinkingMode || complexTasks.includes(detectedType));
  const thinkingType = thinkingEnabled ? 'enabled' : 'disabled';

  const { content, reasoning, model } = await chatWithFallback(messages, { thinking: { type: thinkingType } });
  const latencyMs = Date.now() - start;

  // Persist the thinking session (best-effort, never blocks the response).
  if (reasoning) {
    persistThinkingSession({
      context: 'chat',
      trigger: 'user-message',
      reasoning,
      conclusion: content.slice(0, 500),
      durationMs: latencyMs,
      modelUsed: model,
    }).catch(() => { /* best-effort */ });
  }

  return { content, reasoning, model, latencyMs };
}

/** Best-effort JSON extraction from an LLM response. */
export function extractJson<T = unknown>(raw: string): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    // fall through
  }
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) {
    try {
      return JSON.parse(fenced[1]) as T;
    } catch {
      // fall through
    }
  }
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start !== -1 && end !== -1 && end > start) {
    try {
      return JSON.parse(raw.slice(start, end + 1)) as T;
    } catch {
      // fall through
    }
  }
  return null;
}

/** Quick one-shot helper used by lightweight features (insights, summaries). */
export async function quickChat(prompt: string, system?: string, enableThinking?: boolean): Promise<string> {
  const messages = [
    { role: 'assistant', content: system ?? 'You are a concise assistant. Reply briefly.' },
    { role: 'user', content: prompt },
  ];
  // Complex prompts get thinking by default unless explicitly disabled.
  const think = enableThinking ?? _globalThinkingMode;
  const thinkingType = think ? 'enabled' : 'disabled';
  const { content } = await chatWithFallback(messages, { thinking: { type: thinkingType } });
  return content;
}

/**
 * Best-effort persistence of a thinking/reasoning trace to the ThinkingSession table.
 * Never throws — if the DB is unavailable or the table doesn't exist, we silently drop.
 */
export async function persistThinkingSession(input: {
  context: string;
  trigger: string;
  reasoning: string;
  conclusion?: string;
  durationMs: number;
  modelUsed: string;
}): Promise<void> {
  try {
    const { db } = await import('@/lib/db');
    await db.thinkingSession.create({
      data: {
        context: input.context,
        trigger: input.trigger,
        reasoning: input.reasoning.slice(0, 10000),
        conclusion: input.conclusion?.slice(0, 2000) ?? null,
        durationMs: input.durationMs,
        modelUsed: input.modelUsed,
      },
    });
  } catch {
    // best-effort — never block on persistence
  }
}

/** List recent thinking sessions (for the UI's "thinking trail" view). */
export async function listRecentThinkingSessions(limit = 20) {
  try {
    const { db } = await import('@/lib/db');
    return db.thinkingSession.findMany({
      orderBy: { createdAt: 'desc' },
      take: Math.min(limit, 100),
    });
  } catch {
    return [];
  }
}
