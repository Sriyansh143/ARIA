// =====================================================================
// browser-models.ts — Catalog of browser-accessible free model playgrounds
// =====================================================================
// These are models available via web UIs where an agent (or operator) can
// log in and use models for free — no API key required. The agent-browser
// can automate these if credentials are provided.
//
// Categories:
//   1. Hugging Face Spaces — free hosted model demos (Chat, Vision, Code)
//   2. Replicate — free tier model demos
//   3. Google AI Studio — free Gemini playground
//   4. Poe — free multi-model chat (Claude, GPT, Llama, etc.)
//   5. Perplexity Labs — free online models
//   6. Groq Playground — free Llama playground
//   7. Together AI Playground — free model demos
//   8. Vercel AI SDK Playground — free multi-model
//   9. OpenRouter Free tier — free models (no key needed for some)
// =====================================================================

export interface BrowserModel {
  id: string;
  name: string;
  provider: string;
  url: string;
  category: 'chat' | 'vision' | 'code' | 'reasoning' | 'creative' | 'image-gen' | 'audio' | 'long-context';
  description: string;
  requiresLogin: boolean;
  loginUrl?: string;
  free: boolean;
  contextWindow?: number;
  capabilities: string[];
  automatable: boolean; // can agent-browser drive it?
  notes?: string;
}

export const BROWSER_MODELS: BrowserModel[] = [
  // ── Hugging Face Spaces (free, no login for most) ──
  {
    id: 'hf-chat-llama-3.3-70b',
    name: 'Llama 3.3 70B (HF Chat)',
    provider: 'huggingface',
    url: 'https://huggingface.co/chat',
    category: 'chat',
    description: 'Free Hugging Face Chat with Llama 3.3 70B. No login required for basic use.',
    requiresLogin: false,
    free: true,
    contextWindow: 128000,
    capabilities: ['chat', 'reasoning', 'code'],
    automatable: true,
    notes: 'Best free chat model. HF account needed for history.',
  },
  {
    id: 'hf-chat-command-r-plus',
    name: 'Command R+ (HF Chat)',
    provider: 'huggingface',
    url: 'https://huggingface.co/chat',
    category: 'chat',
    description: 'Cohere Command R+ via Hugging Face Chat. Strong RAG + reasoning.',
    requiresLogin: false,
    free: true,
    contextWindow: 128000,
    capabilities: ['chat', 'reasoning', 'rag'],
    automatable: true,
  },
  {
    id: 'hf-chat-mixtral-8x22b',
    name: 'Mixtral 8x22B (HF Chat)',
    provider: 'huggingface',
    url: 'https://huggingface.co/chat',
    category: 'chat',
    description: 'Mistral Mixtral 8x22B via Hugging Face Chat. Strong multilingual.',
    requiresLogin: false,
    free: true,
    contextWindow: 64000,
    capabilities: ['chat', 'code', 'multilingual'],
    automatable: true,
  },
  {
    id: 'hf-spaces-flux',
    name: 'FLUX.1 Image Generator',
    provider: 'huggingface',
    url: 'https://black-forest-labs-flux-1-dev.hf.space',
    category: 'image-gen',
    description: 'Free FLUX.1 image generation on Hugging Face Spaces.',
    requiresLogin: false,
    free: true,
    capabilities: ['image-generation'],
    automatable: true,
    notes: 'May have queue during peak hours.',
  },
  {
    id: 'hf-spaces-qwen-vl',
    name: 'Qwen-VL Vision Model',
    provider: 'huggingface',
    url: 'https://qwen-vl-plus.hf.space',
    category: 'vision',
    description: 'Free Qwen-VL vision-language model. Upload images + ask questions.',
    requiresLogin: false,
    free: true,
    capabilities: ['vision', 'chat'],
    automatable: true,
  },

  // ── Google AI Studio (free Gemini) ──
  {
    id: 'google-ai-studio-gemini-pro',
    name: 'Gemini 1.5 Pro (AI Studio)',
    provider: 'google',
    url: 'https://aistudio.google.com/app/prompts/new_chat',
    category: 'long-context',
    description: 'Free Gemini 1.5 Pro with 2M token context. Google account required.',
    requiresLogin: true,
    loginUrl: 'https://accounts.google.com',
    free: true,
    contextWindow: 2000000,
    capabilities: ['chat', 'vision', 'long-context', 'reasoning'],
    automatable: true,
    notes: '2M context window — largest free context available.',
  },
  {
    id: 'google-ai-studio-gemini-flash',
    name: 'Gemini 2.0 Flash (AI Studio)',
    provider: 'google',
    url: 'https://aistudio.google.com/app/prompts/new_chat',
    category: 'chat',
    description: 'Free Gemini 2.0 Flash — fast multimodal model.',
    requiresLogin: true,
    loginUrl: 'https://accounts.google.com',
    free: true,
    contextWindow: 1000000,
    capabilities: ['chat', 'fast', 'vision'],
    automatable: true,
  },

  // ── Poe (free multi-model — Claude, GPT, Llama) ──
  {
    id: 'poe-claude-3.5-sonnet',
    name: 'Claude 3.5 Sonnet (Poe)',
    provider: 'poe',
    url: 'https://poe.com/Claude-3.5-Sonnet',
    category: 'reasoning',
    description: 'Free Claude 3.5 Sonnet via Poe. Limited daily messages.',
    requiresLogin: true,
    loginUrl: 'https://poe.com/login',
    free: true,
    contextWindow: 200000,
    capabilities: ['chat', 'reasoning', 'code', 'creative'],
    automatable: true,
    notes: 'Free tier: ~30 messages/day. Poe account required.',
  },
  {
    id: 'poe-gpt-4o',
    name: 'GPT-4o (Poe)',
    provider: 'poe',
    url: 'https://poe.com/GPT-4o',
    category: 'chat',
    description: 'Free GPT-4o via Poe. Limited daily messages.',
    requiresLogin: true,
    loginUrl: 'https://poe.com/login',
    free: true,
    contextWindow: 128000,
    capabilities: ['chat', 'reasoning', 'vision'],
    automatable: true,
    notes: 'Free tier: ~30 messages/day.',
  },
  {
    id: 'poe-llama-3.3-70b',
    name: 'Llama 3.3 70B (Poe)',
    provider: 'poe',
    url: 'https://poe.com/Llama-3.3-70B',
    category: 'chat',
    description: 'Free Llama 3.3 70B via Poe. Unlimited messages on free models.',
    requiresLogin: true,
    loginUrl: 'https://poe.com/login',
    free: true,
    contextWindow: 128000,
    capabilities: ['chat', 'reasoning'],
    automatable: true,
  },

  // ── Groq Playground ──
  {
    id: 'groq-playground-llama-3.3',
    name: 'Llama 3.3 70B (Groq Playground)',
    provider: 'groq',
    url: 'https://groq.com/playground',
    category: 'chat',
    description: 'Free ultra-fast Llama 3.3 70B on Groq Playground. Login required.',
    requiresLogin: true,
    loginUrl: 'https://console.groq.com/login',
    free: true,
    contextWindow: 128000,
    capabilities: ['chat', 'fast', 'reasoning'],
    automatable: true,
    notes: 'Fastest inference available (~500 tokens/sec).',
  },

  // ── Together AI Playground ──
  {
    id: 'together-playground-qwen',
    name: 'Qwen 2.5 72B (Together Playground)',
    provider: 'together',
    url: 'https://api.together.ai/playground',
    category: 'chat',
    description: 'Free Qwen 2.5 72B on Together AI Playground.',
    requiresLogin: true,
    loginUrl: 'https://api.together.ai/login',
    free: true,
    contextWindow: 32768,
    capabilities: ['chat', 'code'],
    automatable: true,
  },

  // ── Vercel AI SDK Playground ──
  {
    id: 'vercel-playground',
    name: 'Vercel AI Playground',
    provider: 'vercel',
    url: 'https://sdk.vercel.ai',
    category: 'chat',
    description: 'Free multi-model playground. Compare models side-by-side.',
    requiresLogin: false,
    free: true,
    capabilities: ['chat', 'comparison'],
    automatable: true,
    notes: 'Compare OpenAI, Anthropic, Google, Mistral models free.',
  },

  // ── Perplexity Labs ──
  {
    id: 'perplexity-labs',
    name: 'Perplexity Labs (Online Llama)',
    provider: 'perplexity',
    url: 'https://labs.perplexity.ai',
    category: 'chat',
    description: 'Free online Llama + Mistral models with web access.',
    requiresLogin: false,
    free: true,
    capabilities: ['chat', 'web-search'],
    automatable: true,
    notes: 'Models have live web access — great for research.',
  },

  // ── DuckDuckGo AI Chat (free, no login) ──
  {
    id: 'ddg-ai-chat',
    name: 'DuckDuckGo AI Chat',
    provider: 'duckduckgo',
    url: 'https://duckduckgo.com/chat',
    category: 'chat',
    description: 'Free anonymous AI chat. Llama 3.1 70B + GPT-4o-mini + Claude 3 Haiku.',
    requiresLogin: false,
    free: true,
    contextWindow: 32000,
    capabilities: ['chat', 'anonymous'],
    automatable: true,
    notes: 'Best for anonymous use — no account, no tracking.',
  },

  // ── Cloudflare AI Playground ──
  {
    id: 'cloudflare-ai-playground',
    name: 'Cloudflare AI Playground',
    provider: 'cloudflare',
    url: 'https://playground.ai.cloudflare.com',
    category: 'chat',
    description: 'Free models on Cloudflare edge network. Llama, Mistral, Gemma.',
    requiresLogin: false,
    free: true,
    capabilities: ['chat', 'fast'],
    automatable: true,
  },

  // ── LMSYS Chatbot Arena ──
  {
    id: 'lmsys-arena',
    name: 'LMSYS Chatbot Arena',
    provider: 'lmsys',
    url: 'https://chat.lmsys.org',
    category: 'chat',
    description: 'Free access to 100+ models including GPT-4o, Claude 3.5, Gemini 1.5 Pro.',
    requiresLogin: false,
    free: true,
    capabilities: ['chat', 'comparison'],
    automatable: true,
    notes: 'Best for testing multiple models free. May have queue.',
  },

  // ── Hugging Face Inference API (free tier) ──
  {
    id: 'hf-inference-api',
    name: 'Hugging Face Inference API',
    provider: 'huggingface',
    url: 'https://api-inference.huggingface.co',
    category: 'chat',
    description: 'Free inference API for 200,000+ models. HF token for higher limits.',
    requiresLogin: false,
    free: true,
    capabilities: ['chat', 'vision', 'code', 'image-generation'],
    automatable: true,
    notes: 'Free without token (rate-limited). HF token increases limits.',
  },
];

/**
 * Get browser models by category.
 */
export function getBrowserModelsByCategory(category: string): BrowserModel[] {
  return BROWSER_MODELS.filter((m) => m.category === category);
}

/**
 * Get all free browser models (no API key needed).
 */
export function getFreeBrowserModels(): BrowserModel[] {
  return BROWSER_MODELS.filter((m) => m.free);
}

/**
 * Get browser models that don't require login (fully anonymous).
 */
export function getNoLoginBrowserModels(): BrowserModel[] {
  return BROWSER_MODELS.filter((m) => !m.requiresLogin);
}

/**
 * Get browser models that can be automated by agent-browser.
 */
export function getAutomatableBrowserModels(): BrowserModel[] {
  return BROWSER_MODELS.filter((m) => m.automatable);
}

/**
 * Get summary stats for the browser model catalog.
 */
export function getBrowserModelStats() {
  return {
    total: BROWSER_MODELS.length,
    free: BROWSER_MODELS.filter((m) => m.free).length,
    noLogin: BROWSER_MODELS.filter((m) => !m.requiresLogin).length,
    automatable: BROWSER_MODELS.filter((m) => m.automatable).length,
    byProvider: BROWSER_MODELS.reduce((acc, m) => {
      acc[m.provider] = (acc[m.provider] ?? 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    byCategory: BROWSER_MODELS.reduce((acc, m) => {
      acc[m.category] = (acc[m.category] ?? 0) + 1;
      return acc;
    }, {} as Record<string, number>),
  };
}
