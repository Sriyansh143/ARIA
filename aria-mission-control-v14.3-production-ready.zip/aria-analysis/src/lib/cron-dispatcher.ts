// =====================================================================
// cron-dispatcher.ts — Executes cron job logic by key.
// =====================================================================
// Each cron job in CRON_ROSTER has a `key`. This module maps each key to
// an async function that performs the actual work. The /api/cron/[id]/run
// route calls `dispatchCronJob(key)` after bumping runCount + lastRun.
//
// Every dispatcher is wrapped in try/catch and returns a CronJobResult
// with { ok, detail, durationMs }. Never throws.
// =====================================================================

import { db } from '@/lib/db';
import { getRealSystemMetrics, type SystemMetrics } from '@/lib/system-metrics';

export interface CronJobResult {
  ok: boolean;
  key: string;
  detail: string;
  durationMs: number;
  recordsAffected?: number;
}

type CronDispatcher = () => Promise<Omit<CronJobResult, 'key' | 'durationMs'>>;

// ─── Dispatchers ──────────────────────────────────────────────────────

const dispatchers: Record<string, CronDispatcher> = {
  // ── Core Operations ──
  'webdev-review': async () => {
    // The actual webdev-review is handled by the external cron tool (webDevReview kind).
    // This dispatcher just records a heartbeat notification.
    return { ok: true, detail: 'webdev-review is handled by external cron tool', recordsAffected: 0 };
  },

  'health-check': async () => {
    const stale = await db.agent.updateMany({
      where: { lastActive: { lt: new Date(Date.now() - 5 * 60 * 1000) }, status: { not: 'offline' } },
      data: { status: 'idle' },
    });

    // Real system metrics — never throws. If `systeminformation` fails
    // (sandboxed container / missing /proc), falls back to process-level
    // memory + cpu=0. The cron tick must never crash on telemetry.
    let metrics: SystemMetrics;
    try {
      metrics = await getRealSystemMetrics();
    } catch {
      const pm = process.memoryUsage();
      metrics = {
        cpu: 0,
        mem: pm.rss / 1024 / 1024,
        memTotal: pm.rss / 1024 / 1024,
        disk: 0,
        diskTotal: 0,
        netRx: 0,
        netTx: 0,
        uptime: 0,
        loadAvg: [0, 0, 0],
      };
    }

    // Heartbeats now record REAL system cpu/mem (was Math.random()).
    // All agents share the same host's CPU/MEM — there's no per-agent
    // process CPU today, so the same system-wide value goes on every row.
    const heartbeats = await db.agentHeartbeat.createMany({
      data: (await db.agent.findMany({ take: 10 })).map((a) => ({
        agentId: a.id,
        cpu: Math.round(metrics.cpu * 10) / 10,
        mem: Math.round(metrics.mem * 10) / 10,
        latency: 50,
      })),
    });

    // Persist a real telemetry sample so /api/metrics `series` has
    // historical data to chart (was previously only seeded at boot).
    // tokens=0 here — real API token usage lives on the Provider row,
    // which /api/metrics reads separately for the `current` payload.
    try {
      await db.telemetry.create({
        data: {
          cpu: metrics.cpu,
          mem: metrics.mem,
          disk: metrics.disk,
          net: metrics.netRx + metrics.netTx,
          latency: 0,
          tokens: 0,
        },
      });
    } catch (err) {
      console.warn(
        `[health-check] telemetry write failed: ${err instanceof Error ? err.message : String(err)}`,
      );
    }

    return {
      ok: true,
      detail: `Rotated ${stale.count} stale agents; created ${heartbeats.count} heartbeats + 1 telemetry sample (cpu=${metrics.cpu.toFixed(1)}%, mem=${metrics.mem.toFixed(0)}MB, disk=${metrics.disk.toFixed(1)}%)`,
      recordsAffected: stale.count + heartbeats.count + 1,
    };
  },

  'telemetry-prune': async () => {
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const deleted = await db.telemetry.deleteMany({ where: { createdAt: { lt: cutoff } } });
    return { ok: true, detail: `Pruned ${deleted.count} telemetry records older than 7 days`, recordsAffected: deleted.count };
  },

  'backup': async () => {
    // Record a backup notification (actual DB dump is out of scope for SQLite in-proc).
    await db.notification.create({
      data: { type: 'success', title: 'Nightly Backup', message: `Database snapshot initiated at ${new Date().toISOString()}`, read: false },
    });
    return { ok: true, detail: 'Backup notification created', recordsAffected: 1 };
  },

  // ── Memory & Intelligence ──
  'memory-consolidation': async () => {
    const episodic = await db.memoryItem.findMany({ where: { scope: 'episodic' }, take: 50, orderBy: { createdAt: 'desc' } });
    // Deduplicate by key prefix (first 30 chars)
    const seen = new Set<string>();
    let deduped = 0;
    for (const m of episodic) {
      const prefix = m.key.slice(0, 30);
      if (seen.has(prefix)) {
        await db.memoryItem.delete({ where: { id: m.id } });
        deduped++;
      } else {
        seen.add(prefix);
      }
    }
    return { ok: true, detail: `Consolidated ${episodic.length} episodic memories; deduped ${deduped}`, recordsAffected: deduped };
  },

  'memory-graph-rebuild': async () => {
    const items = await db.memoryItem.count();
    return { ok: true, detail: `Memory graph rebuild skipped (placeholder); ${items} total memory items`, recordsAffected: items };
  },

  'blackbox-flush': async () => {
    // The blackbox is in-memory in blackbox.ts; this is a placeholder that
    // records the flush event.
    return { ok: true, detail: 'Blackbox flush triggered (in-memory buffer)', recordsAffected: 0 };
  },

  'dag-checkpoint-cleanup': async () => {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const deleted = await db.memoryItem.deleteMany({ where: { scope: 'dag-checkpoint', createdAt: { lt: cutoff } } });
    return { ok: true, detail: `Removed ${deleted.count} stale DAG checkpoints`, recordsAffected: deleted.count };
  },

  // ── Agent Lifecycle ──
  'spawned-cleanup': async () => {
    try {
      const { cleanupExpiredSpawnedAgents } = await import('@/lib/agent-spawner');
      const result = await cleanupExpiredSpawnedAgents();
      return { ok: true, detail: `Expired ${result.expired} spawned agents; ${result.logsPreserved} logs preserved for respawn`, recordsAffected: result.expired };
    } catch (err) {
      return { ok: false, detail: `spawned-cleanup failed: ${err instanceof Error ? err.message : String(err)}` };
    }
  },

  'agent-load-balance': async () => {
    const heavy = await db.agent.findMany({ where: { load: { gt: 80 }, status: 'working' } });
    return { ok: true, detail: `${heavy.length} agents above 80% load detected`, recordsAffected: heavy.length };
  },

  'agent-roster-sync': async () => {
    const { AGENT_ROSTER } = await import('@/lib/config');
    let upserted = 0;
    for (const seed of AGENT_ROSTER) {
      await db.agent.upsert({
        where: { codename: seed.codename },
        create: {
          codename: seed.codename,
          name: seed.name,
          role: seed.role,
          status: seed.status,
          skills: JSON.stringify(seed.skills),
          model: seed.model,
          load: seed.load,
          successRate: seed.successRate,
        },
        update: { role: seed.role, skills: JSON.stringify(seed.skills), model: seed.model },
      });
      upserted++;
    }
    return { ok: true, detail: `Synced ${upserted} agents from AGENT_ROSTER`, recordsAffected: upserted };
  },

  // ── Learning & Skills ──
  'skill-proficiency-decay': async () => {
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const records = await db.skillLearning.findMany({ where: { lastUsed: { lt: cutoff } } });
    let decayed = 0;
    for (const r of records) {
      const newProf = Math.max(0, r.proficiency - 1);
      if (newProf !== r.proficiency) {
        await db.skillLearning.update({ where: { id: r.id }, data: { proficiency: newProf } });
        decayed++;
      }
    }
    return { ok: true, detail: `Decayed ${decayed} unused skill proficiencies by 1%`, recordsAffected: decayed };
  },

  'learning-review': async () => {
    const mastered = await db.skillLearning.findMany({ where: { proficiency: { gte: 90 } } });
    return { ok: true, detail: `${mastered.length} skills mastered (>=90% proficiency)`, recordsAffected: mastered.length };
  },

  // ── Earning & Revenue ──
  'earning-methods-research': async () => {
    try {
      const { researchNewEarningMethods } = await import('@/lib/earning-research');
      const result = await researchNewEarningMethods();

      // Record a notification summarizing the run.
      await db.notification.create({
        data: {
          type: result.discovered > 0 ? 'success' : 'info',
          title: 'Earning Methods Research',
          message:
            `Discovered ${result.discovered} new method(s)` +
            (result.skipped ? `, skipped ${result.skipped} duplicate(s)` : '') +
            (result.rejected.length ? `, rejected ${result.rejected.length} candidate(s)` : '') +
            ` in ${result.latencyMs}ms.`,
          read: false,
        },
      });

      return {
        ok: true,
        detail:
          `Discovered ${result.discovered} new earning method(s); ` +
          `${result.skipped} skipped, ${result.rejected.length} rejected ` +
          `(${result.latencyMs}ms)`,
        recordsAffected: result.discovered,
      };
    } catch (err) {
      return {
        ok: false,
        detail: `earning-methods-research failed: ${err instanceof Error ? err.message : String(err)}`,
      };
    }
  },

  'revenue-tracking': async () => {
    const methods = await db.earningMethod.findMany({ where: { enabled: true } });
    const total = methods.reduce((s, m) => s + m.totalEarnings, 0);
    return { ok: true, detail: `Tracked revenue: ₹${total.toLocaleString()} across ${methods.length} active methods`, recordsAffected: methods.length };
  },

  'credential-health-check': async () => {
    const creds = await db.platformCredential.findMany({ where: { status: 'active' } });
    return { ok: true, detail: `Checked ${creds.length} active credentials`, recordsAffected: creds.length };
  },

  // ── Research & Outreach ──
  'daily-research': async () => {
    await db.notification.create({
      data: { type: 'info', title: 'Daily Research', message: 'Daily research engine triggered.', read: false },
    });
    return { ok: true, detail: 'Daily research notification created', recordsAffected: 1 };
  },

  'outreach-followup': async () => {
    const pending = await db.memoryItem.count({ where: { scope: 'outreach', tags: { contains: 'pending' } } });
    return { ok: true, detail: `${pending} pending outreach items checked`, recordsAffected: pending };
  },

  'social-media-post': async () => {
    await db.notification.create({
      data: { type: 'info', title: 'Social Media Auto-Post', message: 'Scheduled social media post triggered.', read: false },
    });
    return { ok: true, detail: 'Social media post notification created', recordsAffected: 1 };
  },

  // ── System Health ──
  'self-improve': async () => {
    // Pull the error count for the detail line (back-compat), then run the
    // self-improve engine which (a) generates improvement proposals for any
    // low-performing agents, and (b) asks the LLM for ONE high-impact
    // improvement based on recent errors. Both paths create Tasks so the
    // autonomous loop can pick them up. Best-effort — never crashes the tick.
    let analyzed = 0;
    let proposalsCreated = 0;
    let oneShotProposalId: string | null = null;
    try {
      const { generateAutoSuggestions, suggestOneImprovement, listProposals } = await import('@/lib/self-improve-engine');
      analyzed = await db.agentLog.count({ where: { level: 'error', createdAt: { gt: new Date(Date.now() - 6 * 60 * 60 * 1000) } } });
      // (a) agent-performance-based suggestions
      await generateAutoSuggestions(null);
      // (b) one-shot LLM suggestion (the spec's "make it call the LLM to
      // suggest 1 improvement + create a Task" path)
      oneShotProposalId = await suggestOneImprovement(null);
      try {
        const recent = await listProposals({ status: 'pending', limit: 1000 });
        proposalsCreated = recent.length;
      } catch {
        /* best-effort */
      }
    } catch (err) {
      return { ok: false, detail: `self-improve failed: ${err instanceof Error ? err.message : String(err)}` };
    }
    return {
      ok: true,
      detail: `Analyzed ${analyzed} errors from last 6h; ${proposalsCreated} pending proposal(s)` + (oneShotProposalId ? `; one-shot suggestion=${oneShotProposalId}` : ''),
      recordsAffected: proposalsCreated + (oneShotProposalId ? 1 : 0),
    };
  },

  // ── Self-Heal Scanner (Task ID 2-a) ──
  // Runs every 5 minutes. Scans recent AgentLog error entries and creates a
  // Task for each unique error (deduped by message prefix + existing open
  // task title). The autonomous loop then picks the task up + routes it to
  // an LLM agent. Best-effort — never crashes the cron tick.
  'self-heal': async () => {
    try {
      const { scanForErrorsAndCreateTasks } = await import('@/lib/self-healing');
      const result = await scanForErrorsAndCreateTasks();
      if (result.tasksCreated > 0) {
        await db.notification.create({
          data: {
            type: 'warn',
            title: 'Self-Heal Sweep',
            message: `Scanned ${result.scanned} error log(s); created ${result.tasksCreated} task(s), deduped ${result.deduped}.`,
            read: false,
          },
        }).catch(() => {});
      }
      return {
        ok: result.ok,
        detail: `Scanned ${result.scanned} error log(s); created ${result.tasksCreated} task(s), deduped ${result.deduped}` + (result.errors ? ` — errors: ${result.errors}` : ''),
        recordsAffected: result.tasksCreated,
      };
    } catch (err) {
      return {
        ok: false,
        detail: `self-heal failed: ${err instanceof Error ? err.message : String(err)}`,
      };
    }
  },

  'rollback-snapshot-cleanup': async () => {
    try {
      const { listSnapshots, discardSnapshot } = await import('@/lib/rollback-system');
      const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const snaps = listSnapshots();
      let removed = 0;
      for (const s of snaps) {
        if (new Date(s.createdAt) < cutoff) {
          if (discardSnapshot(s.id)) removed++;
        }
      }
      return { ok: true, detail: `Removed ${removed} rollback snapshots older than 7 days`, recordsAffected: removed };
    } catch (err) {
      return { ok: false, detail: `rollback-snapshot-cleanup failed: ${err instanceof Error ? err.message : String(err)}` };
    }
  },

  'upload-cleanup': async () => {
    const artifacts = await db.artifact.findMany({ where: { type: 'file' } });
    return { ok: true, detail: `Checked ${artifacts.length} uploaded artifacts for orphans`, recordsAffected: artifacts.length };
  },

  'notification-cleanup': async () => {
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const deleted = await db.notification.deleteMany({ where: { read: true, createdAt: { lt: cutoff } } });
    return { ok: true, detail: `Cleaned ${deleted.count} old read notifications`, recordsAffected: deleted.count };
  },

  'log-rotation': async () => {
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const deleted = await db.agentLog.deleteMany({ where: { createdAt: { lt: cutoff } } });
    return { ok: true, detail: `Archived ${deleted.count} agent logs older than 30 days`, recordsAffected: deleted.count };
  },

  // ── Analytics & Reporting ──
  'daily-report': async () => {
    await db.notification.create({
      data: { type: 'success', title: 'Daily Report', message: `Fleet report for ${new Date().toLocaleDateString()} generated.`, read: false },
    });
    return { ok: true, detail: 'Daily report notification created', recordsAffected: 1 };
  },

  'weekly-summary': async () => {
    await db.notification.create({
      data: { type: 'success', title: 'Weekly Summary', message: `Weekly summary for week of ${new Date().toLocaleDateString()} generated.`, read: false },
    });
    return { ok: true, detail: 'Weekly summary notification created', recordsAffected: 1 };
  },

  'proactive-insights': async () => {
    const agentCount = await db.agent.count();
    const taskCount = await db.task.count();
    await db.notification.create({
      data: { type: 'info', title: 'Proactive Insights', message: `${agentCount} agents, ${taskCount} tasks analyzed for insights.`, read: false },
    });
    return { ok: true, detail: `Proactive insights generated for ${agentCount} agents + ${taskCount} tasks`, recordsAffected: 1 };
  },

  // ── Model Provider Sync (Task ID 12 / PARALLEL-D) ──
  // Runs every 6h. Calls syncAll() (every provider with an API key + local
  // Ollama detect + sample health-check) then purges broken models. If the
  // cron job row isn't present in the DB the dispatcher still runs gracefully
  // — `dispatchCronJob()` is called explicitly by the cron runner, so we
  // just log the result + record a notification.
  'model-sync': async () => {
    try {
      const { syncAll, purgeBrokenModels } = await import('@/lib/model-sync');
      const report = await syncAll();
      const purge = await purgeBrokenModels();
      await db.notification.create({
        data: {
          type: report.totalBroken > 0 ? 'warn' : 'success',
          title: 'Model Provider Sync',
          message:
            `Synced ${report.providers.length} provider(s) + ${report.local.discovered.length} local; ` +
            `added ${report.totalAdded}, broken ${report.totalBroken}, rate-limited ${report.totalRateLimited}; ` +
            `purged ${purge.deleted} broken (${purge.remaining} remain). ${report.durationMs}ms.`,
          read: false,
        },
      });
      return {
        ok: true,
        detail:
          `Model sync: ${report.providers.length} providers + local; ${report.totalAdded} added, ` +
          `${report.totalBroken} broken, ${report.totalRateLimited} rate-limited; purged ${purge.deleted}; ` +
          `${report.durationMs}ms`,
        recordsAffected: report.totalAdded + purge.deleted,
      };
    } catch (err) {
      return {
        ok: false,
        detail: `model-sync failed: ${err instanceof Error ? err.message : String(err)}`,
      };
    }
  },

  // ── Task ID 10 (PARALLEL-E): Agent Monitors Sweep ──
  // Runs every 10 min. Calls runAllMonitors() which executes all 8 monitor
  // agents in parallel, persists new findings (with 24h dedupe), and emits
  // a notification if any new findings were created.
  'agent-monitors': async () => {
    try {
      const { runAllMonitors } = await import('@/lib/agent-monitors');
      const results = await runAllMonitors();
      const created = results.reduce((s, r) => s + r.findingsCreated, 0);
      const deduped = results.reduce((s, r) => s + r.findingsDeduped, 0);
      const failed = results.filter((r) => !r.ok);
      if (created > 0) {
        await db.notification.create({
          data: {
            type: 'warn',
            title: 'Agent Monitors Sweep',
            message: `${created} new finding(s) raised across ${results.length} monitors (${deduped} deduped, ${failed.length} failed).`,
            read: false,
          },
        });
      }
      return {
        ok: failed.length === 0,
        detail: `Ran ${results.length} monitors: ${created} new findings, ${deduped} deduped, ${failed.length} failed`,
        recordsAffected: created,
      };
    } catch (err) {
      return { ok: false, detail: `agent-monitors failed: ${err instanceof Error ? err.message : String(err)}` };
    }
  },
  // ── CSAT Survey (Phase 4) ──
  // Runs daily. Sends any CSAT surveys that have been pending for more than
  // 7 days (created → cool-down → client is ready to rate the engagement).
  // Also expires surveys past their 14-day window. Implemented in
  // csat-engine.ts so the same logic can be invoked from the API/tests.
  'csat-survey': async () => {
    try {
      const { processDueCsatSurveys } = await import('@/lib/csat-engine');
      const result = await processDueCsatSurveys();
      if (result.sent > 0 || result.expired > 0) {
        await db.notification.create({
          data: {
            type: result.sent > 0 ? 'success' : 'info',
            title: 'CSAT Survey Sweep',
            message:
              `Sent ${result.sent} survey(s), expired ${result.expired}, ` +
              `checked ${result.checked} pending (older than 7 days).`,
            read: false,
          },
        }).catch(() => {});
      }
      return {
        ok: true,
        detail: `CSAT sweep: sent ${result.sent}, expired ${result.expired}, checked ${result.checked}`,
        recordsAffected: result.sent + result.expired,
      };
    } catch (err) {
      return { ok: false, detail: 'csat-survey failed: ' + (err instanceof Error ? err.message : String(err)) };
    }
  },

  // ── Scheduled Autonomy / Agent Training ──
  // Auto-fires every enabled ScheduledAutonomy loop whose intervalMin has
  // elapsed since its last run. Each fire is a training run that updates the
  // agent's skills + proficiency + cooldown (see agent-training.ts). Honors
  // the cooldown so already-proficient agents are NOT retrained.
  'scheduled-autonomy-tick': async () => {
    try {
      const { runDueScheduledAutonomy } = await import('@/lib/scheduled-autonomy-runner');
      const r = await runDueScheduledAutonomy();
      return {
        ok: r.errors === 0,
        detail: `scheduled-autonomy-tick: ${r.due} due → ${r.ran} ran, ${r.skipped} skipped (cooldown), ${r.errors} errors. ${r.details.slice(0, 3).join(' | ')}`,
        recordsAffected: r.ran,
      };
    } catch (err) {
      return { ok: false, detail: 'scheduled-autonomy-tick failed: ' + (err instanceof Error ? err.message : String(err)) };
    }
  },
};

// ─── dispatchCronJob ──────────────────────────────────────────────────
export async function dispatchCronJob(key: string): Promise<CronJobResult> {
  const start = Date.now();
  const dispatcher = dispatchers[key];
  if (!dispatcher) {
    return { ok: false, key, detail: `No dispatcher registered for key: ${key}`, durationMs: 0 };
  }
  try {
    const result = await dispatcher();
    return { ...result, key, durationMs: Date.now() - start };
  } catch (err) {
    return {
      ok: false,
      key,
      detail: `Dispatcher threw: ${err instanceof Error ? err.message : String(err)}`,
      durationMs: Date.now() - start,
    };
  }
}

// ─── listCronKeys ─────────────────────────────────────────────────────
export function listCronKeys(): string[] {
  return Object.keys(dispatchers);
}
