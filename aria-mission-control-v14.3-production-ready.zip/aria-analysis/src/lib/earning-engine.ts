// =====================================================================
// earning-engine.ts — Expert-level autonomous earning engine
// =====================================================================
// RULE 48: EARNING IS #1 — Revenue First, Always.
//
// This engine is the brain of the autonomous earning system:
//   1. FIND opportunities (market research, trend analysis)
//   2. QUALIFY them (profitability, risk, skill match)
//   3. PLAN execution (step-by-step with revenue projection)
//   4. EXECUTE (agents do the work, collect payment)
//   5. TRACK revenue (real-time dashboards)
//   6. OPTIMIZE (double down on winners, cut losers)
//
// The engine uses ALL 455 models with smart routing:
//   - Research → DeepSeek-R1 (deep reasoning)
//   - Planning → GLM-4.6 (excellent planning)
//   - Content → Claude/Qwen (creative writing)
//   - Code → Qwen Coder (code generation)
//   - Analysis → DeepSeek (data analysis)
// =====================================================================

import { db } from '@/lib/db';
import { quickChat, extractJson } from '@/lib/llm';
import { logger } from '@/lib/logger';
import { recommendModel, type TaskType } from '@/lib/smart-model-router';

export interface EarningOpportunity {
  title: string;
  description: string;
  category: string;
  estimatedRevenue: number;
  estimatedTimeHours: number;
  riskLevel: 'low' | 'medium' | 'high';
  skillsRequired: string[];
  method: string;
  marketDemand: 'low' | 'medium' | 'high' | 'very-high';
  competition: 'low' | 'medium' | 'high';
  priority: number; // 0-100, higher = more urgent
}

export interface EarningStats {
  totalMethods: number;
  approvedMethods: number;
  deployedMethods: number;
  totalRevenue: number;
  monthlyProjected: number;
  topEarners: Array<{ name: string; revenue: number }>;
  pendingApprovals: number;
  activeAgents: number;
}

/**
 * Get comprehensive earning stats — the earning dashboard data.
 */
export async function getEarningStats(): Promise<EarningStats> {
  try {
    const [methods, payments, refunds, agents] = await Promise.all([
      db.earningMethod.findMany({ select: { name: true, estimatedMonthly: true, approvalStatus: true, totalEarnings: true, approved: true } }),
      db.payment.aggregate({ where: { status: 'confirmed' }, _sum: { amount: true } }),
      db.refund.aggregate({ where: { status: 'processed' }, _sum: { amount: true } }),
      db.agent.count({ where: { status: { in: ['working', 'thinking'] } } }),
    ]);

    const totalRevenue = (payments._sum.amount ?? 0) - (refunds._sum.amount ?? 0);
    const approvedMethods = methods.filter(m => m.approved).length;
    const deployedMethods = methods.filter(m => m.approvalStatus === 'deployed').length;
    const monthlyProjected = methods
      .filter(m => m.approvalStatus === 'deployed' || m.approvalStatus === 'approved')
      .reduce((sum, m) => sum + (m.estimatedMonthly ?? 0), 0);

    const topEarners = methods
      .filter(m => (m.totalEarnings ?? 0) > 0)
      .sort((a, b) => (b.totalEarnings ?? 0) - (a.totalEarnings ?? 0))
      .slice(0, 5)
      .map(m => ({ name: m.name, revenue: m.totalEarnings ?? 0 }));

    return {
      totalMethods: methods.length,
      approvedMethods,
      deployedMethods,
      totalRevenue,
      monthlyProjected,
      topEarners,
      pendingApprovals: methods.filter(m => m.approvalStatus === 'pending_approval').length,
      activeAgents: agents,
    };
  } catch (err) {
    logger.error({ err }, 'earning-engine: getEarningStats failed');
    return {
      totalMethods: 0, approvedMethods: 0, deployedMethods: 0,
      totalRevenue: 0, monthlyProjected: 0, topEarners: [], pendingApprovals: 0, activeAgents: 0,
    };
  }
}

/**
 * FIND earning opportunities using AI research.
 * Uses DeepSeek-R1 (deep reasoning model) for market analysis.
 */
export async function findEarningOpportunities(count: number = 5): Promise<EarningOpportunity[]> {
  // Get the best model for research
  const modelRec = await recommendModel('research');

  const prompt = `You are an expert business strategist for an autonomous AI company. The company has 69 AI agents with these skills: code generation, web research, content writing, data analysis, image generation, voice synthesis, translation, SEO, social media management, customer support, and more. It has access to 455 AI models.

Find ${count} HIGH-PROFIT earning opportunities the company can execute autonomously. Focus on:
1. High demand, low competition niches
2. Tasks AI agents can do better/cheaper than humans
3. Recurring revenue models (subscriptions, retainers)
4. Scalable services (build once, sell many)

For each opportunity, output JSON:
{
  "title": "short name",
  "description": "what the service is",
  "category": "SaaS|Content|Service|Data|Automation|Consulting",
  "estimatedRevenue": monthly_revenue_in_INR,
  "estimatedTimeHours": hours_to_build_initial_version,
  "riskLevel": "low|medium|high",
  "skillsRequired": ["skill1", "skill2"],
  "method": "step-by-step how to execute",
  "marketDemand": "low|medium|high|very-high",
  "competition": "low|medium|high",
  "priority": 0-100
}

Output a JSON array of ${count} opportunities. Be realistic about revenue (INR/month). Focus on opportunities that can start earning within 1-2 weeks.`;

  try {
    const raw = await quickChat(prompt, 'You are an expert AI business strategist. Output ONLY a JSON array.');
    const opportunities = extractJson<EarningOpportunity[]>(raw);
    if (Array.isArray(opportunities)) {
      return opportunities.slice(0, count);
    }
    return [];
  } catch (err) {
    logger.error({ err }, 'earning-engine: findOpportunities failed');
    return [];
  }
}

/**
 * QUALIFY an earning opportunity — assess profitability + feasibility.
 */
export async function qualifyOpportunity(opp: EarningOpportunity): Promise<{
  qualified: boolean;
  score: number;
  reasoning: string;
  risks: string[];
  recommendations: string[];
}> {
  const prompt = `You are a venture capitalist evaluating an AI business opportunity. Score it 0-100 and assess viability.

Opportunity: ${opp.title}
Description: ${opp.description}
Estimated Revenue: ₹${opp.estimatedRevenue}/month
Time to build: ${opp.estimatedTimeHours} hours
Risk: ${opp.riskLevel}
Skills: ${opp.skillsRequired.join(', ')}
Market demand: ${opp.marketDemand}
Competition: ${opp.competition}

Output JSON: {"qualified":true/false, "score":0-100, "reasoning":"...", "risks":["..."], "recommendations":["..."]}`;

  try {
    const raw = await quickChat(prompt, 'You are a VC evaluator. Output ONLY JSON.');
    const result = extractJson<{ qualified?: boolean; score?: number; reasoning?: string; risks?: string[]; recommendations?: string[] }>(raw);
    if (result) {
      return {
        qualified: result.qualified ?? false,
        score: result.score ?? 0,
        reasoning: result.reasoning ?? 'No reasoning provided',
        risks: result.risks ?? [],
        recommendations: result.recommendations ?? [],
      };
    }
  } catch (err) {
    logger.error({ err }, 'earning-engine: qualifyOpportunity failed');
  }

  return {
    qualified: false,
    score: 0,
    reasoning: 'Qualification failed',
    risks: ['Unable to assess'],
    recommendations: [],
  };
}

/**
 * Create an earning method in the DB from a qualified opportunity.
 */
export async function createEarningMethod(opp: EarningOpportunity): Promise<string | null> {
  try {
    const method = await db.earningMethod.create({
      data: {
        key: `auto-${Date.now()}`,
        name: opp.title,
        description: opp.description,
        category: opp.category,
        earningPotential: opp.estimatedRevenue > 50000 ? 'high' : opp.estimatedRevenue > 20000 ? 'medium' : 'low',
        riskLevel: opp.riskLevel,
        skillsRequired: JSON.stringify(opp.skillsRequired),
        method: opp.method,
        estimatedMonthly: opp.estimatedRevenue,
        approvalStatus: 'pending_approval',
        tags: JSON.stringify([opp.category, opp.marketDemand, opp.competition]),
      },
    });
    return method.id;
  } catch (err) {
    logger.error({ err }, 'earning-engine: createEarningMethod failed');
    return null;
  }
}

/**
 * Run the full earning pipeline: find → qualify → create.
 * This is the autonomous earning loop — called by the CEO agent.
 */
export async function runEarningPipeline(maxOpportunities: number = 3): Promise<{
  found: number;
  qualified: number;
  created: number;
  opportunities: Array<{ title: string; score: number; qualified: boolean }>;
}> {
  // 1. FIND
  const opportunities = await findEarningOpportunities(maxOpportunities);
  const results: Array<{ title: string; score: number; qualified: boolean }> = [];
  let qualified = 0;
  let created = 0;

  // 2. QUALIFY + 3. CREATE
  for (const opp of opportunities) {
    const qualification = await qualifyOpportunity(opp);
    results.push({ title: opp.title, score: qualification.score, qualified: qualification.qualified });

    if (qualification.qualified && qualification.score >= 60) {
      qualified++;
      const methodId = await createEarningMethod(opp);
      if (methodId) created++;
    }
  }

  return {
    found: opportunities.length,
    qualified,
    created,
    opportunities: results,
  };
}

/**
 * Get the best model for a specific earning task.
 */
export async function getBestModelForEarningTask(task: TaskType) {
  return recommendModel(task);
}
