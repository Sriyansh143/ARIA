// =====================================================================
// telegram-bot.ts — Telegram Bot API integration
// =====================================================================
// Sends messages + approval requests to the owner via Telegram.
// Used by the approval escalation system (Level 1: Telegram).
// =====================================================================

import { logger } from '@/lib/logger';

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;
const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN ?? 'MISSING'}`;

export function isTelegramConfigured(): boolean {
  return !!(BOT_TOKEN && CHAT_ID);
}

/**
 * Send a text message to the owner via Telegram.
 */
export async function sendToOwner(message: string): Promise<boolean> {
  if (!isTelegramConfigured()) return false;
  try {
    const res = await fetch(`${API_BASE}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        parse_mode: 'Markdown',
      }),
    });
    const data = await res.json();
    return data.ok === true;
  } catch (err) {
    logger.warn({ err }, 'telegram-bot: sendToOwner failed');
    return false;
  }
}

/**
 * Send a message with inline keyboard buttons (for approval requests).
 */
export async function sendToOwnerWithButtons(
  message: string,
  buttons: Array<{ text: string; callback_data: string }>,
): Promise<boolean> {
  if (!isTelegramConfigured()) return false;
  try {
    const res = await fetch(`${API_BASE}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [buttons] },
      }),
    });
    const data = await res.json();
    return data.ok === true;
  } catch (err) {
    logger.warn({ err }, 'telegram-bot: sendToOwnerWithButtons failed');
    return false;
  }
}

/**
 * Send an approval request with Approve/Reject buttons.
 */
export async function sendApprovalRequest(
  title: string,
  description: string,
  approvalId: string,
): Promise<boolean> {
  const message = `🔔 *Approval Required*\n\n*${title}*\n${description.slice(0, 500)}\n\nApproval ID: \`${approvalId}\``;
  return sendToOwnerWithButtons(message, [
    { text: '✅ Approve', callback_data: `approve:${approvalId}` },
    { text: '❌ Reject', callback_data: `reject:${approvalId}` },
  ]);
}

/**
 * Handle incoming Telegram webhook updates (button clicks, text messages).
 */
export async function handleTelegramUpdate(update: Record<string, unknown>): Promise<{ ok: boolean; response?: string }> {
  // Handle callback queries (button clicks)
  const callbackQuery = update.callback_query as { data?: string; message?: { chat?: { id: number } } } | undefined;
  if (callbackQuery?.data) {
    const [action, approvalId] = callbackQuery.data.split(':');
    if (action === 'approve' || action === 'reject') {
      try {
        const res = await fetch(`http://localhost:${process.env.PORT || 3000}/api/approvals/${approvalId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            decision: action === 'approve' ? 'approved' : 'rejected',
            decidedBy: 'telegram-owner',
            decisionNote: `Resolved via Telegram button`,
          }),
        });
        const data = await res.json();
        return { ok: true, response: `Approval ${action}d: ${data.ok ? 'success' : 'failed'}` };
      } catch (err) {
        logger.error({ err }, 'telegram-bot: handleTelegramUpdate approval resolve failed');
        return { ok: false, response: 'Failed to resolve approval' };
      }
    }
  }

  // Handle text messages — forward to Orion command processor
  const message = update.message as { text?: string; chat?: { id: number } } | undefined;
  if (message?.text) {
    try {
      const res = await fetch(`http://localhost:${process.env.PORT || 3000}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: message.text }),
      });
      const data = await res.json();
      const response = data.message?.content?.slice(0, 4000) ?? 'No response';
      // Send the response back to the chat
      if (message.chat?.id) {
        await fetch(`${API_BASE}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: message.chat.id, text: response, parse_mode: 'Markdown' }),
        });
      }
      return { ok: true, response };
    } catch (err) {
      logger.error({ err }, 'telegram-bot: handleTelegramUpdate message forward failed');
      return { ok: false, response: 'Failed to process message' };
    }
  }

  return { ok: true, response: 'No action needed' };
}
