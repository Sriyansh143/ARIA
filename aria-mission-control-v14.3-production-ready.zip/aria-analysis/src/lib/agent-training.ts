// src/lib/agent-training.ts
// Agent training lifecycle: proficiency, cooldown, skill updates.
//
// When an agent is "trained" (via a scheduled-autonomy run, a manual
// autonomy loop, or the Teach panel), this module records the training:
//   - bumps the skill proficiency (capped 0-100)
//   - records trainingCount, bestProficiency, preProficiency
//   - sets a cooldownUntil so the agent is NOT trained again until its
//     performance actually needs improvisation (proficiency decays below a
//     threshold via the skill-proficiency-decay cron, or successRate drops)
//   - appends the skill to the agent's `skills` JSON array
//   - nudges the agent's successRate (+1 on success, -3 on failure)
//
// This is the single source of truth for "once an agent is trained, update
// its skills / skill level / improvement — and don't repeat the training
// until improvisation is needed".

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

/** Default cooldown after a training run (7 days). */
export const TRAINING_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;
/** Proficiency gained per successful training run. */
export const PROFICIENCY_GAIN = 10;
/** Proficiency at/above which an agent is considered to have mastered a skill
 *  — no retraining is needed until proficiency decays below this. */
export const MASTERY = 80;
/** Legacy threshold (kept for reference / future retrain scheduling). */
export const RETRAIN_THRESHOLD = 60;

/** Infer a stable, human-readable skillKey from a free-form topic string. */
export function inferSkillKey(topic: string): string {
  const t = topic.trim().toLowerCase().replace(/[^a-z0-9\s-]/g, '');
  const stop = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'your', 'into', 'how', 'what', 'why', 'about', 'using', 'via']);
  const words = t.split(/\s+/).filter((w) => w.length > 2 && !stop.has(w));
  const key = words.slice(0, 3).join('-') || 'autonomous-research';
  return `topic:${key}`;
}

export interface CooldownCheck {
  onCooldown: boolean;
  proficiency: number;
  cooldownUntil: Date | null;
  reason?: string;
}

/**
 * Should this agent be trained on this skill right now?
 *
 * Cooldown rules (prevents "repetitive training again until it needs
 * improvisation on performance"):
 *   1. If the agent was trained recently (cooldownUntil > now) → SKIP, no
 *      matter the proficiency. A training run always sets a 7-day cooldown,
 *      so the agent is never retrained again immediately — even if the run
 *      failed (which would otherwise spam the LLM on every click).
 *   2. After the cooldown expires, SKIP if the agent has already mastered
 *      the skill (proficiency >= MASTERY). No need to retrain a master.
 *   3. Otherwise (cooldown expired AND proficiency < MASTERY, e.g. it decayed
 *      via the skill-proficiency-decay cron or never reached mastery) → allow
 *      retraining. This is the "needs improvisation on performance" trigger.
 */
export async function checkTrainingCooldown(
  agentCodename: string,
  skillKey: string,
): Promise<CooldownCheck> {
  const row = await db.skillLearning.findUnique({
    where: { agentCodename_skillKey: { agentCodename, skillKey } },
  });
  if (!row) return { onCooldown: false, proficiency: 0, cooldownUntil: null };
  const now = Date.now();
  if (row.cooldownUntil && row.cooldownUntil.getTime() > now) {
    return {
      onCooldown: true,
      proficiency: row.proficiency,
      cooldownUntil: row.cooldownUntil,
      reason: `Already trained on ${row.lastTrainedAt?.toISOString().slice(0, 10)} — retraining suppressed until ${row.cooldownUntil.toISOString().slice(0, 10)}. Retrains after cooldown when proficiency needs improvisation.`,
    };
  }
  if (row.proficiency >= MASTERY) {
    return {
      onCooldown: true,
      proficiency: row.proficiency,
      cooldownUntil: row.cooldownUntil,
      reason: `Already mastered at ${row.proficiency}% — no retraining needed until proficiency decays below ${MASTERY}%.`,
    };
  }
  return { onCooldown: false, proficiency: row.proficiency, cooldownUntil: row.cooldownUntil };
}

export interface TrainingRecord {
  proficiency: number;
  trainingCount: number;
  bestProficiency: number;
  preProficiency: number;
  cooldownUntil: Date | null;
  onCooldown: boolean;
  skillNewlyAdded: boolean;
}

/**
 * Record a training run for an agent on a skill.
 *   - bumps proficiency (only on success; failure still counts the attempt + sets cooldown)
 *   - updates SkillLearning lifecycle fields
 *   - appends the skillKey to Agent.skills (if missing)
 *   - nudges Agent.successRate (+1 success / -3 failure)
 *
 * Call this AFTER the actual training work (research → task creation) has
 * completed, with `success` reflecting whether the run produced a task.
 */
export async function recordTraining(opts: {
  agentCodename: string;
  skillKey: string;
  success: boolean;
  learnedFrom?: string;
}): Promise<TrainingRecord> {
  const { agentCodename, skillKey, success, learnedFrom = 'autonomy-loop' } = opts;

  const existing = await db.skillLearning.findUnique({
    where: { agentCodename_skillKey: { agentCodename, skillKey } },
  });
  const pre = existing?.proficiency ?? 0;
  const delta = success ? PROFICIENCY_GAIN : 0;
  const nextProf = Math.max(0, Math.min(100, pre + delta));
  const nextCount = (existing?.trainingCount ?? 0) + 1;
  const cooldownUntil = new Date(Date.now() + TRAINING_COOLDOWN_MS);
  const best = Math.max(existing?.bestProficiency ?? 0, nextProf);

  const row = await db.skillLearning.upsert({
    where: { agentCodename_skillKey: { agentCodename, skillKey } },
    update: {
      proficiency: nextProf,
      lastTrainedAt: new Date(),
      trainingCount: nextCount,
      bestProficiency: best,
      preProficiency: pre,
      cooldownUntil,
      lastUsed: new Date(),
      lastRunSuccess: success,
      learnedFrom,
    },
    create: {
      agentCodename,
      skillKey,
      proficiency: nextProf,
      lastTrainedAt: new Date(),
      trainingCount: nextCount,
      bestProficiency: best,
      preProficiency: pre,
      cooldownUntil,
      lastUsed: new Date(),
      lastRunSuccess: success,
      learnedFrom,
    },
  });

  // Update the agent's `skills` JSON array + successRate.
  let skillNewlyAdded = false;
  try {
    const agent = await db.agent.findFirst({ where: { codename: agentCodename } });
    if (agent) {
      let skills: string[] = [];
      try {
        skills = JSON.parse(agent.skills || '[]');
        if (!Array.isArray(skills)) skills = [];
      } catch {
        skills = [];
      }
      if (!skills.includes(skillKey)) {
        skills.push(skillKey);
        skillNewlyAdded = true;
      }
      // Nudge successRate: +1 on success (cap 100), -3 on failure (floor 0).
      const sr = success
        ? Math.min(100, Math.round((agent.successRate + 1) * 10) / 10)
        : Math.max(0, Math.round((agent.successRate - 3) * 10) / 10);
      await db.agent.update({
        where: { id: agent.id },
        data: { skills: JSON.stringify(skills), successRate: sr },
      });
    }
  } catch (e) {
    logger.warn(
      { err: e instanceof Error ? e.message : String(e) },
      'agent-training: failed to update agent skills/successRate',
    );
  }

  return {
    proficiency: row.proficiency,
    trainingCount: row.trainingCount,
    bestProficiency: row.bestProficiency,
    preProficiency: row.preProficiency,
    cooldownUntil: row.cooldownUntil,
    onCooldown: true,
    skillNewlyAdded,
  };
}
