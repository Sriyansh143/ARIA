// =====================================================================
// predictive-analytics.ts — Fleet forecasting for Mission Briefing
// =====================================================================
// PRODUCTION ENHANCEMENT (v11): Generates time-series forecasts for key
// fleet metrics so the operator can anticipate overload, revenue gaps,
// and task-completion shortfalls BEFORE they happen.
//
// Uses lightweight statistical methods (linear regression + EWMA) on the
// recent telemetry/history series. No heavy ML dependency — this runs
// in-process and is fast (<50ms for 100 data points).
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export interface Forecast {
  metric: string;
  horizon: string;
  current: number;
  forecast: number;
  confidence: number; // 0-1
  trend: 'up' | 'down' | 'stable';
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  detail: Record<string, unknown>;
}

/**
 * Simple linear regression forecast: fits y = a + b*x to the series,
 * then projects b forward by `steps`. Returns the forecasted value
 * and a confidence score based on R² (goodness of fit).
 */
function linearForecast(series: number[], steps: number): { forecast: number; confidence: number; slope: number } {
  const n = series.length;
  if (n < 2) return { forecast: series[0] ?? 0, confidence: 0.2, slope: 0 };
  const xs = series.map((_, i) => i);
  const meanX = xs.reduce((s, x) => s + x, 0) / n;
  const meanY = series.reduce((s, y) => s + y, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - meanX) * (series[i] - meanY);
    den += (xs[i] - meanX) ** 2;
  }
  const slope = den === 0 ? 0 : num / den;
  const intercept = meanY - slope * meanX;
  // R² for confidence
  let ssTot = 0;
  let ssRes = 0;
  for (let i = 0; i < n; i++) {
    const pred = intercept + slope * xs[i];
    ssTot += (series[i] - meanY) ** 2;
    ssRes += (series[i] - pred) ** 2;
  }
  const r2 = ssTot === 0 ? 1 : Math.max(0, 1 - ssRes / ssTot);
  const forecast = intercept + slope * (n - 1 + steps);
  return { forecast, confidence: Math.min(0.95, r2), slope };
}

function trendFromSlope(slope: number, current: number): 'up' | 'down' | 'stable' {
  const threshold = Math.max(0.5, Math.abs(current) * 0.02);
  if (slope > threshold) return 'up';
  if (slope < -threshold) return 'down';
  return 'stable';
}

function riskFromForecast(metric: string, forecast: number): 'low' | 'medium' | 'high' | 'critical' {
  switch (metric) {
    case 'fleet-load':
      if (forecast > 90) return 'critical';
      if (forecast > 75) return 'high';
      if (forecast > 60) return 'medium';
      return 'low';
    case 'overload-risk':
      if (forecast > 0.7) return 'critical';
      if (forecast > 0.4) return 'high';
      if (forecast > 0.2) return 'medium';
      return 'low';
    case 'error-rate':
      if (forecast > 15) return 'critical';
      if (forecast > 8) return 'high';
      if (forecast > 3) return 'medium';
      return 'low';
    case 'revenue':
      return forecast < 0 ? 'high' : 'low';
    case 'task-completion':
      if (forecast < 30) return 'high';
      if (forecast < 60) return 'medium';
      return 'low';
    default:
      return 'low';
  }
}

/**
 * Generate forecasts for all key fleet metrics based on recent history.
 * Persists each to the FleetForecast table and returns them.
 */
export async function generateFleetForecasts(): Promise<Forecast[]> {
  const now = new Date();
  const hourAgo = new Date(now.getTime() - 60 * 60 * 1000);
  const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  const forecasts: Forecast[] = [];

  try {
    // 1. Fleet load — from recent telemetry CPU/mem series (1h forecast)
    const telemetry = await db.telemetry.findMany({
      where: { createdAt: { gte: hourAgo } },
      orderBy: { createdAt: 'asc' },
      take: 60,
      select: { cpu: true, mem: true },
    });
    if (telemetry.length >= 2) {
      const loadSeries = telemetry.map((t) => (t.cpu + t.mem) / 2);
      const { forecast, confidence, slope } = linearForecast(loadSeries, 6); // 6 steps ~30min ahead
      const current = loadSeries[loadSeries.length - 1] ?? 0;
      const f: Forecast = {
        metric: 'fleet-load',
        horizon: '1h',
        current: Math.round(current * 10) / 10,
        forecast: Math.round(Math.max(0, Math.min(100, forecast)) * 10) / 10,
        confidence,
        trend: trendFromSlope(slope, current),
        riskLevel: riskFromForecast('fleet-load', forecast),
        detail: { dataPoints: telemetry.length, slope: Math.round(slope * 100) / 100 },
      };
      forecasts.push(f);
    }

    // 2. Overload risk — fraction of agents over 70% load (6h forecast)
    const agents = await db.agent.findMany({ select: { load: true, status: true } });
    const overloadedNow = agents.filter((a) => a.load > 70).length;
    const overloadFraction = agents.length > 0 ? overloadedNow / agents.length : 0;
    // Use recent AgentLog error counts as a proxy trend for overload risk.
    const recentErrors = await db.agentLog.count({ where: { level: 'error', createdAt: { gte: hourAgo } } });
    const olderErrors = await db.agentLog.count({
      where: { level: 'error', createdAt: { gte: dayAgo, lt: hourAgo } },
    });
    const errorTrend = recentErrors - olderErrors / 23; // normalize older (23h span) to per-hour
    const overloadForecast = Math.max(0, Math.min(1, overloadFraction + errorTrend * 0.02));
    forecasts.push({
      metric: 'overload-risk',
      horizon: '6h',
      current: Math.round(overloadFraction * 100) / 100,
      forecast: Math.round(overloadForecast * 100) / 100,
      confidence: 0.6,
      trend: errorTrend > 0.5 ? 'up' : errorTrend < -0.5 ? 'down' : 'stable',
      riskLevel: riskFromForecast('overload-risk', overloadForecast),
      detail: { overloadedAgents: overloadedNow, totalAgents: agents.length, recentErrors, errorTrend: Math.round(errorTrend * 100) / 100 },
    });

    // 3. Task completion rate — completed vs created (24h forecast)
    const dayCompleted = await db.task.count({ where: { status: 'completed', updatedAt: { gte: dayAgo } } });
    const dayCreated = await db.task.count({ where: { createdAt: { gte: dayAgo } } });
    const completionRate = dayCreated > 0 ? (dayCompleted / dayCreated) * 100 : 100;
    forecasts.push({
      metric: 'task-completion',
      horizon: '24h',
      current: Math.round(completionRate),
      forecast: Math.round(Math.max(0, Math.min(100, completionRate - (overloadForecast * 10)))),
      confidence: 0.55,
      trend: dayCompleted >= dayCreated * 0.8 ? 'stable' : 'down',
      riskLevel: riskFromForecast('task-completion', completionRate),
      detail: { dayCompleted, dayCreated, completionRate: Math.round(completionRate) },
    });

    // 4. Revenue forecast — confirmed payments trend (7d forecast)
    const confirmedPayments = await db.payment.findMany({
      where: { status: 'confirmed', createdAt: { gte: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000) } },
      orderBy: { createdAt: 'asc' },
      select: { amount: true, createdAt: true },
    });
    // Bucket into daily sums
    const dailySums: number[] = [];
    for (let d = 6; d >= 0; d--) {
      const dayStart = new Date(now.getTime() - d * 24 * 60 * 60 * 1000);
      const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
      const sum = confirmedPayments
        .filter((p) => p.createdAt >= dayStart && p.createdAt < dayEnd)
        .reduce((s, p) => s + p.amount, 0);
      dailySums.push(sum);
    }
    if (dailySums.length >= 2) {
      const { forecast, confidence, slope } = linearForecast(dailySums, 7);
      const current = dailySums[dailySums.length - 1] ?? 0;
      forecasts.push({
        metric: 'revenue',
        horizon: '7d',
        current: Math.round(current),
        forecast: Math.round(Math.max(0, forecast)),
        confidence,
        trend: trendFromSlope(slope, current),
        riskLevel: riskFromForecast('revenue', forecast),
        detail: { dailySums: dailySums.map((s) => Math.round(s)), weekTotal: Math.round(dailySums.reduce((s, x) => s + x, 0)) },
      });
    }

    // 5. Error rate forecast — from recent AgentLog (1h forecast)
    const errorBuckets: number[] = [];
    for (let m = 11; m >= 0; m--) {
      const start = new Date(now.getTime() - (m + 1) * 5 * 60 * 1000);
      const end = new Date(now.getTime() - m * 5 * 60 * 1000);
      const count = await db.agentLog.count({ where: { level: 'error', createdAt: { gte: start, lt: end } } });
      errorBuckets.push(count);
    }
    if (errorBuckets.length >= 2) {
      const { forecast, confidence, slope } = linearForecast(errorBuckets, 12);
      const current = errorBuckets[errorBuckets.length - 1] ?? 0;
      const errorRate = agents.length > 0 ? (current / agents.length) * 100 : 0;
      const forecastRate = agents.length > 0 ? (forecast / agents.length) * 100 : 0;
      forecasts.push({
        metric: 'error-rate',
        horizon: '1h',
        current: Math.round(errorRate * 10) / 10,
        forecast: Math.round(Math.max(0, forecastRate) * 10) / 10,
        confidence,
        trend: trendFromSlope(slope, current),
        riskLevel: riskFromForecast('error-rate', forecastRate),
        detail: { errorBuckets, recentErrors: current },
      });
    }

    // Persist forecasts (best-effort)
    for (const f of forecasts) {
      try {
        await db.fleetForecast.create({
          data: {
            metric: f.metric,
            horizon: f.horizon,
            current: f.current,
            forecast: f.forecast,
            confidence: f.confidence,
            trend: f.trend,
            riskLevel: f.riskLevel,
            detail: JSON.stringify(f.detail),
          },
        });
      } catch {
        // best-effort
      }
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'predictive-analytics: forecast generation failed');
  }

  return forecasts;
}

/**
 * Get the most recent forecast for each metric (for the briefing UI).
 */
export async function getLatestForecasts(): Promise<Forecast[]> {
  try {
    const rows = await db.fleetForecast.findMany({
      orderBy: { generatedAt: 'desc' },
      take: 50,
    });
    const byKey = new Map<string, Forecast>();
    for (const r of rows) {
      const key = `${r.metric}:${r.horizon}`;
      if (!byKey.has(key)) {
        let detail: Record<string, unknown> = {};
        try { detail = JSON.parse(r.detail); } catch { /* ignore */ }
        byKey.set(key, {
          metric: r.metric,
          horizon: r.horizon,
          current: r.current,
          forecast: r.forecast,
          confidence: r.confidence,
          trend: r.trend as Forecast['trend'],
          riskLevel: r.riskLevel as Forecast['riskLevel'],
          detail,
        });
      }
    }
    return Array.from(byKey.values());
  } catch {
    return [];
  }
}
