// =====================================================================
// app-overview.ts — Comprehensive app overview for monitoring agents
// =====================================================================
// USER RULE: "app overview with each and everything about app every
// element what is used for what best usecases etc of app this can be
// fed to monitoring agents for potential use of app and improve flows"
//
// This module generates a COMPLETE overview of the app — every tab,
// every API, every capability, best use cases, and potential
// improvements. Monitor agents query this to understand the full system.
// =====================================================================

export interface TabOverview {
  key: string;
  label: string;
  group: string;
  purpose: string;
  whatItShows: string[];
  bestUseCases: string[];
  relatedApis: string[];
  monitoringTips: string[];
  potentialImprovements: string[];
}

export const APP_OVERVIEW: TabOverview[] = [
  {
    key: 'overview',
    label: 'Overview',
    group: 'Command',
    purpose: 'Mission-control dashboard with fleet stats, telemetry, and recent activity.',
    whatItShows: ['Fleet size', 'Active tasks', 'Revenue', 'Telemetry charts', 'Recent activity'],
    bestUseCases: ['Quick health check', 'Identify bottlenecks', 'Monitor trends'],
    relatedApis: ['/api/dashboard', '/api/metrics'],
    monitoringTips: ['Watch CPU > 80%', 'Flag agent count drops', 'Monitor pending tasks'],
    potentialImprovements: ['Add customizable widgets', 'Add alert thresholds'],
  },
  {
    key: 'chat',
    label: 'JARVIS Chat',
    group: 'Command',
    purpose: 'AI chat with REAL code execution + action execution. Like Claude + z.ai combined.',
    whatItShows: ['Chat history', 'Code execution results', 'Action execution results', 'Model + latency'],
    bestUseCases: ['Build apps (code is auto-executed)', 'Create tasks/artifacts via actions', 'Run shell commands', 'Analyze data'],
    relatedApis: ['/api/chat', '/api/code-exec', '/api/agent-exec'],
    monitoringTips: ['Watch for high latency', 'Monitor code execution failures', 'Track action success rate'],
    potentialImprovements: ['Add streaming responses', 'Add file upload to chat'],
  },
  {
    key: 'preview',
    label: 'App Preview',
    group: 'Command',
    purpose: 'Build apps and preview them live in an iframe. Like z.ai preview.',
    whatItShows: ['Built app HTML', 'Responsive preview (desktop/tablet/mobile)', 'Live iframe rendering'],
    bestUseCases: ['Build single-page apps', 'Preview generated code', 'Test responsive design'],
    relatedApis: ['/api/chat', '/api/artifacts'],
    monitoringTips: ['Watch for build failures', 'Track app complexity'],
    potentialImprovements: ['Add multi-file app support', 'Add live code editing'],
  },
  {
    key: 'screen-vision',
    label: 'Screen Vision',
    group: 'Command',
    purpose: 'Capture screen + analyze with VLM. Like Claude vision — see screen and reply.',
    whatItShows: ['Screen capture', 'Image upload', 'VLM analysis results'],
    bestUseCases: ['Analyze UI layouts', 'Identify visual bugs', 'Describe screenshots', 'OCR text extraction'],
    relatedApis: ['/api/vision'],
    monitoringTips: ['Watch for VLM errors', 'Monitor analysis latency'],
    potentialImprovements: ['Add batch image analysis', 'Add element detection'],
  },
  {
    key: 'fleet',
    label: 'Agent Fleet',
    group: 'Fleet',
    purpose: 'All 69 agents with status, load, success rate, skills, department.',
    whatItShows: ['Agent cards', 'Status indicators', 'Load bars', 'Skill tags'],
    bestUseCases: ['Monitor agent health', 'Assign tasks', 'Identify overloaded agents'],
    relatedApis: ['/api/agents', '/api/fleet'],
    monitoringTips: ['Load > 70% = overloaded', 'Success rate < 90% = investigate', 'Idle agents = waste'],
    potentialImprovements: ['Add agent grouping by department', 'Add bulk operations'],
  },
  {
    key: 'agent-network',
    label: 'Agent Network',
    group: 'Fleet',
    purpose: 'Visual network of all agents as circles with hover info and connection lines.',
    whatItShows: ['Agent circles (size by seniority)', 'Connection edges', 'Hover tooltips', 'Detail panel'],
    bestUseCases: ['Understand reporting structure', 'See communication patterns', 'Identify isolated agents'],
    relatedApis: ['/api/agents'],
    monitoringTips: ['Watch for disconnected agents', 'Monitor communication frequency'],
    potentialImprovements: ['Add real-time message flow animation', 'Add filter by department'],
  },
  {
    key: 'tasks',
    label: 'Tasks',
    group: 'Work',
    purpose: 'Task management with list, Kanban board, and DAG dependency views.',
    whatItShows: ['Task list', 'Kanban columns', 'Dependency graph'],
    bestUseCases: ['Track work progress', 'Manage priorities', 'Identify blocked tasks'],
    relatedApis: ['/api/tasks', '/api/tasks/kanban'],
    monitoringTips: ['Watch for stalled tasks', 'Flag unassigned items', 'Monitor blocked dependencies'],
    potentialImprovements: ['Add sprint planning', 'Add time tracking'],
  },
  {
    key: 'crm',
    label: 'CRM & Sales',
    group: 'Business',
    purpose: 'Client pipeline, lead scoring, and support ticket management.',
    whatItShows: ['Client list', 'Lead scores', 'Support tickets'],
    bestUseCases: ['Track sales pipeline', 'Prioritize leads', 'Manage support queue'],
    relatedApis: ['/api/clients', '/api/leads', '/api/tickets'],
    monitoringTips: ['Watch for stale leads', 'Flag urgent tickets', 'Monitor conversion rate'],
    potentialImprovements: ['Add email integration', 'Add deal forecasting'],
  },
  {
    key: 'payments',
    label: 'Payments',
    group: 'Business',
    purpose: 'Payment ledger with refund system. Every confirmed payment can be refunded.',
    whatItShows: ['Payment records', 'Refund requests', 'Revenue stats'],
    bestUseCases: ['Track revenue', 'Process refunds', 'Monitor cash flow'],
    relatedApis: ['/api/payments', '/api/refunds'],
    monitoringTips: ['Watch for pending payments', 'Flag large refunds', 'Monitor revenue trends'],
    potentialImprovements: ['Add payment gateway integration', 'Add subscription management'],
  },
  {
    key: 'approvals',
    label: 'Approvals',
    group: 'Monitoring',
    purpose: 'Approval requests with 30-min escalation (Telegram → Email → Voice).',
    whatItShows: ['Pending approvals', 'Escalation levels', 'Decision history'],
    bestUseCases: ['Approve deployments', 'Review change requests', 'Monitor escalation chain'],
    relatedApis: ['/api/approvals', '/api/approvals/escalate'],
    monitoringTips: ['Watch for stale approvals', 'Monitor escalation frequency', 'Flag expired items'],
    potentialImprovements: ['Add approval templates', 'Add batch approvals'],
  },
  {
    key: 'verification',
    label: 'Verification',
    group: 'Monitoring',
    purpose: 'No-Assumption rule enforcement. Every claim is verified by a skeptical LLM.',
    whatItShows: ['Claim records', 'Confidence scores', 'Evidence', 'Question/improve flow'],
    bestUseCases: ['Verify research claims', 'Question agent conclusions', 'Improve plan quality'],
    relatedApis: ['/api/verifications'],
    monitoringTips: ['Flag disputed claims', 'Watch for low confidence', 'Monitor questioned items'],
    potentialImprovements: ['Add web-search verification', 'Add expert review queue'],
  },
  {
    key: 'code-exec',
    label: 'Code Execution',
    group: 'Intelligence',
    purpose: 'Real Python/JS/TS code execution sandbox. Like Claude code interpreter.',
    whatItShows: ['Code input', 'Execution output', 'Stdout/stderr', 'Exit code'],
    bestUseCases: ['Test algorithms', 'Process data', 'Generate reports', 'Validate code'],
    relatedApis: ['/api/code-exec'],
    monitoringTips: ['Watch for timeout errors', 'Monitor execution failures'],
    potentialImprovements: ['Add persistent state', 'Add library installation'],
  },
  {
    key: 'smart-router',
    label: 'Smart Router',
    group: 'Intelligence',
    purpose: 'Automatically selects the best of 455 models per task type.',
    whatItShows: ['Task type detection', 'Model recommendations', 'Alternative models'],
    bestUseCases: ['Optimize model selection', 'Reduce costs', 'Improve quality'],
    relatedApis: ['/api/smart-router'],
    monitoringTips: ['Track model usage distribution', 'Monitor fallback frequency'],
    potentialImprovements: ['Add A/B testing', 'Add cost optimization'],
  },
  {
    key: 'terminal',
    label: 'Terminal',
    group: 'System',
    purpose: 'Real shell command execution with block-list and approval gate.',
    whatItShows: ['Command input', 'stdout/stderr output', 'Command history'],
    bestUseCases: ['Run builds', 'Check files', 'Git operations', 'System admin'],
    relatedApis: ['/api/terminal/exec'],
    monitoringTips: ['Watch for blocked commands', 'Monitor approval requests'],
    potentialImprovements: ['Add SSH support', 'Add command templates'],
  },
  {
    key: 'ide',
    label: 'JARVIS IDE',
    group: 'System',
    purpose: 'In-browser code editor with file tree and syntax highlighting.',
    whatItShows: ['File tree', 'Code editor', 'Multiple tabs'],
    bestUseCases: ['Edit code files', 'Browse workspace', 'Quick fixes'],
    relatedApis: ['/api/file/read', '/api/file/write', '/api/workspace/list'],
    monitoringTips: ['Watch for unsaved changes', 'Monitor file conflicts'],
    potentialImprovements: ['Add git integration', 'Add linting'],
  },
  {
    key: 'action-log',
    label: 'Action Log',
    group: 'System',
    purpose: 'Reversible action log. Every mutation can be undone.',
    whatItShows: ['Action history', 'Before/after state', 'Reverse button'],
    bestUseCases: ['Undo mistakes', 'Audit changes', 'Track who did what'],
    relatedApis: ['/api/action-log', '/api/action-log/{id}/reverse'],
    monitoringTips: ['Watch for destructive actions', 'Monitor reversal failures'],
    potentialImprovements: ['Add bulk reverse', 'Add action search'],
  },
  {
    key: 'change-requests',
    label: 'Change Requests',
    group: 'System',
    purpose: 'App-change approval gate. Any change needs owner approval.',
    whatItShows: ['Change proposals', 'Approval status', 'Deploy/rollback tracking'],
    bestUseCases: ['Review feature requests', 'Approve upgrades', 'Track deployments'],
    relatedApis: ['/api/changes'],
    monitoringTips: ['Watch for stale requests', 'Monitor deployment failures'],
    potentialImprovements: ['Add diff preview', 'Add automated testing'],
  },
];

/**
 * Get the full app overview for monitor agents.
 */
export function getAppOverview(): TabOverview[] {
  return APP_OVERVIEW;
}

/**
 * Get a text summary suitable for injecting into agent system prompts.
 */
export function getAppOverviewSummary(): string {
  const lines = APP_OVERVIEW.map((t) => {
    return `- ${t.label} (${t.group}): ${t.purpose}\n  APIs: ${t.relatedApis.join(', ')}\n  Best for: ${t.bestUseCases.join('; ')}`;
  });
  return `APP OVERVIEW (${APP_OVERVIEW.length} tabs/features):\n${lines.join('\n')}`;
}

/**
 * Get overview for a specific tab.
 */
export function getTabOverview(tabKey: string): TabOverview | null {
  return APP_OVERVIEW.find((t) => t.key === tabKey) ?? null;
}
