// =====================================================================
// api-registry.ts — Real API endpoint registry for agents
// =====================================================================
// THE PROBLEM: agents were generating code with hypothetical clients
// (kanban_client, artifacts_client) instead of calling the REAL API.
// This registry gives agents the actual endpoints + how to call them.
//
// Agents query /api/agent-registry to get this list, then make real
// HTTP calls to /api/tasks, /api/artifacts, etc.
// =====================================================================

export interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  bodyExample?: Record<string, unknown>;
  responseField?: string;
  category: string;
}

export const API_REGISTRY: ApiEndpoint[] = [
  // ─── Tasks ───
  { method: 'GET', path: '/api/tasks', description: 'List all tasks (optional ?status=pending)', responseField: 'tasks', category: 'tasks' },
  { method: 'POST', path: '/api/tasks', description: 'Create a task', bodyExample: { title: 'Task title', assigneeId: 'agent-id', priority: 'high' }, category: 'tasks' },
  { method: 'GET', path: '/api/tasks/kanban', description: 'Get tasks grouped by status for Kanban board', category: 'tasks' },

  // ─── Agents ───
  { method: 'GET', path: '/api/agents', description: 'List all 69 agents with status, load, department', responseField: 'agents', category: 'agents' },
  { method: 'GET', path: '/api/fleet', description: 'Get fleet overview stats', category: 'agents' },
  { method: 'GET', path: '/api/dashboard', description: 'Dashboard stats (agents, tasks, revenue, telemetry)', category: 'agents' },

  // ─── Artifacts ───
  { method: 'GET', path: '/api/artifacts', description: 'List all artifacts (files, reports, code)', responseField: 'artifacts', category: 'artifacts' },
  { method: 'POST', path: '/api/artifacts', description: 'Create an artifact (saves to DB + disk)', bodyExample: { name: 'report.json', type: 'report', content: '{"key":"value"}' }, category: 'artifacts' },

  // ─── Payments ───
  { method: 'GET', path: '/api/payments', description: 'List payments + stats (confirmedTotal, pendingTotal)', category: 'payments' },
  { method: 'POST', path: '/api/payments', description: 'Create a payment record', bodyExample: { method: 'upi', amount: 1000, payer: 'client', status: 'confirmed' }, category: 'payments' },
  { method: 'GET', path: '/api/refunds', description: 'List refunds + stats', category: 'payments' },
  { method: 'POST', path: '/api/refunds', description: 'Request a refund on a confirmed payment', bodyExample: { paymentId: 'id', amount: 500, reason: 'customer_request' }, category: 'payments' },

  // ─── CRM ───
  { method: 'GET', path: '/api/clients', description: 'List clients + pipeline stats', responseField: 'clients', category: 'crm' },
  { method: 'POST', path: '/api/clients', description: 'Create a client', bodyExample: { name: 'Client Name', email: 'c@x.com', status: 'lead', value: 5000 }, category: 'crm' },
  { method: 'GET', path: '/api/leads', description: 'List leads with auto-computed scores', category: 'crm' },
  { method: 'POST', path: '/api/leads', description: 'Create a lead', bodyExample: { clientName: 'Name', source: 'web' }, category: 'crm' },
  { method: 'GET', path: '/api/tickets', description: 'List support tickets', category: 'crm' },
  { method: 'POST', path: '/api/tickets', description: 'Create a support ticket', bodyExample: { clientName: 'Name', subject: 'Issue', body: 'Description', priority: 'high' }, category: 'crm' },

  // ─── Approvals ───
  { method: 'GET', path: '/api/approvals', description: 'List pending approval requests', category: 'approvals' },
  { method: 'POST', path: '/api/approvals', description: 'Create an approval request', bodyExample: { title: 'Deploy feature', description: 'Need approval to deploy', category: 'app-change' }, category: 'approvals' },
  { method: 'POST', path: '/api/approvals/escalate', description: 'Manually trigger escalation sweep', category: 'approvals' },

  // ─── Verification (No-Assumption Rule) ───
  { method: 'GET', path: '/api/verifications', description: 'List verification records + stats', category: 'verification' },
  { method: 'POST', path: '/api/verifications', description: 'Log + verify a claim (LLM cross-checks it)', bodyExample: { claimType: 'fact', claimText: 'The sky is blue', claimSource: 'agent:vega' }, category: 'verification' },

  // ─── Change Requests ───
  { method: 'GET', path: '/api/changes', description: 'List change requests', category: 'changes' },
  { method: 'POST', path: '/api/changes', description: 'Request a change (needs approval before deploying)', bodyExample: { changeType: 'feature-add', title: 'Add X', description: 'Why' }, category: 'changes' },

  // ─── Action Log ───
  { method: 'GET', path: '/api/action-log', description: 'List reversible actions', category: 'action-log' },
  { method: 'POST', path: '/api/action-log/{id}/reverse', description: 'Reverse an action (restores before-state)', bodyExample: { reversedBy: 'operator' }, category: 'action-log' },

  // ─── Skills ───
  { method: 'GET', path: '/api/skills', description: 'List all available skills', category: 'skills' },

  // ─── Memory ───
  { method: 'GET', path: '/api/memory', description: 'List memory items', category: 'memory' },
  { method: 'POST', path: '/api/memory', description: 'Store a memory item', bodyExample: { key: 'fact-key', scope: 'general', value: 'content' }, category: 'memory' },

  // ─── Metrics ───
  { method: 'GET', path: '/api/metrics', description: 'Live system metrics (CPU, mem, disk, latency)', category: 'monitoring' },
  { method: 'GET', path: '/api/health', description: 'Fleet health check', category: 'monitoring' },

  // ─── Terminal + Files ───
  { method: 'POST', path: '/api/terminal/exec', description: 'Execute a shell command (block-list enforced)', bodyExample: { command: 'ls -la' }, category: 'system' },
  { method: 'POST', path: '/api/file/read', description: 'Read a file from workspace', bodyExample: { path: 'hello.txt' }, category: 'system' },
  { method: 'POST', path: '/api/file/write', description: 'Write a file to workspace', bodyExample: { path: 'output.json', content: '{}' }, category: 'system' },
  { method: 'POST', path: '/api/workspace/list', description: 'List directory contents', bodyExample: { path: '.' }, category: 'system' },

  // ─── Monitoring Feed (for agents) ───
  { method: 'GET', path: '/api/monitoring-feed', description: 'Tab inventory + usage guide for monitor agents', category: 'agents' },
  { method: 'GET', path: '/api/agent-registry', description: 'This endpoint — full API registry for agents', category: 'agents' },
];

/**
 * Get the full API registry — agents use this to discover real endpoints.
 */
export function getApiRegistry(): ApiEndpoint[] {
  return API_REGISTRY;
}

/**
 * Get a text summary suitable for injecting into agent system prompts.
 * This is the KEY fix — agents now know the REAL endpoints.
 */
export function getApiRegistrySummary(): string {
  const lines = API_REGISTRY.map((e) => {
    const body = e.bodyExample ? ` Body: ${JSON.stringify(e.bodyExample).slice(0, 100)}` : '';
    return `  ${e.method} ${e.path} — ${e.description}${body}`;
  });
  return `REAL API ENDPOINTS (call these directly — do NOT invent hypothetical clients):\n${lines.join('\n')}`;
}

/**
 * Get endpoints filtered by category.
 */
export function getEndpointsByCategory(category: string): ApiEndpoint[] {
  return API_REGISTRY.filter((e) => e.category === category);
}
