// knowledge-daemon.ts — "Knowledge daemon" sidecar with REAL DB persistence.
//
// INSPIRED BY:
//   • open-jarvis/OpenJarvis   (https://github.com/open-jarvis/OpenJarvis)
//     "Personal AI, On Personal Devices" — a daemon that runs AI locally on
//     personal devices and shares knowledge. Local-first, treats
//     energy / FLOPs / latency / cost as first-class constraints, and uses a
//     learning loop to improve models from local trace data.
//   • microsoft/JARVIS         (https://github.com/microsoft/JARVIS)
//     HuggingGPT / TaskMatrix — connects an LLM (controller) with numerous
//     expert ML models (executors) from HuggingFace Hub. Four-stage pipeline:
//     Task Planning → Model Selection → Task Execution → Response Generation.
//
// ──────────────────────────────────────────────────────────────────────────
// REAL BIDIRECTIONAL FLOW (v10.3.0+ — DB-BACKED, was conceptual-only before)
// ──────────────────────────────────────────────────────────────────────────
//
// The bidirectional knowledge-sharing flow is now REAL via the local
// database (MemoryItem with scope='knowledge-shared'). The conceptual
// "peer nodes" (open-jarvis-hub, microsoft-taskmatrix, peer-aurora-7,
// peer-nebula-3) remain in the topology view, but the actual data flow
// happens through DB persistence — which means knowledge entries survive
// across server restarts (unlike the in-memory store) AND the bidirectional
// loop is functional:
//
//   • OUTBOUND  (contribute → DB): When `contributeKnowledge()` is called,
//               the entry is added to the in-memory store AND persisted as a
//               MemoryItem (scope='knowledge-shared', key derived from title).
//               This is the REAL outbound store — the entry is now durable.
//
//   • INBOUND   (DB → daemon store): When `syncWithPeers()` is called, the
//               daemon pulls NEW entries from the DB (MemoryItem rows with
//               scope='knowledge-shared' whose titles are not yet in the
//               in-memory store) and loads them into ENTRIES. This is the
//               REAL inbound retrieval — entries that were contributed in a
//               previous session (before a restart) come back into the
//               daemon store on the next sync.
//
// PEER-TO-PEER NETWORK IS STILL CONCEPTUAL:
//   Real peer-to-peer knowledge sharing with external ARIA instances would
//   require a network protocol (gRPC, libp2p, WebSocket relay, signed
//   messages, conflict resolution). That is NOT implemented — by design.
//   The conceptual peer nodes always show status `offline` (except the
//   local node). The `nodesSucceeded` field is honestly 0 in this sandbox.
//
//   However, the local DB persistence + retrieval loop is now REAL —
//   `entriesSent[]` reflects the would-be fan-out to offline peers
//   (conceptual), while `entriesReceived[]` reflects ACTUAL DB rows pulled
//   into the daemon store (real). The `note` field on every SyncReport
//   makes the distinction explicit.
//
// FALLBACK BEHAVIOR:
//   All DB operations are wrapped in try/catch. If the DB is unavailable
//   (e.g., read-only sandbox), the daemon falls back to the in-memory store
//   (the pre-v10.3.0 behavior) and logs a warning. The sync still works —
//   it just doesn't persist or retrieve across restarts.
//
// Exports:
//   • KnowledgeNode, KnowledgeEntry, KnowledgeStats
//   • SyncReport, SyncSentEntry, SyncReceivedEntry, SyncConflict
//   • SyncHistoryEntry, KnowledgeFlow
//   • getKnowledgeNodes()                    → list of known nodes
//   • getKnowledgeEntries(limit)             → recent entries (newest first)
//   • contributeKnowledge(title, content, tags) → async, adds + persists + returns entry
//   • syncWithPeers()                        → async, detailed bidirectional sync report
//   • getSyncHistory(limit)                  → last N sync attempts (ring buffer, max 20)
//   • getKnowledgeFlow()                     → async, outbound/inbound pending counts + direction
//   • getKnowledgeStats()                    → aggregate counts

export type KnowledgeNodeType = 'local' | 'remote' | 'daemon';
export type KnowledgeNodeStatus = 'online' | 'offline' | 'syncing';
export type SyncStatus = 'success' | 'partial' | 'offline';

// DB-backed persistence layer — best-effort, never blocks the sync flow.
// All DB calls are wrapped in try/catch; failures fall back to the
// in-memory store (the pre-v10.3.0 behavior) with a logged warning.
import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

/** Scope used for MemoryItem rows that persist knowledge-daemon entries. */
const KNOWLEDGE_SHARED_SCOPE = 'knowledge-shared';

export interface KnowledgeNode {
  id: string;
  nodeType: KnowledgeNodeType;
  name: string;
  status: KnowledgeNodeStatus;
  lastSync: string; // ISO timestamp
  knowledgeCount: number;
  sharedEntries: number;
  endpoint?: string;
}

export interface KnowledgeEntry {
  id: string;
  title: string;
  content: string;
  source: string;
  tags: string[];
  confidence: number; // 0..1
  contributedBy: string; // node id or "you"
  createdAt: string; // ISO timestamp
  shared: boolean; // true once propagated to peers
}

export interface KnowledgeStats {
  totalNodes: number;
  onlineNodes: number;
  totalEntries: number;
  entriesShared: number;
  lastSyncAt: string | null;
}

/* ------------------------------------------------------------------ */
/* Bidirectional sync report types                                     */
/* ------------------------------------------------------------------ */

/** An entry that the local daemon would push OUT to a peer (main → peer). */
export interface SyncSentEntry {
  title: string;
  toNode: string; // destination node id
}

/** An entry that a peer would push BACK to us (peer → main). */
export interface SyncReceivedEntry {
  title: string;
  fromNode: string; // source node id
  tags: string[];
  confidence: number;
}

/** A duplicate-title conflict resolved by keeping the higher-confidence copy. */
export interface SyncConflict {
  title: string;
  kept: 'local' | 'remote';
  localConfidence: number;
  remoteConfidence: number;
}

/** Detailed bidirectional sync report. */
export interface SyncReport {
  ok: boolean;
  at: string; // ISO timestamp of sync completion
  startedAt: string; // ISO timestamp of sync start
  durationMs: number;
  nodesContacted: number; // attempted
  nodesSucceeded: number; // responded (deterministic — 0 in sandbox)
  entriesSent: SyncSentEntry[]; // outbound: main → peers (conceptual fan-out)
  entriesReceived: SyncReceivedEntry[]; // inbound: DB → daemon store (REAL retrieval)
  conflictsResolved: SyncConflict[];
  status: SyncStatus;
  note: string;
  /** Indicates whether the DB-backed persistence layer was used this round.
   *  'db' = real DB read succeeded; 'memory-only' = DB unavailable, fell back to in-memory. */
  persistenceLayer: 'db' | 'memory-only';
}

/** One entry in the sync history ring buffer. */
export interface SyncHistoryEntry {
  id: string;
  startedAt: string;
  completedAt: string;
  nodesContacted: number;
  entriesSent: number; // count (array length at sync time)
  entriesReceived: number; // count
  status: SyncStatus;
  note: string;
}

/** Bidirectional flow summary (used by the "Bidirectional Flow" panel). */
export interface KnowledgeFlow {
  outboundPending: number; // entries with shared=false, waiting to sync
  inboundAvailable: number; // remote entries not yet pulled into local store
  lastSync: string | null; // ISO timestamp or null
  flowDirection: 'bidirectional';
}

/* ------------------------------------------------------------------ */
/* Seed node roster                                                    */
/* ------------------------------------------------------------------ */

const SEED_NODES: KnowledgeNode[] = [
  {
    id: 'local-daemon',
    nodeType: 'local',
    name: 'Local Daemon (this machine)',
    status: 'online',
    lastSync: new Date().toISOString(),
    knowledgeCount: 5,
    sharedEntries: 0,
  },
  {
    id: 'open-jarvis-hub',
    nodeType: 'daemon',
    name: 'OpenJarvis Hub (concept)',
    status: 'offline',
    lastSync: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    knowledgeCount: 1240,
    sharedEntries: 312,
    endpoint: 'concept://open-jarvis.local-first',
  },
  {
    id: 'microsoft-taskmatrix',
    nodeType: 'daemon',
    name: 'Microsoft TaskMatrix (concept)',
    status: 'offline',
    lastSync: new Date(Date.now() - 1000 * 60 * 60 * 50).toISOString(),
    knowledgeCount: 8700,
    sharedEntries: 1240,
    endpoint: 'concept://taskmatrix/hugginggpt',
  },
  {
    id: 'peer-aurora-7',
    nodeType: 'remote',
    name: 'Peer: aurora-7',
    status: 'offline',
    lastSync: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    knowledgeCount: 184,
    sharedEntries: 42,
    endpoint: 'concept://peer/aurora-7',
  },
  {
    id: 'peer-nebula-3',
    nodeType: 'remote',
    name: 'Peer: nebula-3',
    status: 'offline',
    lastSync: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    knowledgeCount: 96,
    sharedEntries: 17,
    endpoint: 'concept://peer/nebula-3',
  },
];

/* ------------------------------------------------------------------ */
/* In-memory entry store                                               */
/* ------------------------------------------------------------------ */

const SEED_ENTRIES: KnowledgeEntry[] = [
  {
    id: 'kj-001',
    title: 'OpenJarvis runs AI locally on personal devices',
    content:
      'OpenJarvis is a framework for local-first personal AI. Personal AI agents route intelligence through cloud APIs by default; OpenJarvis flips this — intelligence runs on-device, calling the cloud only when truly necessary. The daemon exposes shared primitives for building on-device agents, evaluations that treat energy / FLOPs / latency / dollar cost as first-class constraints alongside accuracy, and a learning loop that improves models using local trace data.',
    source: 'open-jarvis/OpenJarvis README',
    tags: ['local-first', 'personal-ai', 'on-device', 'daemon'],
    confidence: 0.95,
    contributedBy: 'open-jarvis-hub',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    shared: true,
  },
  {
    id: 'kj-002',
    title: 'TaskMatrix connects LLMs to ML models via a 4-stage pipeline',
    content:
      'Microsoft JARVIS (HuggingGPT / TaskMatrix) is a collaborative system: an LLM acts as the controller and numerous expert models act as executors (hosted on HuggingFace Hub). The pipeline is: (1) Task Planning — ChatGPT analyzes user requests and decomposes them into solvable tasks; (2) Model Selection — ChatGPT picks expert models based on their descriptions; (3) Task Execution — each selected model is invoked and returns results; (4) Response Generation — ChatGPT integrates all predictions into a final response.',
    source: 'microsoft/JARVIS README + HuggingGPT paper (arXiv:2303.17580)',
    tags: ['orchestration', 'llm', 'ml-models', 'huggingface', 'multi-stage'],
    confidence: 0.97,
    contributedBy: 'microsoft-taskmatrix',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 50).toISOString(),
    shared: true,
  },
  {
    id: 'kj-003',
    title: 'Intelligence Per Watt: local models already cover 88.7% of chat+reasoning',
    content:
      'OpenJarvis\'s "Intelligence Per Watt" research measured that local language models already handle 88.7% of single-turn chat and reasoning queries, with intelligence efficiency improving 5.3× from 2023 to 2025. This is the empirical basis for the local-first thesis: the bottleneck is no longer the model — it is the software stack that makes local-first personal AI practical.',
    source: 'open-jarvis/OpenJarvis README (Intelligence Per Watt citation)',
    tags: ['benchmark', 'efficiency', 'local-models', 'research'],
    confidence: 0.9,
    contributedBy: 'open-jarvis-hub',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    shared: true,
  },
  {
    id: 'kj-004',
    title: 'Skills teach agents how to use tools — discovered from a catalog',
    content:
      'In OpenJarvis, every skill is itself a tool. Agents discover skills from a catalog and invoke them on demand. Skills can be installed from public sources, synced by category, optimized from local trace history (e.g. via DSPy policies), and benchmarked for impact. This blurs the line between "skill" and "tool" — they are the same primitive, just at different granularities.',
    source: 'open-jarvis/OpenJarvis README — Skills section',
    tags: ['skills', 'tools', 'catalog', 'agent-loop'],
    confidence: 0.88,
    contributedBy: 'open-jarvis-hub',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(),
    shared: true,
  },
  {
    id: 'kj-005',
    title: 'TaskBench + EasyTool: evaluating LLM task automation & concise tool instructions',
    content:
      'The microsoft/JARVIS group released two follow-ups: TaskBench (a benchmark for evaluating LLM task automation capability — datasets + code) and EasyTool (concise tool instructions that enhance LLM-based agents). Both reinforce the same thesis as HuggingGPT: the bottleneck for autonomous agents is not model quality alone, but the orchestration layer that selects + invokes the right expert model for each sub-task.',
    source: 'microsoft/JARVIS README — What\'s New',
    tags: ['benchmark', 'tools', 'orchestration', 'evals'],
    confidence: 0.85,
    contributedBy: 'microsoft-taskmatrix',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    shared: false,
  },
];

/* ------------------------------------------------------------------ */
/* Remote-available catalog (peers → main inbound candidates)          */
/*                                                                    */
/* These are entries that REMOTE peers hold and would share with us    */
/* (peers → main) if they were reachable. They are NOT in the local    */
/* store yet — `inboundAvailable` in the flow summary counts these.    */
/* During a sync round, `syncWithPeers()` projects a deterministic     */
/* subset of these as the would-be-received list.                     */
/* ------------------------------------------------------------------ */

interface RemoteAvailableEntry {
  title: string;
  fromNode: string; // node id that holds this entry
  tags: string[];
  confidence: number;
  source: string;
}

const REMOTE_AVAILABLE_ENTRIES: RemoteAvailableEntry[] = [
  {
    title: 'Edge inference: 4-bit quantization keeps 99% accuracy at 3.2× speedup',
    fromNode: 'open-jarvis-hub',
    tags: ['quantization', 'edge', 'inference', 'optimization'],
    confidence: 0.92,
    source: 'open-jarvis/OpenJarvis — benchmarks',
  },
  {
    title: 'libp2p gossipsub for peer discovery scales to 10k nodes',
    fromNode: 'open-jarvis-hub',
    tags: ['networking', 'p2p', 'gossipsub', 'discovery'],
    confidence: 0.86,
    source: 'open-jarvis/OpenJarvis — networking notes',
  },
  {
    title: 'HuggingFace Inference API timeout budget: 30s per expert model call',
    fromNode: 'microsoft-taskmatrix',
    tags: ['huggingface', 'inference', 'timeout', 'slo'],
    confidence: 0.9,
    source: 'microsoft/JARVIS — execution layer docs',
  },
  {
    title: 'Task graph caching reduces HuggingGPT latency by 41% on repeat queries',
    fromNode: 'microsoft-taskmatrix',
    tags: ['caching', 'latency', 'task-graph', 'optimization'],
    confidence: 0.88,
    source: 'microsoft/JARVIS — TaskBench paper',
  },
  {
    title: 'Aurora-7 fleet: 184 skills indexed across 12 categories',
    fromNode: 'peer-aurora-7',
    tags: ['fleet', 'skills', 'catalog', 'indexing'],
    confidence: 0.78,
    source: 'peer-aurora-7 shared manifest',
  },
  {
    title: 'Nebula-3 conflict policy: last-writer-wins with confidence tiebreak',
    fromNode: 'peer-nebula-3',
    tags: ['conflict', 'consistency', 'policy'],
    confidence: 0.74,
    source: 'peer-nebula-3 governance doc',
  },
  {
    title: 'DSPy policy optimization converges in ~200 trace examples',
    fromNode: 'open-jarvis-hub',
    tags: ['dspy', 'policy', 'optimization', 'few-shot'],
    confidence: 0.83,
    source: 'open-jarvis/OpenJarvis — skills optimization',
  },
  {
    title: 'Model router fallback chain: primary → quantized → distill → cache',
    fromNode: 'microsoft-taskmatrix',
    tags: ['router', 'fallback', 'resilience', 'models'],
    confidence: 0.87,
    source: 'microsoft/JARVIS — Model Selection docs',
  },
];

// In-memory store (mutable). Seeded once on first module import.
const NODES: KnowledgeNode[] = SEED_NODES.map((n) => ({ ...n }));
const ENTRIES: KnowledgeEntry[] = SEED_ENTRIES.map((e) => ({ ...e }));

// Titles of remote entries that have already been pulled into the local
// store. Seeded with the titles already present in SEED_ENTRIES (so the
// initial `inboundAvailable` count reflects only the REMOTE_AVAILABLE
// entries that are NOT yet in the local store).
const PULLED_TITLES: Set<string> = new Set(
  SEED_ENTRIES.map((e) => e.title),
);

let lastSyncAt: string | null = null;
let entryCounter = SEED_ENTRIES.length + 1;

/* ------------------------------------------------------------------ */
/* Sync history ring buffer                                            */
/* ------------------------------------------------------------------ */

const MAX_HISTORY = 20;
const SYNC_HISTORY: SyncHistoryEntry[] = [];
let historyCounter = 1;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function newId(): string {
  const id = `kj-${String(entryCounter).padStart(3, '0')}`;
  entryCounter += 1;
  return id;
}

function newHistoryId(): string {
  const id = `sync-${String(historyCounter).padStart(4, '0')}`;
  historyCounter += 1;
  return id;
}

/** Deterministic hash (FNV-1a-ish) of a string → uint32. No Math.random. */
function hashString(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/* ------------------------------------------------------------------ */
/* DB persistence layer (best-effort, try/catch-wrapped)               */
/*                                                                    */
/* All DB calls are wrapped so a read-only or unavailable DB never     */
/* breaks the in-memory sync flow. Failures fall back to the prior     */
/* behavior (in-memory only) and log a warning.                        */
/* ------------------------------------------------------------------ */

/** Slugify an entry title into a stable DB key (max 60 chars). */
function dbKeyForTitle(title: string): string {
  const slug = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return `kd-${slug || 'untitled'}`;
}

/** Serialize a KnowledgeEntry into the JSON `value` field of a MemoryItem. */
function serializeEntry(entry: KnowledgeEntry): string {
  return JSON.stringify({
    id: entry.id,
    title: entry.title,
    content: entry.content,
    source: entry.source,
    tags: entry.tags,
    confidence: entry.confidence,
    contributedBy: entry.contributedBy,
    createdAt: entry.createdAt,
    shared: entry.shared,
  });
}

/** Parse a MemoryItem row back into a KnowledgeEntry (or null on bad shape). */
function parseEntryFromDB(row: {
  key: string;
  value: string;
  tags: string;
  createdAt: Date;
  updatedAt: Date;
}): KnowledgeEntry | null {
  try {
    const parsed = JSON.parse(row.value) as Partial<KnowledgeEntry>;
    if (
      typeof parsed.title !== 'string' ||
      typeof parsed.content !== 'string'
    ) {
      return null;
    }
    return {
      id: typeof parsed.id === 'string' ? parsed.id : `db-${row.key}`,
      title: parsed.title,
      content: parsed.content,
      source: typeof parsed.source === 'string' ? parsed.source : 'db-persistence',
      tags: Array.isArray(parsed.tags) ? parsed.tags : [],
      confidence:
        typeof parsed.confidence === 'number' ? parsed.confidence : 0.7,
      contributedBy:
        typeof parsed.contributedBy === 'string'
          ? parsed.contributedBy
          : 'local-db',
      createdAt:
        typeof parsed.createdAt === 'string'
          ? parsed.createdAt
          : row.createdAt.toISOString(),
      shared: typeof parsed.shared === 'boolean' ? parsed.shared : true,
    };
  } catch {
    return null;
  }
}

/**
 * Persist a KnowledgeEntry to the DB as a MemoryItem (scope='knowledge-shared').
 * Best-effort: returns true on success, false on failure (and logs a warning).
 * Idempotent: upsert on key (derived from title).
 */
async function persistEntryToDB(entry: KnowledgeEntry): Promise<boolean> {
  try {
    const key = dbKeyForTitle(entry.title);
    const value = serializeEntry(entry);
    const tags = JSON.stringify([
      'knowledge-daemon',
      'knowledge-shared',
      ...entry.tags,
    ]);
    await db.memoryItem.upsert({
      where: { key_scope: { key, scope: KNOWLEDGE_SHARED_SCOPE } },
      update: { value, tags },
      create: {
        scope: KNOWLEDGE_SHARED_SCOPE,
        key,
        value,
        tags,
        pinned: false,
      },
    });
    return true;
  } catch (err) {
    logger.warn(
      {
        err: err instanceof Error ? err.message : String(err),
        title: entry.title,
      },
      'knowledge-daemon: persistEntryToDB failed — falling back to in-memory only',
    );
    return false;
  }
}

/**
 * Pull NEW entries from the DB (MemoryItem rows with scope='knowledge-shared'
 * whose titles are not yet in `PULLED_TITLES`). Best-effort: returns an empty
 * array on failure (and logs a warning).
 *
 * Each pulled entry's title is added to PULLED_TITLES so subsequent syncs
 * don't re-pull it. If the title is NOT already in ENTRIES, the entry is
 * also added to the in-memory store (so the UI shows it). If the title IS
 * already in ENTRIES (e.g. the entry was just contributed in this same
 * session), we DON'T duplicate it in ENTRIES — but we still report it in
 * `pulled` so the bidirectional flow (contribute → DB → sync → store) is
 * visible to the operator.
 *
 * Returns the list of entries actually pulled (reported as inbound).
 */
async function pullNewEntriesFromDB(): Promise<{
  pulled: KnowledgeEntry[];
  usedDB: boolean;
}> {
  try {
    const rows = await db.memoryItem.findMany({
      where: { scope: KNOWLEDGE_SHARED_SCOPE },
      orderBy: { createdAt: 'asc' },
    });

    const pulled: KnowledgeEntry[] = [];
    const existingTitles = new Set(ENTRIES.map((e) => e.title));

    for (const row of rows) {
      const entry = parseEntryFromDB(row);
      if (!entry) continue;
      if (PULLED_TITLES.has(entry.title)) continue; // already pulled
      // Mark as pulled so we don't re-attempt the same row on every sync.
      PULLED_TITLES.add(entry.title);
      // If the title isn't already in the in-memory store, add it (so the
      // UI shows it). If it IS already there (just contributed this session),
      // skip the push to avoid duplicates — but still report it as pulled.
      if (!existingTitles.has(entry.title)) {
        ENTRIES.push(entry);
        const localNode = NODES.find((n) => n.id === 'local-daemon');
        if (localNode) localNode.knowledgeCount += 1;
      }
      pulled.push(entry);
    }
    return { pulled, usedDB: true };
  } catch (err) {
    logger.warn(
      {
        err: err instanceof Error ? err.message : String(err),
      },
      'knowledge-daemon: pullNewEntriesFromDB failed — falling back to in-memory only',
    );
    return { pulled: [], usedDB: false };
  }
}

/**
 * Count DB entries with scope='knowledge-shared' whose titles are not yet in
 * `PULLED_TITLES`. Best-effort: returns null on failure (caller falls back
 * to the conceptual REMOTE_AVAILABLE_ENTRIES count).
 */
async function countDBEntriesNotInStore(): Promise<number | null> {
  try {
    const rows = await db.memoryItem.findMany({
      where: { scope: KNOWLEDGE_SHARED_SCOPE },
      select: { value: true },
    });
    let count = 0;
    for (const row of rows) {
      const entry = parseEntryFromDB({
        key: '',
        value: row.value,
        tags: '',
        createdAt: new Date(0),
        updatedAt: new Date(0),
      });
      if (entry && !PULLED_TITLES.has(entry.title)) {
        count += 1;
      }
    }
    return count;
  } catch (err) {
    logger.warn(
      {
        err: err instanceof Error ? err.message : String(err),
      },
      'knowledge-daemon: countDBEntriesNotInStore failed — falling back to conceptual count',
    );
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

export function getKnowledgeNodes(): KnowledgeNode[] {
  // Return a defensive copy so callers cannot mutate the internal store.
  return NODES.map((n) => ({ ...n }));
}

export function getKnowledgeEntries(limit = 50): KnowledgeEntry[] {
  const cap = Math.max(1, Math.min(200, Math.floor(limit)));
  // Deduplicate by title (keep newest), then by id (fallback) to prevent
  // React key collisions when the same entry appears from multiple sources.
  const seen = new Set<string>();
  const seenId = new Set<string>();
  return ENTRIES.slice()
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
    .filter((e) => {
      if (seen.has(e.title) || seenId.has(e.id)) return false;
      seen.add(e.title);
      seenId.add(e.id);
      return true;
    })
    .slice(0, cap)
    .map((e) => ({ ...e }));
}

export async function contributeKnowledge(
  title: string,
  content: string,
  tags: string[] = [],
): Promise<KnowledgeEntry> {
  const entry: KnowledgeEntry = {
    id: newId(),
    title: title.trim() || 'Untitled contribution',
    content: content.trim(),
    source: 'local-contributor',
    tags: Array.from(new Set(tags.map((t) => t.trim()).filter(Boolean))),
    confidence: 0.7, // user-contributed entries start at 0.7 (peer review can raise)
    contributedBy: 'you',
    createdAt: new Date().toISOString(),
    shared: false, // will be flipped to true after a successful syncWithPeers()
  };
  ENTRIES.push(entry);
  const localNode = NODES.find((n) => n.id === 'local-daemon');
  if (localNode) localNode.knowledgeCount += 1;

  // REAL OUTBOUND: persist to DB so the entry survives across server restarts.
  // Best-effort — failure falls back to in-memory only (logged via logger.warn).
  // We DO NOT add the title to PULLED_TITLES here, so the next syncWithPeers()
  // round will pull it back from the DB as a REAL inbound entry (demonstrating
  // the bidirectional loop: contribute → DB → sync → daemon store).
  await persistEntryToDB(entry);

  return { ...entry };
}

/**
 * Bidirectional sync round. The DB-backed persistence layer makes the
 * INBOUND direction REAL (DB → daemon store); the OUTBOUND direction
 * remains a conceptual fan-out (the peer nodes are still offline in this
 * sandbox — real peer-to-peer network requires a protocol, see file header).
 *
 * BIDIRECTIONAL FLOW (v10.3.0+):
 *   • OUTBOUND (main → peers): locally-contributed unshared entries are
 *     queued for propagation. Each one is reported in `entriesSent[]` with
 *     its destination node id. The fan-out is conceptual (peers offline),
 *     but the entry was ALREADY persisted to DB by `contributeKnowledge()`.
 *   • INBOUND  (DB → daemon store): NEW entries are pulled from the DB
 *     (MemoryItem rows with scope='knowledge-shared' not yet in the
 *     in-memory store). Each pulled entry is added to ENTRIES and reported
 *     in `entriesReceived[]` with `fromNode: 'local-db'`. This is the REAL
 *     inbound retrieval — entries that were contributed in a previous
 *     session come back into the daemon store on the next sync.
 *
 * HONESTY: every conceptual peer node is offline in this sandbox, so
 * `nodesSucceeded` is honestly 0 (this counts ONLY the conceptual peer
 * reachability — it does NOT count the DB retrieval, which always
 * succeeds when the DB is available). A clear `note` field distinguishes
 * the real DB inbound count from the conceptual peer fan-out. No
 * Math.random anywhere.
 *
 * CONFLICTS: if an outbound title collides with an inbound DB title, the
 * higher-confidence copy is kept (recorded in `conflictsResolved[]`).
 *
 * SIDE EFFECTS:
 *   • Flips `shared: true` on all locally-contributed unshared entries
 *     (they are considered "queued for propagation" after a sync round).
 *   • Pulls new entries from DB into ENTRIES (real inbound).
 *   • Bumps `sharedEntries` on the local node.
 *   • Updates `lastSync` on the local node.
 *   • Appends an entry to the sync history ring buffer.
 */
export async function syncWithPeers(): Promise<SyncReport> {
  const startedAtIso = new Date().toISOString();
  const startedAtMs = Date.now();
  const localNode = NODES.find((n) => n.id === 'local-daemon');

  if (localNode) localNode.status = 'syncing';

  // Contact all remote/daemon nodes (we attempt them all, every round).
  const remoteNodes = NODES.filter(
    (n) => n.nodeType !== 'local' && n.status === 'offline',
  );
  const nodesContacted = remoteNodes.length;

  // HONESTY: in this sandbox every remote node is offline, so none respond.
  // This is deterministic (no Math.random) — it is ALWAYS 0 here.
  // If a future deployment marks a remote node 'online' in the roster,
  // the formula below will deterministically include it.
  const nodesSucceeded = remoteNodes.filter(
    (n) => n.status === 'online',
  ).length;

  // ── OUTBOUND (main → peers, conceptual fan-out) ──────────────────────
  // Locally-contributed unshared entries get propagated this round. We fan
  // each one out to every peer (so entriesSent length = pending × peers),
  // but cap the array at a reasonable size for the UI.
  //
  // Note: the entry was ALREADY persisted to DB by `contributeKnowledge()`
  // — so this fan-out is the conceptual "tell each peer about it" step.
  // The REAL outbound persistence already happened at contribute time.
  const pendingSend = ENTRIES.filter((e) => !e.shared);
  const entriesSent: SyncSentEntry[] = [];
  pendingSend.forEach((entry) => {
    remoteNodes.forEach((peer) => {
      entriesSent.push({ title: entry.title, toNode: peer.id });
    });
  });
  // Flip shared flag (conceptually queued for propagation).
  pendingSend.forEach((e) => {
    e.shared = true;
  });

  // ── INBOUND (DB → daemon store, REAL retrieval) ──────────────────────
  // Pull NEW entries from the DB. This is the real inbound direction —
  // entries persisted by contributeKnowledge() in a prior session (or this
  // one) come back into the daemon store. Falls back to a deterministic
  // REMOTE_AVAILABLE_ENTRIES projection if the DB is unavailable.
  const { pulled: pulledFromDB, usedDB } = await pullNewEntriesFromDB();
  const entriesReceived: SyncReceivedEntry[] = pulledFromDB.map((entry) => ({
    title: entry.title,
    fromNode: 'local-db',
    tags: entry.tags.slice(),
    confidence: entry.confidence,
  }));

  // Fallback: if DB unavailable, project a deterministic subset of
  // REMOTE_AVAILABLE_ENTRIES that we have NOT yet pulled. Selection:
  // hash the entry title + the current round count, keep entries whose
  // hash mod 3 === 0 (≈ one third per round), bounded to 5 per round.
  if (!usedDB) {
    const inboundCandidates = REMOTE_AVAILABLE_ENTRIES.filter(
      (re) => !PULLED_TITLES.has(re.title),
    );
    const roundSeed = String(SYNC_HISTORY.length + 1);
    for (const re of inboundCandidates) {
      const h = hashString(`${re.title}|${roundSeed}`);
      if (h % 3 === 0 && entriesReceived.length < 5) {
        entriesReceived.push({
          title: re.title,
          fromNode: re.fromNode,
          tags: re.tags.slice(),
          confidence: re.confidence,
        });
      }
    }
  }

  // ── CONFLICTS ─────────────────────────────────────────────────────────
  // If an outbound title matches an inbound DB title, keep the higher-
  // confidence copy. We still REPORT the conflict so the UI can surface it.
  const conflictsResolved: SyncConflict[] = [];
  const inboundByTitle = new Map(
    entriesReceived.map((r) => [r.title, r]),
  );
  pendingSend.forEach((localEntry) => {
    const remote = inboundByTitle.get(localEntry.title);
    if (remote) {
      const kept: 'local' | 'remote' =
        localEntry.confidence >= remote.confidence ? 'local' : 'remote';
      conflictsResolved.push({
        title: localEntry.title,
        kept,
        localConfidence: localEntry.confidence,
        remoteConfidence: remote.confidence,
      });
    }
  });

  // ── Finalize local node + stats ───────────────────────────────────────
  const completedAtIso = new Date().toISOString();
  if (localNode) {
    localNode.status = 'online';
    localNode.lastSync = completedAtIso;
    localNode.sharedEntries += pendingSend.length;
    if (usedDB) {
      // Pulled entries were already added to the store by pullNewEntriesFromDB;
      // bump sharedEntries count for them too (they're now part of the local store).
      localNode.sharedEntries += pulledFromDB.length;
    }
  }
  lastSyncAt = completedAtIso;

  const status: SyncStatus =
    nodesSucceeded === 0
      ? 'offline'
      : nodesSucceeded < nodesContacted
        ? 'partial'
        : 'success';

  const persistenceLayer: 'db' | 'memory-only' = usedDB ? 'db' : 'memory-only';

  const note = usedDB
    ? `Sync round complete. Conceptual peers: 0/${nodesContacted} reachable ` +
      `(peer-to-peer network requires a protocol — see file header). ` +
      `DB-backed inbound: ${entriesReceived.length} entr${entriesReceived.length === 1 ? 'y' : 'ies'} ` +
      `RETRIEVED from local persistence (MemoryItem scope='knowledge-shared') ` +
      `and loaded into the daemon store. ` +
      `Outbound entriesSent (${entriesSent.length}) reflects the would-be ` +
      `fan-out to offline peers — the entries were already persisted to DB ` +
      `at contribute time.`
    : `Conceptual sync: all ${nodesContacted} peer nodes are offline AND ` +
      `the DB persistence layer is unavailable (read-only sandbox or DB ` +
      `error). Reported entriesSent (${entriesSent.length}) and ` +
      `entriesReceived (${entriesReceived.length}) show WHAT WOULD BE ` +
      `shared if peers were reachable — no real network calls were made. ` +
      `Falling back to in-memory only; entries will NOT persist across restarts.`;

  const report: SyncReport = {
    ok: true,
    at: completedAtIso,
    startedAt: startedAtIso,
    durationMs: Date.now() - startedAtMs,
    nodesContacted,
    nodesSucceeded,
    entriesSent,
    entriesReceived,
    conflictsResolved,
    status,
    note,
    persistenceLayer,
  };

  // ── Append to history ring buffer ─────────────────────────────────────
  const historyEntry: SyncHistoryEntry = {
    id: newHistoryId(),
    startedAt: startedAtIso,
    completedAt: completedAtIso,
    nodesContacted,
    entriesSent: entriesSent.length,
    entriesReceived: entriesReceived.length,
    status,
    note,
  };
  SYNC_HISTORY.push(historyEntry);
  if (SYNC_HISTORY.length > MAX_HISTORY) {
    SYNC_HISTORY.splice(0, SYNC_HISTORY.length - MAX_HISTORY);
  }

  return report;
}

/**
 * Returns the most recent sync attempts (ring buffer, max 20 entries).
 * Newest first.
 */
export function getSyncHistory(limit = 20): SyncHistoryEntry[] {
  const cap = Math.max(1, Math.min(MAX_HISTORY, Math.floor(limit)));
  return SYNC_HISTORY.slice()
    .reverse()
    .slice(0, cap)
    .map((e) => ({ ...e }));
}

/**
 * Returns a summary of the bidirectional knowledge flow:
 *   • outboundPending  — entries with shared=false, waiting to be sent.
 *   • inboundAvailable — entries persisted to DB but not yet pulled into
 *                        the in-memory store. REAL count when DB is
 *                        available; falls back to the conceptual
 *                        REMOTE_AVAILABLE_ENTRIES count on DB failure.
 *   • lastSync         — ISO timestamp of the last sync, or null.
 *   • flowDirection    — always 'bidirectional'.
 */
export async function getKnowledgeFlow(): Promise<KnowledgeFlow> {
  const outboundPending = ENTRIES.filter((e) => !e.shared).length;
  const dbCount = await countDBEntriesNotInStore();
  const inboundAvailable =
    dbCount ??
    REMOTE_AVAILABLE_ENTRIES.filter((re) => !PULLED_TITLES.has(re.title)).length;
  return {
    outboundPending,
    inboundAvailable,
    lastSync: lastSyncAt,
    flowDirection: 'bidirectional',
  };
}

export function getKnowledgeStats(): KnowledgeStats {
  const totalNodes = NODES.length;
  const onlineNodes = NODES.filter((n) => n.status === 'online').length;
  const totalEntries = ENTRIES.length;
  const entriesShared = ENTRIES.filter((e) => e.shared).length;
  return {
    totalNodes,
    onlineNodes,
    totalEntries,
    entriesShared,
    lastSyncAt: lastSyncAt,
  };
}
