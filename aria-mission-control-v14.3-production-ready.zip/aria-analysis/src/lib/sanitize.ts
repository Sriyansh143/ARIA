// =====================================================================
// sanitize.ts — Centralized input validation + sanitization utilities
// =====================================================================
// HARDENING (v11.2): Provides reusable validators that every API route
// should use to prevent injection, prototype pollution, oversized
// payloads, and invalid enum values.
// =====================================================================

/** Allowed enum sets for common fields. */
export const ENUMS = {
  taskPriority: new Set(['low', 'medium', 'high', 'critical']),
  taskStatus: new Set(['pending', 'in_progress', 'completed', 'failed', 'cancelled', 'blocked']),
  paymentMethod: new Set(['upi', 'card', 'netbanking', 'qr', 'wallet']),
  paymentStatus: new Set(['pending', 'confirmed', 'failed', 'refunded']),
  agentStatus: new Set(['idle', 'thinking', 'working', 'error', 'offline']),
  approvalStatus: new Set(['pending', 'approved', 'rejected', 'expired']),
  logLevel: new Set(['info', 'warn', 'error', 'debug', 'success']),
} as const;

/**
 * Validate that a value is a string and within the max length.
 * Returns the trimmed string or null if invalid.
 */
export function sanitizeString(value: unknown, maxLength = 1000): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (trimmed.length === 0) return null;
  return trimmed.slice(0, maxLength);
}

/**
 * Validate that a value is a member of an allowed enum set.
 * Returns the value if valid, or the default if not.
 */
export function sanitizeEnum<T extends string>(value: unknown, allowed: Set<T>, defaultValue: T): T {
  return typeof value === 'string' && allowed.has(value as T) ? (value as T) : defaultValue;
}

/**
 * Validate that a value is a finite positive number within a range.
 * Returns null if invalid.
 */
export function sanitizeNumber(value: unknown, opts?: { min?: number; max?: number; allowZero?: boolean }): number | null {
  if (typeof value !== 'number' || !isFinite(value)) return null;
  const min = opts?.min ?? (opts?.allowZero ? 0 : 0.01);
  const max = opts?.max ?? Number.MAX_SAFE_INTEGER;
  if (value < min) return null;
  if (value > max) return null;
  if (!opts?.allowZero && value === 0) return null;
  return value;
}

/**
 * Validate that a value is an array of strings, capped at maxItems.
 * Filters out non-string entries.
 */
export function sanitizeStringArray(value: unknown, maxItems = 20): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is string => typeof item === 'string' && item.length > 0).slice(0, maxItems);
}

/**
 * Validate an email address format. Returns the trimmed email or null.
 */
export function sanitizeEmail(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim().toLowerCase();
  // Simple but effective: something@something.something
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) return null;
  if (trimmed.length > 254) return null;
  return trimmed;
}

/**
 * Validate a URL format. Returns the URL or null.
 */
export function sanitizeUrl(value: unknown, allowedProtocols: string[] = ['http:', 'https:']): string | null {
  if (typeof value !== 'string') return null;
  try {
    const url = new URL(value);
    if (!allowedProtocols.includes(url.protocol)) return null;
    return url.toString();
  } catch {
    return null;
  }
}

/**
 * Validate a phone number (digits, +, -, spaces, parentheses only).
 */
export function sanitizePhone(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!/^[+]?[\d\s\-()]{7,20}$/.test(trimmed)) return null;
  return trimmed;
}

/**
 * Reject prototype pollution keys (__proto__, constructor, prototype).
 * Returns a clean object with dangerous keys removed.
 */
export function stripDangerousKeys<T extends Record<string, unknown>>(obj: T): Partial<T> {
  const dangerous = new Set(['__proto__', 'constructor', 'prototype']);
  const clean: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (!dangerous.has(key)) {
      clean[key] = value;
    }
  }
  return clean as Partial<T>;
}

/**
 * Rate limiter — simple in-memory sliding-window limiter.
 * Returns true if the request is allowed, false if rate-limited.
 */
const _rateBuckets = new Map<string, number[]>();
export function rateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  const now = Date.now();
  const bucket = _rateBuckets.get(key) ?? [];
  // Prune entries outside the window.
  const valid = bucket.filter((ts) => now - ts < windowMs);
  if (valid.length >= maxRequests) {
    _rateBuckets.set(key, valid);
    return false;
  }
  valid.push(now);
  _rateBuckets.set(key, valid);
  return true;
}
