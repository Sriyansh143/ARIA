// =====================================================================
// verification.ts — No-Assumption Rule enforcement
// =====================================================================
// Every claim, research result, analysis, plan, or forecast produced by
// an agent is logged here with evidence. Claims can be questioned and
// improved. No claim is "trusted" until verified + confidence ≥ 50.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { quickChat, extractJson } from '@/lib/llm';

export type ClaimType = 'research' | 'analysis' | 'plan' | 'fact' | 'forecast' | 'recommendation';
export type VerificationStatus = 'unverified' | 'verified' | 'disputed' | 'partial' | 'false';

export interface VerificationInput {
  claimType: ClaimType;
  claimText: string;
  claimSource?: string;
  evidence?: Array<{ type: string; url?: string; quote?: string }>;
  linkedTaskId?: string;
}

const MIN_CONFIDENCE = 50;

export async function logClaim(input: VerificationInput): Promise<string> {
  try {
    const row = await db.verificationRecord.create({
      data: {
        claimType: input.claimType,
        claimText: input.claimText.slice(0, 5000),
        claimSource: input.claimSource ?? null,
        evidence: JSON.stringify(input.evidence ?? []),
        verificationStatus: 'unverified',
        confidenceScore: 0,
      },
    });
    return row.id;
  } catch (err) {
    logger.error({ err }, 'verification: logClaim failed');
    return '';
  }
}

export async function verifyWithLLM(
  claimText: string,
  evidence: VerificationInput['evidence'] = [],
): Promise<{ status: VerificationStatus; confidence: number; note: string }> {
  const system = `You are a strict fact-checker. VERIFY or REFUTE the claim — NEVER accept it on faith. Output JSON: {"status":"verified|partial|disputed|false","confidence":0-100,"note":"one sentence why"}`;
  const evidenceBlock = evidence?.length
    ? evidence.map((e, i) => `  ${i + 1}. [${e.type}]${e.url ? ` ${e.url}` : ''}${e.quote ? ` — "${e.quote.slice(0, 200)}"` : ''}`).join('\n')
    : '  (no evidence provided)';
  const user = `Claim: "${claimText}"\n\nEvidence:\n${evidenceBlock}\n\nVerify this claim. Do NOT assume it is true.`;
  try {
    const raw = await quickChat(user.slice(0, 3000), system);
    const parsed = extractJson<{ status?: string; confidence?: number; note?: string }>(raw);
    if (parsed) {
      const status = (['verified', 'partial', 'disputed', 'false'].includes(parsed.status ?? '')
        ? parsed.status
        : 'unverified') as VerificationStatus;
      const confidence = typeof parsed.confidence === 'number' ? Math.max(0, Math.min(100, parsed.confidence)) : 0;
      return { status, confidence, note: (parsed.note ?? 'No justification').slice(0, 500) };
    }
    return { status: 'unverified', confidence: 0, note: 'LLM response could not be parsed' };
  } catch (err) {
    return { status: 'unverified', confidence: 0, note: `Verification failed: ${err instanceof Error ? err.message : 'error'}` };
  }
}

export async function verifyClaim(
  input: VerificationInput,
  opts: { crossCheck?: boolean } = {},
): Promise<{ id: string; status: VerificationStatus; confidenceScore: number; verifierNote: string }> {
  const id = await logClaim(input);
  if (!id) return { id: '', status: 'unverified', confidenceScore: 0, verifierNote: 'Failed to log claim' };

  let status: VerificationStatus = 'unverified';
  let confidence = 0;
  let note = 'Not yet verified';

  if (opts.crossCheck !== false) {
    const result = await verifyWithLLM(input.claimText, input.evidence);
    status = result.status;
    confidence = result.confidence;
    note = result.note;
  }

  try {
    await db.verificationRecord.update({
      where: { id },
      data: {
        verificationStatus: status,
        confidenceScore: confidence,
        verifierMethod: 'llm-cross-check',
        verifierNote: note,
      },
    });
  } catch { /* best-effort */ }

  return { id, status, confidenceScore: confidence, verifierNote: note };
}

export async function questionClaim(
  id: string,
  questionNote: string,
  improvedVersion?: string,
): Promise<{ ok: boolean }> {
  try {
    await db.verificationRecord.update({
      where: { id },
      data: {
        questioned: true,
        questionNote: questionNote.slice(0, 2000),
        improvedVersion: improvedVersion?.slice(0, 5000),
        verificationStatus: 'disputed',
      },
    });
    return { ok: true };
  } catch {
    return { ok: false };
  }
}

export async function isClaimTrusted(id: string): Promise<boolean> {
  if (!id) return false;
  try {
    const row = await db.verificationRecord.findUnique({ where: { id } });
    if (!row) return false;
    if (!['verified', 'partial'].includes(row.verificationStatus)) return false;
    if (row.confidenceScore < MIN_CONFIDENCE) return false;
    if (row.questioned && !row.improvedVersion) return false;
    return true;
  } catch {
    return false;
  }
}

export async function listVerifications(filter: {
  claimType?: string;
  status?: string;
  questioned?: boolean;
  limit?: number;
} = {}): Promise<{ records: unknown[]; total: number }> {
  const where: Record<string, unknown> = {};
  if (filter.claimType) where.claimType = filter.claimType;
  if (filter.status) where.verificationStatus = filter.status;
  if (filter.questioned !== undefined) where.questioned = filter.questioned;
  const limit = filter.limit ?? 50;
  const [records, total] = await Promise.all([
    db.verificationRecord.findMany({ where, orderBy: { createdAt: 'desc' }, take: limit }),
    db.verificationRecord.count({ where }),
  ]);
  return { records, total };
}

export async function getVerificationStats(): Promise<{
  total: number;
  byStatus: Record<string, number>;
  questioned: number;
  avgConfidence: number;
  trustedCount: number;
}> {
  const [total, byStatusRows, questioned, avgAgg, trustedCount] = await Promise.all([
    db.verificationRecord.count(),
    db.verificationRecord.groupBy({ by: ['verificationStatus'], _count: true }),
    db.verificationRecord.count({ where: { questioned: true } }),
    db.verificationRecord.aggregate({ _avg: { confidenceScore: true } }),
    db.verificationRecord.count({
      where: { verificationStatus: { in: ['verified', 'partial'] }, confidenceScore: { gte: MIN_CONFIDENCE } },
    }),
  ]);
  const byStatus: Record<string, number> = {};
  for (const r of byStatusRows) byStatus[r.verificationStatus] = r._count;
  return { total, byStatus, questioned, avgConfidence: Math.round(avgAgg._avg.confidenceScore ?? 0), trustedCount };
}
