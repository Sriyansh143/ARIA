// agent-loop.ts — JARVIS agent loop.
//
// A thin wrapper around the LLM `chat()` call that optionally routes the
// prompt through one of the claude-skills reasoning patterns (CoT, ReAct,
// Tree-of-Thoughts, etc.) when `reasoningMode` is set.
//
// Wire-in (Task ID 7): the original behaviour (plain chat) is the default
// and is preserved exactly. The `reasoningMode` parameter is OPTIONAL and
// only takes effect when explicitly passed. The claude-skills module is
// imported dynamically to avoid circular dependencies with /api routes.
// If a skill invocation throws, we fall back to a plain `chat()` call so
// the loop never breaks.
//
// Wire-in (Task ID 2-a): when `agentCodename` is set, the loop fetches the
// agent's persona (name/role/skills/model) + 5 most recent episodic
// memories and prepends them to the system prompt. Best-effort — DB
// failure falls back to the base system prompt. This makes the LLM "be"
// the named agent instead of generic JARVIS.

import { chat, type ChatTurn, JARVIS_SYSTEM_PROMPT } from '@/lib/llm'

export type ReasoningMode =
  | 'chain-of-thought'
  | 'constitutional-ai'
  | 'react-pattern'
  | 'tree-of-thoughts'
  | 'step-back-prompting'
  | 'few-shot-learning'
  | 'self-reflection'
  | 'pipeline'
  | null

export interface AgentLoopOptions {
  /** When set, wraps the prompt with the matching claude-skill. */
  reasoningMode?: ReasoningMode
  /** Optional system prompt override. */
  systemPrompt?: string
  /** Optional conversation history. */
  history?: ChatTurn[]
  /** Optional context block passed to skills that accept one (CoT, pipeline). */
  context?: string
  /**
   * When set, fetch the agent's persona (name/role/skills/model) + recent
   * episodic memories from the DB and prepend to the system prompt. The LLM
   * then "becomes" this named agent for the turn. Best-effort — on any DB
   * failure we fall back to the base JARVIS_SYSTEM_PROMPT.
   */
  agentCodename?: string
}

export interface AgentLoopResult {
  content: string
  latencyMs: number
  reasoningMode: ReasoningMode
  reasoningUsed: boolean
  reasoningError?: string
}

/**
 * Fetch an agent's persona (name/role/skills/model) + 5 most recent episodic
 * memories and build a system-prompt prefix that makes the LLM "be" this
 * agent. Returns '' on any failure so the caller can fall back gracefully.
 *
 * Imported dynamically so the chat wrapper stays decoupled from Prisma in
 * case future callers (e.g. browser-side tooling) don't have the DB.
 */
async function buildAgentPersonaPrefix(codename: string): Promise<string> {
  try {
    const { db } = await import('@/lib/db')
    const agent = await db.agent.findUnique({
      where: { codename },
      select: { name: true, codename: true, role: true, skills: true, model: true },
    })
    if (!agent) return ''

    let skills: string[] = []
    try {
      const parsed = JSON.parse(agent.skills || '[]')
      if (Array.isArray(parsed)) skills = parsed.filter((s): s is string => typeof s === 'string')
    } catch {
      /* leave skills empty */
    }

    // Pull the 5 most recent episodic memories so the agent has short-term
    // context for the turn. Cheap query + bounded result set.
    const memories = await db.memoryItem.findMany({
      where: { scope: 'episodic' },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { key: true, value: true, createdAt: true },
    })

    const memoryBlock =
      memories.length > 0
        ? memories
            .map(
              (m, i) =>
                `  ${i + 1}. [${m.key}] ${String(m.value).slice(0, 200)}`,
            )
            .join('\n')
        : '  (no recent episodic memories)'

    return (
      `You are now operating as the agent "${agent.name}" (codename: ${agent.codename}).\n` +
      `Role: ${agent.role}\n` +
      `Model: ${agent.model}\n` +
      `Skills: ${skills.length > 0 ? skills.join(', ') : '(none configured)'}\n\n` +
      `Recent episodic memories (most recent first):\n${memoryBlock}\n\n` +
      `Stay in character as ${agent.name}. Use your role + skills to guide your response. ` +
      `Reference your memories when relevant. Be concise.\n\n---\n\n`
    )
  } catch {
    return ''
  }
}

/**
 * Run a single agent loop step. Default behaviour: plain `chat()` call,
 * identical to calling `chat()` directly. When `opts.reasoningMode` is set,
 * the matching claude-skill is invoked via dynamic import; on failure, we
 * transparently fall back to `chat()` so callers always get an answer.
 *
 * When `opts.agentCodename` is set, the system prompt is prefixed with the
 * agent's persona + recent episodic memories (best-effort).
 */
export async function runAgentLoop(
  message: string,
  opts: AgentLoopOptions = {},
): Promise<AgentLoopResult> {
  const started = Date.now()
  const reasoningMode = opts.reasoningMode ?? null

  // Build the effective system prompt. If an agentCodename is set, prepend
  // the persona+memory block. Caller-supplied systemPrompt wins over the
  // JARVIS default. Best-effort — DB failure is silent.
  let baseSystem = opts.systemPrompt ?? JARVIS_SYSTEM_PROMPT
  if (opts.agentCodename) {
    const personaPrefix = await buildAgentPersonaPrefix(opts.agentCodename)
    if (personaPrefix) {
      baseSystem = personaPrefix + baseSystem
    }
  }

  // No reasoning mode → plain chat, original behaviour preserved.
  if (!reasoningMode) {
    const { content, latencyMs } = await chat(
      message,
      opts.history ?? [],
      baseSystem,
    )
    return {
      content,
      latencyMs,
      reasoningMode: null,
      reasoningUsed: false,
    }
  }

  // Reasoning mode → wrap with the matching claude-skill.
  try {
    const skills = await import('@/lib/claude-skills')
    let content = ''
    switch (reasoningMode) {
      case 'chain-of-thought': {
        const r = await skills.chainOfThought(message, opts.context)
        content = r.answer
        break
      }
      case 'constitutional-ai': {
        const r = await skills.constitutionalAI(message)
        content = r.revised || r.draft
        break
      }
      case 'react-pattern': {
        const r = await skills.reactPattern(message, [])
        content = r.answer
        break
      }
      case 'tree-of-thoughts': {
        const r = await skills.treeOfThoughts(message)
        content = r.refined || r.best?.thought || ''
        break
      }
      case 'step-back-prompting': {
        const r = await skills.stepBackPrompting(message)
        content = r.answer
        break
      }
      case 'few-shot-learning': {
        const r = await skills.fewShotLearning(message)
        content = r.answer
        break
      }
      case 'self-reflection': {
        // Self-reflection needs an answer to reflect on — get one first.
        const draft = (await chat(message, opts.history ?? [], baseSystem)).content
        const r = await skills.selfReflection(message, draft)
        content = r.verdict === 'REVISE' && r.revised ? r.revised : draft
        break
      }
      case 'pipeline': {
        const r = await skills.claudeLevelPipeline(message, opts.context)
        content = r.answer
        break
      }
      default: {
        // Exhaustive guard — unknown mode falls back to plain chat.
        const r = await chat(message, opts.history ?? [], baseSystem)
        content = r.content
      }
    }
    return {
      content,
      latencyMs: Date.now() - started,
      reasoningMode,
      reasoningUsed: true,
    }
  } catch (err: unknown) {
    // Skill failure → fall back to plain chat so the loop never breaks.
    const { content, latencyMs } = await chat(
      message,
      opts.history ?? [],
      baseSystem,
    )
    return {
      content,
      latencyMs,
      reasoningMode,
      reasoningUsed: false,
      reasoningError: err instanceof Error ? err.message : String(err),
    }
  }
}
