// knowledge-enhancer.ts — Enhance skills/memory/knowledge to expert level
import { db } from '@/lib/db';
import { quickChat, extractJson } from '@/lib/llm';
import { logger } from '@/lib/logger';

export type EnhancementLevel = 'basic' | 'intermediate' | 'advanced' | 'expert' | 'pro';

export async function enhanceSkill(skillId: string, targetLevel: EnhancementLevel = 'expert') {
  try {
    const skill = await db.skill.findUnique({ where: { id: skillId } });
    if (!skill) return { ok: false, note: 'Skill not found' };
    const before = skill.description ?? '';
    const prompt = `Skill: ${skill.name}\nDescription: ${before}\nTarget: ${targetLevel}\nGenerate expert manifest JSON with: name, summary, prerequisites, procedure (array of steps), commonPitfalls, verificationCriteria, exampleOutput, expertNotes, estimatedComplexity.`;
    const raw = await quickChat(prompt.slice(0, 2000), 'You are an expert skill architect. Output ONLY JSON.');
    const manifest = extractJson<Record<string, unknown>>(raw);
    if (!manifest) return { ok: false, note: 'LLM did not return JSON', before, after: raw.slice(0, 500) };
    const enhancedDesc = `[ENHANCED:${targetLevel}]\n${JSON.stringify(manifest, null, 2)}`;
    await db.skill.update({ where: { id: skillId }, data: { description: enhancedDesc.slice(0, 8000) } });
    return { ok: true, before, after: enhancedDesc, level: targetLevel, note: `Enhanced with ${Object.keys(manifest).length} fields` };
  } catch (err) {
    logger.error({ err }, 'knowledge-enhancer: failed');
    return { ok: false, note: err instanceof Error ? err.message : 'error' };
  }
}

export async function getKnowledgeStats() {
  const [totalSkills, enhancedSkills, totalMemories] = await Promise.all([
    db.skill.count(),
    db.skill.count({ where: { description: { startsWith: '[ENHANCED:' } } }),
    db.memoryItem.count(),
  ]);
  return { totalSkills, enhancedSkills, totalMemories };
}
