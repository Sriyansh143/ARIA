// =====================================================================
// autopilot-scheduler.ts — Server-side singleton autopilot scheduler
// =====================================================================
// ELIMINATES THE PER-BROWSER AUTOPILOT RACE.
//
// BEFORE: AutopilotToggle.tsx stored ON/OFF in localStorage and ran its
//   own setTimeout(runCycle, 60s) per browser tab. Two browsers = two
//   independent autopilot loops racing on the same DB → divergent briefing
//   metrics (cause #1 of the localhost ↔ network-IP desync).
//
// AFTER:  Exactly ONE autopilot loop runs in the server process. It is
//   started in instrumentation.ts alongside the cron scheduler and idle-
//   agent dispatcher. The client toggle is now a thin UI switch that reads
//   and writes the server-side flag via /api/autopilot/state. Every browser
//   sees the same `active` state, the same `lastTickAt`, the same
//   `nextTickIn` countdown.
//
// Adaptive cadence (preserved from the original client implementation):
//   - Dispatched to idle agents  → re-tick in 30s (keep pipeline full)
//   - Queued as task (no idle)   → re-tick in 120s (avoid task spam)
//   - Error / rate-limit         → re-tick in 120s (back off)
//   - Default                    → 60s
//
// All state lives in module-level vars (single-process safe) + is mirrored
// to MemoryItem (key=autopilot:state) for durability across restarts.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { emitEvent } from '@/lib/event-bus';

// ─── Configuration ────────────────────────────────────────────────────

const BASE_INTERVAL_MS = 60_000; // default cadence
const MIN_INTERVAL_MS = 30_000; // speed up when agents are working
const MAX_INTERVAL_MS = 300_000; // slow down on repeated failures (5 min)
const ERROR_BACKOFF_MS = 120_000; // back off to 2 min on a failed cycle
const MEMORY_KEY = 'autopilot:state';
const MEMORY_SCOPE = 'system';

// ─── Runtime state ────────────────────────────────────────────────────

interface SchedulerState {
  active: boolean;
  lastTickAt: number | null;
  lastTickResult: TickResultSummary | null;
  nextTickIn: number; // ms remaining until next tick
  currentInterval: number; // current cadence in ms
  cycleCount: number;
  errorCount: number;
  lastError: string | null;
  startedAt: number;
}

export interface TickResultSummary {
  cycle: number;
  decidedGoal: string;
  rationale: string;
  dispatched: boolean;
  runId?: string;
  taskCreated?: string;
  agentsDispatched?: number;
  durationMs: number;
  error?: string;
}

let _state: SchedulerState = {
  active: false,
  lastTickAt: null,
  lastTickResult: null,
  nextTickIn: BASE_INTERVAL_MS,
  currentInterval: BASE_INTERVAL_MS,
  cycleCount: 0,
  errorCount: 0,
  lastError: null,
  startedAt: 0,
};

let _timer: ReturnType<typeof setTimeout> | null = null;
let _countdownTimer: ReturnType<typeof setInterval> | null = null;
let _tickRunning = false; // single-flight guard for tick()
let _started = false;

// ─── Dev-mode module isolation fix ────────────────────────────────────
// Next.js Turbopack (dev mode) can load the same module in multiple chunks
// (e.g. one for instrumentation.ts, one for route handlers). Each chunk
// gets its own copy of the module-level vars above, which would break the
// singleton contract: instrumentation sets _started=true in ITS instance,
// but route handlers read _started=false from THEIR instance.
//
// We mirror the same pattern used by src/lib/db.ts: stash the runtime
// state on globalThis so all module instances share one source of truth.
// In production (compiled build) this is a no-op because there's only one
// module instance anyway.
interface GlobalAutopilotState {
  __ariaAutopilotStarted?: boolean;
  __ariaAutopilotActive?: boolean;
  __ariaAutopilotTickRunning?: boolean;
}
const g = globalThis as unknown as GlobalAutopilotState;
if (g.__ariaAutopilotStarted !== undefined) {
  _started = g.__ariaAutopilotStarted;
  _state.active = g.__ariaAutopilotActive ?? false;
  _tickRunning = g.__ariaAutopilotTickRunning ?? false;
}

// ─── Public API ───────────────────────────────────────────────────────

/**
 * Returns the current scheduler state. Safe to call from any route handler.
 * The `nextTickIn` field is recomputed on each call so clients always see
 * a fresh countdown.
 */
export function getAutopilotState(): SchedulerState & { schedulerHealthy: boolean; inFlight: boolean } {
  return {
    ..._state,
    nextTickIn: _state.active ? Math.max(0, _state.nextTickIn) : 0,
    schedulerHealthy: _started,
    inFlight: _tickRunning,
  };
}

/**
 * Toggle the autopilot on or off. Idempotent — calling setActive(true) when
 * already active is a no-op. Persists the flag to MemoryItem so it survives
 * process restarts.
 */
export async function setAutopilotActive(active: boolean): Promise<void> {
  if (_state.active === active) return;
  _state.active = active;
  g.__ariaAutopilotActive = active;
  if (active) {
    _state.startedAt = Date.now();
    _state.nextTickIn = BASE_INTERVAL_MS;
    _state.currentInterval = BASE_INTERVAL_MS;
    // Run one cycle immediately on activation — recursive scheduler inside
    // runTick handles subsequent cycles adaptively.
    scheduleTick(0);
    startCountdown();
  } else {
    stopTimer();
    stopCountdown();
    _state.nextTickIn = 0;
  }
  await persistState();
  emitEvent('autopilot:state', getAutopilotState());
  logger.info({ active }, 'autopilot-scheduler: state changed');
}

/**
 * Start the scheduler service. Called once from instrumentation.ts on server
 * boot. Reads the persisted state from MemoryItem and resumes if the flag
 * was `active` when the process last exited.
 */
export async function startAutopilotScheduler(): Promise<void> {
  if (_started) return;
  _started = true;
  g.__ariaAutopilotStarted = true;

  // Restore persisted state.
  try {
    const row = await db.memoryItem.findUnique({
      where: { key_scope: { key: MEMORY_KEY, scope: MEMORY_SCOPE } },
    });
    if (row) {
      const parsed = JSON.parse(row.value) as Partial<SchedulerState>;
      if (parsed.active) {
        logger.info('autopilot-scheduler: resuming active state from last session');
        _state.active = true;
        g.__ariaAutopilotActive = true;
        _state.startedAt = Date.now();
        _state.currentInterval = BASE_INTERVAL_MS;
        _state.nextTickIn = BASE_INTERVAL_MS;
        scheduleTick(5_000); // first tick after 5s — give the server a moment
        startCountdown();
      }
    }
  } catch (err) {
    logger.warn(
      { err: err instanceof Error ? err.message : String(err) },
      'autopilot-scheduler: failed to restore persisted state, starting fresh',
    );
  }

  logger.info(
    { active: _state.active, intervalMs: BASE_INTERVAL_MS },
    'autopilot-scheduler: started — exactly ONE scheduler runs per server process',
  );
}

// ─── Internal scheduler logic ─────────────────────────────────────────

function scheduleTick(delayMs: number): void {
  stopTimer();
  _state.nextTickIn = delayMs;
  _timer = setTimeout(() => {
    runTick().catch((err) => {
      logger.error(
        { err: err instanceof Error ? err.message : String(err) },
        'autopilot-scheduler: tick threw — scheduler stays alive',
      );
    });
  }, delayMs);
  _timer.unref?.();
}

function stopTimer(): void {
  if (_timer) {
    clearTimeout(_timer);
    _timer = null;
  }
}

function startCountdown(): void {
  stopCountdown();
  _countdownTimer = setInterval(() => {
    _state.nextTickIn = Math.max(0, _state.nextTickIn - 1000);
  }, 1000);
  _countdownTimer.unref?.();
}

function stopCountdown(): void {
  if (_countdownTimer) {
    clearInterval(_countdownTimer);
    _countdownTimer = null;
  }
}

async function runTick(): Promise<void> {
  if (!_state.active) return;
  if (_tickRunning) {
    // Single-flight guard — never let two ticks overlap. This shouldn't
    // happen because scheduleTick chains after runTick resolves, but the
    // guard protects against clock drift / timer bugs.
    logger.warn('autopilot-scheduler: tick already in flight — skipping');
    return;
  }
  _tickRunning = true;
  g.__ariaAutopilotTickRunning = true;
  let errored = false;
  let result: TickResultSummary | null = null;

  try {
    // Use an absolute URL relative to DASHBOARD_BASE — never hardcode
    // localhost:3000 because the server may not be on localhost in prod.
    const baseUrl = process.env.DASHBOARD_BASE || 'http://127.0.0.1:3000';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 90_000); // 90s — orchestrator can take 60s
    try {
      const res = await fetch(`${baseUrl}/api/autopilot/tick`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Internal header — /api/autopilot/tick uses this to skip its own
          // localhost fetch when the scheduler is the caller. See the route.
          'X-Autopilot-Source': 'scheduler',
        },
        body: JSON.stringify({ source: 'scheduler' }),
        signal: controller.signal,
        cache: 'no-store',
      });
      clearTimeout(timeout);
      const data: TickResultSummary = await res.json().catch(() => ({
        cycle: 0,
        decidedGoal: '',
        rationale: '',
        dispatched: false,
        durationMs: 0,
        error: 'parse error',
      }));
      if (!res.ok || data.error) {
        errored = true;
        _state.errorCount++;
        _state.lastError = data.error || `HTTP ${res.status}`;
        logger.warn({ err: _state.lastError }, 'autopilot-scheduler: tick failed');
      } else {
        result = data;
        _state.lastError = null;
      }
    } finally {
      clearTimeout(timeout);
    }

    _state.cycleCount++;
    _state.lastTickAt = Date.now();
    _state.lastTickResult = result;
  } catch (err) {
    errored = true;
    _state.errorCount++;
    _state.lastError = err instanceof Error ? err.message : String(err);
    logger.warn({ err: _state.lastError }, 'autopilot-scheduler: tick threw');
  } finally {
    _tickRunning = false;
    g.__ariaAutopilotTickRunning = false;

    // Adaptive cadence — same logic as the original client implementation.
    const nextInterval = computeNextInterval(result, errored);
    _state.currentInterval = nextInterval;
    _state.nextTickIn = nextInterval;

    // Broadcast state update so subscribed clients see the new countdown.
    emitEvent('autopilot:state', getAutopilotState());

    // Persist state for durability across restarts.
    await persistState().catch(() => {});

    // Schedule the next tick (recursive — keeps the loop alive while active).
    if (_state.active) {
      scheduleTick(nextInterval);
    }
  }
}

function computeNextInterval(result: TickResultSummary | null, errored: boolean): number {
  if (errored) return ERROR_BACKOFF_MS;
  if (!result) return BASE_INTERVAL_MS;
  if (result.dispatched) return MIN_INTERVAL_MS; // agents working — fill the pipeline
  return ERROR_BACKOFF_MS; // queued as task — don't spam the task list
}

async function persistState(): Promise<void> {
  try {
    // Persist ONLY the `active` flag — the rest is runtime state we don't
    // want to restore (cycleCount, lastTickAt, etc. are session-specific).
    // Restoring `active=true` on boot re-engages the scheduler.
    const minimal = JSON.stringify({ active: _state.active });
    await db.memoryItem.upsert({
      where: { key_scope: { key: MEMORY_KEY, scope: MEMORY_SCOPE } },
      update: { value: minimal },
      create: { key: MEMORY_KEY, scope: MEMORY_SCOPE, value: minimal, pinned: true },
    });
  } catch {
    /* best-effort — the in-memory state is still authoritative */
  }
}
