// =====================================================================
// approval-escalation.ts — Approval requests with 30-min escalation
// =====================================================================
// When an approval is pending for >30 min (configurable via branding),
// the system escalates through 3 levels:
//   Level 1: Telegram message to owner
//   Level 2: Telegram + Email
//   Level 3: Telegram + Email + Voice call (FreeSWITCH)
// After 24h, auto-expires.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export interface CreateApprovalInput {
  category?: string;
  title: string;
  description: string;
  requestedBy?: string;
  payload?: Record<string, unknown>;
  timeoutMinutes?: number;
}

export async function createApproval(input: CreateApprovalInput): Promise<string> {
  const timeout = input.timeoutMinutes ?? 30;
  const now = new Date();
  const nextEscalate = new Date(now.getTime() + timeout * 60 * 1000);
  const expires = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  const row = await db.approvalRequest.create({
    data: {
      category: input.category ?? 'other',
      title: input.title,
      description: input.description,
      requestedBy: input.requestedBy ?? 'system',
      payload: JSON.stringify(input.payload ?? {}),
      status: 'pending',
      nextEscalateAt: nextEscalate,
      expiresAt: expires,
    },
  });

  // Also create a notification for the bell icon
  try {
    await db.notification.create({
      data: {
        type: 'approval-required',
        title: `Approval needed: ${input.title}`,
        message: input.description.slice(0, 200),
      },
    });
  } catch { /* best-effort */ }

  return row.id;
}

export async function resolveApproval(
  id: string,
  decision: 'approved' | 'rejected',
  decidedBy: string,
  decisionNote?: string,
): Promise<{ ok: boolean }> {
  try {
    await db.approvalRequest.update({
      where: { id },
      data: {
        status: decision,
        decidedBy,
        decisionNote: decisionNote ?? null,
        resolvedAt: new Date(),
        nextEscalateAt: null,
      },
    });
    return { ok: true };
  } catch (err) {
    logger.error({ err }, 'approval-escalation: resolveApproval failed');
    return { ok: false };
  }
}

export async function escalatePendingApprovals(): Promise<{
  escalated: number;
  details: Array<{ id: string; level: number; channels: string[] }>;
}> {
  const now = new Date();
  const pending = await db.approvalRequest.findMany({
    where: {
      status: 'pending',
      nextEscalateAt: { lte: now },
    },
  });

  const details: Array<{ id: string; level: number; channels: string[] }> = [];
  let escalated = 0;

  for (const apv of pending) {
    const newLevel = Math.min(3, apv.escalationLevel + 1);
    const channels: string[] = [];

    // Level 1: Telegram
    if (newLevel >= 1) {
      try {
        const { sendToOwner } = await import('@/lib/telegram-bot');
        const sent = await sendToOwner(
          `⏰ *Approval Needed (Level ${newLevel}/3)*\n\n*${apv.title}*\n${apv.description.slice(0, 300)}\n\nCategory: ${apv.category}\nRequested by: ${apv.requestedBy}`,
        );
        if (sent) channels.push('telegram');
      } catch { /* best-effort */ }
    }

    // Level 2: Email
    if (newLevel >= 2) {
      try {
        const { sendToOwnerEmail } = await import('@/lib/email-sender');
        // Use DASHBOARD_BASE — never hardcode localhost:3000 because the
        // operator may be accessing the dashboard from a network IP, a
        // tunnel, or a production domain. A hardcoded localhost link in the
        // email would be unreachable from the operator's phone/other device.
        const dashboardUrl = process.env.DASHBOARD_BASE || 'http://localhost:3000';
        const sent = await sendToOwnerEmail(
          `URGENT: Approval needed — ${apv.title}`,
          `${apv.description}\n\nCategory: ${apv.category}\nRequested by: ${apv.requestedBy}\n\nApprove at: ${dashboardUrl}/?tab=approvals`,
        );
        if (sent) channels.push('email');
      } catch { /* best-effort */ }
    }

    // Level 3: Voice call
    if (newLevel >= 3) {
      try {
        const freeswitch = await import('@/lib/freeswitch-bridge');
        if (freeswitch.isFreeSWITCHConfigured()) {
          const phone = process.env.OWNER_PHONE ?? '';
          if (phone) {
            await freeswitch.makeCall({ to: phone });
            channels.push('voice');
          }
        }
      } catch { /* best-effort */ }
    }

    const nextTimeout = 30 * 60 * 1000; // 30 min
    const isExpired = newLevel >= 3 && apv.expiresAt && now > apv.expiresAt;

    await db.approvalRequest.update({
      where: { id: apv.id },
      data: {
        escalationLevel: newLevel,
        lastEscalatedAt: now,
        nextEscalateAt: isExpired ? null : new Date(now.getTime() + nextTimeout),
        status: isExpired ? 'expired' : 'pending',
      },
    });

    escalated++;
    details.push({ id: apv.id, level: newLevel, channels });
  }

  return { escalated, details };
}

export async function listApprovals(filter: {
  status?: string;
  category?: string;
  limit?: number;
} = {}): Promise<unknown[]> {
  const where: Record<string, unknown> = {};
  if (filter.status) where.status = filter.status;
  if (filter.category) where.category = filter.category;
  return db.approvalRequest.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: filter.limit ?? 50,
  });
}

export async function getApprovalStats(): Promise<{
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  expired: number;
  escalating: number;
}> {
  const [total, pending, approved, rejected, expired, escalating] = await Promise.all([
    db.approvalRequest.count(),
    db.approvalRequest.count({ where: { status: 'pending' } }),
    db.approvalRequest.count({ where: { status: 'approved' } }),
    db.approvalRequest.count({ where: { status: 'rejected' } }),
    db.approvalRequest.count({ where: { status: 'expired' } }),
    db.approvalRequest.count({ where: { status: 'pending', escalationLevel: { gt: 0 } } }),
  ]);
  return { total, pending, approved, rejected, expired, escalating };
}
