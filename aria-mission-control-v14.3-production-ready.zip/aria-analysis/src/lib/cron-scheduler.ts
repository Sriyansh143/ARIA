// cron-scheduler.ts — Auto-runs cron jobs every 60 seconds
import { db } from '@/lib/db';
import { dispatchCronJob } from '@/lib/cron-dispatcher';
import { logger } from '@/lib/logger';

let schedulerRunning = false;
let tickInterval: ReturnType<typeof setInterval> | null = null;
let lastTickAt: Date | null = null;

export function shouldRunCron(schedule: string, now: Date = new Date()): boolean {
  try {
    const parts = schedule.trim().split(/\s+/);
    if (parts.length < 5) return false;
    const [minF, hourF, dayF, monthF, weekF] = parts;
    const min = now.getMinutes(), hour = now.getHours(), day = now.getDate(), month = now.getMonth() + 1, week = now.getDay();
    const match = (f: string, v: number) => {
      if (f === '*') return true;
      if (f.startsWith('*/')) { const n = parseInt(f.slice(2), 10); return n > 0 && v % n === 0; }
      if (f.includes(',')) return f.split(',').some(x => match(x.trim(), v));
      if (f.includes('-')) { const [lo, hi] = f.split('-').map(Number); return v >= lo && v <= hi; }
      return parseInt(f, 10) === v;
    };
    return match(minF, min) && match(hourF, hour) && match(dayF, day) && match(monthF, month) && match(weekF, week);
  } catch { return false; }
}

export async function tick(): Promise<{ checked: number; ran: number; errors: number }> {
  lastTickAt = new Date();
  let checked = 0, ran = 0, errors = 0;
  try {
    const jobs = await db.cronJob.findMany({ where: { enabled: true } });
    checked = jobs.length;
    for (const job of jobs) {
      if (!shouldRunCron(job.schedule, lastTickAt)) continue;
      if (job.lastRun) {
        const secs = (lastTickAt.getTime() - job.lastRun.getTime()) / 1000;
        if (secs < 60) continue;
      }
      try {
        const start = Date.now();
        await db.cronJob.update({ where: { id: job.id }, data: { runCount: { increment: 1 }, lastRun: lastTickAt } });
        const result = await dispatchCronJob(job.key);
        await db.cronHistory.create({ data: { cronKey: job.key, status: result.ok ? 'success' : 'error', durationMs: Date.now() - start, detail: result.detail.slice(0, 500) } }).catch(() => {});
        ran++; if (!result.ok) errors++;
      } catch (err) {
        errors++;
        await db.cronHistory.create({ data: { cronKey: job.key, status: 'error', durationMs: 0, detail: err instanceof Error ? err.message.slice(0, 500) : 'error' } }).catch(() => {});
      }
    }
  } catch (err) {
    // Log the actual error message (err alone serializes as {} for Error objects).
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err: msg }, 'cron-scheduler: tick failed');
  }
  return { checked, ran, errors };
}

export function startScheduler(): void {
  if (schedulerRunning) return;
  schedulerRunning = true;
  logger.info('cron-scheduler: starting — tick every 60 seconds');
  tick().catch(() => {});
  tickInterval = setInterval(() => { tick().catch(() => {}); }, 60 * 1000);
}

export function stopScheduler(): void {
  if (tickInterval) { clearInterval(tickInterval); tickInterval = null; }
  schedulerRunning = false;
}

export function getSchedulerStatus(): { running: boolean; lastTickAt: string | null; nextTickIn: number | null } {
  const nextTickIn = lastTickAt ? Math.max(0, 60 - Math.floor((Date.now() - lastTickAt.getTime()) / 1000)) : null;
  return { running: schedulerRunning, lastTickAt: lastTickAt?.toISOString() ?? null, nextTickIn };
}
