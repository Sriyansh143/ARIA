// =====================================================================
// code-sandbox.ts — Real code execution sandbox
// =====================================================================
// Like Claude's code interpreter / Gemini's code execution.
// Executes Python + JavaScript/Typecode safely and returns the output.
//
// - Python: runs via `python3` (or `bunx pyodide` if no python3)
// - JavaScript: runs via `bun` (sandboxed)
// - 10-second timeout
// - Captures stdout, stderr, exit code
// - No network access (blocks fetch, http, https imports in JS)
// =====================================================================

import { execSync } from 'child_process';
import { writeFileSync, mkdirSync, unlinkSync, existsSync } from 'fs';
import { join } from 'path';
import crypto from 'crypto';

const SANDBOX_DIR = join(process.cwd(), 'sandbox-tmp');
if (!existsSync(SANDBOX_DIR)) {
  try { mkdirSync(SANDBOX_DIR, { recursive: true }); } catch { /* ignore */ }
}

export interface CodeExecutionResult {
  language: 'python' | 'javascript' | 'typescript';
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  ok: boolean;
  output: string; // combined useful output for LLM consumption
}

/**
 * Execute Python code safely.
 */
function execPython(code: string, filename: string): CodeExecutionResult {
  const filepath = join(SANDBOX_DIR, filename);
  writeFileSync(filepath, code, 'utf-8');
  const start = Date.now();
  try {
    const stdout = execSync(`python3 ${filepath}`, {
      timeout: 10000,
      encoding: 'utf-8',
      cwd: SANDBOX_DIR,
      env: { ...process.env, PYTHONPATH: SANDBOX_DIR },
    }).toString();
    return {
      language: 'python',
      stdout,
      stderr: '',
      exitCode: 0,
      durationMs: Date.now() - start,
      ok: true,
      output: stdout.slice(0, 5000),
    };
  } catch (err) {
    const e = err as { stderr?: string; stdout?: string; status?: number };
    return {
      language: 'python',
      stdout: e.stdout ?? '',
      stderr: (e.stderr ?? '').slice(0, 3000),
      exitCode: e.status ?? 1,
      durationMs: Date.now() - start,
      ok: false,
      output: (e.stderr ?? e.stdout ?? 'Execution failed').slice(0, 3000),
    };
  } finally {
    try { unlinkSync(filepath); } catch { /* ignore */ }
  }
}

/**
 * Execute JavaScript/TypeScript code safely via bun.
 */
function execJavaScript(code: string, filename: string, isTs: boolean): CodeExecutionResult {
  const filepath = join(SANDBOX_DIR, filename);
  // Inject network-blocking wrapper
  const safeCode = `
// === SANDBOX SAFETY WRAPPER ===
const _origFetch = globalThis.fetch;
globalThis.fetch = () => Promise.reject(new Error('Network access blocked in sandbox'));
globalThis.Request = undefined;
globalThis.Response = undefined;
// === USER CODE BELOW ===
${code}
`;
  writeFileSync(filepath, safeCode, 'utf-8');
  const start = Date.now();
  try {
    const runner = isTs ? `bun` : `bun`;
    const stdout = execSync(`${runner} ${filepath}`, {
      timeout: 10000,
      encoding: 'utf-8',
      cwd: SANDBOX_DIR,
      env: { ...process.env, NODE_ENV: 'production' },
    }).toString();
    return {
      language: isTs ? 'typescript' : 'javascript',
      stdout,
      stderr: '',
      exitCode: 0,
      durationMs: Date.now() - start,
      ok: true,
      output: stdout.slice(0, 5000),
    };
  } catch (err) {
    const e = err as { stderr?: string; stdout?: string; status?: number };
    return {
      language: isTs ? 'typescript' : 'javascript',
      stdout: e.stdout ?? '',
      stderr: (e.stderr ?? '').slice(0, 3000),
      exitCode: e.status ?? 1,
      durationMs: Date.now() - start,
      ok: false,
      output: (e.stderr ?? e.stdout ?? 'Execution failed').slice(0, 3000),
    };
  } finally {
    try { unlinkSync(filepath); } catch { /* ignore */ }
  }
}

/**
 * Execute code in the sandbox.
 * Detects language from the code or explicit parameter.
 */
export function executeCode(
  code: string,
  language?: 'python' | 'javascript' | 'typescript',
): CodeExecutionResult {
  // Auto-detect language if not specified
  let lang = language;
  if (!lang) {
    if (/^\s*(import|from|def |class |print\(|if __name__)/m.test(code)) lang = 'python';
    else if (/(interface|type\s+\w+\s*=|: (string|number|boolean))/.test(code)) lang = 'typescript';
    else lang = 'javascript';
  }

  const id = crypto.randomUUID();
  const filename =
    lang === 'python' ? `${id}.py` : lang === 'typescript' ? `${id}.ts` : `${id}.js`;

  if (lang === 'python') return execPython(code, filename);
  return execJavaScript(code, filename, lang === 'typescript');
}

/**
 * Extract code blocks from an LLM response and execute them.
 * Returns the results so the agent can verify its code works.
 */
export interface CodeBlockResult {
  language: string;
  code: string;
  result: CodeExecutionResult;
}

export function extractAndExecuteCode(llmResponse: string): CodeBlockResult[] {
  const results: CodeBlockResult[] = [];
  // Match ```python, ```javascript, ```typescript, ```js, ```ts, ```py
  const codeBlockRegex = /```(?:python|javascript|typescript|js|ts|py)\s*([\s\S]*?)```/gi;
  const matches = [...llmResponse.matchAll(codeBlockRegex)];

  for (const match of matches) {
    const fullMatch = match[0].toLowerCase();
    const code = match[1].trim();
    if (!code) continue;

    let lang: 'python' | 'javascript' | 'typescript';
    if (fullMatch.includes('python') || fullMatch.includes('py')) lang = 'python';
    else if (fullMatch.includes('typescript') || fullMatch.includes('ts')) lang = 'typescript';
    else lang = 'javascript';

    const result = executeCode(code, lang);
    results.push({ language: lang, code, result });
  }

  return results;
}
