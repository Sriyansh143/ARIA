// ceo-agent.ts — CEO strategic sweep
import { db } from '@/lib/db';
import { chat, extractJson } from '@/lib/llm';
import { createApproval } from '@/lib/approval-escalation';
import { researchBeforeAction } from '@/lib/agent-pre-action';
import { logger } from '@/lib/logger';

export async function runCeoSweep(): Promise<{ tasksCreated: number; approvalsRequested: number }> {
  try {
    const [agents, tasks, pendingTasks, pendingApprovals, earningMethods, revenue] = await Promise.all([
      db.agent.count(), db.task.count(),
      db.task.count({ where: { status: 'pending' } }),
      db.approvalRequest.count({ where: { status: 'pending' } }),
      db.earningMethod.count(), db.payment.aggregate({ where: { status: 'confirmed' }, _sum: { amount: true } }),
    ]);

    const prompt = `You are the CEO of an autonomous AI company. Review the fleet status and propose 0-3 strategic actions.

Fleet status:
- Agents: ${agents}
- Total tasks: ${tasks}
- Pending tasks: ${pendingTasks}
- Pending approvals: ${pendingApprovals}
- Earning methods: ${earningMethods}
- Total revenue: ₹${revenue._sum.amount ?? 0}

Output JSON: {"actions":[{"type":"create_task","title":"...","priority":"low|medium|high","description":"..."},{"type":"request_approval","title":"...","description":"..."}]}`;

    const raw = await chat(prompt, [], 'You are a CEO. Output ONLY JSON.');
    const parsed = extractJson<{ actions?: Array<{ type: string; title: string; priority?: string; description?: string }> }>(raw);

    let tasksCreated = 0, approvalsRequested = 0;
    if (parsed?.actions) {
      for (const action of parsed.actions) {
        if (action.type === 'create_task') {
          // Pre-action research: best-effort, never blocks. The recommendation
          // is logged so the operator can audit why a task was created.
          try {
            const research = await researchBeforeAction({
              agentCodename: 'CEO',
              agentRole: 'ceo',
              action: `Create task: ${action.title}`,
              actionType: 'create',
              target: 'task',
              description: action.description ?? action.title,
              currentContext: `Fleet: ${agents} agents, ${pendingTasks} pending tasks, ${pendingApprovals} pending approvals`,
            });
            logger.info(
              { recommendation: research.recommendation, confidence: research.confidence, title: action.title },
              'ceo-agent: pre-action research for create_task',
            );
            // If research strongly recommends abort, skip this action (best-effort).
            if (research.recommendation === 'abort') {
              logger.warn({ title: action.title, reason: research.notes }, 'ceo-agent: skipping task (research=abort)');
              continue;
            }
          } catch (err) {
            // Research layer failure must never block the CEO's decision.
            logger.warn({ err }, 'ceo-agent: pre-action research failed — proceeding');
          }
          await db.task.create({ data: { title: action.title, description: action.description ?? '', status: 'pending', priority: action.priority ?? 'medium' } }).catch(() => {});
          tasksCreated++;
        } else if (action.type === 'request_approval') {
          // Pre-action research for approval escalation — these are higher-
          // impact (they ping the operator), so research is especially useful.
          try {
            const research = await researchBeforeAction({
              agentCodename: 'CEO',
              agentRole: 'ceo',
              action: `Request approval: ${action.title}`,
              actionType: 'communicate',
              target: 'operator',
              description: action.description ?? action.title,
              currentContext: `${pendingApprovals} approvals already pending`,
            });
            logger.info(
              { recommendation: research.recommendation, confidence: research.confidence, title: action.title },
              'ceo-agent: pre-action research for request_approval',
            );
            if (research.recommendation === 'abort') {
              logger.warn({ title: action.title, reason: research.notes }, 'ceo-agent: skipping approval (research=abort)');
              continue;
            }
          } catch (err) {
            logger.warn({ err }, 'ceo-agent: pre-action research failed — proceeding');
          }
          await createApproval({ category: 'app-change', title: action.title, description: action.description ?? '', requestedBy: 'ceo-agent' }).catch(() => {});
          approvalsRequested++;
        }
      }
    }
    return { tasksCreated, approvalsRequested };
  } catch { return { tasksCreated: 0, approvalsRequested: 0 }; }
}
