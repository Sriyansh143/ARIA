// request-logger.ts — Log every user request as a Goal (Rule 62).
//
// Rule 62 (Request → Goal logging): Every user request MUST be logged as a
// Goal in the system. This creates an audit trail of what was requested vs
// what was delivered, and feeds the roadmap update process.
//
// This is a server-side helper. Call `logRequestAsGoal(requestText)` from any
// API route that receives a user request (chat, agent commands, etc.).

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

/**
 * Log a user request as a Goal (MemoryItem with scope='goal').
 * Idempotent: if a goal with the same key already exists, it's upserted
 * (status preserved, lastRequestedAt updated in tags).
 *
 * The goal key is derived from the request text (slugified, max 50 chars).
 * Tags include: ['user-request', 'auto-logged'] + the source.
 */
export async function logRequestAsGoal(
  requestText: string,
  source: string = 'chat',
): Promise<{ key: string; created: boolean } | null> {
  const trimmed = requestText.trim();
  if (!trimmed || trimmed.length < 8) return null; // skip trivial/greeting messages

  try {
    const key = `req-${trimmed.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50)}`;
    const value = JSON.stringify({
      title: `Request: ${trimmed.slice(0, 80)}${trimmed.length > 80 ? '…' : ''}`,
      description: `User request logged from ${source}:\n\n${trimmed.slice(0, 1000)}`,
      status: 'pending',
      priority: 'medium',
      progress: 0,
      owner: 'ORION',
      dueDate: null,
      source,
      requestText: trimmed.slice(0, 2000),
      loggedAt: new Date().toISOString(),
    });

    // Check if it already exists
    const existing = await db.memoryItem.findUnique({
      where: { key_scope: { key, scope: 'goal' } },
    });

    await db.memoryItem.upsert({
      where: { key_scope: { key, scope: 'goal' } },
      update: {
        value,
        tags: JSON.stringify(['user-request', 'auto-logged', source]),
      },
      create: {
        scope: 'goal',
        key,
        value,
        tags: JSON.stringify(['user-request', 'auto-logged', source]),
        pinned: false,
      },
    });

    return { key, created: !existing };
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'request-logger: failed to log request as goal');
    return null;
  }
}
