import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export async function requestChange(input: {
  changeType: string; scope?: string; title: string; description: string;
  rationale?: string; impact?: string; proposedBy?: string; filePaths?: string[];
}): Promise<string> {
  try {
    const row = await db.changeRequest.create({
      data: {
        changeType: input.changeType,
        scope: input.scope ?? 'app',
        title: input.title,
        description: input.description,
        rationale: input.rationale,
        impact: input.impact,
        proposedBy: input.proposedBy ?? 'system',
        filePaths: JSON.stringify(input.filePaths ?? []),
        status: 'pending',
      },
    });
    return row.id;
  } catch (err) {
    logger.error({ err }, 'change-gate: requestChange failed');
    throw new Error('Failed to create change request');
  }
}

export async function listChanges(filter: { status?: string; changeType?: string } = {}) {
  try {
    const where: Record<string, unknown> = {};
    if (filter.status) where.status = filter.status;
    if (filter.changeType) where.changeType = filter.changeType;
    return db.changeRequest.findMany({ where, orderBy: { createdAt: 'desc' }, take: 50 });
  } catch (err) {
    logger.warn({ err }, 'change-gate: listChanges failed');
    return [];
  }
}

export async function getChangeStats() {
  try {
    const [total, pending, approved, rejected, deployed] = await Promise.all([
      db.changeRequest.count(),
      db.changeRequest.count({ where: { status: 'pending' } }),
      db.changeRequest.count({ where: { status: 'approved' } }),
      db.changeRequest.count({ where: { status: 'rejected' } }),
      db.changeRequest.count({ where: { status: 'deployed' } }),
    ]);
    return { total, pending, approved, rejected, deployed };
  } catch (err) {
    logger.warn({ err }, 'change-gate: getChangeStats failed');
    return { total: 0, pending: 0, approved: 0, rejected: 0, deployed: 0 };
  }
}
