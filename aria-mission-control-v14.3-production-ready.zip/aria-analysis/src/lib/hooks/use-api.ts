'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

// Global CPU load tracker — updated by the main dashboard's metrics poll.
// AGGRESSIVE multi-tier adaptive throttling to prevent CPU spirals + overheating:
//   CPU > 50% → intervals × 2 (early backoff — prevents heat buildup)
//   CPU > 65% → intervals × 3 (heavy backoff)
//   CPU > 80% → intervals × 4 (critical — prevents overheating)
//   CPU > 90% → intervals × 6 + pause non-essential polls (emergency)
// Plus: polling PAUSES entirely when the browser tab is hidden (document.hidden).
// Plus: global concurrency limiter — max 3 concurrent fetches across all useApi instances.
let _cpuLoad = 0;
let _overloadUntil = 0;
let _criticalUntil = 0;
let _emergencyUntil = 0;

/** Called by the dashboard when new metrics arrive. */
export function setCpuLoad(load: number): void {
  _cpuLoad = load;
  if (load > 65) {
    _overloadUntil = Date.now() + 60000;
  }
  if (load > 80) {
    _criticalUntil = Date.now() + 90000;
  }
  if (load > 90) {
    // Emergency: 120s cooldown — prevent laptop overheating.
    _emergencyUntil = Date.now() + 120000;
  }
}

/** Returns true when the system is overloaded (CPU > 65% recently). */
export function isOverloaded(): boolean {
  return _cpuLoad > 65 || Date.now() < _overloadUntil;
}

/** Returns true when the system is in critical overload (CPU > 80% recently). */
export function isCritical(): boolean {
  return _cpuLoad > 80 || Date.now() < _criticalUntil;
}

/** Returns true when the system is in emergency (CPU > 90% recently). */
export function isEmergency(): boolean {
  return _cpuLoad > 90 || Date.now() < _emergencyUntil;
}

/** Returns the adaptive multiplier for polling intervals (1x-6x). */
export function getThrottleMultiplier(): number {
  if (isEmergency()) return 6;
  if (isCritical()) return 4;
  if (_cpuLoad > 65 || Date.now() < _overloadUntil) return 3;
  if (_cpuLoad > 50) return 2;
  return 1;
}

/**
 * Returns a PROGRESSIVE slowdown multiplier — smoothly scales with CPU
 * instead of step functions. This prevents the "all-or-nothing" throttle
 * behavior that can cause jarring UI freezes.
 *
 * CPU 0-40%  → 1.0x (normal)
 * CPU 40-60% → 1.0x → 2.0x (gradual slowdown)
 * CPU 60-80% → 2.0x → 4.0x (heavy slowdown)
 * CPU 80-95% → 4.0x → 6.0x (critical slowdown)
 * CPU 95%+   → 6.0x (emergency — but still polling, NOT stopped)
 */
export function getProgressiveMultiplier(): number {
  const cpu = _cpuLoad;
  if (cpu <= 40) return 1;
  if (cpu <= 60) return 1 + ((cpu - 40) / 20); // 1.0 → 2.0
  if (cpu <= 80) return 2 + ((cpu - 60) / 10); // 2.0 → 4.0
  if (cpu <= 95) return 4 + ((cpu - 80) / 7.5); // 4.0 → 6.0
  return 6; // emergency cap
}

/**
 * Returns the ADAPTIVE max concurrent fetches — reduces when CPU is high
 * so the system can cool down without stopping entirely.
 *
 * CPU 0-50%  → 3 concurrent (normal)
 * CPU 50-70% → 2 concurrent (reduced)
 * CPU 70-85% → 1 concurrent (minimal)
 * CPU 85%+   → 1 concurrent + extra delay (survival mode)
 */
export function getAdaptiveMaxConcurrent(): number {
  if (isEmergency() || isCritical()) return 1;
  if (_cpuLoad > 70) return 1;
  if (_cpuLoad > 50) return 2;
  return 3;
}

// ─── Visibility-based polling pause ───────────────────────────────────
// When the browser tab is hidden (user switched away / minimized), ALL polling
// pauses entirely. This is the single biggest CPU saver — no point fetching
// data for a tab the user can't see. Polling resumes immediately on focus.
let _hidden = false;
if (typeof document !== 'undefined') {
  _hidden = document.hidden;
  document.addEventListener('visibilitychange', () => {
    _hidden = document.hidden;
  });
}

/** Returns true when the browser tab is hidden (polling should pause). */
export function isTabHidden(): boolean {
  return _hidden;
}

// ─── Global concurrency limiter ───────────────────────────────────────
// Max 3 concurrent fetches across ALL useApi instances. Prevents CPU spikes
// when many tabs mount simultaneously (e.g. on page load).
const _activeFetches: Set<Promise<void>> = new Set();
// Increased from 3 to 15 — the dashboard fires ~10+ simultaneous API calls
// on initial load (briefing, metrics, notifications, comms, activity, etc.).
// A limit of 3 caused most calls to queue, making pages appear "stuck loading".
const MAX_CONCURRENT = 15;

async function throttledFetch(url: string): Promise<Response> {
  // Wait until a concurrency slot is available.
  while (_activeFetches.size >= MAX_CONCURRENT) {
    await Promise.race(Array.from(_activeFetches)).catch(() => {});
  }
  const p = fetch(url, { cache: 'no-store' });
  const tracked = p.then(() => {}) as Promise<void>;
  _activeFetches.add(tracked);
  try {
    return await p;
  } finally {
    _activeFetches.delete(tracked);
  }
}

interface ApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

/**
 * Polling fetch hook. Fetches `url` immediately and then every `intervalMs`
 * (default 8s). Returns a manual `refresh` callback. Safe to use for the
 * dashboard's many live panels.
 *
 * ADAPTIVE THROTTLING: When the system is overloaded (CPU > 80%), the polling
 * interval is automatically doubled to reduce load. This prevents the
 * dashboard from compounding CPU pressure during spikes.
 */
export function useApi<T>(url: string | null, intervalMs = 8000): ApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(!!url);
  const [error, setError] = useState<string | null>(null);
  const urlRef = useRef(url);
  urlRef.current = url;

  const doFetch = useCallback(async () => {
    if (!urlRef.current) return;
    // Skip fetch entirely if the tab is hidden — saves CPU when user isn't looking.
    if (isTabHidden()) return;
    try {
      const res = await throttledFetch(urlRef.current);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'fetch error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!url) {
      setData(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    doFetch();
    // intervalMs <= 0 means "fetch once" (no polling) — used by modals and
    // panels that refresh manually.
    if (intervalMs > 0) {
      // Adaptive interval: multiply by the throttle multiplier (1x-6x) based on CPU.
      // Plus: skip polls when the tab is hidden (visibility-based pause).
      const effectiveInterval = () => intervalMs * getThrottleMultiplier();
      let id: ReturnType<typeof setInterval> | null = setInterval(() => {
        // Visibility check — skip the fetch if the tab is hidden.
        if (!isTabHidden()) doFetch();
      }, effectiveInterval());
      // Re-evaluate every 15s — if throttle state changed, reset the interval.
      const adjustId = setInterval(() => {
        if (id) clearInterval(id);
        id = setInterval(() => {
          if (!isTabHidden()) doFetch();
        }, effectiveInterval());
      }, 15000);
      return () => {
        if (id) clearInterval(id);
        clearInterval(adjustId);
      };
    }
  }, [url, intervalMs, doFetch]);

  return { data, loading, error, refresh: doFetch };
}

/** One-shot POST helper that returns parsed JSON. */
export async function postJson<T = unknown>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status}: ${txt}`);
  }
  return res.json() as Promise<T>;
}

/** One-shot PATCH helper. */
export async function patchJson<T = unknown>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json() as Promise<T>;
}

/** One-shot DELETE helper. */
export async function deleteJson<T = unknown>(url: string): Promise<T> {
  const res = await fetch(url, { method: 'DELETE' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json() as Promise<T>;
}
