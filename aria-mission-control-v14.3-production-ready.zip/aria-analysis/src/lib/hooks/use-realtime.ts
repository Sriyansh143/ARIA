'use client';

/**
 * use-realtime.ts
 * ----------------
 * Client-side React hooks for the ARIA real-time socket.io service.
 *
 * The real-time service runs on port 3003 behind the Caddy gateway. Clients
 * MUST connect using the RELATIVE URL `/?XTransformPort=3003` so the gateway
 * can route the WebSocket upgrade to the right port. NEVER use an absolute
 * URL like `http://localhost:3003` — that bypasses the gateway and fails in
 * production.
 *
 * Hooks:
 *   - useRealtime(channel, handler)
 *       Subscribe to a channel and run `handler` on every message. Cleans up
 *       automatically on unmount or when `channel`/`handler` change.
 *
 *   - useRealtimeConnection()
 *       Returns `{ connected }` — useful for showing a live indicator.
 *
 * Design notes:
 *   - `socket.io-client` is imported dynamically so the bundle stays small
 *     and the hook works even if the package isn't installed yet. If the
 *     import fails, every hook silently no-ops — the dashboard keeps working
 *     via HTTP polling (useApi). This is intentional: real-time is a
 *     progressive enhancement, not a hard dependency.
 *   - A single shared Socket instance is reused across all hook consumers.
 *   - Auto-reconnect is enabled with a 2s backoff.
 */

import { useEffect, useRef, useState } from 'react';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Canonical channel names — must match the server's CHANNELS list. */
export type RealtimeChannel =
  | 'agent:heartbeat'
  | 'agent:status'
  | 'task:update'
  | 'decision:new'
  | 'alert:critical'
  | 'telemetry:tick'
  | 'payment:update'
  | 'sync:status';

/** Minimal Socket shape — avoids leaking the full socket.io-client type. */
interface SocketLike {
  connected: boolean;
  on(event: string, cb: (...args: unknown[]) => void): unknown;
  off(event: string, cb?: (...args: unknown[]) => void): unknown;
  emit(event: string, ...args: unknown[]): unknown;
  disconnect(): unknown;
}

type ConnectionListener = (connected: boolean) => void;

// ---------------------------------------------------------------------------
// Module-level singleton
// ---------------------------------------------------------------------------

/**
 * Relative URL with the gateway port query. CRITICAL:
 *   - Path is `/` (so Caddy forwards correctly).
 *   - XTransformPort=3003 routes to the realtime mini-service.
 *   - NEVER use http://localhost:3003 — that breaks in the sandbox/prod.
 */
const SOCKET_URL = '/?XTransformPort=3003';

let _socketPromise: Promise<SocketLike | null> | null = null;
let _socket: SocketLike | null = null;
let _connected = false;
const _connectionListeners = new Set<ConnectionListener>();

const setConnected = (v: boolean) => {
  if (_connected === v) return;
  _connected = v;
  for (const l of _connectionListeners) {
    try {
      l(v);
    } catch {
      /* ignore listener errors */
    }
  }
};

/**
 * Lazily load socket.io-client and connect. Returns null if the package
 * isn't installed or the connection attempt throws — callers must handle
 * null gracefully.
 */
async function getSocket(): Promise<SocketLike | null> {
  if (_socket) return _socket;
  if (_socketPromise) return _socketPromise;

  _socketPromise = (async () => {
    try {
      // Dynamic import keeps socket.io-client out of the main bundle and
      // out of SSR. If the package is missing, this throws — we catch and
      // return null so the app falls back to HTTP polling.
      //
      // NOTE: we deliberately use a non-literal module specifier so that
      // TypeScript resolves the import as `Promise<any>` rather than
      // erroring with "Cannot find module 'socket.io-client'" before the
      // dependency is added to package.json. Runtime resolution still finds
      // the real package once it's installed.
      const SPEC: string = 'socket.io-client';
      const mod: any = await import(SPEC);
      const io = mod.io || mod.default;
      const sock = io(SOCKET_URL, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 2000,
        reconnectionDelayMax: 10_000,
        timeout: 10_000,
        // Don't force a new connection — reuse the shared manager.
        forceNew: false,
      }) as unknown as SocketLike;

      // Wire connection state to our listener set.
      sock.on('connect', () => setConnected(true));
      sock.on('disconnect', () => setConnected(false));
      sock.on('connect_error', () => setConnected(false));

      _socket = sock;
      return sock;
    } catch (err) {
      // Most likely: socket.io-client is not installed. Log once so devs
      // notice, but stay silent in production (the app still works via HTTP).
      if (process.env.NODE_ENV !== 'production') {
        console.warn(
          '[use-realtime] socket.io-client unavailable — falling back to HTTP polling.',
          err,
        );
      }
      return null;
    }
  })();

  return _socketPromise;
}

// Kick off the connection on the client immediately (non-blocking).
if (typeof window !== 'undefined') {
  getSocket();
}

// ---------------------------------------------------------------------------
// Hooks
// ---------------------------------------------------------------------------

/**
 * Subscribe to a real-time channel and run `handler` for every message.
 *
 * The hook is resilient: if the socket can't be loaded (package missing,
 * network blocked, etc.), it silently no-ops. The caller should NOT rely on
 * the handler firing — treat real-time as a progressive enhancement over
 * HTTP polling.
 *
 * @param channel  Channel name (must be one of the server's CHANNELS).
 * @param handler  Callback invoked with the message payload (typed as unknown
 *                 — narrow inside your handler).
 */
export function useRealtime(
  channel: RealtimeChannel | string,
  handler: (data: unknown) => void,
): void {
  // Keep the latest handler in a ref so we don't re-subscribe on every render
  // when the caller passes an inline function.
  const handlerRef = useRef(handler);
  useEffect(() => {
    handlerRef.current = handler;
  });

  useEffect(() => {
    let cancelled = false;
    let localSocket: SocketLike | null = null;

    const localHandler = (data: unknown) => {
      if (!cancelled) handlerRef.current(data);
    };

    (async () => {
      const sock = await getSocket();
      if (!sock || cancelled) return;
      localSocket = sock;
      try {
        // Join the server-side room for this channel so we only receive
        // messages broadcast to it.
        sock.emit('subscribe', channel);
        // Listen for messages on the channel.
        sock.on(channel, localHandler as (...args: unknown[]) => void);
      } catch {
        /* ignore — real-time is best-effort */
      }
    })();

    return () => {
      cancelled = true;
      try {
        localSocket?.emit('unsubscribe', channel);
        localSocket?.off(channel, localHandler as (...args: unknown[]) => void);
      } catch {
        /* ignore */
      }
    };
  }, [channel]);
}

/**
 * Track the real-time connection state. Returns `{ connected }` which flips
 * to true once the shared socket is connected, and false on disconnect.
 *
 * Useful for a small "live" indicator in the header.
 */
export function useRealtimeConnection(): { connected: boolean } {
  const [connected, setConn] = useState<boolean>(_connected);

  useEffect(() => {
    const listener: ConnectionListener = (v) => setConn(v);
    _connectionListeners.add(listener);
    // Sync immediately in case state changed between render and effect.
    // Use a microtask to avoid the synchronous-setState-in-effect lint rule.
    Promise.resolve().then(() => setConn(_connected));
    return () => {
      _connectionListeners.delete(listener);
    };
  }, []);

  return { connected };
}
