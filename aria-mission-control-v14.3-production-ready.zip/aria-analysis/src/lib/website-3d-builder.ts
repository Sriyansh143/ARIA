// website-3d-builder.ts — 3D Website Builder
//
// Generates complete standalone HTML strings containing interactive 3D scenes
// powered by Three.js (r128, loaded from CDN) + OrbitControls. The output is
// a SINGLE self-contained HTML file — no build step, no npm — that renders a
// responsive canvas filling the viewport with a UI overlay on top.
//
// Inspired by the success of pitch-templates.ts (which produces CSS 3D scroll
// animations), this module focuses on real WebGL 3D via Three.js. Templates:
//
//   • product-showcase — rotating 3D product (cube with materials + rim light)
//   • portfolio        — 3D card stack floating in space (planes with textures)
//   • landing-page     — 3D hero with particle field + animated logo
//   • gallery          — 3D image wall (cylindrical arrangement of planes)
//   • game             — simple 3D game (collect spheres with WASD + mouse)
//
// Color schemes: dark · light · violet · ocean.
//
// Exports:
//   • WEBSITE_3D_TEMPLATES — Template list
//   • getWebsite3DTemplates()
//   • generate3DWebsite({ templateId, title, description, colorScheme }) → HTML
//   • WEBSITE_3D_COLOR_SCHEMES — scheme list

export type Website3DTemplateId =
  | 'product-showcase'
  | 'portfolio'
  | 'landing-page'
  | 'gallery'
  | 'game';

export type Website3DColorScheme = 'dark' | 'light' | 'violet' | 'ocean';

export interface Website3DTemplate {
  id: Website3DTemplateId;
  name: string;
  description: string;
  sceneType: Website3DTemplateId;
}

export const WEBSITE_3D_TEMPLATES: Website3DTemplate[] = [
  {
    id: 'product-showcase',
    name: 'Product Showcase',
    description:
      'A rotating 3D product (cube with multi-material faces) lit with a soft rim light + ground reflection. Best for e-commerce, hardware launches, and product reveals.',
    sceneType: 'product-showcase',
  },
  {
    id: 'portfolio',
    name: 'Portfolio Cards',
    description:
      'A floating stack of 3D project cards arranged on a circular arc, each tilting toward the camera. Click a card to bring it forward. Best for designer / developer portfolios.',
    sceneType: 'portfolio',
  },
  {
    id: 'landing-page',
    name: '3D Hero Landing',
    description:
      'A cinematic hero scene with a glowing particle field, an animated 3D logo (extruded text), and parallax camera drift. Best for SaaS / startup landing pages.',
    sceneType: 'landing-page',
  },
  {
    id: 'gallery',
    name: 'Image Wall Gallery',
    description:
      'A curved cylindrical wall of image planes the viewer can orbit around. Hover a tile to enlarge. Best for photography, art, and lookbook galleries.',
    sceneType: 'gallery',
  },
  {
    id: 'game',
    name: '3D Mini Game',
    description:
      'A simple collect-the-spheres game: WASD to move, mouse to look, collect glowing orbs before the timer runs out. Best for engagement-driven landing pages.',
    sceneType: 'game',
  },
];

export const WEBSITE_3D_COLOR_SCHEMES: {
  id: Website3DColorScheme;
  label: string;
  bg: string;
  fg: string;
  accent: string;
  accentDim: string;
  panel: string;
  border: string;
  panelSoft: string;
}[] = [
  {
    id: 'dark',
    label: 'Dark (cyber)',
    bg: '#08090A',
    fg: '#E2E8F0',
    accent: '#7DD3FC',
    accentDim: '#38BDF8',
    panel: 'rgba(14,18,24,0.78)',
    border: 'rgba(125,211,252,0.18)',
    panelSoft: 'rgba(18,24,33,0.9)',
  },
  {
    id: 'light',
    label: 'Light (clean)',
    bg: '#F8FAFC',
    fg: '#0F172A',
    accent: '#0EA5E9',
    accentDim: '#0284C7',
    panel: 'rgba(255,255,255,0.86)',
    border: 'rgba(14,165,233,0.22)',
    panelSoft: 'rgba(241,245,249,0.92)',
  },
  {
    id: 'violet',
    label: 'Violet (neon)',
    bg: '#0B0614',
    fg: '#EDE9FE',
    accent: '#C4B5FD',
    accentDim: '#A78BFA',
    panel: 'rgba(20,12,32,0.82)',
    border: 'rgba(196,181,253,0.22)',
    panelSoft: 'rgba(28,18,42,0.92)',
  },
  {
    id: 'ocean',
    label: 'Ocean (teal)',
    bg: '#04141C',
    fg: '#CCFBF1',
    accent: '#5EEAD4',
    accentDim: '#2DD4BF',
    panel: 'rgba(8,28,38,0.84)',
    border: 'rgba(94,234,212,0.22)',
    panelSoft: 'rgba(12,38,50,0.92)',
  },
];

export function getWebsite3DTemplates(): Website3DTemplate[] {
  return WEBSITE_3D_TEMPLATES.slice();
}

export function coerceTemplateId(id: string | undefined): Website3DTemplateId {
  const found = WEBSITE_3D_TEMPLATES.find((t) => t.id === id);
  return found ? found.id : 'product-showcase';
}

export function coerceColorScheme(
  id: string | undefined,
): Website3DColorScheme {
  const found = WEBSITE_3D_COLOR_SCHEMES.find((s) => s.id === id);
  return found ? found.id : 'dark';
}

export function getColorScheme(
  id: string | undefined,
): (typeof WEBSITE_3D_COLOR_SCHEMES)[number] {
  const found = WEBSITE_3D_COLOR_SCHEMES.find((s) => s.id === id);
  return found ?? WEBSITE_3D_COLOR_SCHEMES[0];
}

interface Generate3DWebsiteParams {
  templateId: string;
  title: string;
  description: string;
  colorScheme: Website3DColorScheme | string;
}

/* ------------------------------------------------------------------ */
/* HTML helpers                                                        */
/* ------------------------------------------------------------------ */

function escapeHtml(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function htmlHead(
  title: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  const fontImport = encodeURIComponent(
    'Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700',
  );
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>${escapeHtml(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=${fontImport}&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: ${scheme.bg};
    --fg: ${scheme.fg};
    --accent: ${scheme.accent};
    --accent-dim: ${scheme.accentDim};
    --panel: ${scheme.panel};
    --panel-soft: ${scheme.panelSoft};
    --border: ${scheme.border};
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body {
    width: 100%; height: 100%; overflow: hidden;
    background: var(--bg);
    color: var(--fg);
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    -webkit-font-smoothing: antialiased;
  }
  #scene { position: fixed; inset: 0; width: 100%; height: 100%; display: block; }
  .overlay { position: fixed; pointer-events: none; }
  .overlay > * { pointer-events: auto; }
  .topbar {
    top: 0; left: 0; right: 0;
    padding: 18px 24px;
    display: flex; align-items: center; justify-content: space-between;
    gap: 16px;
    background: linear-gradient(to bottom, var(--panel) 0%, transparent 100%);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
  }
  .brand { display: flex; align-items: center; gap: 10px; }
  .brand .dot {
    width: 9px; height: 9px; border-radius: 50%;
    background: var(--accent);
    box-shadow: 0 0 12px var(--accent);
  }
  .brand .name {
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 700; font-size: 16px; letter-spacing: 0.04em;
    text-transform: uppercase;
  }
  .pill {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 10px; font-weight: 600; letter-spacing: 0.12em;
    text-transform: uppercase;
    padding: 5px 10px; border-radius: 999px;
    color: var(--accent);
    background: color-mix(in srgb, var(--accent) 12%, transparent);
    border: 1px solid color-mix(in srgb, var(--accent) 35%, transparent);
  }
  .hero {
    left: 24px; bottom: 28px; max-width: 540px;
    padding: 22px 24px;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 14px;
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.35);
  }
  .hero h1 {
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 700; font-size: 30px; line-height: 1.12;
    letter-spacing: -0.02em;
    margin-bottom: 10px;
  }
  .hero h1 .accent { color: var(--accent); }
  .hero p {
    font-size: 14px; line-height: 1.55;
    color: color-mix(in srgb, var(--fg) 75%, transparent);
  }
  .controls-hint {
    right: 24px; bottom: 28px;
    padding: 12px 14px;
    background: var(--panel-soft);
    border: 1px solid var(--border);
    border-radius: 10px;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 10px; letter-spacing: 0.08em;
    text-transform: uppercase;
    color: color-mix(in srgb, var(--fg) 70%, transparent);
    line-height: 1.7;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
  }
  .controls-hint .key {
    display: inline-block;
    padding: 1px 6px; border-radius: 4px;
    background: color-mix(in srgb, var(--accent) 18%, transparent);
    border: 1px solid color-mix(in srgb, var(--accent) 35%, transparent);
    color: var(--accent);
    font-weight: 600;
    margin-right: 4px;
  }
  .loader {
    position: fixed; inset: 0;
    display: flex; align-items: center; justify-content: center;
    background: var(--bg);
    z-index: 10;
    transition: opacity 0.6s ease;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 11px; letter-spacing: 0.18em; text-transform: uppercase;
    color: var(--accent);
  }
  .loader.hidden { opacity: 0; pointer-events: none; }
  .loader .ring {
    width: 26px; height: 26px;
    border: 2px solid color-mix(in srgb, var(--accent) 25%, transparent);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-right: 12px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .hud {
    position: fixed; top: 70px; right: 24px;
    padding: 10px 14px;
    background: var(--panel-soft);
    border: 1px solid var(--border);
    border-radius: 10px;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 11px; letter-spacing: 0.06em;
    color: var(--fg);
    line-height: 1.5;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    min-width: 140px;
  }
  .hud .label { color: color-mix(in srgb, var(--fg) 60%, transparent); font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; }
  .hud .value { color: var(--accent); font-weight: 700; font-size: 18px; }
  @media (max-width: 640px) {
    .hero { left: 12px; right: 12px; bottom: 12px; max-width: none; padding: 16px; }
    .hero h1 { font-size: 22px; }
    .hero p { font-size: 12px; }
    .controls-hint { display: none; }
    .topbar { padding: 12px 14px; }
    .hud { right: 12px; top: 60px; }
  }
</style>
</head>
<body>
<div class="loader" id="loader"><div class="ring"></div>Loading 3D Scene…</div>
<canvas id="scene"></canvas>`;
}

function htmlTopBar(title: string): string {
  const short = title.length > 24 ? title.slice(0, 24) + '…' : title;
  return `<div class="overlay topbar">
  <div class="brand">
    <div class="dot"></div>
    <div class="name">${escapeHtml(short)}</div>
  </div>
  <div class="pill">3D · WebGL</div>
</div>`;
}

function htmlHero(title: string, description: string): string {
  // Split title so the last word gets the accent color.
  const words = title.trim().split(/\s+/);
  const head = words.slice(0, -1).join(' ');
  const tail = words[words.length - 1] ?? '';
  const titleHtml = tail
    ? `${escapeHtml(head)} <span class="accent">${escapeHtml(tail)}</span>`
    : `<span class="accent">${escapeHtml(title)}</span>`;
  return `<div class="overlay hero">
  <h1>${titleHtml}</h1>
  <p>${escapeHtml(description)}</p>
</div>`;
}

function htmlFooter(): string {
  return `
</body>
</html>`;
}

/* ------------------------------------------------------------------ */
/* Template generators                                                 */
/* ------------------------------------------------------------------ */

function productShowcase(
  title: string,
  description: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  return `${htmlHead(title, scheme)}
${htmlTopBar(title)}
${htmlHero(title, description)}
<div class="overlay controls-hint">
  <div><span class="key">Drag</span>Rotate</div>
  <div><span class="key">Wheel</span>Zoom</div>
  <div><span class="key">R-Drag</span>Pan</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script>
(function() {
  var canvas = document.getElementById('scene');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  var scene = new THREE.Scene();
  scene.background = new THREE.Color('${scheme.bg}');
  scene.fog = new THREE.Fog('${scheme.bg}', 8, 22);

  var camera = new THREE.PerspectiveCamera(40, window.innerWidth/window.innerHeight, 0.1, 100);
  camera.position.set(4.5, 3, 6);

  var controls = new THREE.OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 3;
  controls.maxDistance = 14;
  controls.maxPolarAngle = Math.PI * 0.52;

  // Lights
  scene.add(new THREE.AmbientLight('${scheme.accent}', 0.18));
  var key = new THREE.DirectionalLight(0xffffff, 0.95);
  key.position.set(5, 8, 5);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 1;
  key.shadow.camera.far = 30;
  scene.add(key);
  var rim = new THREE.DirectionalLight('${scheme.accent}', 0.9);
  rim.position.set(-6, 4, -4);
  scene.add(rim);
  var fill = new THREE.PointLight('${scheme.accentDim}', 0.6, 18);
  fill.position.set(0, 2, 5);
  scene.add(fill);

  // Ground
  var ground = new THREE.Mesh(
    new THREE.CircleGeometry(8, 64),
    new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.4, metalness: 0.3 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -1.1;
  ground.receiveShadow = true;
  scene.add(ground);

  // Grid accent
  var grid = new THREE.GridHelper(16, 32, '${scheme.accent}', '${scheme.accent}');
  grid.material.opacity = 0.08;
  grid.material.transparent = true;
  grid.position.y = -1.09;
  scene.add(grid);

  // Product — multi-material cube
  var faceColors = [
    '${scheme.accent}', '${scheme.accentDim}',
    '${scheme.fg}', '${scheme.accent}',
    '${scheme.accentDim}', '${scheme.fg}',
  ];
  var mats = faceColors.map(function(c) {
    return new THREE.MeshStandardMaterial({
      color: c, roughness: 0.32, metalness: 0.55,
      emissive: c, emissiveIntensity: 0.08,
    });
  });
  var cube = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 2), mats);
  cube.castShadow = true;
  cube.receiveShadow = true;
  scene.add(cube);

  // Wireframe overlay
  var wire = new THREE.LineSegments(
    new THREE.EdgesGeometry(cube.geometry),
    new THREE.LineBasicMaterial({ color: '${scheme.accent}', transparent: true, opacity: 0.6 })
  );
  cube.add(wire);

  // Floating rings around the product
  var ringGroup = new THREE.Group();
  for (var i = 0; i < 3; i++) {
    var r = new THREE.Mesh(
      new THREE.TorusGeometry(2.2 + i * 0.4, 0.012, 8, 64),
      new THREE.MeshBasicMaterial({ color: '${scheme.accent}', transparent: true, opacity: 0.35 - i * 0.08 })
    );
    r.rotation.x = Math.PI / 2 + i * 0.3;
    r.rotation.y = i * 0.4;
    ringGroup.add(r);
  }
  scene.add(ringGroup);

  // Particles
  var pcount = 220;
  var pgeom = new THREE.BufferGeometry();
  var ppos = new Float32Array(pcount * 3);
  for (var i = 0; i < pcount; i++) {
    ppos[i*3] = (Math.random() - 0.5) * 18;
    ppos[i*3+1] = Math.random() * 8 - 1;
    ppos[i*3+2] = (Math.random() - 0.5) * 18;
  }
  pgeom.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
  var particles = new THREE.Points(pgeom, new THREE.PointsMaterial({
    color: '${scheme.accent}', size: 0.05, transparent: true, opacity: 0.7,
    blending: THREE.AdditiveBlending,
  }));
  scene.add(particles);

  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  var t = 0;
  function loop() {
    requestAnimationFrame(loop);
    t += 0.01;
    cube.rotation.y += 0.005;
    cube.rotation.x = Math.sin(t * 0.3) * 0.15;
    cube.position.y = Math.sin(t * 0.8) * 0.12;
    ringGroup.rotation.y += 0.002;
    ringGroup.rotation.x += 0.001;
    particles.rotation.y += 0.0005;
    controls.update();
    renderer.render(scene, camera);
  }
  loop();
  setTimeout(function() {
    document.getElementById('loader').classList.add('hidden');
  }, 200);
})();
</script>${htmlFooter()}`;
}

function portfolio(
  title: string,
  description: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  return `${htmlHead(title, scheme)}
${htmlTopBar(title)}
${htmlHero(title, description)}
<div class="overlay controls-hint">
  <div><span class="key">Drag</span>Rotate</div>
  <div><span class="key">Wheel</span>Zoom</div>
  <div><span class="key">Click</span>Select card</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script>
(function() {
  var canvas = document.getElementById('scene');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  var scene = new THREE.Scene();
  scene.background = new THREE.Color('${scheme.bg}');

  var camera = new THREE.PerspectiveCamera(45, window.innerWidth/window.innerHeight, 0.1, 100);
  camera.position.set(0, 0.5, 9);

  var controls = new THREE.OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 5;
  controls.maxDistance = 16;
  controls.maxPolarAngle = Math.PI * 0.65;
  controls.minPolarAngle = Math.PI * 0.3;

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  var key = new THREE.DirectionalLight(0xffffff, 0.7);
  key.position.set(4, 6, 6);
  scene.add(key);
  var accent = new THREE.PointLight('${scheme.accent}', 1.4, 14);
  accent.position.set(0, 2, 4);
  scene.add(accent);

  // Build 6 portfolio cards in an arc
  var cards = [];
  var labels = ['Project Alpha','Designer Hub','Brand Kit','Mobile App','Data Viz','Webflow'];
  var cardCount = labels.length;
  var arc = Math.PI * 0.95;
  var radius = 5.2;
  for (var i = 0; i < cardCount; i++) {
    var pct = cardCount === 1 ? 0.5 : i / (cardCount - 1);
    var angle = -arc/2 + arc * pct;
    var group = new THREE.Group();

    // Card body (plane with rounded look via shader-less approach)
    var cardGeo = new THREE.PlaneGeometry(2, 2.6, 1, 1);
    var cardMat = new THREE.MeshStandardMaterial({
      color: 0x0d0d12, roughness: 0.5, metalness: 0.4,
      emissive: '${scheme.accent}', emissiveIntensity: 0.04,
      side: THREE.DoubleSide,
    });
    var card = new THREE.Mesh(cardGeo, cardMat);
    group.add(card);

    // Border frame
    var frame = new THREE.LineSegments(
      new THREE.EdgesGeometry(cardGeo),
      new THREE.LineBasicMaterial({ color: '${scheme.accent}', transparent: true, opacity: 0.7 })
    );
    group.add(frame);

    // Top accent bar
    var bar = new THREE.Mesh(
      new THREE.PlaneGeometry(2, 0.08),
      new THREE.MeshBasicMaterial({ color: '${scheme.accent}' })
    );
    bar.position.y = 1.26;
    group.add(bar);

    // Project number
    var num = new THREE.Mesh(
      new THREE.PlaneGeometry(0.5, 0.5),
      new THREE.MeshBasicMaterial({ color: '${scheme.accentDim}', transparent: true, opacity: 0.4 })
    );
    num.position.set(-0.7, 1.0, 0.01);
    group.add(num);

    group.position.set(
      Math.sin(angle) * radius,
      0,
      -Math.cos(angle) * radius + radius
    );
    group.lookAt(0, 0, radius);
    group.userData = { idx: i, label: labels[i], baseY: 0, baseAngle: angle, targetScale: 1 };
    scene.add(group);
    cards.push(group);
  }

  // Particle backdrop
  var pcount = 180;
  var pgeom = new THREE.BufferGeometry();
  var ppos = new Float32Array(pcount * 3);
  for (var i = 0; i < pcount; i++) {
    ppos[i*3] = (Math.random() - 0.5) * 30;
    ppos[i*3+1] = (Math.random() - 0.5) * 20;
    ppos[i*3+2] = (Math.random() - 0.5) * 30 - 5;
  }
  pgeom.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
  var particles = new THREE.Points(pgeom, new THREE.PointsMaterial({
    color: '${scheme.accent}', size: 0.04, transparent: true, opacity: 0.5,
    blending: THREE.AdditiveBlending,
  }));
  scene.add(particles);

  // Raycaster for click-to-focus
  var raycaster = new THREE.Raycaster();
  var mouse = new THREE.Vector2();
  var focused = -1;
  canvas.addEventListener('click', function(ev) {
    mouse.x = (ev.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(ev.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    var meshes = cards.reduce(function(acc, g) {
      return acc.concat(g.children);
    }, []);
    var hits = raycaster.intersectObjects(meshes);
    if (hits.length > 0) {
      var card = hits[0].object.parent;
      focused = (focused === card.userData.idx) ? -1 : card.userData.idx;
    }
  });

  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  var t = 0;
  function loop() {
    requestAnimationFrame(loop);
    t += 0.01;
    cards.forEach(function(g) {
      var isFocused = g.userData.idx === focused;
      var targetScale = isFocused ? 1.25 : 1;
      var targetY = isFocused ? 0.6 : 0;
      g.scale.x += (targetScale - g.scale.x) * 0.1;
      g.scale.y += (targetScale - g.scale.y) * 0.1;
      g.scale.z += (targetScale - g.scale.z) * 0.1;
      g.position.y += (targetY - g.position.y) * 0.1;
      g.rotation.z = Math.sin(t * 0.5 + g.userData.idx) * 0.02;
    });
    particles.rotation.y += 0.0006;
    controls.update();
    renderer.render(scene, camera);
  }
  loop();
  setTimeout(function() {
    document.getElementById('loader').classList.add('hidden');
  }, 200);
})();
</script>${htmlFooter()}`;
}

function landingPage(
  title: string,
  description: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  return `${htmlHead(title, scheme)}
${htmlTopBar(title)}
${htmlHero(title, description)}
<div class="overlay controls-hint">
  <div><span class="key">Move</span>Parallax</div>
  <div><span class="key">Drag</span>Orbit</div>
  <div><span class="key">Wheel</span>Zoom</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script>
(function() {
  var canvas = document.getElementById('scene');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  var scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2('${scheme.bg}', 0.04);

  var camera = new THREE.PerspectiveCamera(50, window.innerWidth/window.innerHeight, 0.1, 200);
  camera.position.set(0, 0, 12);

  var controls = new THREE.OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.enablePan = false;
  controls.minDistance = 6;
  controls.maxDistance = 22;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 0.4;

  // Lights
  scene.add(new THREE.AmbientLight(0xffffff, 0.4));
  var key = new THREE.PointLight('${scheme.accent}', 2, 40);
  key.position.set(0, 0, 8);
  scene.add(key);
  var back = new THREE.PointLight('${scheme.accentDim}', 1.5, 40);
  back.position.set(-8, 4, -8);
  scene.add(back);

  // Animated 3D logo — torus knot
  var knot = new THREE.Mesh(
    new THREE.TorusKnotGeometry(1.6, 0.45, 200, 32, 2, 3),
    new THREE.MeshStandardMaterial({
      color: '${scheme.accent}', metalness: 0.7, roughness: 0.25,
      emissive: '${scheme.accent}', emissiveIntensity: 0.35,
    })
  );
  scene.add(knot);

  // Inner glow sphere
  var glow = new THREE.Mesh(
    new THREE.SphereGeometry(0.9, 32, 32),
    new THREE.MeshBasicMaterial({
      color: '${scheme.accent}', transparent: true, opacity: 0.35,
    })
  );
  scene.add(glow);

  // Particle field
  var pcount = 1500;
  var pgeom = new THREE.BufferGeometry();
  var ppos = new Float32Array(pcount * 3);
  var psiz = new Float32Array(pcount);
  for (var i = 0; i < pcount; i++) {
    var r = 6 + Math.random() * 18;
    var theta = Math.random() * Math.PI * 2;
    var phi = Math.acos(2 * Math.random() - 1);
    ppos[i*3] = r * Math.sin(phi) * Math.cos(theta);
    ppos[i*3+1] = r * Math.sin(phi) * Math.sin(theta);
    ppos[i*3+2] = r * Math.cos(phi);
    psiz[i] = Math.random() * 0.05 + 0.02;
  }
  pgeom.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
  var particles = new THREE.Points(pgeom, new THREE.PointsMaterial({
    color: '${scheme.accent}', size: 0.06, transparent: true, opacity: 0.8,
    blending: THREE.AdditiveBlending, sizeAttenuation: true,
  }));
  scene.add(particles);

  // Orbit rings
  for (var r = 0; r < 4; r++) {
    var rr = 3.2 + r * 1.2;
    var ring = new THREE.Mesh(
      new THREE.TorusGeometry(rr, 0.005, 8, 100),
      new THREE.MeshBasicMaterial({
        color: '${scheme.accent}', transparent: true,
        opacity: 0.18 - r * 0.03,
      })
    );
    ring.rotation.x = Math.PI / 2 + r * 0.15;
    ring.rotation.y = r * 0.4;
    scene.add(ring);
  }

  // Mouse parallax
  var mouseX = 0, mouseY = 0;
  window.addEventListener('pointermove', function(e) {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 0.4;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 0.4;
  });

  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  var t = 0;
  function loop() {
    requestAnimationFrame(loop);
    t += 0.01;
    knot.rotation.x = t * 0.3;
    knot.rotation.y = t * 0.4;
    glow.scale.setScalar(1 + Math.sin(t * 2) * 0.08);
    particles.rotation.y = t * 0.02;
    particles.rotation.x = t * 0.01;
    camera.position.x += (mouseX * 4 - camera.position.x) * 0.04;
    camera.position.y += (-mouseY * 4 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
    controls.update();
    renderer.render(scene, camera);
  }
  loop();
  setTimeout(function() {
    document.getElementById('loader').classList.add('hidden');
  }, 200);
})();
</script>${htmlFooter()}`;
}

function gallery(
  title: string,
  description: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  return `${htmlHead(title, scheme)}
${htmlTopBar(title)}
${htmlHero(title, description)}
<div class="overlay controls-hint">
  <div><span class="key">Drag</span>Orbit wall</div>
  <div><span class="key">Wheel</span>Zoom</div>
  <div><span class="key">Hover</span>Highlight tile</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script>
(function() {
  var canvas = document.getElementById('scene');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  var scene = new THREE.Scene();
  scene.background = new THREE.Color('${scheme.bg}');

  var camera = new THREE.PerspectiveCamera(55, window.innerWidth/window.innerHeight, 0.1, 100);
  camera.position.set(0, 0, 0.5);

  var controls = new THREE.OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.enablePan = false;
  controls.minDistance = 0.1;
  controls.maxDistance = 12;

  scene.add(new THREE.AmbientLight(0xffffff, 0.7));
  var key = new THREE.DirectionalLight(0xffffff, 0.6);
  key.position.set(5, 5, 5);
  scene.add(key);
  var accent = new THREE.PointLight('${scheme.accent}', 1.0, 20);
  accent.position.set(0, 0, 5);
  scene.add(accent);

  // Build cylindrical image wall
  var tiles = [];
  var rows = 5, cols = 14;
  var radius = 6;
  var tileW = 1.4, tileH = 1.0;
  var palette = [
    '${scheme.accent}', '${scheme.accentDim}', '${scheme.fg}',
    '${scheme.accent}', '${scheme.accentDim}',
  ];
  for (var row = 0; row < rows; row++) {
    for (var col = 0; col < cols; col++) {
      var angle = (col / cols) * Math.PI * 2 + (row % 2) * (Math.PI / cols);
      var y = (row - (rows - 1) / 2) * (tileH + 0.25);
      var color = palette[(row * cols + col) % palette.length];

      var tile = new THREE.Mesh(
        new THREE.PlaneGeometry(tileW, tileH),
        new THREE.MeshStandardMaterial({
          color: color, roughness: 0.4, metalness: 0.3,
          emissive: color, emissiveIntensity: 0.12,
          side: THREE.DoubleSide,
          transparent: true, opacity: 0.85,
        })
      );
      tile.position.set(
        Math.sin(angle) * radius,
        y,
        -Math.cos(angle) * radius
      );
      tile.lookAt(0, y, 0);
      tile.userData = {
        baseColor: color, baseEmissive: 0.12, baseScale: 1,
        baseOpacity: 0.85,
      };
      scene.add(tile);
      tiles.push(tile);

      // Frame border
      var frame = new THREE.LineSegments(
        new THREE.EdgesGeometry(tile.geometry),
        new THREE.LineBasicMaterial({ color: '${scheme.accent}', transparent: true, opacity: 0.4 })
      );
      tile.add(frame);
    }
  }

  // Floor reflection (subtle plane)
  var floor = new THREE.Mesh(
    new THREE.CircleGeometry(radius + 2, 64),
    new THREE.MeshStandardMaterial({
      color: 0x050505, roughness: 0.2, metalness: 0.6,
    })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -3.2;
  scene.add(floor);

  // Raycaster hover
  var raycaster = new THREE.Raycaster();
  var mouse = new THREE.Vector2(-10, -10);
  canvas.addEventListener('pointermove', function(e) {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
  });

  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  function loop() {
    requestAnimationFrame(loop);
    raycaster.setFromCamera(mouse, camera);
    var hits = raycaster.intersectObjects(tiles);
    var hovered = hits.length > 0 ? hits[0].object : null;
    tiles.forEach(function(t) {
      var isHover = t === hovered;
      var ts = isHover ? 1.4 : 1;
      var te = isHover ? 0.55 : t.userData.baseEmissive;
      var to = isHover ? 1.0 : t.userData.baseOpacity;
      t.scale.x += (ts - t.scale.x) * 0.18;
      t.scale.y += (ts - t.scale.y) * 0.18;
      t.material.emissiveIntensity += (te - t.material.emissiveIntensity) * 0.18;
      t.material.opacity += (to - t.material.opacity) * 0.18;
    });
    controls.update();
    renderer.render(scene, camera);
  }
  loop();
  setTimeout(function() {
    document.getElementById('loader').classList.add('hidden');
  }, 200);
})();
</script>${htmlFooter()}`;
}

function game(
  title: string,
  description: string,
  scheme: (typeof WEBSITE_3D_COLOR_SCHEMES)[number],
): string {
  return `${htmlHead(title, scheme)}
${htmlTopBar(title)}
${htmlHero(title, description)}
<div class="overlay hud">
  <div class="label">Score</div>
  <div class="value" id="score">0</div>
  <div class="label" style="margin-top:6px;">Time</div>
  <div class="value" id="time">60</div>
</div>
<div class="overlay controls-hint">
  <div><span class="key">W A S D</span>Move</div>
  <div><span class="key">Mouse</span>Look</div>
  <div><span class="key">Click</span>Lock cursor</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/PointerLockControls.js"></script>
<script>
(function() {
  var canvas = document.getElementById('scene');
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  var scene = new THREE.Scene();
  scene.background = new THREE.Color('${scheme.bg}');
  scene.fog = new THREE.Fog('${scheme.bg}', 12, 32);

  var camera = new THREE.PerspectiveCamera(70, window.innerWidth/window.innerHeight, 0.1, 100);
  camera.position.set(0, 1.5, 0);

  var controls = new THREE.PointerLockControls(camera, canvas);
  canvas.addEventListener('click', function() { controls.lock(); });
  controls.addEventListener('lock', function() {});
  controls.addEventListener('unlock', function() {});
  scene.add(controls.getObject());

  scene.add(new THREE.AmbientLight(0xffffff, 0.45));
  var sun = new THREE.DirectionalLight(0xffffff, 0.7);
  sun.position.set(10, 20, 10);
  scene.add(sun);
  var accent = new THREE.PointLight('${scheme.accent}', 1.2, 25);
  accent.position.set(0, 5, 0);
  scene.add(accent);

  // Ground
  var ground = new THREE.Mesh(
    new THREE.PlaneGeometry(50, 50, 50, 50),
    new THREE.MeshStandardMaterial({ color: 0x070808, roughness: 0.7, metalness: 0.3 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  // Grid
  var grid = new THREE.GridHelper(50, 50, '${scheme.accent}', '${scheme.accent}');
  grid.material.opacity = 0.12;
  grid.material.transparent = true;
  scene.add(grid);

  // Boundary walls
  var wallMat = new THREE.MeshStandardMaterial({
    color: '${scheme.accent}', transparent: true, opacity: 0.15,
    emissive: '${scheme.accent}', emissiveIntensity: 0.4, side: THREE.DoubleSide,
  });
  [[0,0,25,50],[0,0,-25,50],[25,0,0,50],[-25,0,0,50]].forEach(function(w) {
    var wall = new THREE.Mesh(new THREE.PlaneGeometry(w[3], 4), wallMat);
    wall.position.set(w[0], 2, w[1]);
    wall.lookAt(0, 2, 0);
    scene.add(wall);
  });

  // Collectible orbs
  var orbs = [];
  var orbCount = 14;
  function spawnOrbs() {
    orbs.forEach(function(o) { scene.remove(o); });
    orbs = [];
    for (var i = 0; i < orbCount; i++) {
      var orb = new THREE.Mesh(
        new THREE.SphereGeometry(0.35, 16, 16),
        new THREE.MeshStandardMaterial({
          color: '${scheme.accent}', emissive: '${scheme.accent}', emissiveIntensity: 0.9,
          roughness: 0.3, metalness: 0.4,
        })
      );
      orb.position.set(
        (Math.random() - 0.5) * 44,
        0.6,
        (Math.random() - 0.5) * 44
      );
      // Halo
      var halo = new THREE.Mesh(
        new THREE.SphereGeometry(0.55, 16, 16),
        new THREE.MeshBasicMaterial({
          color: '${scheme.accent}', transparent: true, opacity: 0.18,
        })
      );
      orb.add(halo);
      orb.userData = { halo: halo };
      scene.add(orb);
      orbs.push(orb);
    }
  }
  spawnOrbs();

  // Movement
  var keys = { w: false, a: false, s: false, d: false };
  var velocity = new THREE.Vector3();
  var direction = new THREE.Vector3();
  window.addEventListener('keydown', function(e) {
    var k = e.key.toLowerCase();
    if (k === 'w' || k === 'arrowup') keys.w = true;
    if (k === 's' || k === 'arrowdown') keys.s = true;
    if (k === 'a' || k === 'arrowleft') keys.a = true;
    if (k === 'd' || k === 'arrowright') keys.d = true;
  });
  window.addEventListener('keyup', function(e) {
    var k = e.key.toLowerCase();
    if (k === 'w' || k === 'arrowup') keys.w = false;
    if (k === 's' || k === 'arrowdown') keys.s = false;
    if (k === 'a' || k === 'arrowleft') keys.a = false;
    if (k === 'd' || k === 'arrowright') keys.d = false;
  });

  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // Game state
  var score = 0;
  var timeLeft = 60;
  var gameOver = false;
  var prevTime = performance.now();
  var scoreEl = document.getElementById('score');
  var timeEl = document.getElementById('time');

  setInterval(function() {
    if (gameOver) return;
    timeLeft--;
    if (timeEl) timeEl.textContent = timeLeft;
    if (timeLeft <= 0) {
      gameOver = true;
      timeLeft = 0;
    }
  }, 1000);

  function loop() {
    requestAnimationFrame(loop);
    var now = performance.now();
    var dt = Math.min((now - prevTime) / 1000, 0.1);
    prevTime = now;

    if (!gameOver && controls.isLocked) {
      velocity.x -= velocity.x * 10 * dt;
      velocity.z -= velocity.z * 10 * dt;
      direction.z = Number(keys.w) - Number(keys.s);
      direction.x = Number(keys.d) - Number(keys.a);
      direction.normalize();
      if (keys.w || keys.s) velocity.z -= direction.z * 30 * dt;
      if (keys.a || keys.d) velocity.x -= direction.x * 30 * dt;
      controls.moveRight(-velocity.x * dt);
      controls.moveForward(-velocity.z * dt);

      // Boundary clamp
      var obj = controls.getObject();
      obj.position.x = Math.max(-23, Math.min(23, obj.position.x));
      obj.position.z = Math.max(-23, Math.min(23, obj.position.z));
      obj.position.y = 1.5;

      // Orb collection
      for (var i = orbs.length - 1; i >= 0; i--) {
        var orb = orbs[i];
        if (obj.position.distanceTo(orb.position) < 1.1) {
          scene.remove(orb);
          orbs.splice(i, 1);
          score++;
          if (scoreEl) scoreEl.textContent = score;
          if (orbs.length === 0) spawnOrbs();
        } else {
          orb.rotation.y += dt * 2;
          orb.position.y = 0.6 + Math.sin(now * 0.003 + i) * 0.18;
        }
      }
    }

    renderer.render(scene, camera);
  }
  loop();
  setTimeout(function() {
    document.getElementById('loader').classList.add('hidden');
  }, 200);
})();
</script>${htmlFooter()}`;
}

/* ------------------------------------------------------------------ */
/* Public generator                                                    */
/* ------------------------------------------------------------------ */

export function generate3DWebsite(params: Generate3DWebsiteParams): string {
  const templateId = coerceTemplateId(params.templateId);
  const scheme = getColorScheme(params.colorScheme);
  const title = (params.title ?? '').trim() || 'Untitled 3D Website';
  const description =
    (params.description ?? '').trim() ||
    'A 3D website built with Three.js — drag to orbit, scroll to zoom.';

  switch (templateId) {
    case 'product-showcase':
      return productShowcase(title, description, scheme);
    case 'portfolio':
      return portfolio(title, description, scheme);
    case 'landing-page':
      return landingPage(title, description, scheme);
    case 'gallery':
      return gallery(title, description, scheme);
    case 'game':
      return game(title, description, scheme);
    default:
      return productShowcase(title, description, scheme);
  }
}

/** Convenience: returns HTML byte size in KB rounded to 1 decimal. */
export function website3dSizeKb(html: string): number {
  return Math.round((html.length / 1024) * 10) / 10;
}
