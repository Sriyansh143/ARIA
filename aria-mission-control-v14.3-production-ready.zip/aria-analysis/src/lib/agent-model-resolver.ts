// =====================================================================
// agent-model-resolver.ts — Per-agent model diversity
// =====================================================================
// PRODUCTION ENHANCEMENT (v11): Instead of all 64 agents defaulting to
// GLM-4.6, each agent gets a model assigned based on its ROLE. This makes
// the fleet resilient (one provider's outage doesn't take down everyone)
// and lets specialist agents use specialist models (e.g. the coder agent
// uses a coding model, the vision agent uses a vision model).
//
// Resolution order:
//   1. Pinned assignment in DB (AgentModelAssignment with taskRouting='pinned')
//   2. Role-based default map (below) — picks a model appropriate to the
//      agent's role/codename, using whatever providers are configured.
//   3. Fallback to GLM-4.6 (always available via z-ai).
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export interface ResolvedModel {
  modelId: string;
  providerKey: string;
  reason: string;
  source: 'pinned' | 'role-based' | 'fallback';
}

// Role → preferred model spec. The modelId is a pattern matched against
// enabled models in the DB; if none match, we fall back to GLM-4.6.
// This spreads the fleet across multiple providers for resilience.
const ROLE_MODEL_MAP: Array<{
  match: RegExp;            // matches agent role or codename
  preferredModel: string;   // model id pattern
  preferredProvider: string;
  reason: string;
}> = [
  // ── Engineering / Code ──
  { match: /orion|orchestrat|ceo|director|cto/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Top-tier reasoning for orchestration' },
  { match: /orion|orchestrat|ceo|director|cto/i, preferredModel: 'gpt-4o', preferredProvider: 'openai', reason: 'Strong general reasoning' },
  { match: /atlas|engineer|cod|build|deploy|forge|devops|mobile/i, preferredModel: 'Qwen/Qwen2.5-Coder-32B-Instruct', preferredProvider: 'siliconflow', reason: 'Specialized coding model' },
  { match: /atlas|engineer|cod|build|deploy|forge|devops|mobile/i, preferredModel: 'deepseek-coder', preferredProvider: 'deepseek', reason: 'Strong code generation' },
  { match: /atlas|engineer|cod|build|deploy|forge|devops|mobile/i, preferredModel: 'codestral-latest', preferredProvider: 'mistral', reason: 'Mistral coding model' },

  // ── Research ──
  { match: /vega|research|investigat|fact|synth|writer|docs/i, preferredModel: 'deepseek-ai/DeepSeek-R1', preferredProvider: 'siliconflow', reason: 'Deep research reasoning' },
  { match: /vega|research|investigat|fact|synth|writer|docs/i, preferredModel: 'deepseek-reasoner', preferredProvider: 'deepseek', reason: 'Research-grade chain-of-thought' },

  // ── Data / Analytics ──
  { match: /nova|data|analy|scientist|ml|bi|warehouse|etl|sql|dashboard/i, preferredModel: 'deepseek-ai/DeepSeek-V3', preferredProvider: 'siliconflow', reason: 'Strong analytical capability' },
  { match: /nova|data|analy|scientist|ml|bi|warehouse|etl|sql|dashboard/i, preferredModel: 'gpt-4o-mini', preferredProvider: 'openai', reason: 'Fast analysis' },
  { match: /nova|data|analy|scientist|ml|bi|warehouse|etl|sql|dashboard/i, preferredModel: 'mixtral-8x22b', preferredProvider: 'mistral', reason: 'Large mixture-of-experts analysis' },

  // ── Design / Creative ──
  { match: /echo|brand|design|visual|ui|ux|graphic|illustration|motion|creative/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Best creative writing + design reasoning' },
  { match: /echo|brand|design|visual|ui|ux|graphic|illustration|motion|creative/i, preferredModel: 'mistral-large-latest', preferredProvider: 'mistral', reason: 'Nuanced creative output' },

  // ── Product / Strategy ──
  { match: /sage|product|strateg|pm|roadmap|market|positioning|pricing|priorit/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Strategic reasoning' },
  { match: /sage|product|strateg|pm|roadmap|market|positioning|pricing|priorit/i, preferredModel: 'command-r-plus', preferredProvider: 'cohere', reason: 'Strong RAG reasoning for product decisions' },

  // ── Marketing / Growth ──
  { match: /helios|content|seo|social|growth|marketing|blog|twitter|linkedin/i, preferredModel: 'llama-3.3-70b-versatile', preferredProvider: 'groq', reason: 'Fast content generation' },
  { match: /helios|content|seo|social|growth|marketing|blog|twitter|linkedin/i, preferredModel: 'mistral-small-latest', preferredProvider: 'mistral', reason: 'Fast marketing copy' },

  // ── Sales ──
  { match: /antares|sales|account|channel|prospect|demo|negotiat|closing/i, preferredModel: 'gpt-4o-mini', preferredProvider: 'openai', reason: 'Fast sales communication' },
  { match: /antares|sales|account|channel|prospect|demo|negotiat|closing/i, preferredModel: 'command-r', preferredProvider: 'cohere', reason: 'Strong sales reasoning' },

  // ── Finance ──
  { match: /perseus|finance|cfo|billing|pnl|capital|board/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Precise financial reasoning' },
  { match: /perseus|finance|cfo|billing|pnl|capital|board/i, preferredModel: 'deepseek-ai/DeepSeek-V3', preferredProvider: 'siliconflow', reason: 'Strong analytical finance' },

  // ── Legal ──
  { match: /aegis|legal|counsel|patent|trademark|compliance|officer/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Precise legal reasoning' },
  { match: /aegis|legal|counsel|patent|trademark|compliance|officer/i, preferredModel: 'command-r-plus', preferredProvider: 'cohere', reason: 'Strong RAG for legal docs' },

  // ── HR / People ──
  { match: /hr|human resource|recruit|hiring|people/i, preferredModel: 'llama-3.3-70b-versatile', preferredProvider: 'groq', reason: 'Fast HR communication' },

  // ── Operations ──
  { match: /ops|operations|logistics|supply|procurement/i, preferredModel: 'mixtral-8x7b-32768', preferredProvider: 'groq', reason: 'Fast operations model' },

  // ── Security ──
  { match: /security|guard|protect|audit|risk/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Precise security reasoning' },
  { match: /security|guard|protect|audit|risk/i, preferredModel: 'deepseek-coder', preferredProvider: 'deepseek', reason: 'Code security analysis' },

  // ── Support ──
  { match: /support|help|ticket|customer|service/i, preferredModel: 'gpt-4o-mini', preferredProvider: 'openai', reason: 'Fast customer support' },
  { match: /support|help|ticket|customer|service/i, preferredModel: 'gemma2-9b-it', preferredProvider: 'groq', reason: 'Fast support responses' },

  // ── Content ──
  { match: /content|writer|copy|blog|article|documentation/i, preferredModel: 'mistral-large-latest', preferredProvider: 'mistral', reason: 'Best content generation' },
  { match: /content|writer|copy|blog|article|documentation/i, preferredModel: 'claude-3.5-sonnet', preferredProvider: 'anthropic', reason: 'Creative writing' },

  // ── QA / Testing ──
  { match: /qa|quality|test|bug|verify|validation/i, preferredModel: 'deepseek-coder', preferredProvider: 'deepseek', reason: 'Code review + testing' },
  { match: /qa|quality|test|bug|verify|validation/i, preferredModel: 'Qwen/Qwen2.5-Coder-32B-Instruct', preferredProvider: 'siliconflow', reason: 'Code quality analysis' },

  // ── Infrastructure ──
  { match: /infra|server|cloud|deploy|kubernetes|docker/i, preferredModel: 'mixtral-8x22b-instruct-v0.1', preferredProvider: 'nvidia', reason: 'Infrastructure reasoning' },
  { match: /infra|server|cloud|deploy|kubernetes|docker/i, preferredModel: 'llama-3.3-70b-versatile', preferredProvider: 'groq', reason: 'Fast infra commands' },

  // ── Memory / Knowledge ──
  { match: /memory|knowledge|learn|index|retrieve/i, preferredModel: 'glm-4.6', preferredProvider: 'zai', reason: 'Excellent knowledge synthesis' },
  { match: /memory|knowledge|learn|index|retrieve/i, preferredModel: 'command-r-plus', preferredProvider: 'cohere', reason: 'Strong RAG retrieval' },

  // ── Monitoring ──
  { match: /pulse|monitor|watch|health|observ|metric|alert/i, preferredModel: 'llama-3.1-8b-instant', preferredProvider: 'groq', reason: 'Fast monitoring model' },
  { match: /pulse|monitor|watch|health|observ|metric|alert/i, preferredModel: 'gemma2-9b-it', preferredProvider: 'groq', reason: 'Lightweight monitoring' },

  // ── Communication ──
  { match: /comm|email|outreach|message|chat|broadcast/i, preferredModel: 'llama-3.3-70b-versatile', preferredProvider: 'groq', reason: 'Fast comms model' },
  { match: /comm|email|outreach|message|chat|broadcast/i, preferredModel: 'gemini-2.0-flash-exp', preferredProvider: 'gemini', reason: 'Fast multimodal comms' },
];

/**
 * Resolve the best model for a given agent.
 * Checks pinned DB assignment first, then role-based map, then GLM-4.6.
 */
export async function resolveAgentModel(
  agentCodename: string,
  agentRole?: string,
): Promise<ResolvedModel> {
  const haystack = `${agentCodename} ${agentRole ?? ''}`.toLowerCase();

  // 1. Pinned assignment in DB
  try {
    const pinned = await db.agentModelAssignment.findFirst({
      where: { agentCodename, enabled: true, taskRouting: 'pinned' },
    });
    if (pinned) {
      return {
        modelId: pinned.modelId,
        providerKey: pinned.providerKey,
        reason: pinned.reason ?? `Pinned assignment for ${agentCodename}`,
        source: 'pinned',
      };
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'agent-model-resolver: pinned lookup failed');
  }

  // 2. Role-based map — find the first matching spec whose model exists in DB.
  try {
    const enabledModels = await db.model.findMany({
      where: { enabled: true, status: 'active' },
      select: { modelId: true, providerKey: true },
      take: 500,
    });
    for (const spec of ROLE_MODEL_MAP) {
      if (!spec.match.test(haystack)) continue;
      const match = enabledModels.find(
        (m) =>
          m.modelId.toLowerCase().includes(spec.preferredModel.toLowerCase()) ||
          m.providerKey.toLowerCase() === spec.preferredProvider.toLowerCase(),
      );
      if (match) {
        return {
          modelId: match.modelId,
          providerKey: match.providerKey,
          reason: spec.reason,
          source: 'role-based',
        };
      }
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'agent-model-resolver: role-based lookup failed');
  }

  // 3. Fallback — GLM-4.6 via z-ai (always available)
  return {
    modelId: 'glm-4.6',
    providerKey: 'zai',
    reason: `Default fallback for ${agentCodename} (role: ${agentRole ?? 'unknown'})`,
    source: 'fallback',
  };
}

/**
 * Resolve models for ALL agents at once (used by the fleet dashboard +
 * seed script to populate AgentModelAssignment rows).
 */
export async function resolveAllAgentModels(): Promise<Array<{ codename: string; resolved: ResolvedModel }>> {
  const agents = await db.agent.findMany({ select: { codename: true, role: true } });
  const results: Array<{ codename: string; resolved: ResolvedModel }> = [];
  for (const a of agents) {
    const resolved = await resolveAgentModel(a.codename, a.role);
    results.push({ codename: a.codename, resolved });
  }
  return results;
}

/**
 * Seed default role-based assignments for every agent that doesn't have one.
 * Idempotent — safe to call repeatedly.
 */
export async function seedAgentModelAssignments(): Promise<{ created: number; updated: number }> {
  const agents = await db.agent.findMany({ select: { codename: true, role: true } });
  let created = 0;
  let updated = 0;
  for (const a of agents) {
    const resolved = await resolveAgentModel(a.codename, a.role);
    try {
      const existing = await db.agentModelAssignment.findUnique({ where: { agentCodename: a.codename } });
      if (existing) {
        if (existing.modelId !== resolved.modelId || existing.providerKey !== resolved.providerKey) {
          await db.agentModelAssignment.update({
            where: { agentCodename: a.codename },
            data: {
              modelId: resolved.modelId,
              providerKey: resolved.providerKey,
              taskRouting: resolved.source === 'pinned' ? 'pinned' : 'role-based',
              reason: resolved.reason,
            },
          });
          updated += 1;
        }
      } else {
        await db.agentModelAssignment.create({
          data: {
            agentCodename: a.codename,
            modelId: resolved.modelId,
            providerKey: resolved.providerKey,
            taskRouting: resolved.source === 'pinned' ? 'pinned' : 'role-based',
            reason: resolved.reason,
          },
        });
        created += 1;
      }
    } catch (err) {
      logger.warn({ codename: a.codename, err: err instanceof Error ? err.message : String(err) }, 'agent-model-resolver: seed failed for agent');
    }
  }
  logger.info({ created, updated, total: agents.length }, 'agent-model-resolver: seeding complete');
  return { created, updated };
}
