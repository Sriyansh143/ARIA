// =====================================================================
// smart-model-router.ts — Intelligent model selection across 455 models
// =====================================================================
// USER RULE: "use all available 455 models with best model working on
// relevant task"
//
// This module analyzes the task type and selects the optimal model:
//   - Code generation → coding-specialist models (Qwen Coder, DeepSeek)
//   - Vision/image analysis → vision models (Qwen-VL, LLaVA)
//   - Reasoning/analysis → reasoning models (DeepSeek-R1, o1-style)
//   - Fast chat → fast models (Llama 3.1 8B, Phi-3)
//   - Long context → large context models (128K+)
//   - Creative writing → creative models (Claude, GLM-4)
//
// Falls back to GLM-4.6 (the default) if no specialist is available.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export type TaskType =
  | 'code'
  | 'vision'
  | 'reasoning'
  | 'fast-chat'
  | 'long-context'
  | 'creative'
  | 'research'
  | 'analysis'
  | 'summarization'
  | 'translation'
  | 'math'
  | 'general';

export interface ModelRecommendation {
  modelId: string;
  providerKey: string;
  tier: string;
  reason: string;
  alternatives: Array<{ modelId: string; providerKey: string; reason: string }>;
}

// Model specialization map — which models are best for which tasks.
// These are matched against the 455 models in the DB.
const MODEL_SPECIALIZATIONS: Record<TaskType, Array<{ patterns: string[]; reason: string }>> = {
  code: [
    { patterns: ['qwen.*coder', 'deepseek-coder', 'code-llama', 'starcoder', 'codestral', 'codestral.*mamba'], reason: 'Specialized coding model' },
    { patterns: ['command-r-plus', 'command-r'], reason: 'Cohere coding-optimized model' },
    { patterns: ['deepseek'], reason: 'Strong code reasoning' },
    { patterns: ['mistral.*large', 'mixtral'], reason: 'Strong code generation' },
    { patterns: ['glm-4'], reason: 'Excellent general + code' },
  ],
  vision: [
    { patterns: ['qwen.*vl', 'llava', 'internvl', 'cogvlm', 'glm-4v', 'pixtral'], reason: 'Vision-language model' },
    { patterns: ['gpt-4o', 'claude-3', 'gemini.*pro', 'gemini.*flash'], reason: 'Multimodal capability' },
    { patterns: ['llama.*vision', 'pixtral.*large'], reason: 'Open vision model' },
  ],
  reasoning: [
    { patterns: ['deepseek.*r1', 'o1', 'o3', 'qwen.*thinking', 'qwq'], reason: 'Chain-of-thought reasoning model' },
    { patterns: ['claude-3.*opus', 'gpt-4o', 'gpt-4.*turbo'], reason: 'Strong analytical reasoning' },
    { patterns: ['command-r-plus'], reason: 'Strong RAG reasoning' },
    { patterns: ['glm-4.6'], reason: 'Excellent reasoning' },
  ],
  'fast-chat': [
    { patterns: ['llama.*8b', 'phi-3', 'gemma.*2b', 'qwen.*7b', 'mistral.*7b', 'gemma-2'], reason: 'Fast small model' },
    { patterns: ['glm-4.*flash', 'glm-4.*air'], reason: 'Fast GLM variant' },
    { patterns: ['gemini.*flash'], reason: 'Fast Gemini variant' },
  ],
  'long-context': [
    { patterns: ['.*128k', '.*200k', '.*1m', 'gemini.*pro', 'gemini.*1.5'], reason: 'Large context window' },
    { patterns: ['claude-3', 'command-r-plus'], reason: '200K context' },
    { patterns: ['gpt-4o', 'glm-4.*long'], reason: '128K context' },
  ],
  creative: [
    { patterns: ['claude-3.*opus', 'claude-3.*sonnet', 'claude-3.5'], reason: 'Best creative writing' },
    { patterns: ['glm-4.6', 'gpt-4o', 'command-r-plus'], reason: 'Strong creative ability' },
    { patterns: ['mistral.*large'], reason: 'Nuanced creative output' },
  ],
  research: [
    { patterns: ['deepseek.*r1', 'o1', 'qwq'], reason: 'Deep research reasoning' },
    { patterns: ['command-r-plus', 'perplexity'], reason: 'RAG-optimized research' },
    { patterns: ['glm-4.6', 'claude-3'], reason: 'Excellent research synthesis' },
  ],
  analysis: [
    { patterns: ['deepseek', 'glm-4.6', 'claude-3.*opus', 'gpt-4o'], reason: 'Strong analytical capability' },
    { patterns: ['mixtral.*8x22b'], reason: 'Large mixture-of-experts analysis' },
  ],
  summarization: [
    { patterns: ['glm-4.*flash', 'llama.*8b', 'phi-3', 'gemma.*2b'], reason: 'Fast summarization' },
    { patterns: ['command.*light'], reason: 'Lightweight summarization' },
  ],
  translation: [
    { patterns: ['qwen', 'glm-4', 'command-r'], reason: 'Strong multilingual' },
    { patterns: ['seamless', 'nllb'], reason: 'Dedicated translation model' },
  ],
  math: [
    { patterns: ['deepseek.*math', 'qwen.*math', 'o1', 'qwq', 'mathstral'], reason: 'Math specialist' },
    { patterns: ['deepseek-r1'], reason: 'Strong math reasoning' },
    { patterns: ['gpt-4o'], reason: 'Reliable math' },
  ],
  general: [
    { patterns: ['glm-4.6'], reason: 'Best general-purpose model' },
    { patterns: ['gpt-4o', 'claude-3.*sonnet', 'claude-3.5'], reason: 'Strong general model' },
    { patterns: ['mistral.*large', 'command-r-plus'], reason: 'Capable general model' },
  ],
};

function matchesAnyPattern(modelId: string, patterns: string[]): boolean {
  const lower = modelId.toLowerCase();
  return patterns.some((p) => {
    try {
      return new RegExp(p, 'i').test(lower);
    } catch {
      return lower.includes(p.replace(/\.\*/g, ''));
    }
  });
}

/**
 * Recommend the best model for a task type.
 * Queries the DB for available models, then picks the best match.
 */
export async function recommendModel(taskType: TaskType): Promise<ModelRecommendation> {
  try {
    const models = await db.model.findMany({
      where: { enabled: true, status: 'active' },
      select: { modelId: true, providerKey: true, tier: true },
      take: 500,
    });

    const specializations = MODEL_SPECIALIZATIONS[taskType] ?? MODEL_SPECIALIZATIONS.general;

    for (const spec of specializations) {
      const matches = models.filter((m) => matchesAnyPattern(m.modelId, spec.patterns));
      if (matches.length > 0) {
        // Prefer 'strong' or 'expert' tier
        const sorted = matches.sort((a, b) => {
          const tierRank: Record<string, number> = { expert: 4, strong: 3, medium: 2, weak: 1, fast: 2 };
          return (tierRank[b.tier] ?? 2) - (tierRank[a.tier] ?? 2);
        });
        const best = sorted[0];
        const alternatives = sorted.slice(1, 4).map((m) => ({
          modelId: m.modelId,
          providerKey: m.providerKey,
          reason: spec.reason,
        }));
        return {
          modelId: best.modelId,
          providerKey: best.providerKey,
          tier: best.tier,
          reason: spec.reason,
          alternatives,
        };
      }
    }

    // Fallback: GLM-4.6
    const glm = models.find((m) => m.modelId.toLowerCase().includes('glm-4.6'));
    if (glm) {
      return {
        modelId: glm.modelId,
        providerKey: glm.providerKey,
        tier: glm.tier,
        reason: 'Default fallback — excellent general-purpose model',
        alternatives: [],
      };
    }

    // Ultimate fallback
    return {
      modelId: 'glm-4.6',
      providerKey: 'zai',
      tier: 'strong',
      reason: 'Hardcoded fallback',
      alternatives: [],
    };
  } catch (err) {
    logger.error({ err }, 'smart-model-router: recommendModel failed');
    return {
      modelId: 'glm-4.6',
      providerKey: 'zai',
      tier: 'strong',
      reason: 'Error fallback',
      alternatives: [],
    };
  }
}

/**
 * Detect the task type from a user prompt.
 * Used when the caller doesn't explicitly specify a task type.
 */
export function detectTaskType(prompt: string): TaskType {
  const lower = prompt.toLowerCase();
  if (/image|screenshot|see|look|picture|photo|diagram|chart/.test(lower)) return 'vision';
  if (/code|function|bug|debug|implement|refactor|program|api|script/.test(lower)) return 'code';
  if (/analyz|reason|why|explain|compare|evaluate|assess/.test(lower)) return 'analysis';
  if (/research|find|investigate|study|explore/.test(lower)) return 'research';
  if (/summari|tldr|brief|condense/.test(lower)) return 'summarization';
  if (/translat/.test(lower)) return 'translation';
  if (/calculat|math|equation|solve|compute|formula/.test(lower)) return 'math';
  if (/writ.*story|creative|poem|essay|article|blog/.test(lower)) return 'creative';
  if (prompt.length > 5000) return 'long-context';
  if (/quick|fast|simple|short|brief/.test(lower)) return 'fast-chat';
  return 'general';
}

/**
 * Get model stats — how many models are available per task type.
 */
export async function getModelStatsByTask(): Promise<Record<TaskType, number>> {
  const models = await db.model.findMany({
    where: { enabled: true, status: 'active' },
    select: { modelId: true },
    take: 500,
  }).catch(() => []);

  const stats: Partial<Record<TaskType, number>> = {};
  for (const taskType of Object.keys(MODEL_SPECIALIZATIONS) as TaskType[]) {
    const specs = MODEL_SPECIALIZATIONS[taskType];
    let count = 0;
    for (const spec of specs) {
      count += models.filter((m) => matchesAnyPattern(m.modelId, spec.patterns)).length;
    }
    stats[taskType] = count;
  }
  return stats as Record<TaskType, number>;
}

// =====================================================================
// PROACTIVE RATE-LIMIT-RESILIENT ROUTING (v11 enhancement)
// =====================================================================
// The original recommendModel() picks the single best model for a task.
// This new function picks a model that is BOTH good for the task AND
// spread across a DIFFERENT provider than recently-used ones — so the
// fleet proactively distributes load and avoids any single provider's
// rate limits (instead of only reacting after a 429).

export interface ProactiveRouteResult {
  modelId: string;
  providerKey: string;
  tier: string;
  reason: string;
  proactive: true;
  providerSpread: string[]; // providers used in the rotation
  alternatives: Array<{ modelId: string; providerKey: string; reason: string }>;
}

// Simple in-memory provider usage counter (last 5 min window) for
// round-robin spread. Resets on process restart.
const _providerUsage: Map<string, number[]> = new Map();
const USAGE_WINDOW_MS = 5 * 60 * 1000;

function recordProviderUse(providerKey: string): void {
  const now = Date.now();
  const arr = _providerUsage.get(providerKey) ?? [];
  arr.push(now);
  // prune old entries
  _providerUsage.set(providerKey, arr.filter((t) => now - t < USAGE_WINDOW_MS));
}

function providerLoad(providerKey: string): number {
  const now = Date.now();
  const arr = _providerUsage.get(providerKey) ?? [];
  return arr.filter((t) => now - t < USAGE_WINDOW_MS).length;
}

/**
 * Proactively route a task to the best model that ALSO spreads load
 * across providers. Picks from the top-3 matches, preferring the one
 * whose provider has been used least recently.
 */
export async function proactiveRoute(taskType: TaskType): Promise<ProactiveRouteResult> {
  try {
    const models = await db.model.findMany({
      where: { enabled: true, status: 'active' },
      select: { modelId: true, providerKey: true, tier: true, id: true },
      take: 500,
    });

    const specializations = MODEL_SPECIALIZATIONS[taskType] ?? MODEL_SPECIALIZATIONS.general;
    const allMatches: Array<{ modelId: string; providerKey: string; tier: string; reason: string }> = [];

    for (const spec of specializations) {
      const matches = models.filter((m) => matchesAnyPattern(m.modelId, spec.patterns));
      // Include ALL matching models — even if same modelId from different providers.
      // This is critical for rate-limit resilience: if provider A's gpt-4o-mini
      // is rate-limited, provider B's gpt-4o-mini (via OpenRouter/DuckDuckGo/LMSYS)
      // can take over. Each provider has different limits.
      for (const m of matches) {
        // Dedup by modelId+providerKey combo (not just modelId)
        const exists = allMatches.find((x) => x.modelId === m.modelId && x.providerKey === m.providerKey);
        if (!exists) {
          allMatches.push({ modelId: m.modelId, providerKey: m.providerKey, tier: m.tier, reason: spec.reason });
        }
      }
      if (allMatches.length >= 10) break; // enough candidates (more now since we include multi-provider)
    }

    if (allMatches.length === 0) {
      // Fallback to GLM-4.6
      const glm = models.find((m) => m.modelId.toLowerCase().includes('glm-4.6'));
      const result: ProactiveRouteResult = {
        modelId: glm?.modelId ?? 'glm-4.6',
        providerKey: glm?.providerKey ?? 'zai',
        tier: glm?.tier ?? 'strong',
        reason: 'No specialist match — GLM-4.6 fallback',
        proactive: true,
        providerSpread: ['zai'],
        alternatives: [],
      };
      recordProviderUse(result.providerKey);
      return result;
    }

    // Sort by (provider load ASC, then tier DESC) — prefer least-used provider.
    const tierRank: Record<string, number> = { expert: 4, strong: 3, medium: 2, weak: 1, fast: 2 };
    const sorted = allMatches.sort((a, b) => {
      const loadDiff = providerLoad(a.providerKey) - providerLoad(b.providerKey);
      if (loadDiff !== 0) return loadDiff;
      return (tierRank[b.tier] ?? 2) - (tierRank[a.tier] ?? 2);
    });

    const best = sorted[0];
    recordProviderUse(best.providerKey);

    const providerSpread = Array.from(new Set(sorted.slice(0, 5).map((m) => m.providerKey)));
    const alternatives = sorted.slice(1, 4).map((m) => ({
      modelId: m.modelId,
      providerKey: m.providerKey,
      reason: m.reason,
    }));

    return {
      modelId: best.modelId,
      providerKey: best.providerKey,
      tier: best.tier,
      reason: `${best.reason} (proactively spread across ${best.providerKey} — least loaded)`,
      proactive: true,
      providerSpread,
      alternatives,
    };
  } catch (err) {
    logger.error({ err }, 'smart-model-router: proactiveRoute failed');
    return {
      modelId: 'glm-4.6',
      providerKey: 'zai',
      tier: 'strong',
      reason: 'Error fallback',
      proactive: true,
      providerSpread: ['zai'],
      alternatives: [],
    };
  }
}

/**
 * Get the set of providers currently configured (have API keys in env).
 * Used to show the operator which fallback providers are live.
 */
export function getConfiguredProviders(): Array<{ key: string; configured: boolean; envVar: string }> {
  return [
    { key: 'zai', configured: true, envVar: 'ZAI_API_KEY (always available)' },
    { key: 'groq', configured: !!process.env.GROQ_API_KEY, envVar: 'GROQ_API_KEY' },
    { key: 'siliconflow', configured: !!(process.env.SILICONFLOW_API_KEY || process.env.QWEN_API_KEY), envVar: 'SILICONFLOW_API_KEY / QWEN_API_KEY' },
    { key: 'nvidia', configured: !!process.env.NVIDIA_API_KEY, envVar: 'NVIDIA_API_KEY' },
    { key: 'ollama', configured: !!process.env.OLLAMA_HOST, envVar: 'OLLAMA_HOST' },
    { key: 'omniroute', configured: !!process.env.OMNIROUTE_API_KEY, envVar: 'OMNIROUTE_API_KEY' },
    { key: 'bytez', configured: !!process.env.BYTEZ_API_KEY, envVar: 'BYTEZ_API_KEY' },
    { key: 'huggingface', configured: !!process.env.HUGGINGFACE_API_KEY, envVar: 'HUGGINGFACE_API_KEY' },
    { key: 'openai', configured: !!process.env.OPENAI_API_KEY, envVar: 'OPENAI_API_KEY' },
    { key: 'anthropic', configured: !!process.env.ANTHROPIC_API_KEY, envVar: 'ANTHROPIC_API_KEY' },
    { key: 'gemini', configured: !!(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY), envVar: 'GEMINI_API_KEY / GOOGLE_API_KEY' },
    { key: 'openrouter', configured: !!process.env.OPENROUTER_API_KEY, envVar: 'OPENROUTER_API_KEY' },
    { key: 'deepseek', configured: !!process.env.DEEPSEEK_API_KEY, envVar: 'DEEPSEEK_API_KEY' },
    { key: 'cohere', configured: !!process.env.COHERE_API_KEY, envVar: 'COHERE_API_KEY' },
    { key: 'mistral', configured: !!process.env.MISTRAL_API_KEY, envVar: 'MISTRAL_API_KEY' },
    { key: 'together', configured: !!process.env.TOGETHER_API_KEY, envVar: 'TOGETHER_API_KEY' },
  ];
}
