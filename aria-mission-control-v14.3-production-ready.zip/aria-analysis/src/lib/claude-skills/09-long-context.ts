// 09 — Long-Context handling with NATIVE 128K+ model routing.
//
// PRODUCTION ENHANCEMENT (v11): Instead of always chunking long inputs,
// we first check whether a model with a large native context window
// (128K, 200K, 1M tokens) is available. If so, we send the full text
// directly to that model — no information loss from summarization.
//
// Fallback: if no long-context model is reachable, we use the original
// map-reduce chunk-summarize strategy.
//
// Adapted from v8 zip: uses our chat(userMessage, history, systemPrompt).

import { chat, type ChatTurn } from '@/lib/llm'
import { db } from '@/lib/db'
import { logger } from '@/lib/logger'

const DEFAULT_MODEL = 'glm-4.6'
const MAX_CHUNKES_CAP = 8 // cap parallel chunk summaries
// Rough chars-per-token estimate (≈4 chars/token for English). Used to
// decide whether a long-context model can hold the input natively.
const CHARS_PER_TOKEN = 4

export interface LongContextResult {
  originalChars: number
  summarisedChars: number
  chunks: number
  summary: string
  model: string
  latencyMs: number
  truncated: boolean
  fallback?: boolean
  error?: string
  nativeContextUsed?: boolean
  contextWindow?: number
}

type Msg = { role: 'system' | 'user' | 'assistant'; content: string }

async function llmCall(messages: Msg[]): Promise<string> {
  const sys = messages.find((m) => m.role === 'system')?.content ?? ''
  const convo = messages.filter((m) => m.role !== 'system')
  if (convo.length === 0) throw new Error('no user message')
  const last = convo[convo.length - 1]
  const history: ChatTurn[] = convo.slice(0, -1).map((m) => ({
    role: m.role as 'user' | 'assistant',
    content: m.content,
  }))
  const r = await chat(last.content, history, sys)
  return r.content
}

function chunkText(text: string, size: number): string[] {
  const chunks: string[] = []
  for (let i = 0; i < text.length; i += size) chunks.push(text.slice(i, i + size))
  return chunks
}

async function summariseChunk(chunk: string, idx: number, total: number): Promise<string> {
  return llmCall([
    {
      role: 'system',
      content: `Summarise chunk ${idx + 1}/${total}. Preserve all facts, entities, numbers, and key claims. Prose only.`,
    },
    { role: 'user', content: chunk },
  ])
}

/**
 * Find the best available long-context model (128K+ window) from the DB.
 * Returns { modelId, contextWindow } or null if none available.
 */
async function findLongContextModel(requiredTokens: number): Promise<{ modelId: string; contextWindow: number } | null> {
  try {
    const models = await db.model.findMany({
      where: {
        enabled: true,
        status: 'active',
        contextWindow: { gte: Math.min(requiredTokens * 1.5, 128000) },
      },
      select: { modelId: true, contextWindow: true, tier: true },
      take: 100,
    })
    if (models.length === 0) return null
    // Prefer the smallest window that comfortably fits (cheaper/faster),
    // then prefer higher tier.
    const sorted = models.sort((a, b) => {
      if (a.contextWindow !== b.contextWindow) return a.contextWindow - b.contextWindow
      const tierRank: Record<string, number> = { expert: 4, strong: 3, medium: 2, weak: 1, fast: 2 }
      return (tierRank[b.tier] ?? 2) - (tierRank[a.tier] ?? 2)
    })
    const best = sorted[0]
    return { modelId: best.modelId, contextWindow: best.contextWindow }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'long-context: model lookup failed')
    return null
  }
}

export async function longContext(
  text: string,
  maxChars: number = 12_000,
  model: string = DEFAULT_MODEL,
): Promise<LongContextResult> {
  const started = Date.now()
  const originalChars = text.length
  if (originalChars <= maxChars) {
    return {
      originalChars,
      summarisedChars: originalChars,
      chunks: 1,
      summary: text,
      model,
      latencyMs: Date.now() - started,
      truncated: false,
    }
  }

  // ── NATIVE LONG-CONTEXT PATH ──────────────────────────────────────────
  // Estimate token count and look for a model with a big enough window.
  const estTokens = Math.ceil(originalChars / CHARS_PER_TOKEN)
  const lcModel = await findLongContextModel(estTokens)
  if (lcModel && lcModel.contextWindow >= estTokens * 1.2) {
    try {
      logger.info({ model: lcModel.modelId, contextWindow: lcModel.contextWindow, estTokens }, 'long-context: routing to native 128K+ model')
      const summary = await llmCall([
        {
          role: 'system',
          content: `You are processing a ${estTokens}-token document on a model with a ${lcModel.contextWindow}-token context window. Read the FULL document and produce a comprehensive analysis. Preserve all facts, entities, numbers, key claims, and structure. Do not summarize away detail — the operator needs the complete picture. Prose with headers.`,
        },
        { role: 'user', content: text },
      ])
      return {
        originalChars,
        summarisedChars: summary.length,
        chunks: 1,
        summary,
        model: lcModel.modelId,
        latencyMs: Date.now() - started,
        truncated: false,
        nativeContextUsed: true,
        contextWindow: lcModel.contextWindow,
      }
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'long-context: native model failed, falling back to chunk-summarize')
    }
  }

  // ── FALLBACK: MAP-REDUCE CHUNK SUMMARIZE ──────────────────────────────
  const desiredChunks = Math.ceil(originalChars / (maxChars / 2))
  const chunkCount = Math.max(1, Math.min(MAX_CHUNKES_CAP, desiredChunks))
  const chunkSize = Math.ceil(originalChars / chunkCount)
  const chunks = chunkText(text, Math.max(2000, chunkSize))
  const capped = chunks.slice(0, MAX_CHUNKES_CAP)

  let chunkSummaries: string[]
  try {
    chunkSummaries = await Promise.all(
      capped.map((c, i) =>
        summariseChunk(c, i, capped.length).catch(
          (e: unknown) => `[chunk ${i + 1} failed: ${e instanceof Error ? e.message : String(e)}]`,
        ),
      ),
    )
  } catch (err: unknown) {
    const truncated = text.slice(0, maxChars) + '\n[...truncated...]'
    return {
      originalChars,
      summarisedChars: truncated.length,
      chunks: 1,
      summary: truncated,
      model,
      latencyMs: Date.now() - started,
      truncated: true,
      fallback: true,
      error: err instanceof Error ? err.message : String(err),
    }
  }
  try {
    const summary = await llmCall([
      {
        role: 'system',
        content: 'Combine the partial summaries into one coherent summary. Preserve all facts. Prose only.',
      },
      { role: 'user', content: chunkSummaries.join('\n\n---\n\n') },
    ])
    return {
      originalChars,
      summarisedChars: summary.length,
      chunks: capped.length,
      summary,
      model,
      latencyMs: Date.now() - started,
      truncated: true,
      nativeContextUsed: false,
    }
  } catch (err: unknown) {
    const joined = chunkSummaries.join('\n\n---\n\n')
    return {
      originalChars,
      summarisedChars: joined.length,
      chunks: capped.length,
      summary: joined,
      model,
      latencyMs: Date.now() - started,
      truncated: true,
      fallback: true,
      error: err instanceof Error ? err.message : String(err),
    }
  }
}
