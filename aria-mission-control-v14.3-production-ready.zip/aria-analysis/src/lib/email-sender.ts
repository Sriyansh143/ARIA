// =====================================================================
// email-sender.ts — SMTP email sender (native TLS, zero-dependency)
// =====================================================================
// Sends emails to the owner via SMTP. Used by the approval escalation
// system (Level 2: Telegram + Email).
// =====================================================================

import { createConnection, connect as tlsConnect, TLSSocket } from 'node:tls';
import { logger } from '@/lib/logger';

const SMTP_HOST = process.env.SMTP_HOST || 'smtp.gmail.com';
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '465');
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;

export function isEmailConfigured(): boolean {
  return !!(SMTP_USER && SMTP_PASS);
}

function base64Encode(str: string): string {
  return Buffer.from(str).toString('base64');
}

/**
 * Send an email via SMTP (TLS port 465).
 * Zero-dependency — uses node:tls directly.
 */
export async function sendEmail(to: string, subject: string, body: string): Promise<{ success: boolean; error?: string }> {
  if (!isEmailConfigured()) {
    return { success: false, error: 'SMTP_USER and SMTP_PASS not set in .env' };
  }

  return new Promise((resolve) => {
    try {
      const socket = tlsConnect({
        host: SMTP_HOST,
        port: SMTP_PORT,
        servername: SMTP_HOST,
      });

      let step = 0;
      let response = '';

      const send = (data: string) => {
        socket.write(data + '\r\n');
      };

      const handleData = (data: string) => {
        response += data;
        if (!data.endsWith('\r\n')) return;

        const code = parseInt(data.slice(0, 3));

        switch (step) {
          case 0: // Server greeting
            if (code === 220) {
              send('EHLO jarvis.local');
              step = 1;
            }
            break;
          case 1: // EHLO response
            if (code === 250) {
              send('AUTH LOGIN');
              step = 2;
            }
            break;
          case 2: // AUTH LOGIN response
            if (code === 334) {
              send(base64Encode(SMTP_USER!));
              step = 3;
            }
            break;
          case 3: // Username response
            if (code === 334) {
              send(base64Encode(SMTP_PASS!));
              step = 4;
            }
            break;
          case 4: // Password response
            if (code === 235) {
              send(`MAIL FROM:<${SMTP_USER}>`);
              step = 5;
            }
            break;
          case 5: // MAIL FROM response
            if (code === 250) {
              send(`RCPT TO:<${to}>`);
              step = 6;
            }
            break;
          case 6: // RCPT TO response
            if (code === 250) {
              send('DATA');
              step = 7;
            }
            break;
          case 7: // DATA response
            if (code === 354) {
              const email = [
                `From: ARIA Mission Control <${SMTP_USER}>`,
                `To: <${to}>`,
                `Subject: ${subject}`,
                'Content-Type: text/plain; charset=utf-8',
                '',
                body,
                '.',
              ].join('\r\n');
              send(email);
              step = 8;
            }
            break;
          case 8: // Message sent response
            if (code === 250) {
              send('QUIT');
              socket.end();
              resolve({ success: true });
            }
            break;
        }
      };

      socket.on('data', (buf) => {
        const data = buf.toString();
        // Handle multi-line responses
        const lines = data.split('\r\n');
        for (const line of lines) {
          if (line) handleData(line + '\r\n');
        }
      });

      socket.on('error', (err) => {
        logger.warn({ err }, 'email-sender: SMTP connection error');
        resolve({ success: false, error: err.message });
      });

      socket.on('timeout', () => {
        socket.destroy();
        resolve({ success: false, error: 'SMTP timeout' });
      });

      socket.setTimeout(15000);
    } catch (err) {
      resolve({ success: false, error: err instanceof Error ? err.message : 'Unknown error' });
    }
  });
}

/**
 * Send an email to the owner.
 */
export async function sendToOwnerEmail(subject: string, body: string): Promise<{ success: boolean; error?: string }> {
  if (!SMTP_USER) {
    return { success: false, error: 'SMTP_USER not configured' };
  }
  return sendEmail(SMTP_USER, subject, body);
}
