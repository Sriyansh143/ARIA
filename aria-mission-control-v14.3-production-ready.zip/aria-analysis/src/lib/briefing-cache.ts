// =====================================================================
// briefing-cache.ts — Server-side briefing cache with state-hash + single-flight
// =====================================================================
// ELIMINATES THE LOCALHOST ↔ NETWORK-IP BRIEFING DESYNC.
//
// Three layers of defense ensure every browser (regardless of origin) sees
// the byte-identical briefing JSON within a 30-second window:
//
//   1. STATE-HASH CACHE  — If the fleet state (agents/tasks/metrics) hasn't
//      changed since the last briefing, return the cached payload without
//      calling the LLM at all. Caps LLM cost at ONE call per state change,
//      not one call per HTTP request.
//
//   2. TTL CACHE         — Even if state is changing constantly, the cached
//      briefing is served for 30 seconds. This means all clients polling
//      within a 30s window see the same numbers + the same LLM headline.
//
//   3. SINGLE-FLIGHT     — When N clients request /api/briefing concurrently
//      during a cache-miss, only ONE LLM call runs. The rest await the same
//      in-flight promise. Eliminates the "thundering herd" race where 5 tabs
//      trigger 5 parallel quickChat() calls.
//
//   4. EVENT BROADCAST   — When a new briefing is computed, an event is
//      emitted on the in-process event bus. The /api/briefing/stream SSE
//      endpoint listens and pushes the update to all subscribed clients in
//      milliseconds — replaces 30-second polling with sub-second push.
//
// All three layers are in-process (single Node.js server). For multi-process
// deployments, add Redis as the backing store — the API surface here is
// designed to make that swap a one-line change.
// =====================================================================

import { emitEvent } from '@/lib/event-bus';
import { logger } from '@/lib/logger';

// ─── Types ────────────────────────────────────────────────────────────

export interface BriefingPayload {
  briefing: unknown;
  __meta: {
    generatedAt: string;
    stateHash: string;
    cacheHit: boolean;
    llmCalled: boolean;
    durationMs: number;
  };
}

// ─── Cache state ──────────────────────────────────────────────────────

const BRIEFING_TTL_MS = 30_000; // 30 seconds — bounds client divergence

interface CachedBriefing {
  payload: BriefingPayload;
  stateHash: string;
  generatedAt: number;
}

let _cached: CachedBriefing | null = null;
let _inFlight: Promise<BriefingPayload> | null = null;

// ─── State-hash computation ───────────────────────────────────────────
// A short, deterministic hash of the fleet state. If this hash matches the
// last briefing's hash, the LLM call is skipped entirely — the briefing
// hasn't changed because the underlying state hasn't changed.
//
// We hash only the fields that affect the briefing output (agent statuses,
// task counts, telemetry sample, payment sums, comms/approvals/findings
// counts, recent log signatures). Everything else is decorative.

export interface BriefingStateSnapshot {
  agents: Array<{ codename: string; status: string; load: number; successRate: number }>;
  tasks: Array<{ status: string; priority: string; assigneeId: string | null }>;
  telemetry: Array<{ cpu: number; mem: number; disk: number; latency: number; tokens: number }>;
  payments: Array<{ status: string; _sum: { amount: number | null } }>;
  unreadComms: number;
  openApprovals: number;
  criticalFindings: number;
  recentLogs: Array<{ agentId: string; level: string; message: string }>;
}

export function computeStateHash(s: BriefingStateSnapshot): string {
  // Deterministic concatenation — order matters for hash stability.
  const agentSig = s.agents
    .map((a) => `${a.codename}:${a.status}:${Math.round(a.load)}:${Math.round(a.successRate)}`)
    .sort()
    .join('|');
  const taskSig = s.tasks
    .map((t) => `${t.status}:${t.priority}:${t.assigneeId ?? '-'}`)
    .join('|');
  const teleSig = s.telemetry[0]
    ? `cpu${Math.round(s.telemetry[0].cpu)}:mem${Math.round(s.telemetry[0].mem)}:lat${s.telemetry[0].latency}`
    : 'none';
  const paySig = s.payments.map((p) => `${p.status}:${p._sum.amount ?? 0}`).sort().join('|');
  const logSig = s.recentLogs
    .map((l) => `${l.agentId}:${l.level}:${l.message.slice(0, 40)}`)
    .join('|');

  const composite = `a=${agentSig}|t=${taskSig}|tele=${teleSig}|pay=${paySig}|uc=${s.unreadComms}|oa=${s.openApprovals}|cf=${s.criticalFindings}|log=${logSig}`;

  // FNV-1a 32-bit — fast, dependency-free, good enough for state hashing.
  let h = 0x811c9dc5;
  for (let i = 0; i < composite.length; i++) {
    h ^= composite.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

// ─── Public cache API ─────────────────────────────────────────────────

/**
 * Returns the cached briefing if (a) one exists AND (b) it's within the TTL
 * window. Returns null on cache miss — caller MUST fall through to
 * `runSingleFlight` to compute a fresh briefing.
 */
export function getCachedBriefing(): BriefingPayload | null {
  if (!_cached) return null;
  const age = Date.now() - _cached.generatedAt;
  if (age > BRIEFING_TTL_MS) {
    _cached = null;
    return null;
  }
  return _cached.payload;
}

/**
 * Returns the cached briefing's state-hash WITHOUT serving it. Used to decide
 * whether the LLM can be skipped (state unchanged) even when the TTL has
 * expired.
 */
export function getCachedStateHash(): string | null {
  return _cached?.stateHash ?? null;
}

/**
 * Single-flight wrapper. If a briefing generation is already in flight,
 * returns the same promise instead of starting a second one. This prevents
 * N concurrent HTTP requests from triggering N parallel quickChat() calls.
 *
 * Usage:
 *   const payload = await runSingleFlight(async (skipLlm: boolean) => {
 *     // ... compute briefing, calling quickChat() only if !skipLlm ...
 *     return payload;
 *   });
 */
export async function runSingleFlight(
  generator: (skipLlm: boolean) => Promise<BriefingPayload>,
  skipLlm: boolean,
): Promise<BriefingPayload> {
  // If one's already in flight, await it — we get the same payload.
  if (_inFlight) {
    try {
      return await _inFlight;
    } catch {
      // The in-flight call failed — fall through and try again.
      _inFlight = null;
    }
  }

  _inFlight = generator(skipLlm).finally(() => {
    _inFlight = null;
  });

  return _inFlight;
}

/**
 * Persist a freshly-computed briefing in the cache. Also broadcasts a
 * `briefing:updated` event on the event bus so any SSE listeners (and any
 * in-process subscribers) can push the update to their clients in real time.
 */
export function setCachedBriefing(payload: BriefingPayload, stateHash: string): void {
  _cached = {
    payload,
    stateHash,
    generatedAt: Date.now(),
  };
  // Broadcast — /api/briefing/stream listens and pushes to all SSE clients.
  try {
    emitEvent('briefing:updated', payload);
  } catch (err) {
    logger.warn(
      { err: err instanceof Error ? err.message : String(err) },
      'briefing-cache: failed to broadcast briefing:updated event',
    );
  }
}

/**
 * Force a cache invalidation. Called when an operator clicks "Regenerate" on
 * the Briefing tab so the next request computes fresh.
 */
export function invalidateBriefingCache(): void {
  _cached = null;
  _inFlight = null;
  try {
    emitEvent('briefing:invalidated', { at: new Date().toISOString() });
  } catch {
    /* best-effort */
  }
}

/**
 * Returns cache diagnostics for the /api/autopilot/state + system-health tabs.
 */
export function getBriefingCacheStatus(): {
  cached: boolean;
  ageMs: number;
  stateHash: string | null;
  inFlight: boolean;
  ttlMs: number;
} {
  return {
    cached: _cached !== null,
    ageMs: _cached ? Date.now() - _cached.generatedAt : 0,
    stateHash: _cached?.stateHash ?? null,
    inFlight: _inFlight !== null,
    ttlMs: BRIEFING_TTL_MS,
  };
}
