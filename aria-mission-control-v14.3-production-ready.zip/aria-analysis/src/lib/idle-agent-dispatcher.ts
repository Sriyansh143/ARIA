// =====================================================================
// idle-agent-dispatcher.ts — Detects idle agents every 5s + dispatches
// =====================================================================
// PRODUCTION ENHANCEMENT (v11): Implements the user's requested behavior:
//   "if any agents are idle then create tasks from earning methods and
//    do rigorous research analysis. if tasks are pending then agents
//    deployed to complete them all. monitoring agents detect every 5
//    seconds."
//
// This module runs a 5-second ticker that:
//   1. Detects idle agents (status=idle, load<20)
//   2. If earning methods exist → creates tasks from them + assigns to idle agents
//   3. If no earning methods → triggers earning-research to generate new ones
//   4. If pending tasks exist → assigns them to idle agents
//   5. Logs all dispatches for audit
//
// Non-blocking: each tick is wrapped in try/catch. Never crashes the app.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';
import { emitEvent } from '@/lib/event-bus';

const TICK_INTERVAL_MS = 120_000; // 2 minutes — 30s caused CPU spikes when multiple agents were idle
let tickerStarted = false;
let dispatching = false;

interface IdleAgent {
  id: string;
  codename: string;
  name: string;
  role: string;
  load: number;
}

interface PendingTask {
  id: string;
  title: string;
  priority: string;
  assigneeId: string | null;
}

/**
 * Find all idle agents (status=idle AND load<20).
 */
async function findIdleAgents(): Promise<IdleAgent[]> {
  try {
    const agents = await db.agent.findMany({
      where: {
        status: 'idle',
        load: { lt: 20 },
      },
      select: { id: true, codename: true, name: true, role: true, load: true },
      take: 20, // cap per tick
    });
    return agents;
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'idle-dispatcher: findIdleAgents failed');
    return [];
  }
}

/**
 * Find all pending unassigned tasks.
 */
async function findPendingTasks(): Promise<PendingTask[]> {
  try {
    const tasks = await db.task.findMany({
      where: { status: 'pending', assigneeId: null },
      select: { id: true, title: true, priority: true, assigneeId: true },
      take: 20,
    });
    return tasks;
  } catch {
    return [];
  }
}

/**
 * Create tasks from approved earning methods. Each earning method becomes
 * a task with priority based on its earning potential.
 */
async function createTasksFromEarningMethods(idleCount: number): Promise<number> {
  try {
    // Find approved earning methods that haven't been converted to tasks recently.
    const methods = await db.earningMethod.findMany({
      where: {
        approved: true,
        enabled: true,
        // Only create tasks for methods not executed in the last 24h
        OR: [
          { lastExecuted: null },
          { lastExecuted: { lt: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
        ],
      },
      take: Math.min(idleCount, 5), // cap: don't flood the task board
    });

    let created = 0;
    for (const method of methods) {
      const priority = method.earningPotential === 'high' ? 'high' : method.earningPotential === 'medium' ? 'medium' : 'low';
      await db.task.create({
        data: {
          title: `Execute: ${method.name}`,
          description: `${method.description}\n\nMethod: ${method.method || 'N/A'}\nCategory: ${method.category}\nEstimated monthly: ₹${method.estimatedMonthly}`,
          status: 'pending',
          priority,
          tags: JSON.stringify(['earning', method.category, method.key]),
          project: 'earning-engine',
        },
      });
      // Mark as executed to avoid duplicate task creation
      await db.earningMethod.update({
        where: { id: method.id },
        data: { lastExecuted: new Date(), executionCount: { increment: 1 } },
      });
      created++;
    }
    if (created > 0) {
      logger.info({ created, fromMethods: methods.length }, 'idle-dispatcher: created tasks from earning methods');
      emitEvent('task.created', { source: 'earning-method', count: created });
    }
    return created;
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'idle-dispatcher: createTasksFromEarningMethods failed');
    return 0;
  }
}

/**
 * Assign pending tasks to idle agents. Priority order: critical > high > medium > low.
 */
async function dispatchPendingTasks(idleAgents: IdleAgent[], pendingTasks: PendingTask[]): Promise<number> {
  if (idleAgents.length === 0 || pendingTasks.length === 0) return 0;

  // Sort tasks by priority
  const prioRank: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
  const sorted = [...pendingTasks].sort((a, b) => (prioRank[a.priority] ?? 2) - (prioRank[b.priority] ?? 2));

  let dispatched = 0;
  const assignCount = Math.min(idleAgents.length, sorted.length);

  for (let i = 0; i < assignCount; i++) {
    const agent = idleAgents[i];
    const task = sorted[i];
    try {
      await db.task.update({
        where: { id: task.id },
        data: {
          assigneeId: agent.id,
          status: 'in_progress',
          progress: 5, // mark as started
        },
      });
      // Update agent status to working
      await db.agent.update({
        where: { id: agent.id },
        data: {
          status: 'working',
          load: Math.min(100, agent.load + 25),
          taskCount: { increment: 1 },
          lastActive: new Date(),
        },
      });
      dispatched++;
      logger.info({ agent: agent.codename, task: task.title.slice(0, 50) }, 'idle-dispatcher: dispatched task to idle agent');
      emitEvent('agent.dispatched', { agent: agent.codename, taskId: task.id });
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err), agent: agent.codename, taskId: task.id }, 'idle-dispatcher: dispatch failed');
    }
  }
  return dispatched;
}

/**
 * If no earning methods exist, trigger the earning-research engine to
 * generate new ones. This is the "improvise current one" path.
 *
 * THROTTLED: only creates a notification + fires the research API at most
 * once per hour. Previously this fired every tick (30s), spamming the
 * notification panel with identical "No earning methods available" messages
 * when the research engine kept failing (e.g. Z-AI 429 rate-limit).
 */
let _lastEarningResearchAt = 0;
const EARNING_RESEARCH_THROTTLE_MS = 60 * 60 * 1000; // 1 hour

async function ensureEarningMethods(): Promise<void> {
  try {
    const count = await db.earningMethod.count();
    if (count === 0) {
      const now = Date.now();
      const throttled = now - _lastEarningResearchAt < EARNING_RESEARCH_THROTTLE_MS;
      if (throttled) {
        // Already attempted recently — skip the notification + API call to
        // avoid spamming the panel. The daily-research cron will retry.
        logger.debug('idle-dispatcher: no earning methods, but research throttled (attempted recently)');
        return;
      }
      _lastEarningResearchAt = now;
      logger.info('idle-dispatcher: no earning methods found — triggering research (throttled to 1/hour)');
      // Best-effort: call the research API (fire-and-forget).
      try {
        // Use DASHBOARD_BASE — never hardcode localhost:3000 (the server may
        // be hosted on a network IP in production).
        const baseUrl = process.env.DASHBOARD_BASE || 'http://127.0.0.1:3000';
        await fetch(`${baseUrl}/api/earning-methods/research`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ source: 'idle-dispatcher' }),
          signal: AbortSignal.timeout(30_000),
        });
      } catch {
        // non-blocking — the cron will retry
      }
      // Only create ONE notification per throttle window.
      try {
        await db.notification.create({
          data: {
            type: 'info',
            title: 'Earning methods research triggered',
            message: 'No earning methods found — research engine triggered. New methods will appear once the LLM provider is available. (Throttled: next check in 1 hour.)',
          },
        });
      } catch { /* best-effort */ }
    }
  } catch {
    // best-effort
  }
}

/**
 * Single tick: detect idle agents, create tasks from earning methods,
 * dispatch pending tasks, and ensure earning methods exist.
 */
async function tick(): Promise<void> {
  if (dispatching) return; // prevent overlap
  dispatching = true;
  try {
    const [idleAgents, pendingTasks] = await Promise.all([
      findIdleAgents(),
      findPendingTasks(),
    ]);

    // If there are idle agents but no pending tasks, create tasks from earning methods
    if (idleAgents.length > 0 && pendingTasks.length === 0) {
      const created = await createTasksFromEarningMethods(idleAgents.length);
      if (created > 0) {
        // Re-fetch pending tasks after creation
        const newPending = await findPendingTasks();
        await dispatchPendingTasks(idleAgents, newPending);
      } else {
        // No earning methods → ensure they get generated
        await ensureEarningMethods();
      }
      return;
    }

    // If there are pending tasks and idle agents, dispatch
    if (idleAgents.length > 0 && pendingTasks.length > 0) {
      await dispatchPendingTasks(idleAgents, pendingTasks);
    }

    // If there are idle agents but no pending tasks AND no earning methods, ensure research runs
    if (idleAgents.length > 0 && pendingTasks.length === 0) {
      await ensureEarningMethods();
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'idle-dispatcher: tick failed');
  } finally {
    dispatching = false;
  }
}

/**
 * Start the 5-second idle-agent detection ticker.
 * Safe to call multiple times — only starts once.
 */
export function startIdleDispatcher(): void {
  if (tickerStarted) return;
  tickerStarted = true;
  logger.info({ intervalMs: TICK_INTERVAL_MS }, 'idle-dispatcher: started — detecting idle agents every 2min');
  // Run an initial tick after 10s (let the server fully start)
  setTimeout(() => {
    tick().catch(() => { /* best-effort */ });
    // Then every 5s
    setInterval(() => {
      tick().catch(() => { /* best-effort */ });
    }, TICK_INTERVAL_MS);
  }, 10_000);
}

/**
 * Get the current dispatcher status (for the System Health tab).
 */
export function getDispatcherStatus(): { running: boolean; intervalMs: number; dispatching: boolean } {
  return {
    running: tickerStarted,
    intervalMs: TICK_INTERVAL_MS,
    dispatching,
  };
}
