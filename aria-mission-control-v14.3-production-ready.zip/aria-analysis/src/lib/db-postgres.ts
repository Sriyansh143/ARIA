// =====================================================================
// db-postgres.ts — PostgreSQL mirror connection (lazy, optional)
// =====================================================================
// ARIA runs on SQLite by default (offline-capable, single-file). When
// POSTGRES_DATABASE_URL is set AND reachable, this module provides a
// connection pool that the sync engine (db-sync.ts) uses to mirror
// SQLite → PostgreSQL. This gives the platform a cloud backup + a path
// to multi-instance horizontal scaling without giving up SQLite's
// zero-config resilience.
//
// The `pg` driver is loaded via DYNAMIC IMPORT so the app never crashes
// if the package isn't installed (sandbox / minimal deploys). The sync
// layer simply reports "pg-not-installed" and the app keeps running on
// SQLite alone.
// =====================================================================

import { logger } from '@/lib/logger';

export interface PgPoolLike {
  query: (text: string, params?: unknown[]) => Promise<{ rows: unknown[]; rowCount: number }>;
  end: () => Promise<void>;
  totalCount: number;
}

let _pool: PgPoolLike | null = null;
let _poolError: string | null = null;
let _initAttempted = false;

export function getPostgresUrl(): string | null {
  const url = process.env.POSTGRES_DATABASE_URL || process.env.POSTGRES_URL || process.env.DATABASE_URL_POSTGRES;
  if (!url) return null;
  // Only treat as postgres if the scheme matches.
  if (!/^postgres(ql)?:\/\//i.test(url)) return null;
  return url;
}

export function isPostgresConfigured(): boolean {
  return !!getPostgresUrl();
}

/**
 * Lazily initialise the pg connection pool. Returns null if:
 *  - POSTGRES_DATABASE_URL is not set
 *  - the `pg` package is not installed
 *  - the connection fails
 * Never throws — the sync layer treats null as "offline, skip".
 */
export async function getPgPool(): Promise<PgPoolLike | null> {
  if (_pool) return _pool;
  if (_initAttempted && _poolError) return null;
  if (_initAttempted) return _pool;

  _initAttempted = true;
  const url = getPostgresUrl();
  if (!url) {
    _poolError = 'POSTGRES_DATABASE_URL not set';
    return null;
  }

  try {
    // Dynamic import so `pg` is an OPTIONAL dependency.
    const pgModule: any = await import('pg').catch(() => null);
    if (!pgModule || !pgModule.Pool) {
      _poolError = 'pg package not installed — run `bun add pg` to enable PostgreSQL sync';
      logger.warn({ err: _poolError }, 'db-postgres: pg driver unavailable');
      return null;
    }
    const pool = new pgModule.Pool({
      connectionString: url,
      max: 5,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
    });
    // Verify connectivity with a trivial query.
    await pool.query('SELECT 1 AS ok');
    _pool = pool as unknown as PgPoolLike;
    logger.info({ url: url.replace(/:[^:@/]+@/, ':****@') }, 'db-postgres: connected to PostgreSQL mirror');
    return _pool;
  } catch (err) {
    _poolError = err instanceof Error ? err.message : String(err);
    logger.warn({ err: _poolError }, 'db-postgres: connection failed — SQLite-only mode');
    return null;
  }
}

/**
 * Reset the pool (used by the sync API to force a reconnect attempt
 * after the operator fixes the connection / installs pg).
 */
export function resetPgPool(): void {
  _pool = null;
  _poolError = null;
  _initAttempted = false;
}

export function getPgStatus(): {
  configured: boolean;
  reachable: boolean;
  error: string | null;
  poolActive: boolean;
} {
  return {
    configured: isPostgresConfigured(),
    reachable: !!_pool,
    error: _poolError,
    poolActive: !!_pool,
  };
}

/**
 * Ensure a table exists in PostgreSQL (CREATE TABLE IF NOT EXISTS) with a
// schema compatible with the SQLite mirror. We use a generic column shape
// (TEXT for all String fields, DOUBLE PRECISION for Float, etc.) so the
// sync works without needing a per-table DDL map.
 */
export async function ensureTable(pool: PgPoolLike, table: string, columns: Array<{ name: string; type: string }>): Promise<void> {
  const cols = columns.map((c) => `"${c.name}" ${c.type}`).join(', ');
  await pool.query(`CREATE TABLE IF NOT EXISTS "${table}" (${cols})`);
}
