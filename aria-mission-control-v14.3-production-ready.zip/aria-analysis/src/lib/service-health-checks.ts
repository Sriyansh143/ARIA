// =====================================================================
// service-health-checks.ts — External service health probing
// =====================================================================
// Probes a fixed registry of 8 external services (FreeSWITCH, Ollama,
// Telegram, SMTP, Razorpay, Stripe, z.ai SDK, Groq) and returns a
// `ServiceHealth` record per service. Used by:
//   - `/api/service-health` (GET all + history)
//   - `/api/service-health/check` (POST single re-check)
//   - The `service-health-watcher` monitor in `agent-monitors.ts`
//
// Design principles:
//   1. NEVER throw — every probe returns a ServiceHealth, errors go in
//      `status='down'` + `error` string. The caller never has to try/catch.
//   2. Bounded latency — every probe has a 3-5s timeout so a stuck
//      endpoint can never stall the monitor tick (60s budget total).
//   3. In-memory ring buffer (last 100 per service) for history sparklines.
//   4. No secrets leaked — Razorpay/Telegram probes use reachability-only
//      checks (DNS + TCP), never authenticated calls.
// =====================================================================

import net from 'net';
import fs from 'fs';
import path from 'path';

// ─── Types ───────────────────────────────────────────────────────────

export type ServiceStatus = 'healthy' | 'degraded' | 'down' | 'unknown';

export interface ServiceHealth {
  service: string;
  status: ServiceStatus;
  latencyMs: number;
  lastCheckedAt: string;
  error?: string;
  endpoint?: string;
}

// ─── Service registry ────────────────────────────────────────────────

export const SERVICE_REGISTRY = [
  'freeswitch',
  'ollama',
  'telegram',
  'smtp',
  'razorpay',
  'stripe',
  'zai-sdk',
  'groq',
] as const;

export type ServiceName = (typeof SERVICE_REGISTRY)[number];

// ─── In-memory ring buffer (last 100 per service) ────────────────────

const HISTORY_LIMIT = 100;
const historyByService: Map<string, ServiceHealth[]> = new Map();

function recordHistory(svc: string, h: ServiceHealth): void {
  let arr = historyByService.get(svc);
  if (!arr) {
    arr = [];
    historyByService.set(svc, arr);
  }
  arr.push(h);
  if (arr.length > HISTORY_LIMIT) {
    arr.splice(0, arr.length - HISTORY_LIMIT);
  }
}

export function getHealthHistory(service?: string, limit?: number): ServiceHealth[] {
  if (service) {
    const arr = historyByService.get(service) ?? [];
    const n = typeof limit === 'number' && limit > 0 ? Math.min(limit, arr.length) : arr.length;
    return arr.slice(arr.length - n);
  }
  // No service specified → return the latest record per service.
  const latest: ServiceHealth[] = [];
  for (const [svc, arr] of historyByService.entries()) {
    if (arr.length > 0) latest.push(arr[arr.length - 1]!);
  }
  return latest;
}

// ─── Helpers ─────────────────────────────────────────────────────────

/** fetch() with a hard timeout — resolves to {ok, status, latencyMs, error}. */
async function fetchWithTimeout(
  url: string,
  opts: { timeoutMs?: number; method?: string } = {},
): Promise<{ ok: boolean; status: number; latencyMs: number; error?: string }> {
  const timeoutMs = opts.timeoutMs ?? 5000;
  const start = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: opts.method ?? 'GET',
      signal: ctrl.signal,
      cache: 'no-store',
      redirect: 'manual',
    });
    return { ok: true, status: res.status, latencyMs: Date.now() - start };
  } catch (err) {
    const latencyMs = Date.now() - start;
    const msg = err instanceof Error ? err.message : String(err);
    // AbortError → timeout
    if (err instanceof Error && err.name === 'AbortError') {
      return { ok: false, status: 0, latencyMs, error: `timeout after ${timeoutMs}ms` };
    }
    return { ok: false, status: 0, latencyMs, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

/** TCP connect probe — resolves to {ok, latencyMs, error}. */
function tcpProbe(host: string, port: number, timeoutMs = 3000): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const start = Date.now();
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;
    const finish = (ok: boolean, error?: string) => {
      if (settled) return;
      settled = true;
      try { socket.destroy(); } catch {}
      resolve({ ok, latencyMs: Date.now() - start, error });
    };
    const timer = setTimeout(() => finish(false, `timeout after ${timeoutMs}ms`), timeoutMs);
    socket.once('connect', () => {
      clearTimeout(timer);
      finish(true);
    });
    socket.once('error', (err: NodeJS.ErrnoException) => {
      clearTimeout(timer);
      finish(false, err.code ? `${err.code}: ${err.message}` : err.message);
    });
    try {
      socket.connect({ host, port });
    } catch (err) {
      clearTimeout(timer);
      finish(false, err instanceof Error ? err.message : String(err));
    }
  });
}

// ─── Per-service probes ──────────────────────────────────────────────

/**
 * FreeSWITCH — uses ESL TCP socket on port 8021 (see freeswitch-bridge.ts),
 * not HTTP. We do a TCP connect probe. If env vars are not set, mark 'unknown'.
 */
async function probeFreeSWITCH(): Promise<ServiceHealth> {
  const host = process.env.FREESWITCH_ESL_HOST;
  const port = Number(process.env.FREESWITCH_ESL_PORT || 8021);
  const configured = !!(host && process.env.FREESWITCH_ESL_PASSWORD);
  const lastCheckedAt = new Date().toISOString();
  const endpoint = `${host || '127.0.0.1'}:${port}`;
  if (!configured) {
    const h: ServiceHealth = {
      service: 'freeswitch',
      status: 'unknown',
      latencyMs: 0,
      lastCheckedAt,
      endpoint,
      error: 'FREESWITCH_ESL_HOST + FREESWITCH_ESL_PASSWORD not set — probe skipped',
    };
    return h;
  }
  const r = await tcpProbe(host!, port, 3000);
  if (r.ok) {
    const status: ServiceStatus = r.latencyMs > 1500 ? 'degraded' : 'healthy';
    return { service: 'freeswitch', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint };
  }
  return {
    service: 'freeswitch',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint,
    error: r.error ?? 'ESL TCP connect failed',
  };
}

/** Ollama — GET http://localhost:11434/api/tags (200 = healthy). */
async function probeOllama(): Promise<ServiceHealth> {
  const url = 'http://localhost:11434/api/tags';
  const lastCheckedAt = new Date().toISOString();
  const r = await fetchWithTimeout(url, { timeoutMs: 5000 });
  if (r.ok && r.status === 200) {
    const status: ServiceStatus = r.latencyMs > 1500 ? 'degraded' : 'healthy';
    return { service: 'ollama', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint: url };
  }
  if (r.ok) {
    // 2xx but not 200 — degraded but reachable
    return {
      service: 'ollama',
      status: 'degraded',
      latencyMs: r.latencyMs,
      lastCheckedAt,
      endpoint: url,
      error: `Unexpected HTTP ${r.status}`,
    };
  }
  return {
    service: 'ollama',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint: url,
    error: r.error ?? 'fetch failed',
  };
}

/** Telegram — GET /getMe with bot token; 200 = healthy. */
async function probeTelegram(): Promise<ServiceHealth> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const lastCheckedAt = new Date().toISOString();
  if (!token) {
    return {
      service: 'telegram',
      status: 'unknown',
      latencyMs: 0,
      lastCheckedAt,
      error: 'TELEGRAM_BOT_TOKEN not set — probe skipped',
    };
  }
  const url = `https://api.telegram.org/bot${token}/getMe`;
  const r = await fetchWithTimeout(url, { timeoutMs: 5000 });
  if (r.ok && r.status === 200) {
    const status: ServiceStatus = r.latencyMs > 2000 ? 'degraded' : 'healthy';
    return { service: 'telegram', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint: 'https://api.telegram.org/bot<token>/getMe' };
  }
  if (r.ok) {
    return {
      service: 'telegram',
      status: 'degraded',
      latencyMs: r.latencyMs,
      lastCheckedAt,
      endpoint: 'https://api.telegram.org/bot<token>/getMe',
      error: `HTTP ${r.status}`,
    };
  }
  return {
    service: 'telegram',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint: 'https://api.telegram.org/bot<token>/getMe',
    error: r.error ?? 'fetch failed',
  };
}

/** SMTP — TCP connect to localhost:25. */
async function probeSmtp(): Promise<ServiceHealth> {
  const host = process.env.SMTP_HOST || 'localhost';
  const port = Number(process.env.SMTP_PORT || 25);
  const lastCheckedAt = new Date().toISOString();
  const endpoint = `${host}:${port}`;
  const r = await tcpProbe(host, port, 3000);
  if (r.ok) {
    const status: ServiceStatus = r.latencyMs > 1500 ? 'degraded' : 'healthy';
    return { service: 'smtp', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint };
  }
  // ECONNREFUSED is "down" (nothing listening) — different from a network error.
  const isRefused = r.error?.includes('ECONNREFUSED');
  return {
    service: 'smtp',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint,
    error: isRefused
      ? `Connection refused — no SMTP server on ${endpoint}`
      : (r.error ?? 'TCP connect failed'),
  };
}

/**
 * Razorpay — reachability only. We hit https://api.razorpay.com/v1/webhooks
 * (no auth header). A 401/403 means the endpoint is reachable (healthy).
 * A network error means down. Without RAZORPAY_KEY_ID we mark 'unknown'.
 */
async function probeRazorpay(): Promise<ServiceHealth> {
  const lastCheckedAt = new Date().toISOString();
  const url = 'https://api.razorpay.com/v1/webhooks';
  const hasKey = !!(process.env.RAZORPAY_KEY_ID || process.env.RAZORPAY_KEY_SECRET);
  if (!hasKey) {
    return {
      service: 'razorpay',
      status: 'unknown',
      latencyMs: 0,
      lastCheckedAt,
      endpoint: url,
      error: 'RAZORPAY_KEY_ID/RAZORPAY_KEY_SECRET not set — reachability-only probe still runs',
    };
  }
  const r = await fetchWithTimeout(url, { timeoutMs: 5000 });
  // Any HTTP response (even 401/403/404) = reachable = healthy.
  if (r.ok && r.status > 0 && r.status < 500) {
    const status: ServiceStatus = r.latencyMs > 2000 ? 'degraded' : 'healthy';
    return { service: 'razorpay', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint: url };
  }
  if (r.ok) {
    // 5xx — reachable but degraded.
    return {
      service: 'razorpay',
      status: 'degraded',
      latencyMs: r.latencyMs,
      lastCheckedAt,
      endpoint: url,
      error: `HTTP ${r.status} from Razorpay API`,
    };
  }
  return {
    service: 'razorpay',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint: url,
    error: r.error ?? 'fetch failed',
  };
}

/**
 * Stripe — GET https://api.stripe.com/v1/ (no auth). 401 = reachable,
 * so healthy. Network error = down.
 */
async function probeStripe(): Promise<ServiceHealth> {
  const url = 'https://api.stripe.com/v1/';
  const lastCheckedAt = new Date().toISOString();
  const r = await fetchWithTimeout(url, { timeoutMs: 5000 });
  if (r.ok && r.status > 0 && r.status < 500) {
    // 401 is the expected response — proves DNS + reachability.
    const status: ServiceStatus = r.latencyMs > 2000 ? 'degraded' : 'healthy';
    return { service: 'stripe', status, latencyMs: r.latencyMs, lastCheckedAt, endpoint: url };
  }
  if (r.ok) {
    return {
      service: 'stripe',
      status: 'degraded',
      latencyMs: r.latencyMs,
      lastCheckedAt,
      endpoint: url,
      error: `HTTP ${r.status} from Stripe API`,
    };
  }
  return {
    service: 'stripe',
    status: 'down',
    latencyMs: r.latencyMs,
    lastCheckedAt,
    endpoint: url,
    error: r.error ?? 'fetch failed',
  };
}

/** z.ai SDK — check if .z-ai-config file exists + ZAI_API_KEY env set. */
async function probeZaiSdk(): Promise<ServiceHealth> {
  const lastCheckedAt = new Date().toISOString();
  const home = process.env.HOME || process.env.USERPROFILE || '/root';
  const candidates = [
    path.resolve(process.cwd(), '.z-ai-config'),
    path.resolve(home, '.z-ai-config'),
  ];
  let foundAt: string | null = null;
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        foundAt = p;
        break;
      }
    } catch {
      // ignore
    }
  }
  const hasKey = !!process.env.ZAI_API_KEY;
  if (foundAt && hasKey) {
    return {
      service: 'zai-sdk',
      status: 'healthy',
      latencyMs: 0,
      lastCheckedAt,
      endpoint: foundAt,
    };
  }
  if (foundAt || hasKey) {
    return {
      service: 'zai-sdk',
      status: 'degraded',
      latencyMs: 0,
      lastCheckedAt,
      endpoint: foundAt ?? 'env:ZAI_API_KEY',
      error: foundAt
        ? 'ZAI_API_KEY env not set (config file present)'
        : '.z-ai-config file not found (ZAI_API_KEY present)',
    };
  }
  return {
    service: 'zai-sdk',
    status: 'down',
    latencyMs: 0,
    lastCheckedAt,
    error: 'Neither .z-ai-config nor ZAI_API_KEY is configured — z.ai SDK will fail to init',
  };
}

/** Groq — config-only check (GROQ_API_KEY env). No network call. */
async function probeGroq(): Promise<ServiceHealth> {
  const lastCheckedAt = new Date().toISOString();
  if (process.env.GROQ_API_KEY) {
    return {
      service: 'groq',
      status: 'healthy',
      latencyMs: 0,
      lastCheckedAt,
      endpoint: 'env:GROQ_API_KEY',
    };
  }
  return {
    service: 'groq',
    status: 'down',
    latencyMs: 0,
    lastCheckedAt,
    error: 'GROQ_API_KEY env not set — Groq fallback unavailable',
  };
}

// ─── Public API ──────────────────────────────────────────────────────

const PROBES: Record<string, () => Promise<ServiceHealth>> = {
  freeswitch: probeFreeSWITCH,
  ollama: probeOllama,
  telegram: probeTelegram,
  smtp: probeSmtp,
  razorpay: probeRazorpay,
  stripe: probeStripe,
  'zai-sdk': probeZaiSdk,
  groq: probeGroq,
};

/**
 * Check ONE service by name. NEVER throws — returns a ServiceHealth with
 * status='down' + error on any failure (including unknown service name).
 * Records the result into the in-memory history ring buffer.
 */
export async function checkService(service: string): Promise<ServiceHealth> {
  let health: ServiceHealth;
  const probe = PROBES[service];
  if (!probe) {
    health = {
      service,
      status: 'unknown',
      latencyMs: 0,
      lastCheckedAt: new Date().toISOString(),
      error: `Unknown service: ${service}`,
    };
  } else {
    try {
      health = await probe();
    } catch (err) {
      // Defensive: every probe is supposed to never throw, but we double-guard.
      health = {
        service,
        status: 'down',
        latencyMs: 0,
        lastCheckedAt: new Date().toISOString(),
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }
  recordHistory(service, health);
  return health;
}

/**
 * Check ALL registered services in parallel. NEVER throws.
 * Returns 8 ServiceHealth records (order matches SERVICE_REGISTRY).
 */
export async function checkAllServices(): Promise<ServiceHealth[]> {
  const results = await Promise.all(SERVICE_REGISTRY.map((svc) => checkService(svc)));
  return results;
}
