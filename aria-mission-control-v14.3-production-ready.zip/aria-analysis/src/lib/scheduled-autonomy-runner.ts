// src/lib/scheduled-autonomy-runner.ts
// Shared executor for a single scheduled-autonomy / training run.
// Used by:
//   - POST /api/scheduled-autonomy/[id]   (manual "Run now")
//   - the `scheduled-autonomy-tick` cron dispatcher (auto-fire due schedules)
//
// Keeps the run logic in ONE place so the route handler and the cron tick
// never drift apart.

import { db } from '@/lib/db';
import { quickChat } from '@/lib/llm';
import { logger } from '@/lib/logger';
import {
  inferSkillKey,
  checkTrainingCooldown,
  recordTraining,
} from '@/lib/agent-training';

async function getZai(): Promise<any | null> {
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    return await ZAI.create();
  } catch (e) {
    logger.warn({ err: e instanceof Error ? e.message : String(e) }, 'scheduled-autonomy-runner: z-ai SDK unavailable');
    return null;
  }
}

export interface RunResult {
  scheduleId: string;
  skipped?: boolean;
  reason?: string;
  skillKey: string;
  runSuccess: boolean;
  taskTitle: string;
  lastResult: string;
  training?: Awaited<ReturnType<typeof recordTraining>>;
}

/**
 * Run a single scheduled-autonomy loop by its schedule id.
 * Honors the training cooldown (skips if the agent is already proficient and
 * on cooldown), records the training run, and updates the schedule row.
 */
export async function runScheduledAutonomyById(id: string): Promise<RunResult | { error: string; status: number }> {
  const schedule = await db.scheduledAutonomy.findUnique({ where: { id } });
  if (!schedule) return { error: 'not found', status: 404 };
  if (!schedule.enabled) return { error: 'schedule is disabled', status: 400 };

  const agent = await db.agent.findFirst({ where: { codename: schedule.agentCodename } });
  if (!agent) return { error: 'agent not found', status: 404 };

  const skillKey = schedule.skillKey || inferSkillKey(schedule.topic);
  const cooldown = await checkTrainingCooldown(agent.codename, skillKey);
  if (cooldown.onCooldown) {
    const updated = await db.scheduledAutonomy.update({
      where: { id },
      data: {
        lastRun: new Date(),
        runCount: { increment: 1 },
        lastResult: `skipped (cooldown): proficiency ${cooldown.proficiency}% — retrain when it drops below 60%`,
      },
    });
    return {
      scheduleId: id,
      skipped: true,
      reason: cooldown.reason,
      skillKey,
      runSuccess: false,
      taskTitle: '(skipped)',
      lastResult: updated.lastResult ?? '',
    };
  }

  let lastResult = 'started';
  let runSuccess = false;
  let taskTitle = '(no task)';

  try {
    const zai = await getZai();
    await db.agent.update({ where: { id: agent.id }, data: { status: 'working', lastActive: new Date() } });

    let searchResults: Array<{ name?: string; url?: string; snippet?: string; host_name?: string }> = [];
    if (zai) {
      try {
        const results = await zai.functions.invoke('web_search', { query: schedule.topic, num: 5 });
        searchResults = Array.isArray(results) ? results : [];
      } catch (e) {
        logger.warn({ err: e instanceof Error ? e.message : String(e) }, 'scheduled-autonomy-runner: web_search failed');
      }
    }

    let articleText = '';
    if (zai && searchResults.length > 0 && searchResults[0].url) {
      try {
        const pr = await zai.functions.invoke('page_reader', { url: searchResults[0].url });
        const html = (pr as { data?: { html?: string } })?.data?.html ?? '';
        articleText = html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 5000);
      } catch { /* skip */ }
    }

    const context = articleText || searchResults.map((r) => `${r.name}\n${r.snippet}`).join('\n\n');
    let proposed: { title?: string; priority?: string; assignee?: string } | null = null;
    try {
      const sys = `You are ${agent.codename}, a ${agent.role}. Based on the research, propose exactly 1 concrete, actionable task as JSON: {title, priority (low|medium|high), assignee (one of: ORION, VEGA, ATLAS, NOVA, ECHO, SAGE, FORGE, PULSE)}. Title max 80 chars. No preamble, just the JSON object.`;
      const userMsg = `Topic: ${schedule.topic}\n\nResearch:\n${context.slice(0, 4000) || '(no web research available — use your own knowledge of the topic)'}`;
      const raw = await quickChat(userMsg, sys, false);
      const match = raw.match(/\{[\s\S]*\}/);
      if (match) {
        try { proposed = JSON.parse(match[0]); } catch { proposed = null; }
      }
    } catch (e) {
      logger.warn({ err: e instanceof Error ? e.message : String(e) }, 'scheduled-autonomy-runner: LLM planning failed');
      proposed = null;
    }

    if (proposed && proposed.title) {
      const validCodenames = new Set((await db.agent.findMany({ select: { codename: true } })).map((a) => a.codename));
      const assignee = validCodenames.has(String(proposed.assignee).toUpperCase())
        ? await db.agent.findFirst({ where: { codename: String(proposed.assignee).toUpperCase() } })
        : null;
      const t = await db.task.create({
        data: {
          title: String(proposed.title).slice(0, 200),
          status: 'pending',
          priority: ['low', 'medium', 'high', 'critical'].includes(String(proposed.priority)) ? String(proposed.priority) : 'medium',
          assigneeId: assignee?.id ?? null,
          tags: JSON.stringify(['scheduled-autonomy', agent.codename.toLowerCase(), skillKey]),
        },
      });
      taskTitle = t.title;
      runSuccess = true;
      if (assignee) {
        await db.agentLog.create({ data: { agentId: assignee.id, level: 'info', message: `Scheduled autonomy assigned: ${t.title}` } });
      }
    }

    await db.memoryItem.create({
      data: {
        scope: 'episodic',
        key: `sched-${agent.codename.toLowerCase()}-${Date.now()}`,
        value: `Scheduled autonomy on "${schedule.topic}" (skill: ${skillKey}): ${searchResults.length} results, task: ${taskTitle}`,
        tags: JSON.stringify(['scheduled-autonomy', agent.codename.toLowerCase(), skillKey]),
      },
    }).catch(() => { /* ignore */ });

    await db.notification.create({
      data: { type: runSuccess ? 'success' : 'info', title: 'Scheduled Autonomy Run', message: `${agent.codename} researched "${schedule.topic}" → task: ${taskTitle.slice(0, 50)}.`, read: false },
    });

    await db.agentLog.create({ data: { agentId: agent.id, level: runSuccess ? 'success' : 'warn', message: `Scheduled autonomy complete: "${schedule.topic}" → ${taskTitle.slice(0, 60)}` } });
    await db.agent.update({ where: { id: agent.id }, data: { status: 'idle', lastActive: new Date() } });

    lastResult = `${runSuccess ? 'success' : 'no-task'}: ${searchResults.length} results, task: ${taskTitle.slice(0, 60)}`;
  } catch (e) {
    await db.agent.update({ where: { id: agent.id }, data: { status: 'error', lastActive: new Date() } });
    lastResult = `error: ${e instanceof Error ? e.message.slice(0, 80) : 'unknown'}`;
    await db.agentLog.create({ data: { agentId: agent.id, level: 'error', message: `Scheduled autonomy failed: ${lastResult}` } });
  }

  let training: Awaited<ReturnType<typeof recordTraining>> | null = null;
  try {
    training = await recordTraining({
      agentCodename: agent.codename,
      skillKey,
      success: runSuccess,
      learnedFrom: 'scheduled-autonomy',
    });
    lastResult += ` · skill ${skillKey}: ${training.preProficiency}%→${training.proficiency}% (run #${training.trainingCount}, cooldown 7d)`;
  } catch (e) {
    logger.warn({ err: e instanceof Error ? e.message : String(e) }, 'scheduled-autonomy-runner: recordTraining failed');
  }

  await db.scheduledAutonomy.update({
    where: { id },
    data: { lastRun: new Date(), runCount: { increment: 1 }, lastResult },
  });

  return { scheduleId: id, skillKey, runSuccess, taskTitle, lastResult, training };
}

/**
 * Auto-fire all due scheduled-autonomy loops. A schedule is "due" when it is
 * enabled AND (lastRun is null OR lastRun < now − intervalMin minutes).
 * Called by the `scheduled-autonomy-tick` cron dispatcher.
 */
export async function runDueScheduledAutonomy(): Promise<{ due: number; ran: number; skipped: number; errors: number; details: string[] }> {
  const now = Date.now();
  const schedules = await db.scheduledAutonomy.findMany({ where: { enabled: true } });
  const due = schedules.filter((s) => {
    if (!s.lastRun) return true;
    return now - s.lastRun.getTime() > s.intervalMin * 60 * 1000;
  });

  const details: string[] = [];
  let ran = 0;
  let skipped = 0;
  let errors = 0;

  for (const s of due) {
    try {
      const res = await runScheduledAutonomyById(s.id);
      if ('error' in res) { errors++; details.push(`${s.agentCodename}: ${res.error}`); continue; }
      if (res.skipped) { skipped++; details.push(`${s.agentCodename}: skipped (cooldown)`); }
      else { ran++; details.push(`${s.agentCodename}: ${res.runSuccess ? 'task created' : 'no task'} (${res.skillKey})`); }
    } catch (e) {
      errors++;
      details.push(`${s.agentCodename}: ${e instanceof Error ? e.message : 'error'}`);
    }
  }

  return { due: due.length, ran, skipped, errors, details };
}
