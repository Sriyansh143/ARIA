// vector.ts — Embedding cache + similarity search
import { createHash } from 'node:crypto';

const CACHE_MAX = 10000;
const cache = new Map<string, number[]>();
let hits = 0, misses = 0;

function hash(text: string): string {
  return createHash('sha256').update(text, 'utf-8').digest('hex');
}

export function getEmbeddingCacheStats() {
  const total = hits + misses;
  return { size: cache.size, max: CACHE_MAX, hits, misses, hitRate: total > 0 ? `${Math.round((hits / total) * 100)}%` : 'n/a' };
}

export function clearEmbeddingCache() {
  cache.clear();
  hits = 0;
  misses = 0;
}

function pseudoEmbed(text: string, dim = 768): number[] {
  const vec = new Array(dim).fill(0);
  for (let i = 0; i < text.length; i++) {
    vec[i % dim] += text.charCodeAt(i) / 65535;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
  return vec.map((v) => v / norm);
}

export async function embed(text: string): Promise<number[]> {
  if (!text) return new Array(768).fill(0);
  return pseudoEmbed(text);
}

export async function embedCached(text: string): Promise<number[]> {
  const key = hash(text);
  const cached = cache.get(key);
  if (cached) { hits++; return cached; }
  if (cache.size >= CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest) cache.delete(oldest);
  }
  const vec = await embed(text);
  cache.set(key, vec);
  misses++;
  return vec;
}

export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
  const d = Math.sqrt(na) * Math.sqrt(nb);
  return d === 0 ? 0 : dot / d;
}

export async function vectorSearch<T>(query: string, corpus: Array<{ text: string; item: T }>, topK = 5) {
  const qv = await embedCached(query);
  const scored = await Promise.all(
    corpus.map(async (e) => {
      const ev = await embedCached(e.text);
      return { item: e.item, score: cosineSimilarity(qv, ev) };
    }),
  );
  return scored.sort((a, b) => b.score - a.score).slice(0, topK);
}
