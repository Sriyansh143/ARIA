// =====================================================================
// monitoring-agent-feed.ts — Tab inventory + usage guide for monitor agents
// =====================================================================
// USER RULE: "tab data fed to monitoring agents who take care of app and
// autonomously using app feed potential usage or how to use all elements
// potentially"
//
// This module exposes the full tab inventory + usage patterns to monitor
// agents so they can:
//   1. Know what tabs exist + what each does
//   2. Know what data each tab shows
//   3. Know what actions are possible on each tab
//   4. Understand the potential usage of every element
//
// Monitor agents call getTabInventoryForAgents() to get a structured
// guide they can reason about.
// =====================================================================

export interface TabUsageGuide {
  key: string;
  label: string;
  group: string;
  purpose: string;
  dataSources: string[];
  possibleActions: string[];
  monitoringTips: string[];
  relatedApis: string[];
}

const TAB_GUIDES: TabUsageGuide[] = [
  {
    key: 'overview',
    label: 'Overview',
    group: 'Command',
    purpose: 'Mission-control dashboard with fleet stats, telemetry charts, and recent activity.',
    dataSources: ['/api/dashboard', '/api/metrics', '/api/agents', '/api/notifications'],
    possibleActions: ['Click stat cards to navigate', 'View telemetry chart', 'See recent tasks'],
    monitoringTips: ['Watch for CPU > 80%', 'Watch for agent count drops', 'Check pending tasks backlog'],
    relatedApis: ['/api/dashboard', '/api/metrics'],
  },
  {
    key: 'chat',
    label: 'JARVIS Chat',
    group: 'Command',
    purpose: 'AI chat interface with GLM-4.6. Every prompt is enhanced with pro-level scaffold.',
    dataSources: ['/api/chat', '/api/agents/analytics'],
    possibleActions: ['Send message', 'Select model', 'Clear chat', 'View latency'],
    monitoringTips: ['Watch for high latency', 'Monitor error responses', 'Check token usage'],
    relatedApis: ['/api/chat', '/api/models'],
  },
  {
    key: 'fleet',
    label: 'Agent Fleet',
    group: 'Fleet',
    purpose: 'Cards for all agents showing status, load, success rate, skills, model.',
    dataSources: ['/api/agents', '/api/fleet'],
    possibleActions: ['View agent details', 'Filter by department', 'Monitor load', 'Check success rates'],
    monitoringTips: ['Watch for overloaded agents (load > 70%)', 'Flag agents with low success rate', 'Ensure no idle agents'],
    relatedApis: ['/api/agents', '/api/fleet'],
  },
  {
    key: 'tasks',
    label: 'Tasks',
    group: 'Work',
    purpose: 'Task list + Kanban board + DAG dependency graph.',
    dataSources: ['/api/tasks', '/api/tasks/kanban'],
    possibleActions: ['Create task', 'Assign task', 'Update status', 'View dependencies'],
    monitoringTips: ['Watch for stalled tasks', 'Ensure no unassigned tasks', 'Flag blocked dependencies'],
    relatedApis: ['/api/tasks'],
  },
  {
    key: 'payments',
    label: 'Payments',
    group: 'Business',
    purpose: 'Payment ledger + refund system. Every confirmed transaction can be refunded.',
    dataSources: ['/api/payments', '/api/refunds'],
    possibleActions: ['Create payment', 'Request refund', 'Process refund', 'View revenue trend'],
    monitoringTips: ['Watch for pending payments', 'Flag large refunds', 'Monitor revenue drops'],
    relatedApis: ['/api/payments', '/api/refunds'],
  },
  {
    key: 'approvals',
    label: 'Approvals',
    group: 'Monitoring',
    purpose: 'Formal approval requests with 30-min escalation (Telegram → Email → Voice).',
    dataSources: ['/api/approvals'],
    possibleActions: ['Approve/Reject', 'View escalation history', 'Test escalation'],
    monitoringTips: ['Watch for stale approvals', 'Monitor escalation levels', 'Flag expired approvals'],
    relatedApis: ['/api/approvals'],
  },
  {
    key: 'crm',
    label: 'CRM & Sales',
    group: 'Business',
    purpose: 'Client pipeline, lead scoring, support ticket management.',
    dataSources: ['/api/clients', '/api/leads', '/api/tickets'],
    possibleActions: ['Create client', 'Convert lead to client', 'Assign ticket', 'Update pipeline status'],
    monitoringTips: ['Watch for stalled leads', 'Flag urgent tickets', 'Monitor conversion rate'],
    relatedApis: ['/api/clients', '/api/leads', '/api/tickets'],
  },
  {
    key: 'health',
    label: 'Fleet Health',
    group: 'Monitoring',
    purpose: 'System health — CPU, memory, disk, latency, uptime, error rate.',
    dataSources: ['/api/metrics', '/api/health'],
    possibleActions: ['View telemetry charts', 'Check provider status'],
    monitoringTips: ['CPU > 80% = alert', 'Disk > 90% = critical', 'Latency > 2000ms = investigate'],
    relatedApis: ['/api/metrics', '/api/health'],
  },
  {
    key: 'verification',
    label: 'Verification',
    group: 'Monitoring',
    purpose: 'No-Assumption rule enforcement. Every claim is logged + cross-checked.',
    dataSources: ['/api/verifications'],
    possibleActions: ['Log a claim', 'Verify with LLM', 'Question a claim', 'Improve a claim'],
    monitoringTips: ['Flag disputed claims', 'Watch for low confidence scores', 'Monitor questioned claims'],
    relatedApis: ['/api/verifications'],
  },
  {
    key: 'action-log',
    label: 'Action Log',
    group: 'System',
    purpose: 'Reversible action log. Every mutation logged with before/after state.',
    dataSources: ['/api/action-log'],
    possibleActions: ['Reverse an action', 'View before/after state', 'Filter by category'],
    monitoringTips: ['Watch for destructive actions', 'Monitor reversal failures', 'Flag non-reversible actions'],
    relatedApis: ['/api/action-log'],
  },
];

/**
 * Get the full tab inventory for monitor agents.
 * Agents use this to understand what tabs exist + how to use them.
 */
export function getTabInventoryForAgents(): TabUsageGuide[] {
  return TAB_GUIDES;
}

/**
 * Get a specific tab's usage guide.
 */
export function getTabUsageGuide(tabKey: string): TabUsageGuide | null {
  return TAB_GUIDES.find((t) => t.key === tabKey) ?? null;
}

/**
 * Get a condensed text summary of all tabs — useful for injecting into
 * agent system prompts so they know what's available.
 */
export function getTabInventorySummary(): string {
  const lines = TAB_GUIDES.map((t) => {
    return `- ${t.label} (${t.group}): ${t.purpose} | APIs: ${t.relatedApis.join(', ')}`;
  });
  return `Available tabs (${TAB_GUIDES.length}):\n${lines.join('\n')}`;
}
