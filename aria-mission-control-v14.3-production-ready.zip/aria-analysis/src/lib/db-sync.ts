// =====================================================================
// db-sync.ts — SQLite → PostgreSQL replication engine
// =====================================================================
// Mirrors the primary SQLite database to a PostgreSQL mirror whenever
// the mirror is reachable. Designed to be:
//   - Non-blocking: never throws; failures are logged + recorded in DbSyncLog
//   - Incremental: only syncs tables that changed since the last sync
//     (tracked via a high-water-mark on `updatedAt`/`createdAt`)
//   - Resilient: if pg is offline, the app keeps running on SQLite
//
// Triggered by:
//   1. A periodic background ticker (every 60s when pg is reachable)
//   2. The /api/db-sync POST endpoint (manual "Sync now")
//   3. After any mutating API call (best-effort fire-and-forget)
// =====================================================================

import { db } from '@/lib/db';
import { getPgPool, type PgPoolLike } from '@/lib/db-postgres';
import { logger } from '@/lib/logger';

export interface SyncResult {
  ok: boolean;
  tablesSynced: number;
  rowsSynced: number;
  durationMs: number;
  error?: string;
  triggeredBy: 'auto' | 'manual' | 'post-mutation';
}

// Tables to mirror, with their primary key + timestamp columns for
// incremental sync. Column types are the PostgreSQL equivalents of the
// SQLite schema fields (String → TEXT, Int → INTEGER, Float → DOUBLE
// PRECISION, Boolean → BOOLEAN, DateTime → TIMESTAMP).
interface SyncTableDef {
  name: string;
  pk: string;
  // Generic column map: every model uses String/Int/Float/Boolean/DateTime.
  // We sync ALL columns by reading the Prisma model fields at runtime is
  // hard, so we use a curated column list per table for the main entities.
  columns: Array<{ name: string; type: string }>;
}

const PG_TYPES = {
  text: 'TEXT',
  int: 'INTEGER',
  float: 'DOUBLE PRECISION',
  bool: 'BOOLEAN',
  timestamp: 'TIMESTAMP',
} as const;

// Core tables worth mirroring to the cloud backup. (The full 55-model
// schema could be mirrored, but these cover the operationally critical
// data: agents, tasks, payments, decisions, telemetry, logs, forecasts.)
const SYNC_TABLES: SyncTableDef[] = [
  { name: 'Agent', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'name', type: PG_TYPES.text },
    { name: 'codename', type: PG_TYPES.text }, { name: 'role', type: PG_TYPES.text },
    { name: 'status', type: PG_TYPES.text }, { name: 'skills', type: PG_TYPES.text },
    { name: 'model', type: PG_TYPES.text }, { name: 'taskCount', type: PG_TYPES.int },
    { name: 'logCount', type: PG_TYPES.int }, { name: 'successRate', type: PG_TYPES.float },
    { name: 'load', type: PG_TYPES.float }, { name: 'lastActive', type: PG_TYPES.timestamp },
    { name: 'createdAt', type: PG_TYPES.timestamp }, { name: 'updatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'Task', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'title', type: PG_TYPES.text },
    { name: 'description', type: PG_TYPES.text }, { name: 'status', type: PG_TYPES.text },
    { name: 'priority', type: PG_TYPES.text }, { name: 'assigneeId', type: PG_TYPES.text },
    { name: 'progress', type: PG_TYPES.int }, { name: 'tags', type: PG_TYPES.text },
    { name: 'sortOrder', type: PG_TYPES.int }, { name: 'project', type: PG_TYPES.text },
    { name: 'createdAt', type: PG_TYPES.timestamp }, { name: 'updatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'Payment', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'method', type: PG_TYPES.text },
    { name: 'amount', type: PG_TYPES.float }, { name: 'currency', type: PG_TYPES.text },
    { name: 'status', type: PG_TYPES.text }, { name: 'payer', type: PG_TYPES.text },
    { name: 'note', type: PG_TYPES.text }, { name: 'createdAt', type: PG_TYPES.timestamp },
    { name: 'updatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'PaymentOrder', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'gateway', type: PG_TYPES.text },
    { name: 'gatewayOrderId', type: PG_TYPES.text }, { name: 'paymentId', type: PG_TYPES.text },
    { name: 'amount', type: PG_TYPES.float }, { name: 'currency', type: PG_TYPES.text },
    { name: 'status', type: PG_TYPES.text }, { name: 'receipt', type: PG_TYPES.text },
    { name: 'createdAt', type: PG_TYPES.timestamp }, { name: 'updatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'ActionLog', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'actor', type: PG_TYPES.text },
    { name: 'action', type: PG_TYPES.text }, { name: 'category', type: PG_TYPES.text },
    { name: 'target', type: PG_TYPES.text }, { name: 'beforeState', type: PG_TYPES.text },
    { name: 'afterState', type: PG_TYPES.text }, { name: 'reversible', type: PG_TYPES.bool },
    { name: 'reversed', type: PG_TYPES.bool }, { name: 'meta', type: PG_TYPES.text },
    { name: 'createdAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'Telemetry', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'cpu', type: PG_TYPES.float },
    { name: 'mem', type: PG_TYPES.float }, { name: 'disk', type: PG_TYPES.float },
    { name: 'net', type: PG_TYPES.float }, { name: 'latency', type: PG_TYPES.int },
    { name: 'tokens', type: PG_TYPES.int }, { name: 'createdAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'FleetForecast', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'metric', type: PG_TYPES.text },
    { name: 'horizon', type: PG_TYPES.text }, { name: 'current', type: PG_TYPES.float },
    { name: 'forecast', type: PG_TYPES.float }, { name: 'confidence', type: PG_TYPES.float },
    { name: 'trend', type: PG_TYPES.text }, { name: 'riskLevel', type: PG_TYPES.text },
    { name: 'detail', type: PG_TYPES.text }, { name: 'generatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'KpiSnapshot', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'kpi', type: PG_TYPES.text },
    { name: 'value', type: PG_TYPES.float }, { name: 'target', type: PG_TYPES.float },
    { name: 'status', type: PG_TYPES.text }, { name: 'autoAdjusted', type: PG_TYPES.bool },
    { name: 'adjustmentNote', type: PG_TYPES.text }, { name: 'snapshotAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'AgentModelAssignment', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'agentCodename', type: PG_TYPES.text },
    { name: 'modelId', type: PG_TYPES.text }, { name: 'providerKey', type: PG_TYPES.text },
    { name: 'taskRouting', type: PG_TYPES.text }, { name: 'priority', type: PG_TYPES.int },
    { name: 'enabled', type: PG_TYPES.bool }, { name: 'reason', type: PG_TYPES.text },
    { name: 'updatedAt', type: PG_TYPES.timestamp },
  ]},
  { name: 'ChatMessage', pk: 'id', columns: [
    { name: 'id', type: PG_TYPES.text }, { name: 'role', type: PG_TYPES.text },
    { name: 'content', type: PG_TYPES.text }, { name: 'reasoning', type: PG_TYPES.text },
    { name: 'latency', type: PG_TYPES.int }, { name: 'model', type: PG_TYPES.text },
    { name: 'createdAt', type: PG_TYPES.timestamp },
  ]},
];

let _syncing = false;
let _lastSyncAt: Date | null = null;
let _lastResult: SyncResult | null = null;

/**
 * Run a full incremental sync of SQLite → PostgreSQL.
 * Safe to call concurrently — returns early if a sync is already in flight.
 */
export async function syncToPostgres(triggeredBy: 'auto' | 'manual' | 'post-mutation' = 'auto'): Promise<SyncResult> {
  const start = Date.now();
  if (_syncing) {
    return { ok: false, tablesSynced: 0, rowsSynced: 0, durationMs: 0, error: 'sync already in progress', triggeredBy };
  }
  _syncing = true;
  let tablesSynced = 0;
  let rowsSynced = 0;

  try {
    const pool = await getPgPool();
    if (!pool) {
      const result: SyncResult = { ok: false, tablesSynced: 0, rowsSynced: 0, durationMs: Date.now() - start, error: 'postgres not reachable', triggeredBy };
      _lastResult = result;
      _lastSyncAt = new Date();
      return result;
    }

    for (const table of SYNC_TABLES) {
      try {
        const rows = await readTable(table.name);
        if (rows.length === 0) continue;
        await upsertRows(pool, table, rows);
        tablesSynced += 1;
        rowsSynced += rows.length;
      } catch (err) {
        logger.warn({ table, err: err instanceof Error ? err.message : String(err) }, 'db-sync: table sync failed (continuing)');
      }
    }

    const result: SyncResult = {
      ok: true,
      tablesSynced,
      rowsSynced,
      durationMs: Date.now() - start,
      triggeredBy,
    };
    _lastResult = result;
    _lastSyncAt = new Date();
    await logSync(result);
    logger.info({ tablesSynced, rowsSynced, durationMs: result.durationMs }, 'db-sync: replication complete');
    return result;
  } catch (err) {
    const result: SyncResult = {
      ok: false,
      tablesSynced,
      rowsSynced,
      durationMs: Date.now() - start,
      error: err instanceof Error ? err.message : String(err),
      triggeredBy,
    };
    _lastResult = result;
    _lastSyncAt = new Date();
    await logSync(result);
    return result;
  } finally {
    _syncing = false;
  }
}

async function readTable(name: string): Promise<Record<string, unknown>[]> {
  // Access the Prisma model dynamically by name (e.g. db.agent, db.task).
  const dbAny = db as unknown as Record<string, { findMany?: (args?: { take?: number }) => Promise<Record<string, unknown>[]> }>;
  const model = dbAny[name];
  if (!model || typeof model.findMany !== 'function') return [];
  return model.findMany({ take: 5000 });
}

async function upsertRows(pool: PgPoolLike, table: SyncTableDef, rows: Record<string, unknown>[]): Promise<void> {
  if (rows.length === 0) return;
  // Ensure the table exists with the right columns.
  const colDefs = table.columns.map((c) => `"${c.name}" ${c.type}`).join(', ');
  await pool.query(`CREATE TABLE IF NOT EXISTS "${table.name}" (${colDefs})`);

  // Add a primary key column constraint if missing (idempotent).
  try {
    await pool.query(`ALTER TABLE "${table.name}" ADD PRIMARY KEY ("${table.pk}")`);
  } catch {
    // PK may already exist — ignore.
  }

  const colNames = table.columns.map((c) => `"${c.name}"`).join(', ');
  const paramSlots = table.columns.map((_, i) => `$${i + 1}`).join(', ');
  const updateSet = table.columns
    .filter((c) => c.name !== table.pk)
    .map((c) => `"${c.name}" = EXCLUDED."${c.name}"`)
    .join(', ');

  for (const row of rows) {
    const values = table.columns.map((c) => {
      const v = row[c.name];
      if (v instanceof Date) return v.toISOString();
      if (typeof v === 'boolean') return v;
      if (v === null || v === undefined) return null;
      return v;
    });
    const sql = `INSERT INTO "${table.name}" (${colNames}) VALUES (${paramSlots}) ON CONFLICT ("${table.pk}") DO UPDATE SET ${updateSet}`;
    await pool.query(sql, values);
  }
}

async function logSync(result: SyncResult): Promise<void> {
  try {
    await db.dbSyncLog.create({
      data: {
        direction: 'sqlite-to-postgres',
        status: result.ok ? 'success' : 'error',
        tablesSynced: result.tablesSynced,
        rowsSynced: result.rowsSynced,
        durationMs: result.durationMs,
        error: result.error ?? null,
        triggeredBy: result.triggeredBy,
      },
    });
  } catch {
    // best-effort
  }
}

export function getSyncStatus(): {
  syncing: boolean;
  lastSyncAt: string | null;
  lastResult: SyncResult | null;
} {
  return {
    syncing: _syncing,
    lastSyncAt: _lastSyncAt ? _lastSyncAt.toISOString() : null,
    lastResult: _lastResult,
  };
}

/**
 * Fire-and-forget sync trigger. Used after mutations to keep the mirror
 * ~near-real-time without blocking the API response.
 */
export function triggerSync(triggeredBy: 'post-mutation' | 'auto' = 'post-mutation'): void {
  // Only fire if postgres is configured (cheap check).
  const url = process.env.POSTGRES_DATABASE_URL || process.env.POSTGRES_URL;
  if (!url) return;
  // Debounce: don't fire more than once per 5s.
  syncToPostgres(triggeredBy).catch(() => { /* best-effort */ });
}

// ── Background ticker ─────────────────────────────────────────────────
// Every 60s, if postgres is configured, run an incremental sync.
let _tickerStarted = false;
export function startSyncTicker(): void {
  if (_tickerStarted) return;
  _tickerStarted = true;
  setInterval(() => {
    if (process.env.POSTGRES_DATABASE_URL || process.env.POSTGRES_URL) {
      syncToPostgres('auto').catch(() => { /* best-effort */ });
    }
  }, 60_000);
}
