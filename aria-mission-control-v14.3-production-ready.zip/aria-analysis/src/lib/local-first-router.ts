// local-first-router.ts — Tries local Ollama first, falls back to cloud (z-ai).
//
// Our llm.ts exports a single chat() backed by z-ai-web-dev-sdk (GLM-4.6).
// This router provides a "local-first" wrapper:
//   1. If a model id "looks like" an Ollama tag (e.g. "qwen2.5:7b") AND
//      Ollama is reachable at http://127.0.0.1:11434, route to Ollama
//      via fetch() (chat completions endpoint).
//   2. Otherwise fall back to our canonical chat() from '@/lib/llm'.
//
// Exports:
//   chatLocalFirst(params)         — throws on hard failure
//   chatLocalFirstSafe(params)     — never throws
//   looksLikeLocalOllamaModel(id)  — heuristic check
//   isOllamaUp()                   — cached reachability probe

import { chat, type ChatTurn } from '@/lib/llm'
import { logger } from '@/lib/logger'

export interface LocalChatParams {
  /** Optional model id. If omitted/empty, falls back to chat() default. */
  model?: string
  /** User message (required). */
  message: string
  /** Optional conversation history. */
  history?: ChatTurn[]
  /** Optional system prompt override. */
  systemPrompt?: string
}

export interface LocalChatResponse {
  content: string
  latencyMs: number
  model: string
  provider: 'ollama' | 'cloud'
  usedLocal: boolean
}

export interface SafeLocalChatResponse extends LocalChatResponse {
  error?: string
}

// ── Ollama reachability check (5s cache) ──────────────────────────────────
let _ollamaUp: boolean | null = null
let _ollamaCheckedAt = 0
const OLLAMA_CACHE_MS = 5_000
const OLLAMA_BASE = process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434'

export async function isOllamaUp(): Promise<boolean> {
  const now = Date.now()
  if (_ollamaUp !== null && now - _ollamaCheckedAt < OLLAMA_CACHE_MS) return _ollamaUp
  try {
    const r = await fetch(`${OLLAMA_BASE}/api/tags`, {
      method: 'GET',
      signal: AbortSignal.timeout(1500),
    })
    _ollamaUp = r.ok
  } catch {
    _ollamaUp = false
  }
  _ollamaCheckedAt = now
  return _ollamaUp
}

// Heuristic: a model id "looks local" if it has a colon-tag suffix typical
// of Ollama ("name:tag") and isn't prefixed with a cloud provider.
const CLOUD_PREFIXES = ['groq:', 'omniroute:', 'zai:', 'qwen3-vl:', 'glm-']
export function looksLikeLocalOllamaModel(model: string): boolean {
  if (!model) return false
  if (CLOUD_PREFIXES.some((p) => model.startsWith(p))) return false
  return /^[a-z0-9][a-z0-9._-]*:[a-z0-9._-]+$/i.test(model) || model.endsWith(':latest')
}

async function callOllama(model: string, params: LocalChatParams): Promise<LocalChatResponse> {
  const start = Date.now()
  const messages: Array<{ role: string; content: string }> = []
  if (params.systemPrompt) {
    messages.push({ role: 'system', content: params.systemPrompt })
  }
  for (const h of params.history ?? []) {
    messages.push({ role: h.role, content: h.content })
  }
  messages.push({ role: 'user', content: params.message })

  const r = await fetch(`${OLLAMA_BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages, stream: false }),
    signal: AbortSignal.timeout(60_000),
  })
  if (!r.ok) {
    throw new Error(`Ollama HTTP ${r.status}: ${await r.text().catch(() => '')}`)
  }
  const data = (await r.json()) as { message?: { content?: string } }
  const content = data.message?.content ?? ''
  return {
    content,
    latencyMs: Date.now() - start,
    model,
    provider: 'ollama',
    usedLocal: true,
  }
}

async function callCloud(params: LocalChatParams): Promise<LocalChatResponse> {
  const start = Date.now()
  const { content, latencyMs } = await chat(
    params.message,
    params.history ?? [],
    params.systemPrompt,
  )
  return {
    content,
    latencyMs,
    model: 'glm-4.6',
    provider: 'cloud',
    usedLocal: false,
  }
}

// ── chatLocalFirst (throws on hard failure) ──────────────────────────────
export async function chatLocalFirst(params: LocalChatParams): Promise<LocalChatResponse> {
  const model = params.model ?? ''
  if (looksLikeLocalOllamaModel(model) && (await isOllamaUp())) {
    try {
      return await callOllama(model, params)
    } catch (err) {
      logger.warn({ err: (err as Error).message, model }, 'local-first: ollama failed, falling back to cloud')
    }
  }
  return callCloud(params)
}

// ── Safe variant — never throws ──────────────────────────────────────────
export async function chatLocalFirstSafe(params: LocalChatParams): Promise<SafeLocalChatResponse> {
  try {
    return await chatLocalFirst(params)
  } catch (err) {
    return {
      content: '',
      latencyMs: 0,
      model: params.model ?? 'glm-4.6',
      provider: 'cloud',
      usedLocal: false,
      error: err instanceof Error ? err.message : String(err),
    }
  }
}
