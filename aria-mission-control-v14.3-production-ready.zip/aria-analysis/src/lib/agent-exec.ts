// =====================================================================
// agent-exec.ts — Real API execution sandbox for agent outputs
// =====================================================================
// THE PROBLEM: agents generated code with hypothetical clients
// (kanban_client, artifacts_client) that never actually executed.
//
// THE FIX: this module parses "action blocks" from LLM responses and
// executes them against the REAL API endpoints. An action block looks
// like:
//
//   ```action
//   {"method": "POST", "path": "/api/artifacts", "body": {...}}
//   ```
//
// The agent can chain multiple action blocks. Each is executed in order
// and the result is returned to the agent so it can verify success.
//
// This is what makes the app a REAL autonomous system — agents can
// actually create tasks, save artifacts, process payments, etc.
// =====================================================================

export interface AgentAction {
  method: string;
  path: string;
  body?: Record<string, unknown>;
  query?: Record<string, string>;
}

export interface ActionResult {
  action: AgentAction;
  status: number;
  ok: boolean;
  data: unknown;
  error?: string;
  durationMs: number;
}

const ACTION_BLOCK_REGEX = /```action\s*([\s\S]*?)```/gi;

/**
 * Parse action blocks from an LLM response.
 * Returns an array of AgentAction objects.
 */
export function parseActions(llmResponse: string): AgentAction[] {
  const actions: AgentAction[] = [];
  const matches = [...llmResponse.matchAll(ACTION_BLOCK_REGEX)];
  for (const match of matches) {
    const raw = match[1].trim();
    try {
      const parsed = JSON.parse(raw) as AgentAction;
      if (parsed.method && parsed.path) {
        actions.push({
          method: parsed.method.toUpperCase(),
          path: parsed.path,
          body: parsed.body,
          query: parsed.query,
        });
      }
    } catch {
      // Try to find a JSON object in the raw text
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}');
      if (jsonStart !== -1 && jsonEnd > jsonStart) {
        try {
          const parsed = JSON.parse(raw.slice(jsonStart, jsonEnd + 1)) as AgentAction;
          if (parsed.method && parsed.path) {
            actions.push({
              method: parsed.method.toUpperCase(),
              path: parsed.path,
              body: parsed.body,
              query: parsed.query,
            });
          }
        } catch {
          // skip unparseable block
        }
      }
    }
  }
  return actions;
}

/**
 * Execute a single action against the real API.
 * Uses the app's own base URL (localhost:3000) to make an internal HTTP call.
 */
export async function executeAction(action: AgentAction): Promise<ActionResult> {
  const start = Date.now();
  const baseUrl = `http://localhost:${process.env.PORT || 3000}`;

  let url = action.path;
  if (action.query) {
    const params = new URLSearchParams(action.query);
    url += `?${params.toString()}`;
  }

  try {
    const options: RequestInit = {
      method: action.method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (action.body && ['POST', 'PUT', 'PATCH'].includes(action.method)) {
      options.body = JSON.stringify(action.body);
    }

    const res = await fetch(`${baseUrl}${url}`, options);
    const data = await res.json().catch(() => ({}));

    return {
      action,
      status: res.status,
      ok: res.ok,
      data,
      error: res.ok ? undefined : (data as { error?: string }).error ?? `HTTP ${res.status}`,
      durationMs: Date.now() - start,
    };
  } catch (err) {
    return {
      action,
      status: 0,
      ok: false,
      data: null,
      error: err instanceof Error ? err.message : 'Network error',
      durationMs: Date.now() - start,
    };
  }
}

/**
 * Execute all actions in an LLM response, in order.
 * Returns the results so the caller can feed them back to the agent.
 */
export async function executeActionsFromResponse(llmResponse: string): Promise<{
  actions: AgentAction[];
  results: ActionResult[];
  summary: string;
}> {
  const actions = parseActions(llmResponse);
  const results: ActionResult[] = [];

  for (const action of actions) {
    const result = await executeAction(action);
    results.push(result);
  }

  const successCount = results.filter((r) => r.ok).length;
  const summary =
    results.length === 0
      ? 'No actions found in response.'
      : `Executed ${results.length} action(s): ${successCount} succeeded, ${results.length - successCount} failed.`;

  return { actions, results, summary };
}

/**
 * Format action results as a context string for the agent's next turn.
 * The agent uses this to verify its actions succeeded.
 */
export function formatResultsForAgent(results: ActionResult[]): string {
  if (results.length === 0) return '';
  const lines = results.map((r, i) => {
    const status = r.ok ? '✓ SUCCESS' : '✗ FAILED';
    return `  ${i + 1}. ${status} ${r.action.method} ${r.action.path} (${r.status}, ${r.durationMs}ms)${r.error ? `\n     Error: ${r.error}` : ''}`;
  });
  return `ACTION RESULTS:\n${lines.join('\n')}`;
}
