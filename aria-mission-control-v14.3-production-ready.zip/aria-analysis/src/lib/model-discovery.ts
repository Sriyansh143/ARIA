// =====================================================================
// model-discovery.ts — Discover AI models from memory/knowledge/learning
// =====================================================================
// Scans the MemoryItem, SkillLearning, and AgentLog tables for mentions
// of AI model names (e.g. "used GPT-4o for code review", "Claude 3.5 is
// great for design"). Extracts model IDs + adds them to the Model catalog
// so the smart-router can use them.
//
// This ensures that when agents learn about new models during their work,
// those models are automatically added to the catalog — no manual sync
// needed.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

// Known model name patterns to search for in text.
const MODEL_PATTERNS: Array<{ regex: RegExp; providerKey: string; category: string }> = [
  // OpenAI
  { regex: /\b(gpt-4o|gpt-4o-mini|gpt-4-turbo|gpt-4|gpt-3\.5-turbo|o1|o1-mini|o3-mini)\b/gi, providerKey: 'openai', category: 'chat' },
  // Anthropic
  { regex: /\b(claude-3\.5-sonnet|claude-3-opus|claude-3-haiku|claude-3-sonnet|claude-3\.5-haiku)\b/gi, providerKey: 'anthropic', category: 'chat' },
  // Google
  { regex: /\b(gemini-1\.5-pro|gemini-1\.5-flash|gemini-2\.0-flash|gemini-pro|gemini-ultra)\b/gi, providerKey: 'gemini', category: 'chat' },
  // Meta Llama
  { regex: /\b(llama-3\.3-70b|llama-3\.1-70b|llama-3\.1-8b|llama-3-70b|llama-3-8b|llama-2-70b)\b/gi, providerKey: 'groq', category: 'chat' },
  // Mistral
  { regex: /\b(mistral-large|mistral-small|codestral|mixtral-8x7b|mixtral-8x22b)\b/gi, providerKey: 'mistral', category: 'chat' },
  // DeepSeek
  { regex: /\b(deepseek-v3|deepseek-r1|deepseek-coder|deepseek-chat|deepseek-reasoner)\b/gi, providerKey: 'deepseek', category: 'chat' },
  // Qwen
  { regex: /\b(qwen2\.5-72b|qwen2\.5-7b|qwen2\.5-coder|qwen-vl|qwq)\b/gi, providerKey: 'siliconflow', category: 'chat' },
  // Cohere
  { regex: /\b(command-r-plus|command-r|command-light)\b/gi, providerKey: 'cohere', category: 'chat' },
  // Other
  { regex: /\b(phi-3|gemma-2-9b|gemma-7b)\b/gi, providerKey: 'huggingface', category: 'chat' },
];

export interface DiscoveryResult {
  discovered: number; // total mentions found
  added: number; // new models added to catalog
  skipped: number; // already in catalog
  models: string[]; // list of model IDs found
}

/**
 * Scan memory items, skill-learning records, and agent logs for AI model
 * mentions. Add any newly-discovered models to the Model catalog.
 */
export async function discoverModelsFromMemory(): Promise<DiscoveryResult> {
  const result: DiscoveryResult = { discovered: 0, added: 0, skipped: 0, models: [] };
  const foundModels = new Set<string>();

  try {
    // 1. Scan MemoryItem values for model mentions
    const memories = await db.memoryItem.findMany({
      where: {
        OR: [
          { key: { contains: 'model' } },
          { key: { contains: 'llm' } },
          { value: { contains: 'model' } },
          { value: { contains: 'gpt' } },
          { value: { contains: 'claude' } },
          { value: { contains: 'gemini' } },
          { value: { contains: 'llama' } },
        ],
      },
      select: { value: true, key: true },
      take: 200,
    });

    for (const mem of memories) {
      const text = `${mem.key} ${mem.value}`;
      for (const pattern of MODEL_PATTERNS) {
        const matches = text.match(pattern.regex);
        if (matches) {
          for (const m of matches) {
            const modelId = m.toLowerCase().trim();
            foundModels.add(`${pattern.providerKey}::${modelId}`);
          }
        }
      }
    }

    // 2. Scan AgentLog messages for model mentions
    const logs = await db.agentLog.findMany({
      where: {
        OR: [
          { message: { contains: 'model' } },
          { message: { contains: 'gpt' } },
          { message: { contains: 'claude' } },
          { message: { contains: 'gemini' } },
          { message: { contains: 'llama' } },
          { message: { contains: 'deepseek' } },
        ],
      },
      select: { message: true },
      take: 200,
    });

    for (const log of logs) {
      for (const pattern of MODEL_PATTERNS) {
        const matches = log.message.match(pattern.regex);
        if (matches) {
          for (const m of matches) {
            const modelId = m.toLowerCase().trim();
            foundModels.add(`${pattern.providerKey}::${modelId}`);
          }
        }
      }
    }

    // 3. Scan SkillLearning for model mentions in skill keys
    const learnings = await db.skillLearning.findMany({
      where: {
        OR: [
          { skillKey: { contains: 'llm' } },
          { skillKey: { contains: 'model' } },
        ],
      },
      select: { skillKey: true },
      take: 100,
    });

    for (const sl of learnings) {
      for (const pattern of MODEL_PATTERNS) {
        const matches = sl.skillKey.match(pattern.regex);
        if (matches) {
          for (const m of matches) {
            const modelId = m.toLowerCase().trim();
            foundModels.add(`${pattern.providerKey}::${modelId}`);
          }
        }
      }
    }

    result.discovered = foundModels.size;

    // 4. Add newly-discovered models to the catalog
    for (const entry of foundModels) {
      const [providerKey, modelId] = entry.split('::');
      if (!providerKey || !modelId) continue;

      // Check if already in catalog
      const existing = await db.model.findFirst({
        where: { modelId, providerKey },
      });
      if (existing) {
        result.skipped++;
        continue;
      }

      // Add to catalog
      try {
        await db.model.create({
          data: {
            providerKey,
            modelId,
            contextWindow: 128000, // default
            capabilities: JSON.stringify(['chat']),
            tier: 'medium',
            source: 'memory-discovery',
            status: 'active',
          },
        });
        result.added++;
        result.models.push(modelId);
      } catch {
        // unique constraint or other error — skip
      }
    }

    if (result.added > 0) {
      logger.info({ discovered: result.discovered, added: result.added, models: result.models }, 'model-discovery: found new models in memory/knowledge');
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'model-discovery: failed');
  }

  return result;
}
