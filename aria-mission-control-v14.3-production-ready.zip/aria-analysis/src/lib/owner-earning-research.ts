// owner-earning-research.ts — Owner submits earning idea → agents research
import { db } from '@/lib/db';
import { quickChat, extractJson } from '@/lib/llm';

export async function submitOwnerEarningIdea(idea: string, industry?: string): Promise<string> {
  try {
    const id = `oei-${Date.now()}`;
    const record = { id, ownerIdea: idea, industry: industry ?? 'general', status: 'submitted', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    await db.memoryItem.create({ data: { key: id, scope: 'owner-earning-idea', value: JSON.stringify(record), tags: JSON.stringify(['earning', 'owner-idea']), pinned: true } });
    researchOwnerIdea(id, idea, industry).catch(() => {});
    return id;
  } catch { return ''; }
}

async function updateStatus(id: string, status: string): Promise<void> {
  try {
    const row = await db.memoryItem.findUnique({ where: { key_scope: { key: id, scope: 'owner-earning-idea' } } });
    if (!row) return;
    const record = JSON.parse(row.value);
    record.status = status; record.updatedAt = new Date().toISOString();
    await db.memoryItem.update({ where: { key_scope: { key: id, scope: 'owner-earning-idea' } }, data: { value: JSON.stringify(record) } });
  } catch {}
}

export async function researchOwnerIdea(id: string, idea: string, industry?: string): Promise<void> {
  try {
    await updateStatus(id, 'researching');
    const prompt = `You are an expert business analyst. The owner submitted: "${idea}" (Industry: ${industry ?? 'general'}).

Output JSON: {"researchSummary":"3-4 sentences","howItWorks":"detailed revenue mechanism","stepByStepWorkflow":[{"step":1,"action":"...","detail":"...","expectedOutcome":"..."}],"revenuePotential":{"low":50000,"medium":200000,"high":500000},"expertKnowledge":"industry secrets","executionFlow":[{"phase":"Phase 1","tasks":["..."],"agent":"ORION"}]}`;
    const raw = await quickChat(prompt, 'You are a business analyst. Output ONLY JSON.');
    const research = extractJson<Record<string, unknown>>(raw);
    if (!research) { await updateStatus(id, 'research_failed'); return; }

    const row = await db.memoryItem.findUnique({ where: { key_scope: { key: id, scope: 'owner-earning-idea' } } });
    if (!row) return;
    const record = JSON.parse(row.value);
    record.status = 'researched'; record.updatedAt = new Date().toISOString();
    Object.assign(record, research);
    await db.memoryItem.update({ where: { key_scope: { key: id, scope: 'owner-earning-idea' } }, data: { value: JSON.stringify(record) } });

    try {
      const rp = research.revenuePotential as { medium?: number } ?? {};
      await db.earningMethod.create({ data: { key: `owner-${id}`, name: idea.slice(0, 100), description: (research.researchSummary as string) ?? idea, category: industry ?? 'general', earningPotential: (rp.medium ?? 50000) > 50000 ? 'high' : 'medium', riskLevel: 'low', skillsRequired: JSON.stringify(['research']), method: (research.howItWorks as string) ?? '', estimatedMonthly: rp.medium ?? 50000, approvalStatus: 'pending_approval', tags: JSON.stringify(['owner-idea', industry ?? 'general']) } });
    } catch {}
  } catch { await updateStatus(id, 'research_failed'); }
}

export async function listOwnerEarningIdeas() {
  try {
    const items = await db.memoryItem.findMany({ where: { scope: 'owner-earning-idea' }, orderBy: { createdAt: 'desc' } });
    return items.map(i => JSON.parse(i.value));
  } catch { return []; }
}

export async function getOwnerEarningIdea(id: string) {
  try {
    const item = await db.memoryItem.findUnique({ where: { key_scope: { key: id, scope: 'owner-earning-idea' } } });
    return item ? JSON.parse(item.value) : null;
  } catch { return null; }
}
