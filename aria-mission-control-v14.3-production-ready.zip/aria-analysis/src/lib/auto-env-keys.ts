// =====================================================================
// auto-env-keys.ts — Auto-generate auth keys on page load
// =====================================================================
// PRODUCTION ENHANCEMENT (v11.3): On server startup, this module checks
// for empty/missing auth keys in process.env and auto-generates secure
// random values for them. This ensures the app is always secured even
// if the operator didn't manually set the keys.
//
// Generated keys are written to the .env file so they persist across
// restarts. The generator is idempotent — it only fills EMPTY keys,
// never overwrites existing ones.
// =====================================================================

import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

const ENV_FILE = path.join(process.cwd(), '.env');

/**
 * Generate a secure random hex string of the given byte length.
 */
function generateKey(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Generate a base64-encoded key (for tokens that prefer base64).
 */
function generateBase64Key(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('base64');
}

/**
 * Keys to auto-generate if empty. Format: { envVar: generatorFn }
 */
const AUTO_KEYS: Record<string, () => string> = {
  AUTH_SECRET: () => generateKey(32),
  NEXTAUTH_SECRET: () => generateKey(32),
  JARVIS_SHARED_KEY: () => generateKey(32),
  ENCRYPTION_MASTER_KEY: () => generateKey(32),
  ENCRYPTION_KEY: () => generateKey(16),
  CREDENTIAL_ENCRYPTION_KEY: () => generateKey(32),
  JARVIS_OWNER_TOKEN: () => generateBase64Key(24),
  REQUEST_SIGNING_SECRET: () => generateKey(32),
  JARVIS_VAULT_AUTH_TOKEN: () => generateBase64Key(24),
  HASH_SALT: () => generateKey(16),
};

/**
 * Read the current .env file into a map.
 */
function readEnvFile(): Map<string, string> {
  const map = new Map<string, string>();
  if (!fs.existsSync(ENV_FILE)) return map;
  const content = fs.readFileSync(ENV_FILE, 'utf-8');
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const value = trimmed.slice(eqIdx + 1).trim();
    map.set(key, value);
  }
  return map;
}

/**
 * Write the env map back to the .env file (preserving comments + order).
 */
function writeEnvFile(map: Map<string, string>): void {
  if (!fs.existsSync(ENV_FILE)) return;
  const content = fs.readFileSync(ENV_FILE, 'utf-8');
  const lines = content.split('\n');
  const updated = lines.map((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return line;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) return line;
    const key = trimmed.slice(0, eqIdx).trim();
    if (map.has(key)) {
      return `${key}=${map.get(key)}`;
    }
    return line;
  });
  fs.writeFileSync(ENV_FILE, updated.join('\n'), 'utf-8');
}

/**
 * Auto-generate missing auth keys. Called on server startup.
 * Returns a summary of what was generated.
 */
export function autoGenerateAuthKeys(): {
  generated: string[];
  skipped: string[];
  total: number;
} {
  const generated: string[] = [];
  const skipped: string[] = [];

  // Read the .env file (authoritative source for persisted keys)
  const envMap = readEnvFile();

  for (const [key, genFn] of Object.entries(AUTO_KEYS)) {
    const currentValue = envMap.get(key) ?? process.env[key] ?? '';

    // Only generate if the key is empty or missing
    if (!currentValue || currentValue.trim() === '') {
      const newValue = genFn();
      envMap.set(key, newValue);
      process.env[key] = newValue;
      generated.push(key);
    } else {
      skipped.push(key);
    }
  }

  // Persist generated keys to .env
  if (generated.length > 0) {
    try {
      writeEnvFile(envMap);
      console.log(`[auto-env-keys] Generated ${generated.length} auth keys: ${generated.join(', ')}`);
    } catch (err) {
      console.warn(`[auto-env-keys] Failed to write .env: ${err instanceof Error ? err.message : String(err)}`);
      // Keys are still in process.env for this session — just not persisted
    }
  }

  return { generated, skipped, total: Object.keys(AUTO_KEYS).length };
}
