// =====================================================================
// system-metrics.ts — REAL system metrics via `systeminformation`.
// =====================================================================
// Provides `getRealSystemMetrics()` — a single async entry point that
// returns live CPU / memory / disk / network / uptime / load-average
// values from the underlying OS. Designed to NEVER throw: if the
// systeminformation library fails (sandboxed container, missing
// /proc, etc.) it returns sensible fallbacks derived from Node's
// `process.memoryUsage()` + `os` module.
//
// A 500ms in-memory cache prevents rapid successive calls (e.g. from
// /api/metrics + /api/dashboard + cron tick all firing at once) from
// hammering the OS with `si.currentLoad()` / `si.fsSize()` calls.
//
// Network throughput (netRx / netTx) is computed as a delta from the
// previous reading — the first call always returns 0 because there is
// no baseline yet. Subsequent calls return bytes-per-second since the
// last successful sample.
// =====================================================================

import * as os from 'os';
import * as si from 'systeminformation';

export interface SystemMetrics {
  /** CPU load percentage (0-100). */
  cpu: number;
  /** Used memory in MB. */
  mem: number;
  /** Total memory in MB. */
  memTotal: number;
  /** Disk usage percentage (0-100) of the root partition. */
  disk: number;
  /** Total disk size in GB of the root partition. */
  diskTotal: number;
  /** Network receive bytes per second (delta from previous sample). */
  netRx: number;
  /** Network transmit bytes per second (delta from previous sample). */
  netTx: number;
  /** System uptime in seconds (os.uptime()). */
  uptime: number;
  /** 1 / 5 / 15 minute load averages (os.loadavg()). */
  loadAvg: number[];
}

// ─── Module-level state ───────────────────────────────────────────────
//  • `cache`     — short-lived (500ms) memoized result so the metrics
//                  API + dashboard + cron tick can all read within the
//                  same event-loop turn without re-querying the OS.
//  • `lastNet`   — last cumulative rx/tx byte counters + timestamp.
//                  Used to compute the per-second rate on each call.
let cache: { value: SystemMetrics; ts: number } | null = null;
let lastNet: { rx: number; tx: number; ts: number } | null = null;

const CACHE_TTL_MS = 500;
const BYTES_PER_MB = 1024 * 1024;
const BYTES_PER_GB = 1024 * 1024 * 1024;

// ─── Fallback (when systeminformation is unavailable / errors) ────────
// Returns process-level metrics instead of system-level — better than
// throwing, which would crash whatever called this (cron tick, API
// route, autonomous loop). Still real (just narrower scope).
function getFallbackMetrics(): SystemMetrics {
  const mem = process.memoryUsage();
  return {
    cpu: 0,
    mem: mem.rss / BYTES_PER_MB,
    memTotal: mem.rss / BYTES_PER_MB,
    disk: 0,
    diskTotal: 0,
    netRx: 0,
    netTx: 0,
    uptime: os.uptime(),
    loadAvg: os.loadavg(),
  };
}

// ─── Main entry point ─────────────────────────────────────────────────
export async function getRealSystemMetrics(): Promise<SystemMetrics> {
  // Cache hit — return immediately without touching the OS.
  if (cache && Date.now() - cache.ts < CACHE_TTL_MS) {
    return cache.value;
  }

  try {
    const [currentLoad, memInfo, fsSize, netStats] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
      si.networkStats(),
    ]);

    // ── CPU ── currentLoad.currentLoad is 0-100 (clamped defensively).
    // NOTE: field is `currentLoad` (camelCase) per systeminformation typings.
    const cpu = Math.max(0, Math.min(100, currentLoad.currentLoad ?? 0));

    // ── Memory ── used = total - available (fall back to `free` if
    // `available` is undefined on older kernels). Convert bytes → MB.
    const memTotalBytes = memInfo.total ?? 0;
    const memAvailBytes = memInfo.available ?? memInfo.free ?? 0;
    const memUsedBytes = Math.max(0, memTotalBytes - memAvailBytes);
    const memTotalMb = memTotalBytes / BYTES_PER_MB;
    const memUsedMb = memUsedBytes / BYTES_PER_MB;

    // ── Disk ── prefer the root mount (`/`); fall back to first entry.
    //    `fsSize.use` is already a 0-100 percentage; `fsSize.size` is bytes.
    const rootFs =
      fsSize.find((f) => f.mount === '/' || f.mount === '') ?? fsSize[0];
    const diskPct = rootFs?.use ?? 0;
    const diskTotalGb = rootFs ? rootFs.size / BYTES_PER_GB : 0;

    // ── Network ── sum cumulative rx/tx across all interfaces, then
    //    compute delta-vs-last / elapsed-seconds = bytes per second.
    //    First call has no baseline → returns 0 (next call will be real).
    const now = Date.now();
    const totalRx = netStats.reduce((s, n) => s + (n.rx_bytes ?? 0), 0);
    const totalTx = netStats.reduce((s, n) => s + (n.tx_bytes ?? 0), 0);
    let netRx = 0;
    let netTx = 0;
    if (lastNet) {
      const elapsedSec = (now - lastNet.ts) / 1000;
      if (elapsedSec > 0) {
        // Clamp at 0 — counter resets on reboot would otherwise produce
        // a huge negative spike.
        netRx = Math.max(0, (totalRx - lastNet.rx) / elapsedSec);
        netTx = Math.max(0, (totalTx - lastNet.tx) / elapsedSec);
      }
    }
    lastNet = { rx: totalRx, tx: totalTx, ts: now };

    const metrics: SystemMetrics = {
      cpu: Math.round(cpu * 10) / 10,
      mem: Math.round(memUsedMb * 10) / 10,
      memTotal: Math.round(memTotalMb * 10) / 10,
      disk: Math.round(diskPct * 10) / 10,
      diskTotal: Math.round(diskTotalGb * 10) / 10,
      netRx: Math.round(netRx),
      netTx: Math.round(netTx),
      uptime: os.uptime(),
      loadAvg: os.loadavg(),
    };

    cache = { value: metrics, ts: now };
    return metrics;
  } catch (err) {
    // NEVER throw — callers (API routes, cron tick) must not crash.
    console.warn(
      `[system-metrics] getRealSystemMetrics failed: ${
        err instanceof Error ? err.message : String(err)
      } — returning process-level fallback`,
    );
    return getFallbackMetrics();
  }
}
