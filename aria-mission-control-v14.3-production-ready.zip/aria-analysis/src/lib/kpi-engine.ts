// =====================================================================
// kpi-engine.ts — Automatic KPI adjustments based on logged outcomes
// =====================================================================
// PRODUCTION ENHANCEMENT (v11): When autonomous decisions are logged
// (briefings, autopilot ticks, reversals), the KPI engine re-evaluates
// the fleet's key performance indicators and auto-adjusts targets so
// they stay realistic and actionable. Snapshots are persisted to the
// KpiSnapshot table for trend analysis.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export interface KpiStatus {
  kpi: string;
  value: number;
  target: number;
  status: 'nominal' | 'warning' | 'critical' | 'exceeded';
  autoAdjusted: boolean;
  adjustmentNote?: string;
}

const KPI_TARGETS: Record<string, { default: number; min: number; max: number }> = {
  health: { default: 85, min: 60, max: 100 },
  throughput: { default: 80, min: 40, max: 100 },
  'success-rate': { default: 95, min: 70, max: 100 },
  revenue: { default: 100000, min: 10000, max: 1000000 },
  latency: { default: 2000, min: 500, max: 10000 },
};

function classifyStatus(kpi: string, value: number, target: number): KpiStatus['status'] {
  if (kpi === 'latency') {
    // lower is better
    if (value > target * 1.5) return 'critical';
    if (value > target * 1.2) return 'warning';
    if (value < target * 0.7) return 'exceeded';
    return 'nominal';
  }
  if (kpi === 'revenue' || kpi === 'throughput' || kpi === 'success-rate' || kpi === 'health') {
    // higher is better
    if (value >= target) return 'exceeded';
    if (value < target * 0.5) return 'critical';
    if (value < target * 0.75) return 'warning';
    return 'nominal';
  }
  return 'nominal';
}

/**
 * Compute the current KPI values from live fleet state.
 */
export async function computeKpis(): Promise<KpiStatus[]> {
  const now = new Date();
  const hourAgo = new Date(now.getTime() - 60 * 60 * 1000);
  const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  const [agents, tasks, telemetry, payments, recentLogs, lastBriefing] = await Promise.all([
    db.agent.findMany({ select: { successRate: true, load: true, status: true } }),
    db.task.findMany({ where: { updatedAt: { gte: dayAgo } }, select: { status: true } }),
    db.telemetry.findMany({ orderBy: { createdAt: 'desc' }, take: 1 }),
    db.payment.findMany({ where: { status: 'confirmed', createdAt: { gte: dayAgo } }, select: { amount: true } }),
    db.agentLog.count({ where: { level: 'error', createdAt: { gte: hourAgo } } }),
    db.actionLog.findFirst({ where: { action: 'briefing.generated' }, orderBy: { createdAt: 'desc' }, select: { meta: true } }),
  ]).catch(() => [[], [], [], [], 0, null] as const);

  const avgSuccess = agents.length > 0 ? agents.reduce((s, a) => s + a.successRate, 0) / agents.length : 100;
  const completed = tasks.filter((t: { status: string }) => t.status === 'completed').length;
  const totalTasks = tasks.length || 1;
  const throughput = (completed / totalTasks) * 100;
  const revenue = payments.reduce((s: number, p: { amount: number }) => s + p.amount, 0);
  const t = telemetry[0] as { latency?: number; cpu?: number; mem?: number } | undefined;
  const latency = t?.latency ?? 0;

  // Health from last briefing meta (or compute a rough proxy)
  let health = 85;
  try {
    if (lastBriefing?.meta) {
      const meta = JSON.parse(lastBriefing.meta);
      if (typeof meta.health === 'number') health = meta.health;
    }
  } catch { /* ignore */ }

  const kpis: KpiStatus[] = [];
  for (const [kpi, def] of Object.entries(KPI_TARGETS)) {
    const value =
      kpi === 'health' ? health :
      kpi === 'throughput' ? Math.round(throughput) :
      kpi === 'success-rate' ? Math.round(avgSuccess * 10) / 10 :
      kpi === 'revenue' ? Math.round(revenue) :
      kpi === 'latency' ? latency :
      0;
    kpis.push({
      kpi,
      value,
      target: def.default,
      status: classifyStatus(kpi, value, def.default),
      autoAdjusted: false,
    });
  }

  return kpis;
}

/**
 * Auto-adjust KPI targets based on recent performance. If a KPI is
 * consistently exceeded, raise the target. If it's consistently missed,
 * lower the target (to keep it achievable + actionable). Returns the
 * adjusted KPIs and persists a snapshot.
 */
export async function autoAdjustKpis(trigger: string): Promise<KpiStatus[]> {
  const kpis = await computeKpis();

  // Look at the last 7 snapshots to detect a consistent trend.
  const recentSnapshots = await db.kpiSnapshot.findMany({
    orderBy: { snapshotAt: 'desc' },
    take: 35, // ~7 per KPI × 5 KPIs
  }).catch(() => []);

  for (const kpi of kpis) {
    const def = KPI_TARGETS[kpi.kpi];
    if (!def) continue;
    const history = recentSnapshots.filter((s) => s.kpi === kpi.kpi).slice(0, 7);
    if (history.length < 3) {
      // Not enough history — keep the default target.
      continue;
    }
    const exceededCount = history.filter((s) => s.status === 'exceeded').length;
    const criticalCount = history.filter((s) => s.status === 'critical').length;
    let newTarget = kpi.target;
    let note = '';
    // If exceeded in ≥5 of last 7, raise the target by 10% (more aggressive).
    if (exceededCount >= 5) {
      newTarget = Math.min(def.max, Math.round(kpi.target * 1.1));
      note = `Auto-raised target (exceeded ${exceededCount}/7 recent) — ${trigger}`;
    }
    // If critical in ≥4 of last 7, lower the target by 15% (more realistic).
    else if (criticalCount >= 4) {
      newTarget = Math.max(def.min, Math.round(kpi.target * 0.85));
      note = `Auto-lowered target (critical ${criticalCount}/7 recent) — ${trigger}`;
    }
    if (newTarget !== kpi.target) {
      kpi.target = newTarget;
      kpi.autoAdjusted = true;
      kpi.adjustmentNote = note;
      kpi.status = classifyStatus(kpi.kpi, kpi.value, newTarget);
    }
  }

  // Persist snapshots (best-effort).
  for (const kpi of kpis) {
    try {
      await db.kpiSnapshot.create({
        data: {
          kpi: kpi.kpi,
          value: kpi.value,
          target: kpi.target,
          status: kpi.status,
          autoAdjusted: kpi.autoAdjusted,
          adjustmentNote: kpi.adjustmentNote ?? null,
        },
      });
    } catch {
      // best-effort
    }
  }

  const adjusted = kpis.filter((k) => k.autoAdjusted);
  if (adjusted.length > 0) {
    logger.info({ adjusted: adjusted.map((a) => ({ kpi: a.kpi, newTarget: a.target, note: a.adjustmentNote })), trigger }, 'kpi-engine: auto-adjusted KPI targets');
  }
  return kpis;
}

/**
 * Get the latest KPI snapshot for each KPI (for the UI).
 */
export async function getLatestKpis(): Promise<KpiStatus[]> {
  try {
    const kpis = await computeKpis();
    // Overlay the last persisted target so auto-adjustments stick.
    for (const kpi of kpis) {
      const last = await db.kpiSnapshot.findFirst({
        where: { kpi: kpi.kpi },
        orderBy: { snapshotAt: 'desc' },
      });
      if (last) {
        kpi.target = last.target;
        kpi.autoAdjusted = last.autoAdjusted;
        kpi.adjustmentNote = last.adjustmentNote ?? undefined;
        kpi.status = classifyStatus(kpi.kpi, kpi.value, last.target);
      }
    }
    return kpis;
  } catch {
    return [];
  }
}
