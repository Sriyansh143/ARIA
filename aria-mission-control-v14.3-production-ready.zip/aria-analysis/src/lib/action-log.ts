// =====================================================================
// action-log.ts — Reversible action log with before/after state
// =====================================================================
// Every mutating action is logged here. Each entry has beforeState +
// afterState JSON snapshots so the action can be REVERSED later.
// =====================================================================

import { db } from '@/lib/db';
import { logger } from '@/lib/logger';

export interface LogActionInput {
  actor?: string;
  action: string;
  category?: string;
  target?: string;
  beforeState?: unknown;
  afterState?: unknown;
  reversible?: boolean;
  meta?: Record<string, unknown>;
}

export async function logAction(input: LogActionInput): Promise<string> {
  try {
    const row = await db.actionLog.create({
      data: {
        actor: input.actor ?? 'system',
        action: input.action,
        category: input.category ?? 'mutation',
        target: input.target ?? null,
        beforeState: input.beforeState ? JSON.stringify(input.beforeState) : null,
        afterState: input.afterState ? JSON.stringify(input.afterState) : null,
        reversible: input.reversible ?? true,
        meta: JSON.stringify(input.meta ?? {}),
      },
    });
    return row.id;
  } catch (err) {
    logger.error({ err }, 'action-log: logAction failed');
    return '';
  }
}

export async function reverseAction(
  id: string,
  opts: { reversedBy?: string; force?: boolean } = {},
): Promise<{ ok: boolean; detail: string }> {
  const reversedBy = opts.reversedBy ?? 'operator';
  try {
    const row = await db.actionLog.findUnique({ where: { id } });
    if (!row) return { ok: false, detail: 'ActionLog not found' };
    if (row.reversed) return { ok: true, detail: 'Already reversed' };
    if (!row.reversible) return { ok: false, detail: 'Action is not reversible' };

    // Log the reversal attempt to audit log
    try {
      await db.auditLog.create({
        data: {
          actor: reversedBy,
          action: 'reversal.initiated',
          target: `action-log:${id}`,
          meta: JSON.stringify({ originalAction: row.action, forced: opts.force === true }),
        },
      });
    } catch { /* best-effort */ }

    // Destructive reversal safety gate
    const isDestructive = row.category === 'destructive' || row.action.endsWith('.delete');
    if (isDestructive && !opts.force) {
      return {
        ok: false,
        detail: 'Reversal of destructive action requires force: true',
      };
    }

    // Perform the reversal based on action type
    const verb = row.action.split('.').pop() ?? '';
    const before = row.beforeState ? JSON.parse(row.beforeState) : null;

    if (verb === 'create' && before) {
      // Reverse a create → delete the entity
      const entityType = row.action.split('.')[0];
      if (entityType === 'client' && before.id) {
        await db.client.delete({ where: { id: before.id } }).catch(() => {});
      } else if (entityType === 'lead' && before.id) {
        await db.lead.delete({ where: { id: before.id } }).catch(() => {});
      } else if (entityType === 'ticket' && before.id) {
        await db.supportTicket.delete({ where: { id: before.id } }).catch(() => {});
      }
    } else if (verb === 'delete' && before) {
      // Reverse a delete → re-create the entity
      const entityType = row.action.split('.')[0];
      if (entityType === 'client') {
        await db.client.create({ data: before }).catch(() => {});
      } else if (entityType === 'lead') {
        await db.lead.create({ data: before }).catch(() => {});
      } else if (entityType === 'ticket') {
        await db.supportTicket.create({ data: before }).catch(() => {});
      }
    } else if (verb === 'update' && before) {
      // Reverse an update → restore beforeState
      const entityType = row.action.split('.')[0];
      if (entityType === 'client' && before.id) {
        await db.client.update({ where: { id: before.id }, data: before }).catch(() => {});
      } else if (entityType === 'lead' && before.id) {
        await db.lead.update({ where: { id: before.id }, data: before }).catch(() => {});
      } else if (entityType === 'ticket' && before.id) {
        await db.supportTicket.update({ where: { id: before.id }, data: before }).catch(() => {});
      }
    }

    await db.actionLog.update({
      where: { id },
      data: {
        reversed: true,
        reversedAt: new Date(),
        reversedBy,
        reverseResult: JSON.stringify({ ok: true, method: verb }),
      },
    });

    return { ok: true, detail: `Reversed via ${verb}` };
  } catch (err) {
    logger.error({ err }, 'action-log: reverseAction failed');
    return { ok: false, detail: err instanceof Error ? err.message : 'unknown error' };
  }
}

export async function listActions(filter: {
  actor?: string;
  action?: string;
  category?: string;
  reversed?: boolean;
  limit?: number;
} = {}): Promise<{ rows: unknown[]; total: number }> {
  const where: Record<string, unknown> = {};
  if (filter.actor) where.actor = filter.actor;
  if (filter.action) where.action = filter.action;
  if (filter.category) where.category = filter.category;
  if (filter.reversed !== undefined) where.reversed = filter.reversed;
  const limit = filter.limit ?? 50;
  const [rows, total] = await Promise.all([
    db.actionLog.findMany({ where, orderBy: { createdAt: 'desc' }, take: limit }),
    db.actionLog.count({ where }),
  ]);
  return { rows, total };
}

export async function getActionStats(): Promise<{
  total: number;
  reversed: number;
  reversible: number;
  byCategory: Record<string, number>;
}> {
  const [total, reversed, reversible, byCatRows] = await Promise.all([
    db.actionLog.count(),
    db.actionLog.count({ where: { reversed: true } }),
    db.actionLog.count({ where: { reversible: true } }),
    db.actionLog.groupBy({ by: ['category'], _count: true }),
  ]);
  const byCategory: Record<string, number> = {};
  for (const r of byCatRows) byCategory[r.category] = r._count;
  return { total, reversed, reversible, byCategory };
}
