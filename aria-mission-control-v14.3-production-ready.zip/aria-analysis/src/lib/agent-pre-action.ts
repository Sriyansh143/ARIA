// =====================================================================
// agent-pre-action.ts — Pre-action research + thinking layer
// =====================================================================
// USER RULE: "agents should think and research before doing anything"
//
// Before any agent executes an action, this module:
//   1. Researches the context (what's the current state? what could go wrong?)
//   2. Generates a step-by-step action plan
//   3. Identifies risks + mitigations
//   4. Verifies the plan against the no-assumption rule
//   5. Only then returns the green light to execute
//
// This is NOT a gate (it doesn't block actions) — it's an ENHANCER that
// gives the agent a researched context so it acts intelligently.
// =====================================================================

import { quickChat, extractJson } from '@/lib/llm';
import { logger } from '@/lib/logger';

export interface PreActionContext {
  agentCodename: string;
  agentRole: string;
  action: string;
  actionType: 'create' | 'update' | 'delete' | 'execute' | 'research' | 'communicate' | 'deploy';
  target?: string;
  description: string;
  currentContext?: string;
}

export interface PreActionResearch {
  research: string;
  risks: Array<{ risk: string; severity: 'low' | 'medium' | 'high'; mitigation: string }>;
  plan: Array<{ step: number; action: string; expectedOutcome: string; verification: string }>;
  requiresApproval: boolean;
  approvalReason?: string;
  confidence: number;
  recommendation: 'proceed' | 'proceed-with-caution' | 'request-approval' | 'abort';
  notes: string;
}

const RESEARCH_SYSTEM = `You are a pre-action research agent for an autonomous AI system. Before an agent takes an action, you RESEARCH the context and generate a risk assessment + step-by-step plan.

Rules:
- THINK before acting. Consider what could go wrong.
- Research the current state — don't assume.
- Identify risks and mitigations.
- If the action is destructive or irreversible, recommend "request-approval".
- If the action is routine and safe, recommend "proceed".
- Output STRICT JSON with the structure below.

JSON schema:
{
  "research": "2-3 sentences summarizing what you found",
  "risks": [{"risk":"...","severity":"low|medium|high","mitigation":"..."}],
  "plan": [{"step":1,"action":"...","expectedOutcome":"...","verification":"..."}],
  "requiresApproval": true/false,
  "approvalReason": "why approval is needed (if applicable)",
  "confidence": 0-100,
  "recommendation": "proceed|proceed-with-caution|request-approval|abort",
  "notes": "any additional context"
}`;

/**
 * Research + plan before an agent takes an action.
 * Returns a structured PreActionResearch that the agent uses to decide
 * whether to proceed, request approval, or abort.
 */
export async function researchBeforeAction(ctx: PreActionContext): Promise<PreActionResearch> {
  const userMsg = `Agent: ${ctx.agentCodename} (${ctx.agentRole})
Action: ${ctx.action}
Action type: ${ctx.actionType}
Target: ${ctx.target ?? 'n/a'}
Description: ${ctx.description}
Current context: ${ctx.currentContext ?? 'none provided'}

Research this action before it's executed. What could go wrong? What's the safest way to do it?`;

  try {
    const raw = await quickChat(userMsg.slice(0, 3000), RESEARCH_SYSTEM);
    const parsed = extractJson<PreActionResearch>(raw);
    if (parsed && parsed.research && parsed.recommendation) {
      return {
        research: parsed.research,
        risks: parsed.risks ?? [],
        plan: parsed.plan ?? [],
        requiresApproval: parsed.requiresApproval ?? false,
        approvalReason: parsed.approvalReason,
        confidence: parsed.confidence ?? 0,
        recommendation: parsed.recommendation,
        notes: parsed.notes ?? '',
      };
    }
    // Fallback if JSON parsing fails
    return {
      research: raw.slice(0, 500),
      risks: [],
      plan: [],
      requiresApproval: ctx.actionType === 'delete' || ctx.actionType === 'deploy',
      approvalReason: ctx.actionType === 'delete' ? 'Destructive action' : undefined,
      confidence: 50,
      recommendation: 'proceed-with-caution',
      notes: 'LLM research could not be parsed — proceeding with caution',
    };
  } catch (err) {
    logger.error({ err }, 'agent-pre-action: research failed');
    return {
      research: `Research failed: ${err instanceof Error ? err.message : 'unknown error'}`,
      risks: [],
      plan: [],
      requiresApproval: false,
      confidence: 0,
      recommendation: 'proceed-with-caution',
      notes: 'Research layer failed — agent should proceed carefully',
    };
  }
}

/**
 * Quick check: should this action type require approval?
 * Used as a fast pre-filter before the full research runs.
 */
export function actionTypeNeedsApproval(actionType: PreActionContext['actionType']): boolean {
  return ['delete', 'deploy'].includes(actionType);
}
