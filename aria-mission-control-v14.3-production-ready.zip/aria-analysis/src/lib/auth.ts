// auth.ts — Lightweight role-based access control
import { NextRequest } from 'next/server';

export type Role = 'owner' | 'viewer';

export const OWNER_ONLY_TABS = new Set([
  'terminal', 'files', 'ide', 'approvals', 'change-requests', 'action-log', 'branding', 'data-mgmt', 'scheduler',
]);

export const OWNER_ONLY_API_PREFIXES = [
  '/api/terminal/', '/api/file/', '/api/workspace/', '/api/ide/',
  '/api/action-log/', '/api/changes/', '/api/branding', '/api/data-mgmt/',
  '/api/system/autonomy', '/api/refunds', '/api/approvals',
];

export function getRoleFromRequest(req: NextRequest | null): Role {
  if (!req) return 'owner';
  const ownerToken = process.env.JARVIS_OWNER_TOKEN;
  if (ownerToken) {
    const headerToken = req.headers.get('x-owner-token');
    if (headerToken && headerToken === ownerToken) return 'owner';
  }
  const roleCookie = req.cookies.get('jarvis-role')?.value;
  if (roleCookie === 'viewer' || roleCookie === 'owner') return roleCookie;
  return 'owner';
}

export function canAccessTab(tabKey: string, role: Role): boolean {
  if (role === 'owner') return true;
  return !OWNER_ONLY_TABS.has(tabKey);
}

export function canAccessApi(path: string, role: Role): boolean {
  if (role === 'owner') return true;
  return !OWNER_ONLY_API_PREFIXES.some((p) => path.startsWith(p));
}
