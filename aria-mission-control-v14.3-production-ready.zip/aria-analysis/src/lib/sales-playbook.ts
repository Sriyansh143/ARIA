// sales-playbook.ts — 12+ industry sales playbooks (restaurant, retail,
// real-estate, professional-services, healthcare, technology, education,
// automotive, hospitality, fitness, legal, beauty-salon) + 3D scroll
// template generator (kept for backwards compatibility — see pitch-templates.ts
// for the richer 3-template system used by the Pitch Templates tab).

export interface SalesPlaybook {
  industry: string;
  openingHook: string;
  valueProps: string[];
  commonObjections: Array<{ objection: string; rebuttal: string }>;
  pricingTiers: Array<{ name: string; price: number; features: string[] }>;
  upsellPaths: Array<{ trigger: string; offer: string; price: number }>;
  closingQuestions: string[];
}

const PLAYBOOKS: Record<string, SalesPlaybook> = {
  restaurant: {
    industry: 'restaurant',
    openingHook: "I noticed your restaurant doesn't have a website. I build restaurant websites with online menus, table booking, and Google Maps — starting at ₹4,999.",
    valueProps: ['Online menu (no printing costs)', 'Table booking (reduces no-shows 40%)', 'Google Maps integration', 'Mobile-responsive', 'SEO for "restaurants near me"'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'At ₹4,999 one-time, it pays for itself with 2-3 new customers.' },
      { objection: "I don't have time", rebuttal: 'Fully managed — we handle everything. You just cook.' },
      { objection: 'I have Facebook', rebuttal: '60% search Google. Without a website, you lose them.' },
      { objection: 'Customers know me', rebuttal: 'New residents + tourists search online first.' },
      { objection: "I'll think about it", rebuttal: 'Let me show you a free preview. Takes 2 minutes.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 4999, features: ['3-page website', 'Online menu', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 9999, features: ['Everything in Basic', 'Table booking', 'Photo gallery', 'Google Maps', 'SEO setup'] },
      { name: 'Enterprise', price: 19999, features: ['Everything in Pro', 'Online ordering', 'Payment integration', 'Monthly updates'] },
    ],
    upsellPaths: [
      { trigger: 'online ordering', offer: 'Online ordering + payment', price: 7999 },
      { trigger: 'marketing', offer: 'Monthly social media', price: 2999 },
    ],
    closingQuestions: ['Want me to build a preview right now?', 'Can I get you started with Basic today?'],
  },
  retail: {
    industry: 'retail',
    openingHook: "I build e-commerce websites with product catalogs, online payments, and inventory — starting at ₹7,999.",
    valueProps: ['Online product catalog', 'Secure payment gateway', 'Inventory auto-sync', 'WhatsApp ordering', 'Delivery tracking'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: '5 online orders/month at ₹1000 pays for it in 2 months.' },
      { objection: 'I sell on Amazon', rebuttal: 'Marketplaces charge 15-30% commission. Your website keeps 100%.' },
      { objection: "I don't know inventory", rebuttal: 'Auto-updates when you sell. Simple dashboard.' },
      { objection: 'Customers visit in person', rebuttal: 'Website showcases products 24/7. They browse online, then visit.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with 5 products.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 7999, features: ['50 products', 'UPI payment', 'WhatsApp ordering', 'Mobile responsive'] },
      { name: 'Pro', price: 14999, features: ['Unlimited products', 'Full payment gateway', 'Inventory management', 'Order tracking', 'SEO'] },
      { name: 'Enterprise', price: 29999, features: ['Everything in Pro', 'Multi-vendor', 'Mobile app', 'Analytics'] },
    ],
    upsellPaths: [
      { trigger: 'mobile app', offer: 'Mobile app (Android+iOS)', price: 19999 },
      { trigger: 'marketing', offer: 'Google Ads + social media', price: 4999 },
    ],
    closingQuestions: ['Want a free preview with 5 products?', 'Can we start with Basic and upgrade?'],
  },
  'real-estate': {
    industry: 'real-estate',
    openingHook: "I build real estate websites with property listings, virtual tours, and lead capture — starting at ₹12,999.",
    valueProps: ['Property listings with galleries', 'Lead capture forms (auto-save CRM)', 'Mortgage calculator', 'Area guides', 'Agent profiles'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'One property sale covers it 10x.' },
      { objection: 'I use MagicBricks', rebuttal: 'Those send leads to 10 agents. Your website sends only to you.' },
      { objection: "I don't update listings", rebuttal: 'We handle all updates. Just send photos on WhatsApp.' },
      { objection: 'References work', rebuttal: 'New buyers search Google first. Without a website, you lose them.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a preview with 3 properties.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 12999, features: ['10 listings', 'Photo gallery', 'Lead form', 'Agent profile', 'Mobile responsive'] },
      { name: 'Pro', price: 24999, features: ['Unlimited listings', 'Virtual tours', 'CRM integration', 'Mortgage calculator', 'SEO'] },
      { name: 'Enterprise', price: 49999, features: ['Everything in Pro', 'Multi-agent', 'Mobile app', 'API integration'] },
    ],
    upsellPaths: [
      { trigger: 'virtual tours', offer: '360° virtual tour package', price: 9999 },
      { trigger: 'lead gen', offer: 'Google Ads + Facebook leads', price: 7999 },
    ],
    closingQuestions: ['Want a preview with 3 properties?', 'When is your next launch?'],
  },
  'professional-services': {
    industry: 'professional-services',
    openingHook: "I build professional websites for consultants, lawyers, doctors, and CAs — starting at ₹6,999.",
    valueProps: ['Professional design builds trust', 'Appointment booking', 'Service pages', 'Client testimonials', 'Blog for SEO'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'One new client covers it 5x.' },
      { objection: 'I get references', rebuttal: 'A website validates credibility when prospects Google you.' },
      { objection: "I don't need appointments", rebuttal: 'Even without booking, a website helps prospects learn about you.' },
      { objection: 'Too busy', rebuttal: 'Fully managed. You just receive leads.' },
      { objection: "I'll think about it", rebuttal: 'Let me show you a free preview.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 6999, features: ['5-page website', 'Contact form', 'Service pages', 'Mobile responsive'] },
      { name: 'Pro', price: 12999, features: ['10 pages', 'Appointment booking', 'Blog', 'Testimonials', 'SEO'] },
      { name: 'Enterprise', price: 24999, features: ['Unlimited pages', 'Client portal', 'Payment integration', 'Monthly content'] },
    ],
    upsellPaths: [
      { trigger: 'content', offer: 'Monthly blog + SEO', price: 3999 },
      { trigger: 'lead gen', offer: 'Google Ads', price: 5999 },
    ],
    closingQuestions: ['Want a free preview?', 'Can we start with Basic?'],
  },
  healthcare: {
    industry: 'healthcare',
    openingHook: "I build clinic websites with online appointments, patient portals, and doctor profiles — starting at ₹9,999.",
    valueProps: ['Online appointment booking (reduces calls 60%)', 'Doctor profiles', 'Patient portal', 'Emergency contact', 'Health blog'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'Reducing calls by 60% saves ₹10,000+/month in staff time.' },
      { objection: 'Patients prefer calling', rebuttal: 'Online booking is for new patients who search Google.' },
      { objection: 'Privacy concerns', rebuttal: 'HIPAA-compliant. Patient data encrypted.' },
      { objection: "I don't have time", rebuttal: 'Fully managed. We handle everything.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a preview with 3 doctor profiles.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 9999, features: ['5-page website', 'Doctor profiles', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 19999, features: ['Online appointments', 'Patient portal', 'Health blog', 'Emergency integration', 'SEO'] },
      { name: 'Enterprise', price: 39999, features: ['Everything in Pro', 'Multi-location', 'Telemedicine', 'Payment system'] },
    ],
    upsellPaths: [
      { trigger: 'telemedicine', offer: 'Video consultation', price: 14999 },
      { trigger: 'marketing', offer: 'Health content marketing', price: 4999 },
    ],
    closingQuestions: ['Want a preview with doctor profiles?', 'When would you like to launch?'],
  },
  technology: {
    industry: 'technology',
    openingHook: "I build tech company websites with product showcases, API docs, and lead capture — starting at ₹15,999.",
    valueProps: ['Modern developer-friendly design', 'Product documentation portal', 'API docs integration', 'Lead capture with CRM sync', '90+ Lighthouse score'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'A professional website increases conversion 200%+.' },
      { objection: 'In-house team', rebuttal: 'We build faster (2 weeks vs 2 months) and cheaper.' },
      { objection: 'We use a template', rebuttal: 'Templates look generic. Custom sets you apart.' },
      { objection: "We'll do it later", rebuttal: 'Every day without a website, you lose leads.' },
      { objection: "I'll think about it", rebuttal: 'Let me show you a free preview.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 15999, features: ['5-page website', 'Product showcase', 'Lead capture', '90+ Lighthouse'] },
      { name: 'Pro', price: 29999, features: ['10 pages', 'API docs portal', 'CRM integration', 'Blog', 'SEO'] },
      { name: 'Enterprise', price: 59999, features: ['Unlimited pages', 'Custom integrations', 'Multi-language', 'A/B testing'] },
    ],
    upsellPaths: [
      { trigger: 'SEO', offer: 'Technical SEO + content strategy', price: 9999 },
      { trigger: 'app', offer: 'Mobile app development', price: 49999 },
    ],
    closingQuestions: ['Want a preview with your product?', 'When is your next launch?'],
  },
  education: {
    industry: 'education',
    openingHook: "I build school/ed-tech websites with online admissions, course catalogs, and student portals — starting at ₹8,999.",
    valueProps: ['Online admission system (reduces paperwork 80%)', 'Course catalog', 'Student portal', 'Parent notifications', 'Faculty dashboard'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'One new admission covers it 3x.' },
      { objection: 'We use paper forms', rebuttal: 'Digital saves 20+ hours/month of staff time.' },
      { objection: "Parents prefer visiting", rebuttal: 'Website lets parents explore 24/7.' },
      { objection: "We'll do it later", rebuttal: 'Admission season is coming.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with your courses.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 8999, features: ['5-page website', 'Course catalog', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 17999, features: ['Online admissions', 'Student portal', 'Parent notifications', 'Faculty dashboard', 'SEO'] },
      { name: 'Enterprise', price: 34999, features: ['Everything in Pro', 'Online exams', 'Payment integration', 'Mobile app'] },
    ],
    upsellPaths: [
      { trigger: 'online exams', offer: 'Online exam platform', price: 14999 },
      { trigger: 'marketing', offer: 'Social media + Google Ads', price: 5999 },
    ],
    closingQuestions: ['Want a preview with your courses?', 'Can we start before admission season?'],
  },
  fitness: {
    industry: 'fitness',
    openingHook: "I build gym websites with class booking, membership management, and trainer profiles — starting at ₹7,999.",
    valueProps: ['Online class booking (reduces calls 70%)', 'Membership plans + payment', 'Trainer profiles', 'Workout schedule', 'Transformation gallery'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: '5 new memberships covers it.' },
      { objection: 'Members call to book', rebuttal: 'Online booking captures the 60% who search Google first.' },
      { objection: "We use WhatsApp", rebuttal: 'Google search needs a website. Without one, you lose to competitors.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with your schedule.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 7999, features: ['5-page website', 'Class schedule', 'Trainer profiles', 'Mobile responsive'] },
      { name: 'Pro', price: 14999, features: ['Online booking', 'Membership plans', 'Payment integration', 'Gallery', 'SEO'] },
      { name: 'Enterprise', price: 29999, features: ['Everything in Pro', 'Mobile app', 'Diet plan portal', 'Wearable integration'] },
    ],
    upsellPaths: [
      { trigger: 'app', offer: 'Fitness mobile app', price: 24999 },
      { trigger: 'marketing', offer: 'Instagram + Facebook ads', price: 4999 },
    ],
    closingQuestions: ['Want a preview with your schedule?', 'How many new members monthly?'],
  },
  'beauty-salon': {
    industry: 'beauty-salon',
    openingHook: "I build salon, spa & barbershop websites with online appointments, service menus, and stylist portfolios — starting at ₹5,999.",
    valueProps: ['Online appointment booking (reduces no-shows 40%)', 'Service menu with prices', 'Stylist / therapist portfolios', 'Before/after gallery', 'Loyalty program + gift cards'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: '3 new clients covers it — and online booking cuts no-shows by 40%.' },
      { objection: 'Clients call to book', rebuttal: 'Online booking captures clients who search at 11 PM when your shop is closed.' },
      { objection: 'We use Instagram', rebuttal: 'Instagram is for photos. Google search needs a website — without one, you lose clients to competitors.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with your services in 24 hours.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 5999, features: ['3-page website', 'Service menu', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 11999, features: ['Online booking', 'Stylist profiles', 'Photo gallery', 'Loyalty program', 'SEO'] },
      { name: 'Enterprise', price: 22999, features: ['Everything in Pro', 'Payment + gift cards', 'Inventory management', 'Mobile app'] },
    ],
    upsellPaths: [
      { trigger: 'marketing', offer: 'Instagram + Google Ads', price: 3999 },
      { trigger: 'loyalty', offer: 'Digital loyalty card system', price: 5999 },
    ],
    closingQuestions: ['Want a preview with your services?', 'How many appointments weekly?'],
  },
  automotive: {
    industry: 'automotive',
    openingHook: "I build car dealership websites with inventory display, service booking, and EMI calculator — starting at ₹12,999.",
    valueProps: ['Vehicle inventory with galleries', 'Online service booking', 'EMI calculator', 'Trade-in evaluation', 'Test drive requests'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'One car sale covers it 10x.' },
      { objection: 'We use Cars24', rebuttal: 'Those charge commission. Your website keeps 100% of leads.' },
      { objection: "Customers visit in person", rebuttal: 'New customers search Google first.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a preview with 3 sample cars.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 12999, features: ['10 vehicle listings', 'Photo gallery', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 24999, features: ['Unlimited inventory', 'Service booking', 'EMI calculator', 'Trade-in form', 'SEO'] },
      { name: 'Enterprise', price: 49999, features: ['Everything in Pro', 'Multi-location', 'Payment integration', 'API integration'] },
    ],
    upsellPaths: [
      { trigger: 'leads', offer: 'Google Ads + Facebook leads', price: 7999 },
      { trigger: 'inventory sync', offer: 'Auto-sync with DMS', price: 14999 },
    ],
    closingQuestions: ['Want a preview with your inventory?', 'How many cars do you sell monthly?'],
  },
  legal: {
    industry: 'legal',
    openingHook: "I build lawyer websites with practice areas, case results, and consultation booking — starting at ₹9,999.",
    valueProps: ['Practice area pages', 'Case results showcase', 'Online consultation booking', 'Client testimonials', 'Legal blog for SEO'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: 'One new client covers it 5x.' },
      { objection: 'References work', rebuttal: 'New clients Google you first. A website validates credibility.' },
      { objection: "I don't need booking", rebuttal: 'Even without booking, a website helps prospects learn about you.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with your practice areas.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 9999, features: ['5-page website', 'Practice areas', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 19999, features: ['Consultation booking', 'Case results', 'Testimonials', 'Legal blog', 'SEO'] },
      { name: 'Enterprise', price: 39999, features: ['Everything in Pro', 'Client portal', 'Document upload', 'Multi-lawyer profiles'] },
    ],
    upsellPaths: [
      { trigger: 'content', offer: 'Monthly legal blog', price: 4999 },
      { trigger: 'leads', offer: 'Google Ads for lawyers', price: 7999 },
    ],
    closingQuestions: ['Want a preview with your practice areas?', 'How do new clients find you now?'],
  },
  hospitality: {
    industry: 'hospitality',
    openingHook: "I build hotel websites with online room booking, photo galleries, and guest reviews — starting at ₹14,999.",
    valueProps: ['Room types with galleries + pricing', 'Online booking engine (no commission)', 'Guest review integration', 'Amenities + restaurant menu', 'Multi-language support'],
    commonObjections: [
      { objection: 'Too expensive', rebuttal: '3 direct bookings (saving 15% OTA commission) covers it.' },
      { objection: 'We use Booking.com', rebuttal: 'OTAs charge 15-25% commission. Your website books at 0%.' },
      { objection: "Guests prefer OTAs", rebuttal: 'Repeat guests book directly. Saves commission.' },
      { objection: "I'll think about it", rebuttal: 'Let me build a free preview with your room types.' },
    ],
    pricingTiers: [
      { name: 'Basic', price: 14999, features: ['5-page website', 'Room gallery', 'Contact form', 'Mobile responsive'] },
      { name: 'Pro', price: 29999, features: ['Booking engine', 'Guest reviews', 'Restaurant menu', 'Multi-language', 'SEO'] },
      { name: 'Enterprise', price: 59999, features: ['Everything in Pro', 'Payment integration', 'Channel manager sync', 'Loyalty program'] },
    ],
    upsellPaths: [
      { trigger: 'more bookings', offer: 'Google Ads + OTA optimization', price: 9999 },
      { trigger: 'reviews', offer: 'Automated review collection', price: 4999 },
    ],
    closingQuestions: ['Want a preview with your room types?', 'How much OTA commission do you pay monthly?'],
  },
};

export function getPlaybook(industry: string): SalesPlaybook {
  return PLAYBOOKS[industry.toLowerCase().trim()] ?? PLAYBOOKS['professional-services'];
}

export function getAllPlaybooks(): SalesPlaybook[] {
  return Object.values(PLAYBOOKS);
}

/** All industry keys (lowercase, stable identifiers — used by the Pitch
 *  Templates tab's industry dropdown + the /api/pitch-templates routes). */
export const SALES_INDUSTRY_KEYS: string[] = Object.keys(PLAYBOOKS);

/** Display label for each industry key (Title Case, friendly for dropdowns). */
export function industryLabel(key: string): string {
  const labelMap: Record<string, string> = {
    'restaurant': 'Restaurant & Cafe',
    'retail': 'Retail & E-commerce',
    'real-estate': 'Real Estate',
    'professional-services': 'Professional Services',
    'healthcare': 'Healthcare & Clinics',
    'technology': 'Technology / SaaS',
    'education': 'Education & EdTech',
    'fitness': 'Fitness & Gyms',
    'beauty-salon': 'Beauty Salon & Spa',
    'automotive': 'Automotive',
    'legal': 'Legal & Law Firms',
    'hospitality': 'Hospitality & Hotels',
  };
  return labelMap[key] ?? key.split('-').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export function generatePitchEmail(businessName: string, industry: string, previewUrl: string): string {
  const playbook = getPlaybook(industry);
  const basicTier = playbook.pricingTiers[0];
  return `Hi ${businessName} team,

${playbook.openingHook}

Here's what you get:
${playbook.valueProps.map((v, i) => `${i + 1}. ${v}`).join('\n')}

I've built a preview — see it here:
${previewUrl}

Pricing starts at ₹${basicTier.price} (${basicTier.name}):
${basicTier.features.map((f) => `✓ ${f}`).join('\n')}

The preview is watermarked. Full website delivered within 48 hours after approval.

Best regards,
ARIA Sales Team
Liafon Software Private Limited`;
}

export function generateNegotiationResponse(industry: string, objection: string): string {
  const playbook = getPlaybook(industry);
  const match = playbook.commonObjections.find((o) => objection.toLowerCase().includes(o.objection.toLowerCase().split(' ')[0]));
  return match ? match.rebuttal : 'I understand. We offer flexible pricing, EMI options, and 100% satisfaction guarantee. Can I show you the preview first?';
}

/**
 * Generate a 3D scroll-animation website template (like Apple product pages).
 * Images/sections transform as user scrolls, creating a video-like effect.
 */
export function generate3DScrollTemplate(businessName: string, industry: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${businessName} — ${industry}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0a0a0a;color:#fff;font-family:-apple-system,sans-serif;overflow-x:hidden}
.scroll-container{height:400vh;position:relative}
.sticky{position:sticky;top:0;height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden}
.hero h1{font-size:4rem;font-weight:700;text-align:center;background:linear-gradient(135deg,#7DD3FC,#C4B5FD);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{font-size:1.2rem;color:#94A3B8;text-align:center;margin-top:1rem}
.feature-section{min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:2rem}
.feature-section h2{font-size:2.5rem;margin-bottom:1rem;text-align:center}
.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:2rem;max-width:1000px;margin-top:3rem}
.card{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:2rem;text-align:center;opacity:0;transform:translateY(40px);transition:all 0.5s ease}
.card.visible{opacity:1;transform:translateY(0)}
.cta{min-height:80vh;display:flex;align-items:center;justify-content:center;flex-direction:column}
.cta button{padding:1rem 3rem;font-size:1.2rem;border:none;border-radius:50px;background:linear-gradient(135deg,#7DD3FC,#C4B5FD);color:#0a0a0a;font-weight:600;cursor:pointer;margin-top:2rem}
.scroll-indicator{position:fixed;bottom:2rem;left:50%;transform:translateX(-50%);font-size:1.5rem;animation:bounce 1.5s infinite;z-index:10}
@keyframes bounce{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(10px)}}
footer{padding:2rem;text-align:center;color:#475569}
</style>
</head>
<body>
<div class="scroll-container">
  <div class="sticky">
    <div class="hero">
      <h1>${businessName}</h1>
      <p>Premium ${industry} services. Scroll to explore.</p>
    </div>
  </div>
</div>
<div class="feature-section">
  <h2>Why Choose Us</h2>
  <div class="card-grid">
    <div class="card"><h3>⭐ Quality</h3><p>Top-tier service delivery</p></div>
    <div class="card"><h3>⚡ Speed</h3><p>Fast turnaround times</p></div>
    <div class="card"><h3>🛡️ Trust</h3><p>100% satisfaction guarantee</p></div>
    <div class="card"><h3>💎 Premium</h3><p>Luxury experience</p></div>
  </div>
</div>
<div class="cta">
  <h2>Ready to Get Started?</h2>
  <button onclick="alert('Contact us!')">Contact Us</button>
</div>
<div class="scroll-indicator">⬇️</div>
<footer><p>© 2026 ${businessName}. Built by ARIA Mission Control.</p></footer>
<script>
window.addEventListener('scroll',()=>{
  const y=window.scrollY;
  const max=document.querySelector('.scroll-container').offsetHeight-window.innerHeight;
  const p=Math.min(y/max,1);
  const h=document.querySelector('.hero h1');
  const hp=document.querySelector('.hero p');
  const si=document.querySelector('.scroll-indicator');
  if(h){h.style.transform='translateY('+p*-100+'px)';h.style.opacity=1-p*1.5}
  if(hp){hp.style.transform='translateY('+p*-60+'px)';hp.style.opacity=1-p*2}
  if(si){si.style.opacity=y>100?0:1}
  document.querySelectorAll('.card').forEach(c=>{
    if(c.getBoundingClientRect().top<window.innerHeight*0.8){c.classList.add('visible')}
  });
});
</script>
</body>
</html>`;
}
