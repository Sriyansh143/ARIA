// payment-gateways.ts — Razorpay + Stripe integration helpers
//
// Originally: webhook signature verification only.
// Extended (Task 2-c): real payment-gateway order-creation + status-fetch APIs
// to move ARIA toward a production-ready revenue model.
//
// Design rules:
//   * Every function returns a Result-style object — `{ ok, ... } | { ok:false, error }`.
//   * Never throws. Network / config / parse errors are caught and surfaced.
//   * Uses `AbortSignal.timeout(15000)` so a slow gateway can't hang a request.
//   * Detects test-mode keys (Razorpay `test_` prefix, Stripe `sk_test_` / `rk_test_`)
//     and reports mode so the UI can render a clear "test" badge.
import { createHmac, timingSafeEqual } from 'node:crypto';
import { logger } from '@/lib/logger';

export function verifyRazorpaySignature(payload: string, signature: string, secret: string): boolean {
  if (!secret) return false;
  const expected = createHmac('sha256', secret).update(payload).digest('hex');
  try {
    return timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  } catch {
    return false;
  }
}

export function verifyStripeSignature(payload: string, sigHeader: string, secret: string): boolean {
  if (!secret || !sigHeader) return false;
  const parts = sigHeader.split(',');
  const tPart = parts.find((p) => p.startsWith('t='));
  const v1Part = parts.find((p) => p.startsWith('v1='));
  if (!tPart || !v1Part) return false;
  const t = tPart.slice(2);
  const v1 = v1Part.slice(3);
  const expected = createHmac('sha256', secret).update(`${t}.${payload}`).digest('hex');
  try {
    return timingSafeEqual(Buffer.from(v1), Buffer.from(expected));
  } catch {
    return false;
  }
}

export function getWebhookConfigStatus() {
  return {
    razorpay: {
      configured: !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
      hasWebhookSecret: !!process.env.RAZORPAY_WEBHOOK_SECRET,
    },
    stripe: {
      configured: !!process.env.STRIPE_SECRET_KEY,
      hasWebhookSecret: !!process.env.STRIPE_WEBHOOK_SECRET,
    },
  };
}

// ============================================================================
// Order creation + status fetching (Task 2-c)
// ============================================================================

const GATEWAY_TIMEOUT_MS = 15_000;

/** Convert INR amount (rupees, decimal) to Razorpay paise (integer). */
function toRazorpayPaise(amount: number): number {
  return Math.round(amount * 100);
}

/** Convert amount to Stripe smallest-unit integer (cents/paise). */
function toStripeSmallestUnit(amount: number): number {
  return Math.round(amount * 100);
}

/** Detect whether a Razorpay key pair is in test mode. */
function detectRazorpayMode(): 'live' | 'test' | 'unconfigured' {
  const keyId = process.env.RAZORPAY_KEY_ID ?? '';
  const keySecret = process.env.RAZORPAY_KEY_SECRET ?? '';
  if (!keyId || !keySecret) return 'unconfigured';
  // Razorpay test keys historically begin with `rzp_test_` but newer portals
  // may issue keys without that prefix in sandbox projects. We treat the
  // presence of either marker as test mode; fall back to live otherwise.
  if (keyId.startsWith('rzp_test_') || keyId.includes('test_')) return 'test';
  return 'live';
}

/** Detect whether a Stripe secret key is in test mode. */
function detectStripeMode(): 'live' | 'test' | 'unconfigured' {
  const key = process.env.STRIPE_SECRET_KEY ?? '';
  if (!key) return 'unconfigured';
  // Stripe convention: sk_test_…, rk_test_… (restricted), ek_test_… (ephemeral).
  if (key.startsWith('sk_test_') || key.startsWith('rk_test_') || key.startsWith('ek_test_')) {
    return 'test';
  }
  return 'live';
}

export interface CreateOrderOptions {
  amount: number; // rupees / dollars (major currency unit)
  currency?: string; // default INR
  receipt?: string;
  notes?: Record<string, string>;
}

export interface CreateOrderResult {
  ok: boolean;
  orderId?: string;
  error?: string;
}

/**
 * Create a Razorpay Order.
 *
 * Razorpay expects the amount in the smallest currency unit (paise for INR),
 * sent as a positive integer via `POST /v1/orders`. Authentication is HTTP
 * Basic with `KEY_ID:KEY_SECRET`.
 *
 * Docs: https://razorpay.com/docs/api/orders/
 */
export async function createRazorpayOrder(opts: CreateOrderOptions): Promise<CreateOrderResult> {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    return { ok: false, error: 'Razorpay keys not configured (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET)' };
  }
  if (typeof opts.amount !== 'number' || !(opts.amount > 0)) {
    return { ok: false, error: 'amount must be a positive number' };
  }

  const currency = (opts.currency ?? 'INR').toUpperCase();
  const amountPaise = toRazorpayPaise(opts.amount);

  const body = new URLSearchParams();
  body.set('amount', String(amountPaise));
  body.set('currency', currency);
  body.set('payment_capture', '1'); // auto-capture on success
  if (opts.receipt) body.set('receipt', opts.receipt);
  if (opts.notes) {
    for (const [k, v] of Object.entries(opts.notes)) {
      body.set(`notes[${k}]`, v);
    }
  }

  const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');

  try {
    const res = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'application/json',
      },
      body: body.toString(),
      signal: AbortSignal.timeout(GATEWAY_TIMEOUT_MS),
    });

    const data = (await res.json().catch(() => ({}))) as {
      id?: string;
      status?: string;
      error?: { description?: string; field?: string; code?: string };
    };

    if (!res.ok || !data.id) {
      const msg = data.error?.description ?? `razorpay orders API returned HTTP ${res.status}`;
      logger.warn({ route: 'createRazorpayOrder', status: res.status, error: data.error }, 'razorpay order creation failed');
      return { ok: false, error: msg };
    }

    return { ok: true, orderId: data.id };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown error';
    logger.warn({ route: 'createRazorpayOrder', err: message }, 'razorpay order creation error');
    return { ok: false, error: message };
  }
}

export interface CreatePaymentIntentOptions {
  amount: number; // major currency unit
  currency?: string; // default USD
  description?: string;
  receiptEmail?: string;
}

export interface CreatePaymentIntentResult {
  ok: boolean;
  clientSecret?: string;
  paymentIntentId?: string;
  error?: string;
}

/**
 * Create a Stripe PaymentIntent.
 *
 * Stripe expects the amount in the smallest currency unit (cents for USD,
 * paise for INR, etc.) and authenticates with a Bearer token.
 *
 * Docs: https://stripe.com/docs/api/payment_intents/create
 */
export async function createStripePaymentIntent(
  opts: CreatePaymentIntentOptions,
): Promise<CreatePaymentIntentResult> {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    return { ok: false, error: 'Stripe secret key not configured (STRIPE_SECRET_KEY)' };
  }
  if (typeof opts.amount !== 'number' || !(opts.amount > 0)) {
    return { ok: false, error: 'amount must be a positive number' };
  }

  const currency = (opts.currency ?? 'USD').toLowerCase();
  const amountMinor = toStripeSmallestUnit(opts.amount);

  const body = new URLSearchParams();
  body.set('amount', String(amountMinor));
  body.set('currency', currency);
  // Confirm manually on the client with the returned client_secret.
  body.set('automatic_payment_methods[enabled]', 'true');
  if (opts.description) body.set('description', opts.description);
  if (opts.receiptEmail) body.set('receipt_email', opts.receiptEmail);

  try {
    const res = await fetch('https://api.stripe.com/v1/payment_intents', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'application/json',
      },
      body: body.toString(),
      signal: AbortSignal.timeout(GATEWAY_TIMEOUT_MS),
    });

    const data = (await res.json().catch(() => ({}))) as {
      id?: string;
      client_secret?: string;
      status?: string;
      error?: { message?: string; type?: string; code?: string };
    };

    if (!res.ok || !data.id || !data.client_secret) {
      const msg = data.error?.message ?? `stripe payment_intents API returned HTTP ${res.status}`;
      logger.warn({ route: 'createStripePaymentIntent', status: res.status, error: data.error }, 'stripe paymentintent creation failed');
      return { ok: false, error: msg };
    }

    return {
      ok: true,
      clientSecret: data.client_secret,
      paymentIntentId: data.id,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown error';
    logger.warn({ route: 'createStripePaymentIntent', err: message }, 'stripe paymentintent creation error');
    return { ok: false, error: message };
  }
}

export interface FetchRazorpayPaymentResult {
  ok: boolean;
  status?: string;
  paymentId?: string;
  error?: string;
}

/**
 * Fetch the live payment state for a Razorpay Order.
 *
 * Razorpay returns an array of payments under `/v1/orders/:id/payments`. The
 * first (most recent) successful or attempted payment is the authoritative
 * status. We surface a normalized status string (`paid` | `authorized` |
 * `failed` | `created` | `attempted`) plus the payment id when available.
 *
 * Docs: https://razorpay.com/docs/api/orders/#fetch-payments-for-an-order
 */
export async function fetchRazorpayPayment(orderId: string): Promise<FetchRazorpayPaymentResult> {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    return { ok: false, error: 'Razorpay keys not configured' };
  }
  if (!orderId) {
    return { ok: false, error: 'orderId required' };
  }

  const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');

  try {
    const res = await fetch(`https://api.razorpay.com/v1/orders/${encodeURIComponent(orderId)}/payments`, {
      method: 'GET',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        Accept: 'application/json',
      },
      signal: AbortSignal.timeout(GATEWAY_TIMEOUT_MS),
    });

    const data = (await res.json().catch(() => ({}))) as {
      items?: Array<{ id?: string; status?: string; amount?: number; method?: string }>;
      error?: { description?: string; code?: string };
    };

    if (!res.ok) {
      const msg = data.error?.description ?? `razorpay payments API returned HTTP ${res.status}`;
      logger.warn({ route: 'fetchRazorpayPayment', orderId, status: res.status }, 'razorpay payment fetch failed');
      return { ok: false, error: msg };
    }

    const items = Array.isArray(data.items) ? data.items : [];
    // Prefer the most recent payment record (Razorpay returns newest-first).
    const latest = items[0];
    if (!latest) {
      // No payment attempts yet — the order exists but the customer hasn't paid.
      return { ok: true, status: 'created', paymentId: undefined };
    }

    const rawStatus = (latest.status ?? '').toLowerCase();
    // Normalize Razorpay's granular statuses to the set ARIA stores.
    let normalized = rawStatus;
    if (rawStatus === 'captured') normalized = 'paid';
    else if (rawStatus === 'authorized') normalized = 'authorized';
    else if (rawStatus === 'failed') normalized = 'failed';
    else if (rawStatus === 'created' || rawStatus === 'attempted') normalized = rawStatus;

    return { ok: true, status: normalized, paymentId: latest.id };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown error';
    logger.warn({ route: 'fetchRazorpayPayment', orderId, err: message }, 'razorpay payment fetch error');
    return { ok: false, error: message };
  }
}

export interface FetchStripePaymentIntentResult {
  ok: boolean;
  status?: string;
  error?: string;
}

/**
 * Fetch a Stripe PaymentIntent's live status.
 *
 * Docs: https://stripe.com/docs/api/payment_intents/retrieve
 *
 * Stripe statuses: requires_payment_method | requires_confirmation | requires_action
 *                  | processing | requires_capture | canceled | succeeded
 * We map the ones ARIA cares about onto the same vocabulary used by the
 * Razorpay path (`paid` / `failed` / `created` / `processing`).
 */
export async function fetchStripePaymentIntent(piId: string): Promise<FetchStripePaymentIntentResult> {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    return { ok: false, error: 'Stripe secret key not configured' };
  }
  if (!piId) {
    return { ok: false, error: 'paymentIntentId required' };
  }

  try {
    const res = await fetch(`https://api.stripe.com/v1/payment_intents/${encodeURIComponent(piId)}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${secretKey}`,
        Accept: 'application/json',
      },
      signal: AbortSignal.timeout(GATEWAY_TIMEOUT_MS),
    });

    const data = (await res.json().catch(() => ({}))) as {
      id?: string;
      status?: string;
      error?: { message?: string; type?: string; code?: string };
    };

    if (!res.ok) {
      const msg = data.error?.message ?? `stripe paymentintent API returned HTTP ${res.status}`;
      logger.warn({ route: 'fetchStripePaymentIntent', piId, status: res.status }, 'stripe paymentintent fetch failed');
      return { ok: false, error: msg };
    }

    const rawStatus = (data.status ?? '').toLowerCase();
    let normalized = rawStatus;
    if (rawStatus === 'succeeded') normalized = 'paid';
    else if (rawStatus === 'canceled' || rawStatus === 'requires_payment_method') normalized = 'failed';
    else if (rawStatus === 'processing' || rawStatus === 'requires_action' || rawStatus === 'requires_confirmation') {
      normalized = 'processing';
    } else if (rawStatus === 'requires_capture') normalized = 'authorized';

    return { ok: true, status: normalized };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown error';
    logger.warn({ route: 'fetchStripePaymentIntent', piId, err: message }, 'stripe paymentintent fetch error');
    return { ok: false, error: message };
  }
}

export interface PaymentGatewayStatus {
  razorpay: { configured: boolean; mode: 'live' | 'test' | 'unconfigured' };
  stripe: { configured: boolean; mode: 'live' | 'test' | 'unconfigured' };
}

/**
 * Return the configuration + mode of each gateway. Used by the UI's payment
 * settings page to render green/test/grey badges.
 */
export function getPaymentGatewayStatus(): PaymentGatewayStatus {
  const razorpayMode = detectRazorpayMode();
  const stripeMode = detectStripeMode();
  return {
    razorpay: {
      configured: razorpayMode !== 'unconfigured',
      mode: razorpayMode,
    },
    stripe: {
      configured: stripeMode !== 'unconfigured',
      mode: stripeMode,
    },
  };
}
