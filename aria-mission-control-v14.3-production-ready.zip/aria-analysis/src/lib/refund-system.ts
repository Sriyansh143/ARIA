import { db } from '@/lib/db';
import { logAction } from '@/lib/action-log';
import { logger } from '@/lib/logger';

export async function createRefund(input: {
  paymentId: string; amount: number; reason: string; reasonNote?: string; requestedBy?: string;
}): Promise<{ ok: boolean; id?: string; error?: string }> {
  try {
    const payment = await db.payment.findUnique({ where: { id: input.paymentId } });
    if (!payment) return { ok: false, error: 'Payment not found' };
    if (payment.status !== 'confirmed') return { ok: false, error: 'Payment must be confirmed' };
    if (input.amount <= 0 || input.amount > payment.amount) return { ok: false, error: 'Invalid refund amount' };
    const refund = await db.refund.create({
      data: {
        paymentId: input.paymentId, amount: input.amount, reason: input.reason,
        reasonNote: input.reasonNote, requestedBy: input.requestedBy ?? 'operator',
      },
    });
    await logAction({ action: 'refund.create', target: `refund:${refund.id}`, afterState: refund, actor: input.requestedBy ?? 'operator' });
    return { ok: true, id: refund.id };
  } catch (err) {
    logger.error({ err }, 'refund-system: createRefund failed');
    return { ok: false, error: 'Failed to create refund' };
  }
}

export async function processRefund(id: string, reviewer: string, gatewayRef?: string) {
  try {
    const refund = await db.refund.findUnique({ where: { id } });
    if (!refund) return { ok: false, error: 'Refund not found' };
    if (refund.status === 'processed') return { ok: false, error: 'Already processed' };
    await db.refund.update({ where: { id }, data: { status: 'processed', reviewedBy: reviewer, gatewayRef, processedAt: new Date() } });
    const fullRefund = await db.refund.findUnique({ where: { id } });
    const payment = await db.payment.findUnique({ where: { id: refund.paymentId } });
    if (payment && fullRefund && fullRefund.amount >= payment.amount) {
      await db.payment.update({ where: { id: payment.id }, data: { status: 'refunded' } });
    }
    await logAction({ action: 'refund.process', target: `refund:${id}`, beforeState: refund, afterState: fullRefund, actor: reviewer });
    return { ok: true };
  } catch (err) {
    logger.error({ err }, 'refund-system: processRefund failed');
    return { ok: false, error: 'Failed to process refund' };
  }
}

export async function rejectRefund(id: string, reviewer: string, reviewNote: string) {
  try {
    await db.refund.update({ where: { id }, data: { status: 'rejected', reviewedBy: reviewer, reviewNote } });
    return { ok: true };
  } catch (err) {
    logger.error({ err }, 'refund-system: rejectRefund failed');
    return { ok: false, error: 'Failed to reject refund' };
  }
}

export async function listRefunds(filter: { status?: string; paymentId?: string } = {}) {
  try {
    const where: Record<string, unknown> = {};
    if (filter.status) where.status = filter.status;
    if (filter.paymentId) where.paymentId = filter.paymentId;
    return db.refund.findMany({ where, orderBy: { createdAt: 'desc' }, take: 50 });
  } catch (err) {
    logger.warn({ err }, 'refund-system: listRefunds failed');
    return [];
  }
}

export async function getRefundStats() {
  try {
    const [total, pending, processed, rejected] = await Promise.all([
      db.refund.count(),
      db.refund.count({ where: { status: 'requested' } }),
      db.refund.count({ where: { status: 'processed' } }),
      db.refund.count({ where: { status: 'rejected' } }),
    ]);
    const processedSum = await db.refund.aggregate({ where: { status: 'processed' }, _sum: { amount: true } });
    return { total, pending, processed, rejected, totalRefunded: processedSum._sum.amount ?? 0 };
  } catch (err) {
    logger.warn({ err }, 'refund-system: getRefundStats failed');
    return { total: 0, pending: 0, processed: 0, rejected: 0, totalRefunded: 0 };
  }
}
