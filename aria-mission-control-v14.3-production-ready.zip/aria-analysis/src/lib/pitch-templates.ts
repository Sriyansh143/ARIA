// pitch-templates.ts — 3D scroll-animation website template generator.
//
// Produces complete standalone HTML strings (CSS 3D scroll animations,
// perspective transforms, parallax sections, sticky scroll reveals) using
// only vanilla JS + Tailwind CDN — no build step. Designed for cold-outreach
// pitch emails where the prospect receives an HTML attachment and opens it
// directly in a browser.
//
// Exports:
//   • generate3DScrollWebsite(businessName, industry, headline, templateId?)
//       → returns { html, metadata }
//   • generateTemplateHtml(businessName, industry, headline, templateId)
//       → returns the HTML string only (used by /api/pitch-templates/generate)
//   • getTemplatePreview(templateId) → TemplateMetadata
//   • getAllTemplates() → TemplateMetadata[]
//   • PITCH_TEMPLATE_IDS — ['aurora-3d','cinematic-scroll','sticky-parallax']

import { getPlaybook, industryLabel } from './sales-playbook';

export type PitchTemplateId = 'aurora-3d' | 'cinematic-scroll' | 'sticky-parallax';

export const PITCH_TEMPLATE_IDS: PitchTemplateId[] = [
  'aurora-3d',
  'cinematic-scroll',
  'sticky-parallax',
];

export interface TemplateMetadata {
  id: PitchTemplateId;
  name: string;
  description: string;
  industries: string[];
  features: string[];
  accent: string; // primary accent color hex
  /** Approx file size of the generated HTML in KB (rough estimate). */
  estimatedSizeKb: number;
  /** Suggested use case for the template. */
  bestFor: string;
}

export interface GeneratedTemplate {
  html: string;
  metadata: TemplateMetadata;
}

/* ------------------------------------------------------------------ */
/* Template metadata registry                                          */
/* ------------------------------------------------------------------ */

const ALL_INDUSTRIES = [
  'restaurant', 'retail', 'real-estate', 'professional-services',
  'healthcare', 'technology', 'education', 'fitness',
  'beauty-salon', 'automotive', 'legal', 'hospitality',
];

const TEMPLATE_REGISTRY: Record<PitchTemplateId, TemplateMetadata> = {
  'aurora-3d': {
    id: 'aurora-3d',
    name: 'Aurora 3D',
    description:
      'A living aurora-gradient hero that rotates in 3D as the visitor scrolls. Cards peel off the page with perspective transforms; CTA glows. Best for premium brands that want a "wow" first impression.',
    industries: ALL_INDUSTRIES,
    features: [
      '3D perspective hero with rotating aurora gradient',
      'Scroll-driven card rotateX/rotateY transforms',
      'Sticky feature reveals with translateZ depth',
      'Animated number counters',
      'Glass-morphism CTA panel',
      'Tailwind CDN (no build step)',
    ],
    accent: '#7DD3FC',
    estimatedSizeKb: 18,
    bestFor: 'Cold-outreach pitch emails where the prospect opens the HTML directly in a browser.',
  },
  'cinematic-scroll': {
    id: 'cinematic-scroll',
    name: 'Cinematic Scroll',
    description:
      'Full-screen sticky panels that morph scene-by-scene like a film reel. Parallax background layers, word-by-word headline reveals, and dramatic letterboxing. Best for storytelling pitches.',
    industries: ALL_INDUSTRIES,
    features: [
      'Sticky full-viewport cinematic panels',
      'Multi-layer parallax (bg / mid / fg)',
      'Word-by-word headline fade-in',
      'Letterbox bars that shrink on scroll',
      'Scene-by-scene color transitions',
      'Tailwind CDN (no build step)',
    ],
    accent: '#C4B5FD',
    estimatedSizeKb: 21,
    bestFor: 'Storytelling pitches — case studies, transformation narratives, brand films.',
  },
  'sticky-parallax': {
    id: 'sticky-parallax',
    name: 'Sticky Parallax',
    description:
      'A multi-layer parallax with pinned chapter headings and a 3D card-stack that flattens like Apple product pages. Horizontal-scroll section embedded in vertical scroll. Best for product / service showcases.',
    industries: ALL_INDUSTRIES,
    features: [
      'Pinned chapter headings (sticky scroll reveal)',
      '3D card-stack that flattens on scroll',
      'Horizontal-scroll section inside vertical scroll',
      'Multi-layer parallax depth',
      'Progress bar with scroll percentage',
      'Tailwind CDN (no build step)',
    ],
    accent: '#34D399',
    estimatedSizeKb: 22,
    bestFor: 'Product / service showcases with multiple features or pricing tiers.',
  },
};

export function getAllTemplates(): TemplateMetadata[] {
  return PITCH_TEMPLATE_IDS.map((id) => TEMPLATE_REGISTRY[id]);
}

export function getTemplatePreview(templateId: string): TemplateMetadata {
  const id = (templateId as PitchTemplateId) ?? 'aurora-3d';
  return TEMPLATE_REGISTRY[id] ?? TEMPLATE_REGISTRY['aurora-3d'];
}

/* ------------------------------------------------------------------ */
/* Industry-specific copy generator                                     */
/* ------------------------------------------------------------------ */

interface IndustryCopy {
  tagline: string;
  featureCards: Array<{ icon: string; title: string; body: string }>;
  stats: Array<{ value: string; label: string }>;
  testimonial: { quote: string; author: string; role: string };
  ctaPrimary: string;
  ctaSecondary: string;
}

function getIndustryCopy(industry: string, businessName: string): IndustryCopy {
  const playbook = getPlaybook(industry);
  const label = industryLabel(industry);
  // Use the playbook's value props as feature cards (first 4).
  const featureCards = playbook.valueProps.slice(0, 4).map((vp, i) => {
    const icons = ['✦', '◈', '◉', '✚'];
    return {
      icon: icons[i] ?? '✦',
      title: vp.split(' ')[0].replace(/[()]/g, ''),
      body: vp,
    };
  });
  // Use pricing tiers as stats.
  const stats = playbook.pricingTiers.map((t) => ({
    value: '₹' + t.price.toLocaleString('en-IN'),
    label: t.name,
  }));
  return {
    tagline: `Premium ${label.toLowerCase()} experiences, delivered by ${businessName}.`,
    featureCards,
    stats,
    testimonial: {
      quote:
        `"${businessName} transformed how we serve customers. ` +
        `The new website paid for itself in the first month."`,
      author: 'Happy Client',
      role: label + ' customer',
    },
    ctaPrimary: 'Book a Free Consultation',
    ctaSecondary: 'View Pricing',
  };
}

/* ------------------------------------------------------------------ */
/* HTML head + Tailwind CDN (shared)                                    */
/* ------------------------------------------------------------------ */

function htmlHead(title: string): string {
  return [
    '<!DOCTYPE html>',
    '<html lang="en">',
    '<head>',
    '<meta charset="UTF-8" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0" />',
    '<meta name="description" content="' + title + ' — built by ARIA Mission Control." />',
    '<title>' + title + '</title>',
    '<script src="https://cdn.tailwindcss.com"></script>',
    '<link rel="preconnect" href="https://fonts.googleapis.com" />',
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />',
    '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />',
    '<style>',
    ':root{--accent:#7DD3FC;--bg:#08090A;--panel:#0E1218;--text:#E2E8F0;--dim:#94A3B8}',
    '*{margin:0;padding:0;box-sizing:border-box}',
    'html{scroll-behavior:smooth}',
    'body{font-family:Inter,-apple-system,sans-serif;background:var(--bg);color:var(--text);overflow-x:hidden}',
    '.font-display{font-family:Space Grotesk,Inter,sans-serif}',
    '.glass{background:rgba(255,255,255,0.04);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.08)}',
    '.gradient-text{background:linear-gradient(135deg,#7DD3FC 0%,#C4B5FD 50%,#34D399 100%);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}',
    '.scrollbar-hidden::-webkit-scrollbar{display:none}',
    '</style>',
    '</head>',
    '<body>',
  ].join('\n');
}

function htmlFooter(businessName: string): string {
  return [
    '  <footer class="border-t border-white/5 py-12 px-6 text-center">',
    '    <div class="font-display text-lg font-semibold gradient-text mb-2">' + businessName + '</div>',
    '    <p class="text-xs text-[var(--dim)]">Built by ARIA Mission Control · Liafon Software Private Limited</p>',
    '    <p class="text-[10px] text-white/30 mt-2">© ' + new Date().getFullYear() + ' ' + businessName + '. All rights reserved.</p>',
    '  </footer>',
    '</body>',
    '</html>',
  ].join('\n');
}

/* ------------------------------------------------------------------ */
/* Template 1: AURORA-3D                                                */
/* ------------------------------------------------------------------ */

function aurora3dHtml(businessName: string, headline: string, copy: IndustryCopy): string {
  const cards = copy.featureCards
    .map(
      (c, i) =>
        '        <div class="aurora-card glass rounded-2xl p-8" data-depth="' +
        (i + 1) +
        '" style="transform:rotateX(' +
        (i % 2 === 0 ? -8 : 8) +
        'deg) rotateY(' +
        (i % 2 === 0 ? 6 : -6) +
        'deg)">\n' +
        '          <div class="text-3xl mb-3" style="color:var(--accent)">' + c.icon + '</div>\n' +
        '          <h3 class="font-display text-xl font-semibold mb-2">' + c.title + '</h3>\n' +
        '          <p class="text-sm text-[var(--dim)] leading-relaxed">' + c.body + '</p>\n' +
        '        </div>',
    )
    .join('\n');

  const stats = copy.stats
    .map(
      (s) =>
        '      <div class="text-center">\n' +
        '        <div class="font-display text-4xl md:text-5xl font-bold gradient-text counter" data-target="' +
        s.value +
        '">0</div>\n' +
        '        <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--dim)] mt-2">' +
        s.label +
        '</div>\n' +
        '      </div>',
    )
    .join('\n');

  return (
    htmlHead(businessName + ' — ' + headline) +
    [
      '  <!-- ============ AURORA 3D HERO ============ -->',
      '  <section class="aurora-hero relative min-h-screen flex items-center justify-center overflow-hidden">',
      '    <div class="aurora-bg absolute inset-0"></div>',
      '    <div class="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[var(--bg)]"></div>',
      '    <div class="relative z-10 text-center px-6 max-w-5xl mx-auto" id="hero-content">',
      '      <div class="inline-block mb-6 px-4 py-1.5 rounded-full glass text-xs uppercase tracking-widest text-[var(--accent)] font-display">',
      '        ✦ ' + businessName + ' ✦',
      '      </div>',
      '      <h1 class="font-display text-5xl md:text-7xl lg:text-8xl font-black tracking-tight leading-[1.05] mb-6">',
      '        <span class="gradient-text">' + headline + '</span>',
      '      </h1>',
      '      <p class="text-lg md:text-xl text-[var(--dim)] max-w-2xl mx-auto mb-10">' + copy.tagline + '</p>',
      '      <div class="flex flex-wrap gap-4 justify-center">',
      '        <a href="#contact" class="px-8 py-4 rounded-full font-display font-semibold text-sm uppercase tracking-wider text-[var(--bg)] transition-transform hover:scale-105" style="background:linear-gradient(135deg,#7DD3FC,#C4B5FD)">' + copy.ctaPrimary + '</a>',
      '        <a href="#features" class="px-8 py-4 rounded-full font-display font-semibold text-sm uppercase tracking-wider glass text-[var(--text)] hover:text-[var(--accent)] transition-colors">' + copy.ctaSecondary + '</a>',
      '      </div>',
      '      <div class="absolute bottom-10 left-1/2 -translate-x-1/2 text-[var(--dim)] animate-bounce text-2xl">⌄</div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ FEATURES (3D CARD GRID) ============ -->',
      '  <section id="features" class="py-32 px-6 relative" style="perspective:1000px">',
      '    <div class="max-w-6xl mx-auto">',
      '      <div class="text-center mb-20" id="features-head">',
      '        <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--accent)] mb-4">Why Choose Us</div>',
      '        <h2 class="font-display text-4xl md:text-6xl font-bold mb-4">Crafted to <span class="gradient-text">stand out</span></h2>',
      '        <p class="text-[var(--dim)] max-w-2xl mx-auto">Every detail engineered for impact, performance, and trust.</p>',
      '      </div>',
      '      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" id="card-grid">',
      cards,
      '      </div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ STATS (3D PARALLAX BAND) ============ -->',
      '  <section class="py-32 px-6 relative overflow-hidden">',
      '    <div class="absolute inset-0 opacity-30" style="background:radial-gradient(ellipse at center,rgba(125,211,252,0.3) 0%,transparent 60%)"></div>',
      '    <div class="relative max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">',
      stats,
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ TESTIMONIAL ============ -->',
      '  <section class="py-32 px-6">',
      '    <div class="max-w-4xl mx-auto text-center glass rounded-3xl p-12 relative" style="perspective:800px" id="testimonial-card">',
      '      <div class="text-7xl mb-4 text-[var(--accent)] opacity-30">"</div>',
      '      <blockquote class="font-display text-2xl md:text-3xl font-medium leading-relaxed mb-8">' + copy.testimonial.quote + '</blockquote>',
      '      <div class="font-semibold text-[var(--accent)]">' + copy.testimonial.author + '</div>',
      '      <div class="text-xs uppercase tracking-widest text-[var(--dim)] mt-1">' + copy.testimonial.role + '</div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ CTA ============ -->',
      '  <section id="contact" class="py-32 px-6 relative overflow-hidden">',
      '    <div class="absolute inset-0" style="background:linear-gradient(135deg,rgba(125,211,252,0.1),rgba(196,181,253,0.1),rgba(52,211,153,0.1))"></div>',
      '    <div class="relative max-w-3xl mx-auto text-center glass rounded-3xl p-16">',
      '      <h2 class="font-display text-4xl md:text-5xl font-bold mb-6">Ready to begin?</h2>',
      '      <p class="text-[var(--dim)] mb-10 max-w-xl mx-auto">Get in touch today and let ' + businessName + ' show you what premium really feels like.</p>',
      '      <a href="mailto:hello@example.com" class="inline-block px-10 py-5 rounded-full font-display font-bold text-sm uppercase tracking-wider text-[var(--bg)] transition-transform hover:scale-105" style="background:linear-gradient(135deg,#7DD3FC,#34D399)">Get Started →</a>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ AURORA 3D STYLES ============ -->',
      '  <style>',
      '    .aurora-hero{background:radial-gradient(ellipse at top,#0E1218,#08090A)}',
      '    .aurora-bg{',
      '      background:',
      '        radial-gradient(ellipse 800px 400px at 20% 30%,rgba(125,211,252,0.45),transparent 60%),',
      '        radial-gradient(ellipse 600px 600px at 80% 60%,rgba(196,181,253,0.4),transparent 60%),',
      '        radial-gradient(ellipse 500px 400px at 50% 80%,rgba(52,211,153,0.3),transparent 60%);',
      '      filter:blur(40px);',
      '      animation:aurora-rotate 18s ease-in-out infinite alternate;',
      '    }',
      '    @keyframes aurora-rotate{',
      '      0%{transform:rotate(0deg) scale(1)}',
      '      50%{transform:rotate(8deg) scale(1.1)}',
      '      100%{transform:rotate(-8deg) scale(1.05)}',
      '    }',
      '    .aurora-card{',
      '      opacity:0;',
      '      transform:translateY(60px) rotateX(-12deg);',
      '      transition:opacity 0.8s ease,transform 0.8s cubic-bezier(0.22,1,0.36,1);',
      '      transform-style:preserve-3d;',
      '    }',
      '    .aurora-card.visible{opacity:1;transform:translateY(0) rotateX(0) rotateY(0)}',
      '    .aurora-card:hover{transform:translateY(-8px) rotateX(4deg) rotateY(-4deg)!important;border-color:rgba(125,211,252,0.4)}',
      '    #features-head,#testimonial-card{opacity:0;transform:translateY(40px);transition:all 0.8s ease}',
      '    #features-head.visible,#testimonial-card.visible{opacity:1;transform:translateY(0)}',
      '    .counter{opacity:0;transition:opacity 0.6s ease}',
      '    .counter.visible{opacity:1}',
      '  </style>',
      '',
      '  <!-- ============ AURORA 3D SCRIPT ============ -->',
      '  <script>',
      '    (function(){',
      '      // Scroll-driven 3D parallax on hero content',
      '      var hero = document.getElementById("hero-content");',
      '      var heroSection = document.querySelector(".aurora-hero");',
      '      // IntersectionObserver reveals for cards + headings',
      '      var revealEls = document.querySelectorAll(".aurora-card, #features-head, #testimonial-card, .counter");',
      '      var io = new IntersectionObserver(function(entries){',
      '        entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add("visible"); io.unobserve(e.target); } });',
      '      }, { threshold: 0.2 });',
      '      revealEls.forEach(function(el){ io.observe(el); });',
      '      // Counter animation',
      '      var counters = document.querySelectorAll(".counter");',
      '      counters.forEach(function(c){',
      '        var target = c.getAttribute("data-target") || "";',
      '        var numMatch = target.match(/[0-9,]+/);',
      '        if(!numMatch) return;',
      '        var num = parseInt(numMatch[0].replace(/,/g,""),10);',
      '        var prefix = target.substring(0, target.indexOf(numMatch[0]));',
      '        var suffix = target.substring(target.indexOf(numMatch[0]) + numMatch[0].length);',
      '        var started = false;',
      '        var co = new IntersectionObserver(function(entries){',
      '          entries.forEach(function(e){',
      '            if(e.isIntersecting && !started){',
      '              started = true;',
      '              var cur = 0;',
      '              var step = Math.max(1, Math.floor(num/60));',
      '              var iv = setInterval(function(){',
      '                cur += step;',
      '                if(cur >= num){ cur = num; clearInterval(iv); }',
      '                c.textContent = prefix + cur.toLocaleString("en-IN") + suffix;',
      '              }, 16);',
      '              co.unobserve(c);',
      '            }',
      '          });',
      '        }, { threshold: 0.5 });',
      '        co.observe(c);',
      '      });',
      '      // Hero parallax on scroll',
      '      window.addEventListener("scroll", function(){',
      '        var y = window.scrollY;',
      '        if(y < window.innerHeight && hero){',
      '          hero.style.transform = "translateY(" + (y*0.4) + "px)";',
      '          hero.style.opacity = String(Math.max(0, 1 - y/(window.innerHeight*0.8)));',
      '        }',
      '        if(heroSection){',
      '          var bg = heroSection.querySelector(".aurora-bg");',
      '          if(bg){ bg.style.transform = "translateY(" + (y*0.2) + "px)"; }',
      '        }',
      '      }, { passive: true });',
      '    })();',
      '  </script>',
      '',
      htmlFooter(businessName),
    ].join('\n')
  );
}

/* ------------------------------------------------------------------ */
/* Template 2: CINEMATIC-SCROLL                                         */
/* ------------------------------------------------------------------ */

function cinematicScrollHtml(businessName: string, headline: string, copy: IndustryCopy): string {
  // Split headline into words for word-by-word reveal.
  const words = headline.split(/\s+/);
  const wordSpans = words
    .map(
      (w, i) =>
        '<span class="cinema-word inline-block opacity-0 translate-y-8 transition-all duration-700" style="transition-delay:' +
        i * 80 +
        'ms">' +
        w +
        '&nbsp;</span>',
    )
    .join('');

  // Cinematic scenes — 3 acts plus testimonial + CTA.
  const scenes = [
    {
      eyebrow: 'Act I',
      title: 'A new beginning',
      body: copy.tagline,
      bg: 'radial-gradient(ellipse at 30% 40%, rgba(125,211,252,0.25), transparent 60%), linear-gradient(135deg,#0E1218,#1a2333)',
    },
    {
      eyebrow: 'Act II',
      title: 'Engineered for impact',
      body:
        'Every pixel, every interaction, every word — refined until nothing more can be removed. Only what truly matters remains.',
      bg: 'radial-gradient(ellipse at 70% 60%, rgba(196,181,253,0.25), transparent 60%), linear-gradient(135deg,#1a1333,#0E1218)',
    },
    {
      eyebrow: 'Act III',
      title: 'Your transformation',
      body:
        'This is where your story begins. ' +
        businessName +
        ' is ready when you are.',
      bg: 'radial-gradient(ellipse at 50% 80%, rgba(52,211,153,0.25), transparent 60%), linear-gradient(135deg,#0E1218,#13251c)',
    },
  ];

  const sceneHtml = scenes
    .map(
      (s, i) =>
        '  <section class="cinema-scene relative h-screen flex items-center justify-center overflow-hidden sticky top-0" data-scene="' +
        i +
        '" style="background:' +
        s.bg +
        '">\n' +
        '    <div class="absolute inset-0 cinema-bg" data-depth="' +
        (i * 0.3) +
        '"></div>\n' +
        '    <div class="absolute inset-0 bg-black/30"></div>\n' +
        '    <div class="relative z-10 text-center px-6 max-w-4xl cinema-content">\n' +
        '      <div class="jarvis-mono text-[10px] uppercase tracking-[0.4em] text-white/60 mb-6 cinema-eyebrow">' + s.eyebrow + '</div>\n' +
        '      <h2 class="font-display text-5xl md:text-7xl font-bold mb-6 cinema-title">' + s.title + '</h2>\n' +
        '      <p class="text-lg md:text-xl text-white/80 max-w-2xl mx-auto cinema-body">' + s.body + '</p>\n' +
        '    </div>\n' +
        '  </section>',
    )
    .join('\n');

  const stats = copy.stats
    .map(
      (s) =>
        '        <div class="text-center cinema-fade">\n' +
        '          <div class="font-display text-5xl font-bold gradient-text">' + s.value + '</div>\n' +
        '          <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--dim)] mt-2">' + s.label + '</div>\n' +
        '        </div>',
    )
    .join('\n');

  return (
    htmlHead(businessName + ' — ' + headline) +
    [
      '  <!-- Cinematic letterbox bars -->',
      '  <div id="letterbox-top" class="fixed top-0 left-0 right-0 bg-black z-50 transition-all duration-500" style="height:12vh"></div>',
      '  <div id="letterbox-bottom" class="fixed bottom-0 left-0 right-0 bg-black z-50 transition-all duration-500" style="height:12vh"></div>',
      '',
      '  <!-- ============ CINEMATIC OPENER ============ -->',
      '  <section class="relative h-screen flex items-center justify-center overflow-hidden bg-black">',
      '    <div class="absolute inset-0 opacity-40" style="background:radial-gradient(ellipse at center,rgba(125,211,252,0.3),transparent 60%)"></div>',
      '    <div class="relative z-10 text-center px-6 max-w-5xl" id="opener">',
      '      <div class="jarvis-mono text-[10px] uppercase tracking-[0.5em] text-[var(--accent)] mb-8 cinema-fade">' + businessName + '</div>',
      '      <h1 class="font-display text-5xl md:text-7xl lg:text-9xl font-black tracking-tight leading-[1.05] mb-8">',
      '        <span class="gradient-text">' + wordSpans + '</span>',
      '      </h1>',
      '      <p class="text-lg md:text-2xl text-white/70 max-w-2xl mx-auto cinema-fade" style="transition-delay:600ms">' + copy.tagline + '</p>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ CINEMATIC SCENES (sticky reveal) ============ -->',
      sceneHtml,
      '',
      '  <!-- ============ STATS BAND ============ -->',
      '  <section class="py-32 px-6 relative bg-black">',
      '    <div class="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">',
      stats,
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ TESTIMONIAL ============ -->',
      '  <section class="py-32 px-6 relative bg-black">',
      '    <div class="max-w-4xl mx-auto text-center cinema-fade">',
      '      <div class="text-7xl mb-6 text-[var(--accent)] opacity-30 font-display">"</div>',
      '      <blockquote class="font-display text-2xl md:text-4xl font-medium leading-tight mb-10 max-w-3xl mx-auto">' + copy.testimonial.quote + '</blockquote>',
      '      <div class="font-semibold text-[var(--accent)]">' + copy.testimonial.author + '</div>',
      '      <div class="text-xs uppercase tracking-widest text-[var(--dim)] mt-1">' + copy.testimonial.role + '</div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ CTA ============ -->',
      '  <section id="contact" class="py-40 px-6 relative bg-black text-center">',
      '    <h2 class="font-display text-5xl md:text-7xl font-bold mb-8 cinema-fade">The end is the <span class="gradient-text">beginning</span></h2>',
      '    <p class="text-white/70 mb-12 max-w-xl mx-auto cinema-fade" style="transition-delay:200ms">Contact ' + businessName + ' today.</p>',
      '    <a href="mailto:hello@example.com" class="inline-block px-12 py-5 rounded-full font-display font-bold text-sm uppercase tracking-widest text-black transition-transform hover:scale-105 cinema-fade" style="background:linear-gradient(135deg,#7DD3FC,#C4B5FD,#34D399);transition-delay:400ms">Begin →</a>',
      '  </section>',
      '',
      '  <!-- ============ CINEMATIC SCROLL STYLES ============ -->',
      '  <style>',
      '    .cinema-scene{opacity:0.4;transition:opacity 0.6s ease}',
      '    .cinema-scene.in-view{opacity:1}',
      '    .cinema-word{display:inline-block}',
      '    .cinema-word.visible{opacity:1;transform:translateY(0)}',
      '    .cinema-fade{opacity:0;transform:translateY(40px);transition:opacity 1s ease,transform 1s ease}',
      '    .cinema-fade.visible{opacity:1;transform:translateY(0)}',
      '  </style>',
      '',
      '  <!-- ============ CINEMATIC SCROLL SCRIPT ============ -->',
      '  <script>',
      '    (function(){',
      '      // Word-by-word headline reveal',
      '      var opener = document.getElementById("opener");',
      '      if(opener){',
      '        var words = opener.querySelectorAll(".cinema-word");',
      '        setTimeout(function(){ words.forEach(function(w){ w.classList.add("visible"); }); }, 200);',
      '        var fades = opener.querySelectorAll(".cinema-fade");',
      '        setTimeout(function(){ fades.forEach(function(f){ f.classList.add("visible"); }); }, 100);',
      '      }',
      '      // Sticky scene opacity transitions',
      '      var scenes = document.querySelectorAll(".cinema-scene");',
      '      var sceneObserver = new IntersectionObserver(function(entries){',
      '        entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add("in-view"); } else { e.target.classList.remove("in-view"); } });',
      '      }, { threshold: 0.35 });',
      '      scenes.forEach(function(s){ sceneObserver.observe(s); });',
      '      // Letterbox bars shrink on scroll (cinematic effect)',
      '      var lt = document.getElementById("letterbox-top");',
      '      var lb = document.getElementById("letterbox-bottom");',
      '      // Fade-in elements',
      '      var fadeEls = document.querySelectorAll(".cinema-fade");',
      '      var fadeObs = new IntersectionObserver(function(entries){',
      '        entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add("visible"); fadeObs.unobserve(e.target); } });',
      '      }, { threshold: 0.25 });',
      '      fadeEls.forEach(function(el){ fadeObs.observe(el); });',
      '      // Scroll listener for letterbox + parallax',
      '      window.addEventListener("scroll", function(){',
      '        var y = window.scrollY;',
      '        var max = document.body.scrollHeight - window.innerHeight;',
      '        var p = max > 0 ? Math.min(y/max, 1) : 0;',
      '        // Letterbox shrinks from 12vh → 4vh as you scroll',
      '        if(lt) lt.style.height = (12 - p*8) + "vh";',
      '        if(lb) lb.style.height = (12 - p*8) + "vh";',
      '        // Parallax bg layers',
      '        scenes.forEach(function(s, i){',
      '          var bg = s.querySelector(".cinema-bg");',
      '          if(bg){ var depth = parseFloat(bg.getAttribute("data-depth")||"0"); bg.style.transform = "translateY(" + (y*0.05*(1+depth)) + "px)"; }',
      '          var content = s.querySelector(".cinema-content");',
      '          if(content){ var rect = s.getBoundingClientRect(); var center = rect.top + rect.height/2; var offset = (center - window.innerHeight/2)/window.innerHeight; content.style.transform = "translateY(" + (offset*-30) + "px)"; }',
      '        });',
      '      }, { passive: true });',
      '    })();',
      '  </script>',
      '',
      htmlFooter(businessName),
    ].join('\n')
  );
}

/* ------------------------------------------------------------------ */
/* Template 3: STICKY-PARALLAX                                          */
/* ------------------------------------------------------------------ */

function stickyParallaxHtml(businessName: string, headline: string, copy: IndustryCopy): string {
  // Card stack — uses pricing tiers as cards that flatten on scroll (Apple-style).
  const stackCards = copy.stats
    .map(
      (s, i) =>
        '      <div class="stack-card absolute inset-0 rounded-3xl glass p-12 flex flex-col items-center justify-center" data-index="' +
        i +
        '" style="z-index:' +
        (10 - i) +
        ';transform:translateY(' +
        i * 40 +
        'px) scale(' +
        (1 - i * 0.04) +
        ');opacity:' +
        (1 - i * 0.15) +
        '">\n' +
        '        <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--accent)] mb-3">Tier ' +
        (i + 1) +
        '</div>\n' +
        '        <div class="font-display text-5xl md:text-7xl font-black gradient-text mb-4">' + s.value + '</div>\n' +
        '        <div class="text-sm uppercase tracking-widest text-[var(--dim)]">' + s.label + '</div>\n' +
        '      </div>',
    )
    .join('\n');

  // Horizontal-scroll feature slides.
  const featureSlides = copy.featureCards
    .map(
      (c, i) =>
        '        <div class="feature-slide w-screen h-screen flex items-center justify-center px-6" data-index="' +
        i +
        '">\n' +
        '          <div class="max-w-2xl text-center glass rounded-3xl p-12">\n' +
        '            <div class="text-6xl mb-6" style="color:var(--accent)">' + c.icon + '</div>\n' +
        '            <h3 class="font-display text-4xl md:text-5xl font-bold mb-4">' + c.title + '</h3>\n' +
        '            <p class="text-lg text-[var(--dim)]">' + c.body + '</p>\n' +
        '          </div>\n' +
        '        </div>',
    )
    .join('\n');

  return (
    htmlHead(businessName + ' — ' + headline) +
    [
      '  <!-- Scroll progress bar -->',
      '  <div class="fixed top-0 left-0 right-0 h-1 z-50 bg-transparent">',
      '    <div id="progress-bar" class="h-full transition-all duration-100" style="width:0%;background:linear-gradient(90deg,#7DD3FC,#C4B5FD,#34D399)"></div>',
      '  </div>',
      '',
      '  <!-- ============ HERO with parallax bg layers ============ -->',
      '  <section class="relative h-screen flex items-center justify-center overflow-hidden" id="hero">',
      '    <div class="absolute inset-0 parallax-layer" data-speed="0.2" style="background:radial-gradient(ellipse at top,rgba(125,211,252,0.3),transparent 50%)"></div>',
      '    <div class="absolute inset-0 parallax-layer" data-speed="0.4" style="background:radial-gradient(ellipse at bottom right,rgba(196,181,253,0.25),transparent 50%)"></div>',
      '    <div class="absolute inset-0 parallax-layer" data-speed="0.6" style="background:radial-gradient(ellipse at bottom left,rgba(52,211,153,0.2),transparent 50%)"></div>',
      '    <div class="relative z-10 text-center px-6 max-w-5xl">',
      '      <div class="jarvis-mono text-[10px] uppercase tracking-[0.4em] text-[var(--accent)] mb-6 hero-fade">' + businessName + '</div>',
      '      <h1 class="font-display text-5xl md:text-7xl lg:text-8xl font-black tracking-tight leading-[1.05] mb-6 hero-fade" style="transition-delay:200ms">',
      '        <span class="gradient-text">' + headline + '</span>',
      '      </h1>',
      '      <p class="text-lg md:text-xl text-[var(--dim)] max-w-2xl mx-auto hero-fade" style="transition-delay:400ms">' + copy.tagline + '</p>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ STICKY CHAPTER: Features ============ -->',
      '  <section class="relative" id="chapter-features">',
      '    <div class="sticky top-0 h-screen flex items-center px-6 overflow-hidden">',
      '      <div class="max-w-7xl mx-auto w-full flex flex-col lg:flex-row gap-12 items-center">',
      '        <div class="lg:w-1/3 chapter-heading">',
      '          <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--accent)] mb-3">Chapter 01</div>',
      '          <h2 class="font-display text-5xl md:text-6xl font-bold mb-4">Features that <span class="gradient-text">matter</span></h2>',
      '          <p class="text-[var(--dim)]">Scroll horizontally to explore what makes ' + businessName + ' different.</p>',
      '        </div>',
      '        <div class="lg:w-2/3 w-full overflow-x-auto scrollbar-hidden feature-track" style="scroll-snap-type:x mandatory">',
      featureSlides,
      '        </div>',
      '      </div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ STICKY CHAPTER: Pricing (card-stack) ============ -->',
      '  <section class="relative" id="chapter-pricing" style="height:300vh">',
      '    <div class="sticky top-0 h-screen flex items-center justify-center px-6">',
      '      <div class="max-w-2xl w-full text-center mb-12">',
      '        <div class="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--accent)] mb-3">Chapter 02</div>',
      '        <h2 class="font-display text-5xl md:text-6xl font-bold">Pricing that <span class="gradient-text">scales</span></h2>',
      '      </div>',
      '      <div class="relative w-full max-w-md h-96" id="card-stack" style="perspective:1000px">',
      stackCards,
      '      </div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ TESTIMONIAL ============ -->',
      '  <section class="py-32 px-6 relative">',
      '    <div class="max-w-4xl mx-auto text-center glass rounded-3xl p-12 parallax-fade">',
      '      <div class="text-7xl mb-4 text-[var(--accent)] opacity-30">"</div>',
      '      <blockquote class="font-display text-2xl md:text-3xl font-medium leading-relaxed mb-8">' + copy.testimonial.quote + '</blockquote>',
      '      <div class="font-semibold text-[var(--accent)]">' + copy.testimonial.author + '</div>',
      '      <div class="text-xs uppercase tracking-widest text-[var(--dim)] mt-1">' + copy.testimonial.role + '</div>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ CTA ============ -->',
      '  <section id="contact" class="py-32 px-6 relative overflow-hidden">',
      '    <div class="absolute inset-0" style="background:linear-gradient(135deg,rgba(125,211,252,0.1),rgba(52,211,153,0.1))"></div>',
      '    <div class="relative max-w-3xl mx-auto text-center parallax-fade">',
      '      <h2 class="font-display text-4xl md:text-5xl font-bold mb-6">Ready when you are.</h2>',
      '      <p class="text-[var(--dim)] mb-10 max-w-xl mx-auto">Get in touch with ' + businessName + ' today and start your journey.</p>',
      '      <a href="mailto:hello@example.com" class="inline-block px-10 py-5 rounded-full font-display font-bold text-sm uppercase tracking-wider text-[var(--bg)] transition-transform hover:scale-105" style="background:linear-gradient(135deg,#7DD3FC,#34D399)">Get Started →</a>',
      '    </div>',
      '  </section>',
      '',
      '  <!-- ============ STICKY PARALLAX STYLES ============ -->',
      '  <style>',
      '    .hero-fade{opacity:0;transform:translateY(40px);transition:opacity 1s ease,transform 1s ease}',
      '    .hero-fade.visible{opacity:1;transform:translateY(0)}',
      '    .parallax-fade{opacity:0;transform:translateY(40px);transition:opacity 0.8s ease,transform 0.8s ease}',
      '    .parallax-fade.visible{opacity:1;transform:translateY(0)}',
      '    .feature-slide{scroll-snap-align:start;flex-shrink:0}',
      '    .feature-track{display:flex;scroll-snap-type:x mandatory}',
      '    .chapter-heading{opacity:0;transform:translateX(-40px);transition:all 0.8s ease}',
      '    .chapter-heading.visible{opacity:1;transform:translateX(0)}',
      '    .stack-card{transition:transform 0.6s cubic-bezier(0.22,1,0.36,1),opacity 0.6s ease}',
      '  </style>',
      '',
      '  <!-- ============ STICKY PARALLAX SCRIPT ============ -->',
      '  <script>',
      '    (function(){',
      '      // Scroll progress bar',
      '      var pb = document.getElementById("progress-bar");',
      '      // Hero fade-in',
      '      var heroFades = document.querySelectorAll(".hero-fade");',
      '      setTimeout(function(){ heroFades.forEach(function(f){ f.classList.add("visible"); }); }, 150);',
      '      // Parallax layers (hero)',
      '      var layers = document.querySelectorAll(".parallax-layer");',
      '      // Chapter heading + parallax-fade reveals',
      '      var fadeEls = document.querySelectorAll(".chapter-heading, .parallax-fade");',
      '      var io = new IntersectionObserver(function(entries){',
      '        entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add("visible"); io.unobserve(e.target); } });',
      '      }, { threshold: 0.2 });',
      '      fadeEls.forEach(function(el){ io.observe(el); });',
      '      // Card-stack flatten on scroll',
      '      var pricingSection = document.getElementById("chapter-pricing");',
      '      var stackCards = document.querySelectorAll(".stack-card");',
      '      window.addEventListener("scroll", function(){',
      '        var y = window.scrollY;',
      '        var max = document.body.scrollHeight - window.innerHeight;',
      '        if(pb && max > 0){ pb.style.width = Math.min((y/max)*100, 100) + "%"; }',
      '        // Hero parallax',
      '        layers.forEach(function(l){ var speed = parseFloat(l.getAttribute("data-speed")||"0.2"); l.style.transform = "translateY(" + (y*speed) + "px)"; });',
      '        // Card-stack: each card flattens onto the previous one as you scroll through pricing',
      '        if(pricingSection){',
      '          var rect = pricingSection.getBoundingClientRect();',
      '          var sectionHeight = pricingSection.offsetHeight;',
      '          var scrolled = Math.max(0, Math.min(1, (rect.top * -1) / (sectionHeight - window.innerHeight)));',
      '          stackCards.forEach(function(c, i){',
      '            if(i === 0) return;',
      '            var localProgress = Math.max(0, Math.min(1, (scrolled - (i-1)*0.2) / 0.2));',
      '            var translateY = (1 - localProgress) * 80;',
      '            var scale = 1 - i * 0.04 + localProgress * 0.04;',
      '            var opacity = 1 - i * 0.15 + localProgress * 0.15;',
      '            c.style.transform = "translateY(" + translateY + "px) scale(" + scale + ")";',
      '            c.style.opacity = String(opacity);',
      '          });',
      '        }',
      '      }, { passive: true });',
      '    })();',
      '  </script>',
      '',
      htmlFooter(businessName),
    ].join('\n')
  );
}

/* ------------------------------------------------------------------ */
/* Public entry points                                                 */
/* ------------------------------------------------------------------ */

/**
 * Generate a complete standalone HTML string for a 3D scroll-animation
 * pitch website. The output uses only vanilla JS + Tailwind CDN — no build
 * step required. Suitable for cold-outreach pitch emails (just attach the
 * HTML file or paste it into a hosted preview).
 *
 * @param businessName Prospect's business name (e.g. "Bella Italia")
 * @param industry     Industry key from SALES_INDUSTRY_KEYS (e.g. "restaurant")
 * @param headline     Hero headline (e.g. "Italian food, redefined")
 * @param templateId   Optional template id — defaults to 'aurora-3d'
 */
export function generate3DScrollWebsite(
  businessName: string,
  industry: string,
  headline: string,
  templateId: PitchTemplateId = 'aurora-3d',
): GeneratedTemplate {
  const metadata = getTemplatePreview(templateId);
  const html = generateTemplateHtml(businessName, industry, headline, templateId);
  return { html, metadata };
}

/** Returns just the HTML string for the given template. */
export function generateTemplateHtml(
  businessName: string,
  industry: string,
  headline: string,
  templateId: PitchTemplateId,
): string {
  const copy = getIndustryCopy(industry, businessName);
  const safeName = (businessName || 'Your Business').trim();
  const safeHeadline = (headline || 'Premium experiences, crafted for you').trim();
  switch (templateId) {
    case 'cinematic-scroll':
      return cinematicScrollHtml(safeName, safeHeadline, copy);
    case 'sticky-parallax':
      return stickyParallaxHtml(safeName, safeHeadline, copy);
    case 'aurora-3d':
    default:
      return aurora3dHtml(safeName, safeHeadline, copy);
  }
}

/** Coerce an unknown string into a valid PitchTemplateId (falls back to aurora-3d). */
export function coerceTemplateId(id: string | undefined | null): PitchTemplateId {
  if (id && (PITCH_TEMPLATE_IDS as string[]).includes(id)) {
    return id as PitchTemplateId;
  }
  return 'aurora-3d';
}
