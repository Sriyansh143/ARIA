'use client';

// =====================================================================
// ServiceHealthTab — External service health dashboard.
// =====================================================================
// Surfaces:
//   1. Header with "Re-check all" button + summary counts (healthy /
//      degraded / down / unknown).
//   2. 8 service cards in a responsive grid (1 col mobile, 2 col desktop):
//      - Status dot (green/amber/red/grey)
//      - Service name + endpoint
//      - Latency + last-checked time
//      - Error message (if any)
//      - Sparkline of the last 20 latency samples
//      - Per-card "Re-check" button
//
// Polls /api/service-health every 15s. Per-card re-check hits
// /api/service-health/check. Uses JARVIS cyberpunk design tokens.
// =====================================================================

import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, RefreshCw, Phone, Cpu, Send, Mail, CreditCard,
  DollarSign, Sparkles, Zap, AlertTriangle, CheckCircle2,
  XCircle, HelpCircle, Loader2, Clock,
} from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { SectionTitle, StatCard, Pill, Sparkline } from '@/components/jarvis/shared';
import { timeAgo } from '@/lib/config';

// ─── Types ───────────────────────────────────────────────────────────

type ServiceStatus = 'healthy' | 'degraded' | 'down' | 'unknown';

interface ServiceHealth {
  service: string;
  status: ServiceStatus;
  latencyMs: number;
  lastCheckedAt: string;
  error?: string;
  endpoint?: string;
}

interface HealthResponse {
  services: ServiceHealth[];
  history: Record<string, ServiceHealth[]>;
  sampledAt?: string;
  error?: string;
}

interface CheckResponse {
  health: ServiceHealth;
  error?: string;
}

// ─── Constants ───────────────────────────────────────────────────────

const STATUS_COLORS: Record<ServiceStatus, string> = {
  healthy: JARVIS.colors.green,
  degraded: JARVIS.colors.amber,
  down: JARVIS.colors.red,
  unknown: JARVIS.colors.textMute,
};

const STATUS_LABEL: Record<ServiceStatus, string> = {
  healthy: 'Healthy',
  degraded: 'Degraded',
  down: 'Down',
  unknown: 'Unknown',
};

const SERVICE_ICONS: Record<string, typeof Phone> = {
  freeswitch: Phone,
  ollama: Cpu,
  telegram: Send,
  smtp: Mail,
  razorpay: CreditCard,
  stripe: DollarSign,
  'zai-sdk': Sparkles,
  groq: Zap,
};

const SERVICE_LABELS: Record<string, string> = {
  freeswitch: 'FreeSWITCH',
  ollama: 'Ollama',
  telegram: 'Telegram Bot',
  smtp: 'SMTP Server',
  razorpay: 'Razorpay API',
  stripe: 'Stripe API',
  'zai-sdk': 'Z.ai SDK',
  groq: 'Groq API',
};

const SERVICE_DESCRIPTIONS: Record<string, string> = {
  freeswitch: 'ESL socket (port 8021) for voice calls',
  ollama: 'Local LLM inference (port 11434)',
  telegram: 'Telegram Bot API getMe endpoint',
  smtp: 'Outbound email server (port 25)',
  razorpay: 'Payment gateway reachability',
  stripe: 'Payment gateway reachability',
  'zai-sdk': 'GLM-4.6 SDK config + API key',
  groq: 'Groq fallback LLM API key',
};

// ─── Status dot ──────────────────────────────────────────────────────

function StatusDot({ status, size = 10 }: { status: ServiceStatus; size?: number }) {
  const color = STATUS_COLORS[status];
  const pulse = status === 'degraded' || status === 'down';
  return (
    <span
      className={`inline-block rounded-full ${pulse ? 'jarvis-pulse-dot' : ''}`}
      style={{
        width: size,
        height: size,
        background: color,
        boxShadow: `0 0 8px ${color}`,
      }}
    />
  );
}

// ─── Service card ────────────────────────────────────────────────────

function ServiceCard({
  health,
  history,
  onRecheck,
  rechecking,
}: {
  health: ServiceHealth;
  history: ServiceHealth[];
  onRecheck: () => void;
  rechecking: boolean;
}) {
  const Icon = SERVICE_ICONS[health.service] ?? Activity;
  const color = STATUS_COLORS[health.status];
  const label = SERVICE_LABELS[health.service] ?? health.service;
  const description = SERVICE_DESCRIPTIONS[health.service] ?? '';
  const sparkData = history
    .map((h) => (h.status === 'down' || h.status === 'unknown' ? 0 : Math.max(1, h.latencyMs)))
    .slice(-20);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="jarvis-panel p-4 relative overflow-hidden flex flex-col gap-3"
      style={{ borderColor: `${color}40` }}
    >
      {/* Top accent line — color matches status */}
      <div
        className="absolute top-0 left-0 h-[2px]"
        style={{ width: '100%', background: `linear-gradient(90deg, ${color}, transparent)` }}
      />

      {/* Header: icon + name + status dot */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className="flex h-9 w-9 items-center justify-center rounded-lg shrink-0"
            style={{ background: `${color}1a`, border: `1px solid ${color}33`, color }}
          >
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold text-[var(--j-text)] truncate">{label}</div>
            <div className="text-[10px] text-[var(--j-text-mute)] truncate">{description}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <StatusDot status={health.status} />
          <span
            className="jarvis-mono text-[9px] uppercase"
            style={{ color }}
          >
            {STATUS_LABEL[health.status]}
          </span>
        </div>
      </div>

      {/* Endpoint */}
      {health.endpoint && (
        <div className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate" title={health.endpoint}>
          {health.endpoint}
        </div>
      )}

      {/* Latency + last checked */}
      <div className="flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5 text-[var(--j-text-dim)]">
          <Zap className="h-3 w-3" />
          <span>{health.latencyMs > 0 ? `${health.latencyMs}ms` : '—'}</span>
        </div>
        <div className="flex items-center gap-1.5 text-[var(--j-text-mute)]">
          <Clock className="h-3 w-3" />
          <span>{timeAgo(health.lastCheckedAt)}</span>
        </div>
      </div>

      {/* Error message */}
      {health.error && (
        <div
          className="text-[10px] text-[var(--j-text-dim)] leading-snug line-clamp-2 px-2 py-1 rounded"
          style={{ background: `${color}10`, border: `1px solid ${color}22` }}
          title={health.error}
        >
          {health.error}
        </div>
      )}

      {/* Sparkline + re-check button */}
      <div className="flex items-center justify-between gap-2 pt-1 mt-auto">
        <div className="flex items-center gap-1.5">
          <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">latency</span>
          {sparkData.length >= 2 ? (
            <Sparkline data={sparkData} color={color} width={70} height={20} />
          ) : (
            <span className="text-[9px] text-[var(--j-text-mute)] italic">no history yet</span>
          )}
        </div>
        <button
          onClick={onRecheck}
          disabled={rechecking}
          className="jarvis-mono text-[9px] uppercase px-2 py-1 rounded-md border transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          style={{
            borderColor: `${JARVIS.colors.cyan}40`,
            color: JARVIS.colors.cyan,
            background: `${JARVIS.colors.cyan}10`,
          }}
        >
          {rechecking ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
        </button>
      </div>
    </motion.div>
  );
}

// ─── Main tab ────────────────────────────────────────────────────────

export default function ServiceHealthTab() {
  const { toast } = useToast();
  const { data, loading, error, refresh } = useApi<HealthResponse>('/api/service-health', 15000);
  const [recheckingAll, setRecheckingAll] = useState(false);
  const [recheckingSvc, setRecheckingSvc] = useState<string | null>(null);

  const services = data?.services ?? [];
  const history = data?.history ?? {};

  // Summary counts
  const counts = {
    healthy: services.filter((s) => s.status === 'healthy').length,
    degraded: services.filter((s) => s.status === 'degraded').length,
    down: services.filter((s) => s.status === 'down').length,
    unknown: services.filter((s) => s.status === 'unknown').length,
  };

  const handleRecheckAll = useCallback(async () => {
    setRecheckingAll(true);
    try {
      await refresh();
      toast({
        title: 'Service health re-checked',
        description: `${services.length} services probed.`,
      });
    } catch (err) {
      toast({
        title: 'Re-check failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setRecheckingAll(false);
    }
  }, [refresh, services.length, toast]);

  const handleRecheckOne = useCallback(
    async (service: string) => {
      setRecheckingSvc(service);
      try {
        const res = await postJson<CheckResponse>('/api/service-health/check', { service });
        if (res.health) {
          toast({
            title: `${SERVICE_LABELS[service] ?? service}: ${STATUS_LABEL[res.health.status]}`,
            description: res.health.error
              ? res.health.error.slice(0, 120)
              : `Latency ${res.health.latencyMs}ms`,
          });
        }
        // Refresh the whole grid so the sparkline picks up the new sample.
        refresh();
      } catch (err) {
        toast({
          title: `Re-check failed for ${service}`,
          description: err instanceof Error ? err.message : 'Unknown error',
          variant: 'destructive',
        });
      } finally {
        setRecheckingSvc(null);
      }
    },
    [refresh, toast],
  );

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Service Health"
        icon={Activity}
        accent={JARVIS.colors.green}
        action={
          <div className="flex items-center gap-2">
            {data?.sampledAt && (
              <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                sampled {timeAgo(data.sampledAt)}
              </span>
            )}
            <button
              onClick={handleRecheckAll}
              disabled={recheckingAll}
              className="jarvis-btn-accent jarvis-mono text-[10px] uppercase px-3 py-1.5 rounded-md border border-transparent flex items-center gap-1.5 transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {recheckingAll ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
              Re-check all
            </button>
          </div>
        }
      />

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard
          label="Healthy"
          value={counts.healthy}
          icon={CheckCircle2}
          accent={JARVIS.colors.green}
        />
        <StatCard
          label="Degraded"
          value={counts.degraded}
          icon={AlertTriangle}
          accent={JARVIS.colors.amber}
        />
        <StatCard
          label="Down"
          value={counts.down}
          icon={XCircle}
          accent={JARVIS.colors.red}
        />
        <StatCard
          label="Unknown"
          value={counts.unknown}
          icon={HelpCircle}
          accent={JARVIS.colors.textMute}
        />
      </div>

      {/* Error banner */}
      {error && (
        <div
          className="jarvis-panel p-3 flex items-center gap-2"
          style={{ borderColor: `${JARVIS.colors.red}40` }}
        >
          <AlertTriangle className="h-4 w-4 text-[var(--j-red)]" />
          <span className="text-xs text-[var(--j-text-dim)]">
            Failed to load service health: {error}
          </span>
        </div>
      )}

      {/* Loading state */}
      {loading && services.length === 0 && (
        <div className="jarvis-panel p-8 flex items-center justify-center">
          <Loader2 className="h-5 w-5 animate-spin text-[var(--j-cyan)]" />
          <span className="ml-2 text-xs text-[var(--j-text-dim)] jarvis-mono uppercase">
            Probing services…
          </span>
        </div>
      )}

      {/* Service grid: 1 col mobile, 2 col desktop (2x4 layout for 8 services) */}
      {services.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {services.map((svc) => (
            <ServiceCard
              key={svc.service}
              health={svc}
              history={history[svc.service] ?? []}
              onRecheck={() => handleRecheckOne(svc.service)}
              rechecking={recheckingSvc === svc.service}
            />
          ))}
        </div>
      )}

      {/* Footer note */}
      {services.length > 0 && (
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-3">
            <Pill color={JARVIS.colors.green}>healthy</Pill>
            <Pill color={JARVIS.colors.amber}>degraded</Pill>
            <Pill color={JARVIS.colors.red}>down</Pill>
            <Pill color={JARVIS.colors.textMute}>unknown</Pill>
          </div>
          <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
            auto-refresh 15s · ring buffer 100/service
          </span>
        </div>
      )}
    </div>
  );
}
