'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, Cpu, Database, Radio, RefreshCw, Loader2, TrendingUp, TrendingDown,
  ShieldCheck, AlertTriangle, Zap, Server, Wifi, WifiOff, HardDrive,
  Layers, GitBranch, CheckCircle2, XCircle, ArrowRight, Gauge, Cloud, CloudOff,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { useRealtimeConnection } from '@/lib/hooks/use-realtime';

// ─── Types matching the v11 API responses ─────────────────────────────
interface Kpi {
  kpi: string;
  value: number;
  target: number;
  status: 'nominal' | 'warning' | 'critical' | 'exceeded';
  autoAdjusted: boolean;
  adjustmentNote?: string;
}

interface Forecast {
  metric: string;
  horizon: string;
  current: number;
  forecast: number;
  confidence: number;
  trend: 'up' | 'down' | 'stable';
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  detail: Record<string, unknown>;
}

interface DbSyncStatus {
  primary: { provider: string; url: string };
  mirror: { provider: string; configured: boolean; reachable: boolean; error: string | null; poolActive: boolean };
  sync: { syncing: boolean; lastSyncAt: string | null; lastResult: { ok: boolean; tablesSynced: number; rowsSynced: number; durationMs: number; error?: string } | null; autoSyncEnabled: boolean };
}

interface RealtimeStatus {
  running: boolean;
  connections: number;
  uptime: number;
  port: number;
  channels?: string[];
}

interface AgentModelDiversity {
  assignments: Array<{ agentCodename: string; modelId: string; providerKey: string; taskRouting: string; enabled: boolean; reason: string | null }>;
  diversity: { uniqueModels: number; uniqueProviders: number; byModel: Record<string, number>; byProvider: Record<string, number> };
}

interface SmartRouterStats {
  taskTypeStats: Record<string, number>;
  totalModels: number;
  configuredProviders: Array<{ key: string; configured: boolean; envVar: string }>;
  configuredProviderCount: number;
}

const RISK_COLORS: Record<string, string> = {
  low: JARVIS.colors.green,
  medium: JARVIS.colors.cyan,
  high: JARVIS.colors.amber,
  critical: JARVIS.colors.red,
};

const KPI_STATUS_COLORS: Record<string, string> = {
  nominal: JARVIS.colors.green,
  warning: JARVIS.colors.amber,
  critical: JARVIS.colors.red,
  exceeded: JARVIS.colors.cyan,
};

const METRIC_LABELS: Record<string, string> = {
  'fleet-load': 'Fleet Load',
  'overload-risk': 'Overload Risk',
  'task-completion': 'Task Completion',
  revenue: 'Revenue',
  'error-rate': 'Error Rate',
};

export default function SystemHealthTab() {
  const { toast } = useToast();
  const { connected: realtimeConnected } = useRealtimeConnection();
  const [syncing, setSyncing] = useState(false);

  const { data: kpis, loading: kpisLoading, refresh: refreshKpis } = useApi<{ kpis: Kpi[] }>('/api/kpis', 30000);
  const { data: forecasts, loading: forecastsLoading, refresh: refreshForecasts } = useApi<{ forecasts: Forecast[] }>('/api/forecasts', 30000);
  const { data: dbSync, refresh: refreshDbSync } = useApi<DbSyncStatus>('/api/db-sync', 15000);
  const { data: realtime } = useApi<RealtimeStatus>('/api/realtime/status', 10000);
  const { data: modelData, loading: modelsLoading } = useApi<AgentModelDiversity>('/api/agent-models', 30000);
  const { data: routerStats, loading: routerLoading } = useApi<SmartRouterStats>('/api/smart-router', 30000);

  const handleSyncNow = useCallback(async () => {
    setSyncing(true);
    try {
      const res = await postJson<{ ok: boolean; result: { ok: boolean; tablesSynced: number; rowsSynced: number; durationMs: number; error?: string } }>('/api/db-sync', {});
      if (res.ok && res.result.ok) {
        toast({ title: 'DB Sync complete', description: `${res.result.tablesSynced} tables, ${res.result.rowsSynced} rows in ${res.result.durationMs}ms` });
        refreshDbSync();
      } else {
        toast({ title: 'DB Sync failed', description: res.result?.error ?? 'postgres not reachable', variant: 'destructive' });
      }
    } catch (err) {
      toast({ title: 'DB Sync failed', description: err instanceof Error ? err.message : 'network error', variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  }, [toast, refreshDbSync]);

  const handleAdjustKpis = useCallback(async () => {
    try {
      const res = await postJson<{ ok: boolean; kpis: Kpi[] }>('/api/kpis', {});
      if (res.ok) {
        const adjusted = res.kpis.filter((k) => k.autoAdjusted).length;
        toast({ title: 'KPIs re-evaluated', description: adjusted > 0 ? `${adjusted} target(s) auto-adjusted` : 'No adjustments needed' });
        refreshKpis();
      }
    } catch (err) {
      toast({ title: 'KPI adjustment failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshKpis]);

  const handleRefreshForecasts = useCallback(async () => {
    try {
      await postJson<{ ok: boolean }>('/api/forecasts', {});
      toast({ title: 'Forecasts regenerated' });
      refreshForecasts();
    } catch (err) {
      toast({ title: 'Forecast refresh failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshForecasts]);

  const overallHealth = kpis?.kpis?.find((k) => k.kpi === 'health');
  const healthScore = overallHealth?.value ?? 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">v11 Production Readiness · Operational Dashboard</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">System Health</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Consolidated view of KPIs, predictive forecasts, dual-DB sync, real-time connectivity, and model diversity.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleAdjustKpis}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-sm"
          >
            <Zap className="h-3.5 w-3.5" />
            <span className="jarvis-mono text-[10px] uppercase">Adjust KPIs</span>
          </button>
          <button
            onClick={handleRefreshForecasts}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-violet)] hover:border-[var(--j-violet)] transition-colors text-sm"
          >
            <TrendingUp className="h-3.5 w-3.5" />
            <span className="jarvis-mono text-[10px] uppercase">Refresh Forecasts</span>
          </button>
        </div>
      </div>

      {/* Top stat strip — health score + realtime + db sync + providers */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <HealthScoreCard score={healthScore} loading={kpisLoading} />
        <RealtimeCard connected={realtimeConnected} status={realtime} />
        <DbSyncCard status={dbSync} onSync={handleSyncNow} syncing={syncing} />
        <ProvidersCard stats={routerStats} loading={routerLoading} />
      </div>

      {/* KPIs + Forecasts side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* KPI Panel */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Gauge className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">KPI Targets · Auto-Adjusted</h4>
          </div>
          {kpisLoading && !kpis ? (
            <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-12 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          ) : (
            <div className="space-y-2.5">
              {kpis?.kpis?.map((kpi, i) => {
                const color = KPI_STATUS_COLORS[kpi.status] ?? JARVIS.colors.cyan;
                const pct = kpi.target > 0 ? Math.min(100, (kpi.value / kpi.target) * 100) : 0;
                const isLatency = kpi.kpi === 'latency';
                const displayPct = isLatency ? Math.max(5, Math.min(100, (kpi.target / Math.max(kpi.value, 1)) * 100)) : pct;
                return (
                  <motion.div
                    key={kpi.kpi}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="p-2.5 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">{kpi.kpi.replace(/-/g, ' ')}</span>
                        {kpi.autoAdjusted && (
                          <span className="jarvis-mono text-[8px] px-1 py-0.5 rounded font-bold" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.12)' }}>AUTO</span>
                        )}
                      </div>
                      <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>{kpi.status}</span>
                    </div>
                    <div className="flex items-baseline gap-2 mb-1.5">
                      <span className="jarvis-mono text-lg font-bold tabular-nums" style={{ color: 'var(--j-text)' }}>
                        {kpi.kpi === 'revenue' ? '₹' : ''}{Math.round(kpi.value).toLocaleString()}
                      </span>
                      <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">/ target {kpi.kpi === 'revenue' ? '₹' : ''}{Math.round(kpi.target).toLocaleString()}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-[var(--j-bg)] overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${displayPct}%` }}
                        transition={{ duration: 0.5, delay: i * 0.05 }}
                        className="h-full rounded-full"
                        style={{ background: color, boxShadow: `0 0 6px ${color}66` }}
                      />
                    </div>
                    {kpi.adjustmentNote && (
                      <p className="text-[9px] text-[var(--j-text-mute)] mt-1 jarvis-mono">{kpi.adjustmentNote}</p>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {/* Forecasts Panel */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Predictive Forecasts</h4>
          </div>
          {forecastsLoading && !forecasts ? (
            <div className="grid grid-cols-2 gap-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-20 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {forecasts?.forecasts?.map((f, i) => {
                const color = RISK_COLORS[f.riskLevel] ?? JARVIS.colors.cyan;
                const TrendIcon = f.trend === 'up' ? TrendingUp : f.trend === 'down' ? TrendingDown : Activity;
                return (
                  <motion.div
                    key={f.metric}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="p-3 rounded-md border bg-[var(--j-panel-soft)]/60"
                    style={{ borderColor: `${color}33` }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] truncate">{METRIC_LABELS[f.metric] ?? f.metric}</span>
                      <TrendIcon className="h-3 w-3 shrink-0" style={{ color }} />
                    </div>
                    <div className="flex items-baseline gap-1 mb-1">
                      <span className="jarvis-mono text-base font-bold tabular-nums">{Math.round(f.forecast)}</span>
                      <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">/{f.horizon}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">now {Math.round(f.current)}</span>
                      <span className="jarvis-mono text-[8px] px-1 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>{f.riskLevel}</span>
                    </div>
                    <div className="mt-1 h-0.5 rounded-full bg-[var(--j-bg)] overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${Math.round(f.confidence * 100)}%`, background: color }} />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Model Diversity + DB Sync Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Model Diversity */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Layers className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Per-Agent Model Diversity</h4>
            {modelData && (
              <span className="jarvis-mono text-[10px] ml-auto text-[var(--j-text-mute)]">
                {modelData.diversity.uniqueModels} models · {modelData.diversity.uniqueProviders} providers
              </span>
            )}
          </div>
          {modelsLoading && !modelData ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-8 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          ) : modelData ? (
            <div className="space-y-3">
              {/* Provider distribution bars */}
              <div>
                <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2">Provider Distribution</p>
                <div className="space-y-1.5">
                  {Object.entries(modelData.diversity.byProvider).map(([provider, count]) => {
                    const total = modelData.assignments.length || 1;
                    const pct = (count / total) * 100;
                    const colors: Record<string, string> = { zai: JARVIS.colors.cyan, openai: JARVIS.colors.green, anthropic: JARVIS.colors.amber, groq: JARVIS.colors.violet, deepseek: JARVIS.colors.red };
                    const color = colors[provider] ?? JARVIS.colors.cyan;
                    return (
                      <div key={provider} className="flex items-center gap-2">
                        <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] w-20 truncate">{provider}</span>
                        <div className="flex-1 h-4 rounded-full bg-[var(--j-bg)] overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${pct}%` }}
                            transition={{ duration: 0.5 }}
                            className="h-full rounded-full flex items-center justify-end pr-1.5"
                            style={{ background: `${color}33`, borderRight: `2px solid ${color}` }}
                          >
                            <span className="jarvis-mono text-[9px] font-bold tabular-nums" style={{ color }}>{count}</span>
                          </motion.div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              {/* Model distribution */}
              <div>
                <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2">Model Distribution</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(modelData.diversity.byModel).map(([model, count]) => (
                    <span key={model} className="jarvis-mono text-[9px] px-2 py-1 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)]">
                      {model} <span className="font-bold" style={{ color: JARVIS.colors.cyan }}>{count}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-[var(--j-text-mute)]">No model data.</p>
          )}
        </div>

        {/* DB Sync Detail */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Database className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Dual-DB Replication</h4>
            <button
              onClick={handleSyncNow}
              disabled={syncing}
              className="ml-auto flex items-center gap-1 h-7 px-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-green)] hover:border-[var(--j-green)] transition-colors text-[11px] disabled:opacity-50"
            >
              {syncing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
              <span className="jarvis-mono text-[10px] uppercase">Sync Now</span>
            </button>
          </div>
          {dbSync ? (
            <div className="space-y-3">
              {/* Primary DB */}
              <div className="flex items-center gap-3 p-2.5 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]">
                <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `${JARVIS.colors.green}1a`, color: JARVIS.colors.green }}>
                  <HardDrive className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">Primary</span>
                    <span className="jarvis-mono text-[10px] font-bold" style={{ color: JARVIS.colors.green }}>SQLite</span>
                    <CheckCircle2 className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
                  </div>
                  <p className="text-[10px] text-[var(--j-text-mute)] truncate jarvis-mono">{dbSync.primary.url}</p>
                </div>
              </div>

              {/* Arrow */}
              <div className="flex items-center justify-center gap-2 py-0.5">
                <GitBranch className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />
                <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">
                  {dbSync.sync.autoSyncEnabled ? 'auto-sync every 60s' : 'auto-sync disabled'}
                </span>
                <ArrowRight className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />
              </div>

              {/* Mirror DB */}
              <div className="flex items-center gap-3 p-2.5 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]">
                <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `${dbSync.mirror.reachable ? JARVIS.colors.green : JARVIS.colors.amber}1a`, color: dbSync.mirror.reachable ? JARVIS.colors.green : JARVIS.colors.amber }}>
                  {dbSync.mirror.configured ? <Cloud className="h-4 w-4" /> : <CloudOff className="h-4 w-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">Mirror</span>
                    <span className="jarvis-mono text-[10px] font-bold" style={{ color: dbSync.mirror.configured ? JARVIS.colors.cyan : JARVIS.colors.amber }}>PostgreSQL</span>
                    {dbSync.mirror.reachable ? (
                      <CheckCircle2 className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
                    ) : (
                      <XCircle className="h-3 w-3" style={{ color: JARVIS.colors.amber }} />
                    )}
                  </div>
                  <p className="text-[10px] text-[var(--j-text-mute)] truncate jarvis-mono">
                    {dbSync.mirror.configured
                      ? dbSync.mirror.reachable
                        ? 'connected · mirroring active'
                        : dbSync.mirror.error ?? 'unreachable'
                      : 'not configured (set POSTGRES_DATABASE_URL)'}
                  </p>
                </div>
              </div>

              {/* Last sync result */}
              {dbSync.sync.lastResult && (
                <div className="p-2.5 rounded-md bg-[var(--j-panel-soft)]/40 border border-[var(--j-border)]">
                  <div className="flex items-center justify-between mb-1">
                    <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">Last Sync</span>
                    <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">
                      {dbSync.sync.lastSyncAt ? timeAgo(new Date(dbSync.sync.lastSyncAt)) : 'never'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px]">
                    <span className="jarvis-mono" style={{ color: dbSync.sync.lastResult.ok ? JARVIS.colors.green : JARVIS.colors.red }}>
                      {dbSync.sync.lastResult.ok ? '✓ success' : '✗ failed'}
                    </span>
                    <span className="jarvis-mono text-[var(--j-text-mute)]">{dbSync.sync.lastResult.tablesSynced} tables</span>
                    <span className="jarvis-mono text-[var(--j-text-mute)]">{dbSync.sync.lastResult.rowsSynced} rows</span>
                    <span className="jarvis-mono text-[var(--j-text-mute)]">{dbSync.sync.lastResult.durationMs}ms</span>
                  </div>
                  {dbSync.sync.syncing && (
                    <div className="flex items-center gap-1.5 mt-1">
                      <Loader2 className="h-2.5 w-2.5 animate-spin" style={{ color: JARVIS.colors.cyan }} />
                      <span className="jarvis-mono text-[9px] text-[var(--j-cyan)]">syncing…</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-12 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          )}
        </div>
      </div>

      {/* Configured Providers strip */}
      {routerStats?.configuredProviders && (
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Server className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">LLM Provider Fleet · {routerStats.configuredProviderCount} configured</h4>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-2">
            {routerStats.configuredProviders.map((p) => (
              <div
                key={p.key}
                className="flex items-center gap-1.5 p-2 rounded-md border"
                style={{
                  borderColor: p.configured ? `${JARVIS.colors.green}33` : 'var(--j-border)',
                  background: p.configured ? 'rgba(52,211,153,0.06)' : 'var(--j-panel-soft)',
                }}
              >
                {p.configured ? (
                  <CheckCircle2 className="h-3 w-3 shrink-0" style={{ color: JARVIS.colors.green }} />
                ) : (
                  <XCircle className="h-3 w-3 shrink-0" style={{ color: JARVIS.colors.textMute }} />
                )}
                <span className="jarvis-mono text-[10px] uppercase tracking-wider" style={{ color: p.configured ? 'var(--j-text)' : 'var(--j-text-mute)' }}>{p.key}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────

function HealthScoreCard({ score, loading }: { score: number; loading: boolean }) {
  const color = score >= 85 ? JARVIS.colors.green : score >= 60 ? JARVIS.colors.amber : JARVIS.colors.red;
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <ShieldCheck className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Health Score</span>
      </div>
      {loading ? (
        <div className="h-8 w-16 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
      ) : (
        <div className="flex items-baseline gap-1.5">
          <span className="jarvis-mono text-3xl font-bold tabular-nums" style={{ color }}>{Math.round(score)}</span>
          <span className="jarvis-mono text-sm text-[var(--j-text-mute)]">/ 100</span>
        </div>
      )}
      <div className="mt-2 h-1 rounded-full bg-[var(--j-bg)] overflow-hidden">
        <motion.div initial={{ width: 0 }} animate={{ width: `${score}%` }} transition={{ duration: 0.6 }} className="h-full rounded-full" style={{ background: color, boxShadow: `0 0 8px ${color}66` }} />
      </div>
    </div>
  );
}

function RealtimeCard({ connected, status }: { connected: boolean; status?: RealtimeStatus }) {
  const running = status?.running ?? false;
  const color = running && connected ? JARVIS.colors.green : running ? JARVIS.colors.amber : JARVIS.colors.red;
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        {running && connected ? <Wifi className="h-4 w-4" style={{ color }} /> : <WifiOff className="h-4 w-4" style={{ color }} />}
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Realtime</span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="jarvis-mono text-3xl font-bold tabular-nums" style={{ color }}>
          {status?.connections ?? 0}
        </span>
        <span className="jarvis-mono text-sm text-[var(--j-text-mute)]">conn(s)</span>
      </div>
      <div className="flex items-center gap-2 mt-2">
        <span className="jarvis-mono text-[9px] flex items-center gap-1" style={{ color }}>
          <span className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ background: color }} />
          {running ? (connected ? 'LIVE' : 'service up') : 'offline'}
        </span>
        {status?.uptime != null && <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">up {Math.round(status.uptime)}s</span>}
      </div>
    </div>
  );
}

function DbSyncCard({ status, onSync, syncing }: { status?: DbSyncStatus; onSync: () => void; syncing: boolean }) {
  const configured = status?.mirror?.configured ?? false;
  const reachable = status?.mirror?.reachable ?? false;
  const color = reachable ? JARVIS.colors.green : configured ? JARVIS.colors.amber : JARVIS.colors.cyan;
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <Database className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">DB Mirror</span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="jarvis-mono text-lg font-bold" style={{ color }}>
          {reachable ? 'Synced' : configured ? 'Pending' : 'SQLite'}
        </span>
      </div>
      <div className="flex items-center gap-2 mt-2">
        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">SQLite → {configured ? 'Postgres' : '—'}</span>
        {status?.sync?.lastSyncAt && (
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{timeAgo(new Date(status.sync.lastSyncAt))}</span>
        )}
      </div>
    </div>
  );
}

function ProvidersCard({ stats, loading }: { stats?: SmartRouterStats; loading: boolean }) {
  const configured = stats?.configuredProviderCount ?? 0;
  const total = stats?.configuredProviders?.length ?? 16;
  const color = configured >= 3 ? JARVIS.colors.green : configured >= 1 ? JARVIS.colors.amber : JARVIS.colors.red;
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <Server className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">LLM Providers</span>
      </div>
      {loading ? (
        <div className="h-8 w-16 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
      ) : (
        <div className="flex items-baseline gap-1.5">
          <span className="jarvis-mono text-3xl font-bold tabular-nums" style={{ color }}>{configured}</span>
          <span className="jarvis-mono text-sm text-[var(--j-text-mute)]">/ {total}</span>
        </div>
      )}
      <div className="mt-2 h-1 rounded-full bg-[var(--j-bg)] overflow-hidden">
        <motion.div initial={{ width: 0 }} animate={{ width: `${(configured / total) * 100}%` }} transition={{ duration: 0.6 }} className="h-full rounded-full" style={{ background: color }} />
      </div>
    </div>
  );
}
