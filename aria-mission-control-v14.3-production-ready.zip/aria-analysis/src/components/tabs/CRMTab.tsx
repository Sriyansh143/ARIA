'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Plus, X, UserCheck, TrendingUp, Trophy, Handshake,
  Sparkles, Target, ArrowRight, Mail,
  LifeBuoy, AlertTriangle, CheckCircle2, Clock,
  Trash2, ArrowLeftRight, User as UserIcon,
} from 'lucide-react';
import { useApi, postJson, patchJson, deleteJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { SectionTitle, StatCard, Pill, EmptyState } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

/* ====================================================================
 *  Types — mirror the Prisma models (subset of fields used by the UI).
 * ==================================================================== */
interface Client {
  id: string;
  name: string;
  company?: string | null;
  email?: string | null;
  phone?: string | null;
  status: string;
  source?: string | null;
  value: number;
  notes?: string | null;
  assignee?: string | null;
  createdAt: string;
}
interface ClientStats {
  total: number;
  totalValue: number;
  pipelineValue: number;
  wonThisMonth: number;
  activeDeals: number;
  statusCounts: Record<string, number>;
  statusValue: Record<string, number>;
}
interface Lead {
  id: string;
  clientName: string;
  company?: string | null;
  email?: string | null;
  phone?: string | null;
  source: string;
  status: string;
  score: number;
  notes?: string | null;
  createdAt: string;
}
interface LeadStats {
  total: number;
  newCount: number;
  qualifiedCount: number;
  convertedCount: number;
  lostCount: number;
  conversionRate: number;
}
interface Ticket {
  id: string;
  clientName: string;
  subject: string;
  body: string;
  priority: string;
  status: string;
  channel: string;
  assignee?: string | null;
  resolution?: string | null;
  createdAt: string;
  updatedAt: string;
}
interface TicketStats {
  openCount: number;
  inProgressCount: number;
  urgentCount: number;
  resolvedToday: number;
  avgResolutionMins: number;
  total: number;
}

/* ====================================================================
 *  Color maps — JARVIS palette per CRM status.
 * ==================================================================== */
const CLIENT_STATUS_COLORS: Record<string, string> = {
  lead: JARVIS.colors.cyan,
  contacted: JARVIS.colors.violet,
  qualified: JARVIS.colors.green,
  proposal: JARVIS.colors.amber,
  negotiation: JARVIS.colors.amber,
  won: JARVIS.colors.green,
  lost: JARVIS.colors.red,
};
const LEAD_STATUS_COLORS: Record<string, string> = {
  new: JARVIS.colors.cyan,
  contacted: JARVIS.colors.violet,
  qualified: JARVIS.colors.green,
  converted: JARVIS.colors.green,
  lost: JARVIS.colors.red,
};
const TICKET_STATUS_COLORS: Record<string, string> = {
  open: JARVIS.colors.amber,
  in_progress: JARVIS.colors.cyan,
  resolved: JARVIS.colors.green,
  closed: JARVIS.colors.textMute,
};
const TICKET_PRIORITY_COLORS: Record<string, string> = {
  low: JARVIS.colors.cyan,
  medium: JARVIS.colors.violet,
  high: JARVIS.colors.amber,
  urgent: JARVIS.colors.red,
};

const CLIENT_STATUSES = ['lead', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost'];
const LEAD_STATUSES = ['new', 'contacted', 'qualified', 'converted', 'lost'];
const TICKET_STATUSES = ['open', 'in_progress', 'resolved', 'closed'];
const TICKET_PRIORITIES = ['low', 'medium', 'high', 'urgent'];
const TICKET_CHANNELS = ['chat', 'email', 'phone', 'web', 'social'];
const LEAD_SOURCES = ['web', 'referral', 'outreach', 'event', 'ads', 'social'];

const CURRENCY_FMT = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

/* ====================================================================
 *  Main tab — Tabs shell + 3 sub-views.
 * ==================================================================== */
export default function CRMTab() {
  const [view, setView] = useState('clients');
  return (
    <div className="space-y-4">
      <SectionTitle
        title="CRM — Customer Relations"
        icon={Users}
        accent={JARVIS.colors.cyan}
      />
      <Tabs value={view} onValueChange={setView} className="w-full">
        <TabsList className="bg-[var(--j-panel-soft)] border border-[var(--j-border)] h-auto p-1">
          <TabsTrigger
            value="clients"
            className="data-[state=active]:bg-[var(--j-cyan)]/15 data-[state=active]:text-[var(--j-cyan)] jarvis-mono text-[10px] uppercase tracking-widest"
          >
            <Users className="h-3.5 w-3.5 mr-1.5" /> Clients
          </TabsTrigger>
          <TabsTrigger
            value="leads"
            className="data-[state=active]:bg-[var(--j-violet)]/15 data-[state=active]:text-[var(--j-violet)] jarvis-mono text-[10px] uppercase tracking-widest"
          >
            <Sparkles className="h-3.5 w-3.5 mr-1.5" /> Leads
          </TabsTrigger>
          <TabsTrigger
            value="tickets"
            className="data-[state=active]:bg-[var(--j-amber)]/15 data-[state=active]:text-[var(--j-amber)] jarvis-mono text-[10px] uppercase tracking-widest"
          >
            <LifeBuoy className="h-3.5 w-3.5 mr-1.5" /> Tickets
          </TabsTrigger>
        </TabsList>
        <TabsContent value="clients" className="mt-4">
          <ClientsView />
        </TabsContent>
        <TabsContent value="leads" className="mt-4">
          <LeadsView />
        </TabsContent>
        <TabsContent value="tickets" className="mt-4">
          <TicketsView />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ====================================================================
 *  Clients sub-view
 * ==================================================================== */
function ClientsView() {
  const { data, loading, refresh } = useApi<{ clients: Client[]; stats: ClientStats }>('/api/clients', 15000);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');

  const clients = useMemo(
    () => (data?.clients ?? []).filter((c) => statusFilter === 'all' || c.status === statusFilter),
    [data, statusFilter],
  );

  const onDelete = async (c: Client) => {
    try {
      await deleteJson(`/api/clients/${c.id}`);
      toast({ title: 'Client deleted' });
      refresh();
    } catch (e) {
      toast({ title: 'Delete failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Clients" value={data?.stats.total ?? 0} sub="all records" icon={Users} accent={JARVIS.colors.cyan} delay={0} />
        <StatCard label="Pipeline Value" value={CURRENCY_FMT.format(data?.stats.pipelineValue ?? 0)} sub="active deals" icon={TrendingUp} accent={JARVIS.colors.amber} delay={0.05} />
        <StatCard label="Won This Month" value={data?.stats.wonThisMonth ?? 0} sub="closes this month" icon={Trophy} accent={JARVIS.colors.green} delay={0.1} />
        <StatCard label="Active Deals" value={data?.stats.activeDeals ?? 0} sub="in pipeline" icon={Handshake} accent={JARVIS.colors.violet} delay={0.15} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px] h-8 bg-[var(--j-panel-soft)] border-[var(--j-border)] jarvis-mono text-[10px] uppercase">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {CLIENT_STATUSES.map((s) => (
              <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="ml-auto">
          <Button size="sm" variant="outline" className="jarvis-btn-accent border-0" onClick={() => setOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1" /> New Client
          </Button>
        </div>
      </div>

      {loading && !data ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="jarvis-panel h-12 animate-pulse" />)}</div>
      ) : clients.length > 0 ? (
        <div className="jarvis-panel p-0 overflow-hidden">
          <div className="grid grid-cols-12 gap-2 px-4 py-2 border-b border-[var(--j-border)] jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] bg-[var(--j-panel-soft)]/40">
            <div className="col-span-3">Name</div>
            <div className="col-span-2">Company</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-2 text-right">Value</div>
            <div className="col-span-2">Assignee</div>
            <div className="col-span-1 text-right">Created</div>
          </div>
          <div className="max-h-[28rem] overflow-y-auto jarvis-scroll">
            {clients.map((c, i) => {
              const color = CLIENT_STATUS_COLORS[c.status] ?? JARVIS.colors.textDim;
              return (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.02 }}
                  className="group grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[var(--j-border-soft)] hover:bg-[var(--j-panel-soft)]/40 items-center"
                >
                  <div className="col-span-3 flex items-center gap-2 min-w-0">
                    <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
                    <span className="text-xs text-[var(--j-text)] truncate">{c.name}</span>
                  </div>
                  <div className="col-span-2 text-xs text-[var(--j-text-dim)] truncate">{c.company ?? '—'}</div>
                  <div className="col-span-2"><Pill color={color}>{c.status}</Pill></div>
                  <div className="col-span-2 text-right jarvis-mono text-xs" style={{ color: c.value > 0 ? JARVIS.colors.green : JARVIS.colors.textMute }}>
                    {c.value > 0 ? CURRENCY_FMT.format(c.value) : '—'}
                  </div>
                  <div className="col-span-2 text-xs text-[var(--j-text-dim)] truncate">
                    {c.assignee ? <span className="inline-flex items-center gap-1"><UserIcon className="h-2.5 w-2.5" />{c.assignee}</span> : '—'}
                  </div>
                  <div className="col-span-1 text-right jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                    {timeAgo(c.createdAt)}
                    <button
                      onClick={() => onDelete(c)}
                      className="ml-2 opacity-0 group-hover:opacity-100 text-[var(--j-red)] hover:bg-[var(--j-red)]/10 rounded p-0.5 transition-opacity"
                      title="Delete client"
                    >
                      <Trash2 className="h-3 w-3 inline" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <EmptyState icon={Users} message="No clients yet" hint="Create your first client to start tracking pipeline value." />
      )}

      <AnimatePresence>
        {open && <NewClientModal onClose={() => setOpen(false)} onDone={() => { setOpen(false); refresh(); }} />}
      </AnimatePresence>
    </div>
  );
}

function NewClientModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState('lead');
  const [source, setSource] = useState('web');
  const [value, setValue] = useState('');
  const [assignee, setAssignee] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!name.trim()) { toast({ title: 'Name required', variant: 'destructive' }); return; }
    setBusy(true);
    try {
      await postJson('/api/clients', {
        name, company, email, phone, status, source,
        value: value ? Number(value) : 0,
        assignee, notes,
      });
      toast({ title: 'Client created' });
      onDone();
    } catch (e) {
      toast({ title: 'Failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ scale: 0.96, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative w-full max-w-lg jarvis-panel p-5 max-h-[90vh] overflow-y-auto jarvis-scroll">
        <div className="flex items-center justify-between mb-4">
          <h3 className="jarvis-mono text-sm uppercase text-[var(--j-cyan)]">New Client</h3>
          <button onClick={onClose} className="text-[var(--j-text-mute)] hover:text-[var(--j-text)]"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Name *">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Cooper" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Company">
              <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Acme Inc." className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Email">
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@acme.com" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 555-0100" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Status">
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"><SelectValue /></SelectTrigger>
                <SelectContent>{CLIENT_STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Source">
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"><SelectValue /></SelectTrigger>
                <SelectContent>{LEAD_SOURCES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Value (USD)">
              <Input type="number" value={value} onChange={(e) => setValue(e.target.value)} placeholder="5000" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Assignee">
              <Input value={assignee} onChange={(e) => setAssignee(e.target.value)} placeholder="ORION" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
          </div>
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Context, requirements, deal stage notes…" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] min-h-[60px]" />
          </Field>
          <Button onClick={submit} disabled={busy} className="w-full jarvis-btn-accent border-0">{busy ? 'Creating…' : 'Create Client'}</Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ====================================================================
 *  Leads sub-view
 * ==================================================================== */
function LeadsView() {
  const { data, loading, refresh } = useApi<{ leads: Lead[]; stats: LeadStats }>('/api/leads', 15000);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');

  const leads = useMemo(
    () => (data?.leads ?? []).filter((l) => statusFilter === 'all' || l.status === statusFilter),
    [data, statusFilter],
  );

  const onConvert = async (lead: Lead) => {
    try {
      await postJson(`/api/leads/${lead.id}?action=convert`, {});
      toast({ title: 'Lead converted', description: `${lead.clientName} → Client record created.` });
      refresh();
    } catch (e) {
      toast({ title: 'Convert failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };
  const onDelete = async (lead: Lead) => {
    try {
      await deleteJson(`/api/leads/${lead.id}`);
      toast({ title: 'Lead deleted' });
      refresh();
    } catch (e) {
      toast({ title: 'Delete failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <StatCard label="New Leads" value={data?.stats.newCount ?? 0} sub="awaiting first contact" icon={Sparkles} accent={JARVIS.colors.cyan} delay={0} />
        <StatCard label="Qualified" value={data?.stats.qualifiedCount ?? 0} sub="sales-ready" icon={UserCheck} accent={JARVIS.colors.green} delay={0.05} />
        <StatCard label="Conversion Rate" value={`${data?.stats.conversionRate ?? 0}%`} sub={`${data?.stats.convertedCount ?? 0} converted`} icon={Target} accent={JARVIS.colors.amber} delay={0.1} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px] h-8 bg-[var(--j-panel-soft)] border-[var(--j-border)] jarvis-mono text-[10px] uppercase">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {LEAD_STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="ml-auto">
          <Button size="sm" variant="outline" className="jarvis-btn-accent border-0" onClick={() => setOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1" /> New Lead
          </Button>
        </div>
      </div>

      {loading && !data ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="jarvis-panel h-12 animate-pulse" />)}</div>
      ) : leads.length > 0 ? (
        <div className="jarvis-panel p-0 overflow-hidden">
          <div className="grid grid-cols-12 gap-2 px-4 py-2 border-b border-[var(--j-border)] jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] bg-[var(--j-panel-soft)]/40">
            <div className="col-span-3">Name</div>
            <div className="col-span-2">Company</div>
            <div className="col-span-1">Source</div>
            <div className="col-span-3">Score</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-1 text-right">Action</div>
          </div>
          <div className="max-h-[28rem] overflow-y-auto jarvis-scroll">
            {leads.map((l, i) => {
              const color = LEAD_STATUS_COLORS[l.status] ?? JARVIS.colors.textDim;
              const scoreColor = l.score >= 70 ? JARVIS.colors.green : l.score >= 50 ? JARVIS.colors.amber : l.score >= 35 ? JARVIS.colors.cyan : JARVIS.colors.red;
              return (
                <motion.div
                  key={l.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.02 }}
                  className="group grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[var(--j-border-soft)] hover:bg-[var(--j-panel-soft)]/40 items-center"
                >
                  <div className="col-span-3 min-w-0">
                    <div className="text-xs text-[var(--j-text)] truncate">{l.clientName}</div>
                    {l.email && <div className="text-[10px] text-[var(--j-text-mute)] truncate flex items-center gap-0.5"><Mail className="h-2 w-2" />{l.email}</div>}
                  </div>
                  <div className="col-span-2 text-xs text-[var(--j-text-dim)] truncate">{l.company ?? '—'}</div>
                  <div className="col-span-1"><Pill color={JARVIS.colors.violet}>{l.source}</Pill></div>
                  <div className="col-span-3 flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full bg-[var(--j-border)] overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ background: `linear-gradient(90deg, ${scoreColor}, ${scoreColor}aa)` }}
                        initial={{ width: 0 }}
                        animate={{ width: `${l.score}%` }}
                        transition={{ duration: 0.5, ease: 'easeOut' }}
                      />
                    </div>
                    <span className="jarvis-mono text-[10px] w-7 text-right" style={{ color: scoreColor }}>{l.score}</span>
                  </div>
                  <div className="col-span-2"><Pill color={color}>{l.status}</Pill></div>
                  <div className="col-span-1 flex items-center justify-end gap-0.5">
                    {l.status !== 'converted' && (
                      <button
                        onClick={() => onConvert(l)}
                        className="h-6 px-1.5 rounded text-[var(--j-green)] hover:bg-[var(--j-green)]/10 flex items-center gap-0.5 jarvis-mono text-[9px] uppercase"
                        title="Convert to client"
                      >
                        <ArrowLeftRight className="h-3 w-3" />
                      </button>
                    )}
                    <button
                      onClick={() => onDelete(l)}
                      className="h-6 w-6 rounded text-[var(--j-red)] hover:bg-[var(--j-red)]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete lead"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <EmptyState icon={Sparkles} message="No leads yet" hint="Capture new leads from web, referrals, outreach or events." />
      )}

      <AnimatePresence>
        {open && <NewLeadModal onClose={() => setOpen(false)} onDone={() => { setOpen(false); refresh(); }} />}
      </AnimatePresence>
    </div>
  );
}

function NewLeadModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { toast } = useToast();
  const [clientName, setClientName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [source, setSource] = useState('web');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!clientName.trim()) { toast({ title: 'Client name required', variant: 'destructive' }); return; }
    setBusy(true);
    try {
      await postJson('/api/leads', { clientName, company, email, phone, source, notes });
      toast({ title: 'Lead created' });
      onDone();
    } catch (e) {
      toast({ title: 'Failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ scale: 0.96, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative w-full max-w-md jarvis-panel p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="jarvis-mono text-sm uppercase text-[var(--j-violet)]">New Lead</h3>
          <button onClick={onClose} className="text-[var(--j-text-mute)] hover:text-[var(--j-text)]"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3">
          <Field label="Name *">
            <Input value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="Jane Cooper" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Company">
              <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Acme Inc." className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Source">
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"><SelectValue /></SelectTrigger>
                <SelectContent>{LEAD_SOURCES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Email">
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@acme.com" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 555-0100" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
          </div>
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What they're looking for, budget, timing…" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] min-h-[60px]" />
          </Field>
          <Button onClick={submit} disabled={busy} className="w-full jarvis-btn-accent border-0">{busy ? 'Creating…' : 'Create Lead'}</Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ====================================================================
 *  Tickets sub-view
 * ==================================================================== */
function TicketsView() {
  const { data, loading, refresh } = useApi<{ tickets: Ticket[]; stats: TicketStats }>('/api/tickets', 15000);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const tickets = useMemo(
    () => (data?.tickets ?? []).filter((t) =>
      (statusFilter === 'all' || t.status === statusFilter) &&
      (priorityFilter === 'all' || t.priority === priorityFilter),
    ),
    [data, statusFilter, priorityFilter],
  );

  const fmtDuration = (mins: number) => {
    if (mins <= 0) return '—';
    if (mins < 60) return `${mins}m`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m === 0 ? `${h}h` : `${h}h ${m}m`;
  };

  const onAdvance = async (t: Ticket) => {
    const next: Record<string, string> = { open: 'in_progress', in_progress: 'resolved', resolved: 'closed', closed: 'open' };
    try {
      await patchJson(`/api/tickets/${t.id}`, { status: next[t.status] ?? 'open' });
      toast({ title: `Status → ${next[t.status] ?? 'open'}` });
      refresh();
    } catch (e) {
      toast({ title: 'Update failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };
  const onDelete = async (t: Ticket) => {
    try {
      await deleteJson(`/api/tickets/${t.id}`);
      toast({ title: 'Ticket deleted' });
      refresh();
    } catch (e) {
      toast({ title: 'Delete failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Open Tickets" value={data?.stats.openCount ?? 0} sub={`${data?.stats.inProgressCount ?? 0} in progress`} icon={LifeBuoy} accent={JARVIS.colors.amber} delay={0} />
        <StatCard label="Urgent" value={data?.stats.urgentCount ?? 0} sub="priority = urgent" icon={AlertTriangle} accent={JARVIS.colors.red} delay={0.05} />
        <StatCard label="Resolved Today" value={data?.stats.resolvedToday ?? 0} sub="since midnight" icon={CheckCircle2} accent={JARVIS.colors.green} delay={0.1} />
        <StatCard label="Avg Resolution" value={fmtDuration(data?.stats.avgResolutionMins ?? 0)} sub="across resolved tickets" icon={Clock} accent={JARVIS.colors.cyan} delay={0.15} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] h-8 bg-[var(--j-panel-soft)] border-[var(--j-border)] jarvis-mono text-[10px] uppercase">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {TICKET_STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace('_', ' ')}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[150px] h-8 bg-[var(--j-panel-soft)] border-[var(--j-border)] jarvis-mono text-[10px] uppercase">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            {TICKET_PRIORITIES.map((p) => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="ml-auto">
          <Button size="sm" variant="outline" className="jarvis-btn-accent border-0" onClick={() => setOpen(true)}>
            <Plus className="h-3.5 w-3.5 mr-1" /> New Ticket
          </Button>
        </div>
      </div>

      {loading && !data ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="jarvis-panel h-12 animate-pulse" />)}</div>
      ) : tickets.length > 0 ? (
        <div className="jarvis-panel p-0 overflow-hidden">
          <div className="grid grid-cols-12 gap-2 px-4 py-2 border-b border-[var(--j-border)] jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] bg-[var(--j-panel-soft)]/40">
            <div className="col-span-4">Subject</div>
            <div className="col-span-2">Client</div>
            <div className="col-span-1">Priority</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-1">Channel</div>
            <div className="col-span-1">Assignee</div>
            <div className="col-span-1 text-right">Action</div>
          </div>
          <div className="max-h-[28rem] overflow-y-auto jarvis-scroll">
            {tickets.map((t, i) => {
              const sColor = TICKET_STATUS_COLORS[t.status] ?? JARVIS.colors.textDim;
              const pColor = TICKET_PRIORITY_COLORS[t.priority] ?? JARVIS.colors.textDim;
              return (
                <motion.div
                  key={t.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.02 }}
                  className="group grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[var(--j-border-soft)] hover:bg-[var(--j-panel-soft)]/40 items-center"
                >
                  <div className="col-span-4 min-w-0">
                    <div className="text-xs text-[var(--j-text)] truncate">{t.subject}</div>
                    <div className="text-[10px] text-[var(--j-text-mute)] truncate">{t.body.slice(0, 80)}{t.body.length > 80 ? '…' : ''}</div>
                  </div>
                  <div className="col-span-2 text-xs text-[var(--j-text-dim)] truncate">{t.clientName}</div>
                  <div className="col-span-1"><Pill color={pColor}>{t.priority}</Pill></div>
                  <div className="col-span-2"><Pill color={sColor}>{t.status.replace('_', ' ')}</Pill></div>
                  <div className="col-span-1 text-[10px] text-[var(--j-text-mute)] capitalize">{t.channel}</div>
                  <div className="col-span-1 text-[10px] text-[var(--j-text-dim)] truncate">{t.assignee ?? '—'}</div>
                  <div className="col-span-1 flex items-center justify-end gap-0.5">
                    <button
                      onClick={() => onAdvance(t)}
                      className="h-6 w-6 rounded text-[var(--j-cyan)] hover:bg-[var(--j-cyan)]/10 flex items-center justify-center"
                      title="Advance status"
                    >
                      <ArrowRight className="h-3 w-3" />
                    </button>
                    <button
                      onClick={() => onDelete(t)}
                      className="h-6 w-6 rounded text-[var(--j-red)] hover:bg-[var(--j-red)]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete ticket"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <EmptyState icon={LifeBuoy} message="No tickets" hint="Support tickets appear here once customers raise issues." />
      )}

      <AnimatePresence>
        {open && <NewTicketModal onClose={() => setOpen(false)} onDone={() => { setOpen(false); refresh(); }} />}
      </AnimatePresence>
    </div>
  );
}

function NewTicketModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { toast } = useToast();
  const [clientName, setClientName] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState('medium');
  const [channel, setChannel] = useState('chat');
  const [assignee, setAssignee] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!clientName.trim()) { toast({ title: 'Client name required', variant: 'destructive' }); return; }
    if (!subject.trim()) { toast({ title: 'Subject required', variant: 'destructive' }); return; }
    setBusy(true);
    try {
      await postJson('/api/tickets', { clientName, subject, body, priority, channel, assignee });
      toast({ title: 'Ticket created' });
      onDone();
    } catch (e) {
      toast({ title: 'Failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ scale: 0.96, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative w-full max-w-md jarvis-panel p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="jarvis-mono text-sm uppercase text-[var(--j-amber)]">New Support Ticket</h3>
          <button onClick={onClose} className="text-[var(--j-text-mute)] hover:text-[var(--j-text)]"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3">
          <Field label="Client Name *">
            <Input value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="Jane Cooper" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
          </Field>
          <Field label="Subject *">
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Cannot access dashboard" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
          </Field>
          <Field label="Description">
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Detailed description of the issue…" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] min-h-[80px]" />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Priority">
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"><SelectValue /></SelectTrigger>
                <SelectContent>{TICKET_PRIORITIES.map((p) => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Channel">
              <Select value={channel} onValueChange={setChannel}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"><SelectValue /></SelectTrigger>
                <SelectContent>{TICKET_CHANNELS.map((c) => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Assignee">
              <Input value={assignee} onChange={(e) => setAssignee(e.target.value)} placeholder="ATLAS" className="bg-[var(--j-panel-soft)] border-[var(--j-border)]" />
            </Field>
          </div>
          <Button onClick={submit} disabled={busy} className="w-full jarvis-btn-accent border-0">{busy ? 'Creating…' : 'Create Ticket'}</Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ---------- Field wrapper ---------- */
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] block mb-1">{label}</label>
      {children}
    </div>
  );
}
