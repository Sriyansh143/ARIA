'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { History, RotateCcw, AlertCircle, CheckCircle, XCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, StatCard } from '@/components/jarvis/shared';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface ActionRow {
  id: string; actor: string; action: string; category: string; target: string | null;
  beforeState: string | null; afterState: string | null; reversible: boolean; reversed: boolean;
  reversedAt: string | null; reversedBy: string | null; reverseResult: string | null; meta: string;
  createdAt: string;
}

export default function ActionLogTab() {
  const { toast } = useToast();
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterReversed, setFilterReversed] = useState('all');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const query = (() => {
    const p = new URLSearchParams();
    if (filterCategory !== 'all') p.set('category', filterCategory);
    if (filterReversed === 'true') p.set('reversed', 'true');
    if (filterReversed === 'false') p.set('reversed', 'false');
    return `/api/action-log?${p.toString()}`;
  })();

  const { data: stats } = useApi<{ total: number; reversed: number; reversible: number; byCategory: Record<string, number> }>('/api/action-log?stats=1', 30000);
  const { data, refresh } = useApi<{ rows: ActionRow[]; total: number }>(query, 15000);

  const s = stats ?? { total: 0, reversed: 0, reversible: 0, byCategory: {} };

  const toggleExpand = (id: string) => setExpanded(prev => { const n = new Set(prev); if (n.has(id)) { n.delete(id); } else { n.add(id); } return n; });

  const reverseAction = async (id: string, isDestructive: boolean) => {
    if (isDestructive && !confirm('This is a destructive action reversal. Are you sure?')) return;
    try {
      const res = await postJson(`/api/action-log/${id}/reverse`, { reversedBy: 'operator', force: isDestructive });
      const result = (res as { result: { ok: boolean; detail: string } }).result;
      if (result.ok) {
        toast({ title: 'Action reversed', description: result.detail });
      } else {
        toast({ title: 'Reversal blocked', description: result.detail, variant: 'destructive' });
      }
      refresh();
    } catch (e) {
      toast({ title: 'Reversal failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <SectionTitle title="Action Log" icon={History} accent={JARVIS.colors.green} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Actions" value={s.total} icon={History} accent={JARVIS.colors.cyan} />
        <StatCard label="Reversible" value={s.reversible} icon={RotateCcw} accent={JARVIS.colors.amber} />
        <StatCard label="Reversed" value={s.reversed} icon={CheckCircle} accent={JARVIS.colors.green} />
        <StatCard label="Irreversible" value={s.total - s.reversible} icon={XCircle} accent={JARVIS.colors.red} />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-[160px] bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Categories</SelectItem><SelectItem value="mutation">Mutation</SelectItem><SelectItem value="destructive">Destructive</SelectItem><SelectItem value="config">Config</SelectItem><SelectItem value="file">File</SelectItem><SelectItem value="exec">Exec</SelectItem></SelectContent>
        </Select>
        <Select value={filterReversed} onValueChange={setFilterReversed}>
          <SelectTrigger className="w-[160px] bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"><SelectValue placeholder="Reversed" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All</SelectItem><SelectItem value="true">Reversed</SelectItem><SelectItem value="false">Not Reversed</SelectItem></SelectContent>
        </Select>
        <div className="ml-auto text-[11px] text-[var(--j-text-mute)] jarvis-mono">{data?.total ?? 0} records</div>
      </div>
      <div className="space-y-2 max-h-[600px] overflow-y-auto">
        {data?.rows?.map((row, i) => {
          const isExpanded = expanded.has(row.id);
          const isDestructive = row.category === 'destructive' || row.action.endsWith('.delete');
          const canReverse = row.reversible && !row.reversed;
          return (
            <motion.div key={row.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.02, 0.4) }}>
              <Card className="p-3 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
                <button onClick={() => toggleExpand(row.id)} className="flex items-center gap-3 w-full text-left">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md" style={{ background: `${JARVIS.colors.green}1a`, border: `1px solid ${JARVIS.colors.green}33`, color: JARVIS.colors.green }}>
                    <span className="jarvis-mono text-[9px] font-bold">{row.category[0]?.toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="jarvis-mono text-xs text-[var(--j-text)]">{row.action}</span>
                      {row.target && <span className="text-[10px] text-[var(--j-text-mute)] truncate">{row.target}</span>}
                      {row.reversed && <span className="text-[9px] text-[var(--j-green)] jarvis-mono">REVERSED</span>}
                      {isDestructive && <span className="text-[9px] text-[var(--j-red)] jarvis-mono">DESTRUCTIVE</span>}
                      <span className="text-[10px] text-[var(--j-text-mute)] ml-auto jarvis-mono">{new Date(row.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-[10px] text-[var(--j-text-mute)] mt-0.5">by {row.actor}</div>
                  </div>
                  {isExpanded ? <ChevronDown className="h-4 w-4 text-[var(--j-text-mute)]" /> : <ChevronRight className="h-4 w-4 text-[var(--j-text-mute)]" />}
                </button>
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-[var(--j-border-soft)] space-y-2">
                    {row.beforeState && <div><div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">Before State</div><pre className="text-[10px] text-[var(--j-text-dim)] bg-[var(--j-panel-soft)] rounded p-2 overflow-x-auto max-h-32">{row.beforeState}</pre></div>}
                    {row.afterState && <div><div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">After State</div><pre className="text-[10px] text-[var(--j-text-dim)] bg-[var(--j-panel-soft)] rounded p-2 overflow-x-auto max-h-32">{row.afterState}</pre></div>}
                    {row.reverseResult && <div><div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">Reverse Result</div><pre className="text-[10px] text-[var(--j-green)] bg-[var(--j-panel-soft)] rounded p-2 overflow-x-auto max-h-32">{row.reverseResult}</pre></div>}
                    {canReverse && (
                      <Button size="sm" variant="outline" onClick={() => reverseAction(row.id, isDestructive)} className="border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-green)] h-7 text-[11px]">
                        <RotateCcw className="h-3 w-3 mr-1" /> {isDestructive ? 'Force Reverse' : 'Reverse'}
                      </Button>
                    )}
                    {!row.reversible && <div className="flex items-center gap-1.5 text-[11px] text-[var(--j-red)]"><AlertCircle className="h-3 w-3" /> Not reversible</div>}
                  </div>
                )}
              </Card>
            </motion.div>
          );
        })}
        {data?.rows?.length === 0 && (
          <Card className="p-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] text-center"><History className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)]" /><div className="text-sm text-[var(--j-text-dim)]">No actions logged yet.</div></Card>
        )}
      </div>
    </div>
  );
}
