'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Box,
  Sparkles,
  Wand2,
  Download,
  Copy,
  Check,
  Loader2,
  Eye,
  Code2,
  ExternalLink,
  Package,
  Layers,
  Rocket,
  Images,
  Gamepad2,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

/* ---------- Types ---------- */

type TemplateId =
  | 'product-showcase'
  | 'portfolio'
  | 'landing-page'
  | 'gallery'
  | 'game';

interface TemplateItem {
  id: TemplateId;
  name: string;
  description: string;
  sceneType: TemplateId;
}

interface ColorSchemeOption {
  id: 'dark' | 'light' | 'violet' | 'ocean';
  label: string;
}

interface CatalogApiResponse {
  templates: TemplateItem[];
  colorSchemes: ColorSchemeOption[];
  defaultTemplateId: TemplateId;
  defaultColorScheme: 'dark' | 'light' | 'violet' | 'ocean';
}

interface GenerateApiResponse {
  html: string;
  sizeKb: number;
  sizeBytes: number;
  template: TemplateItem;
  templateId: TemplateId;
  colorScheme: string;
}

const TEMPLATE_ICONS: Record<TemplateId, typeof Box> = {
  'product-showcase': Package,
  portfolio: Layers,
  'landing-page': Rocket,
  gallery: Images,
  game: Gamepad2,
};

/* ---------- Component ---------- */

export default function Website3DBuilderTab() {
  const { toast } = useToast();
  const { data, loading, error } = useApi<CatalogApiResponse>(
    '/api/website-3d',
    -1,
  );

  const templates = data?.templates ?? [];
  const colorSchemes = data?.colorSchemes ?? [];

  // Form state
  const [templateId, setTemplateId] = useState<TemplateId>('product-showcase');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [colorScheme, setColorScheme] = useState<
    'dark' | 'light' | 'violet' | 'ocean'
  >('dark');

  // Generation state
  const [generating, setGenerating] = useState(false);
  const [generatedHtml, setGeneratedHtml] = useState('');
  const [generatedInfo, setGeneratedInfo] = useState<{
    sizeKb: number;
    templateId: TemplateId;
    colorScheme: string;
  } | null>(null);

  // UI helpers
  const [copied, setCopied] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  /* Default form values once API responds */
  useEffect(() => {
    if (data) {
      setTemplateId(data.defaultTemplateId);
      setColorScheme(data.defaultColorScheme);
    }
  }, [data]);

  /* Write generated HTML into the iframe via srcdoc */
  useEffect(() => {
    if (iframeRef.current && generatedHtml) {
      iframeRef.current.srcdoc = generatedHtml;
    }
  }, [generatedHtml]);

  /* ---------- Actions ---------- */

  const handleGenerate = async () => {
    if (!title.trim()) {
      toast({ title: 'Title required', variant: 'destructive' });
      return;
    }
    setGenerating(true);
    setGeneratedHtml('');
    setGeneratedInfo(null);
    try {
      const res = (await postJson('/api/website-3d/generate', {
        templateId,
        title: title.trim(),
        description: description.trim(),
        colorScheme,
      })) as GenerateApiResponse;
      setGeneratedHtml(res.html);
      setGeneratedInfo({
        sizeKb: res.sizeKb,
        templateId: res.templateId,
        colorScheme: res.colorScheme,
      });
      toast({
        title: '3D website generated',
        description: `${res.template.name} · ${res.sizeKb} KB`,
      });
    } catch (e) {
      toast({
        title: 'Generation failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedHtml) return;
    const slug = (title || '3d-website')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    const blob = new Blob([generatedHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${slug}-${templateId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: 'Downloaded', description: a.download });
  };

  const handleCopy = async () => {
    if (!generatedHtml) return;
    try {
      await navigator.clipboard.writeText(generatedHtml);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      toast({ title: 'Copied', description: 'HTML copied to clipboard' });
    } catch {
      toast({
        title: 'Copy failed',
        description: 'Clipboard not available — try Download instead.',
        variant: 'destructive',
      });
    }
  };

  const handleOpenInNewTab = () => {
    if (!generatedHtml) return;
    const blob = new Blob([generatedHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'noopener,noreferrer');
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  };

  /* ---------- Render ---------- */

  const selectedTemplate = useMemo(
    () => templates.find((t) => t.id === templateId) ?? null,
    [templates, templateId],
  );

  return (
    <div className="space-y-4">
      <SectionTitle
        title="3D Website Builder"
        icon={Box}
        accent={JARVIS.colors.violet}
        action={
          <div className="flex items-center gap-2">
            <Pill color={JARVIS.colors.violet}>{templates.length} templates</Pill>
            <Pill color={JARVIS.colors.cyan}>{colorSchemes.length} color schemes</Pill>
          </div>
        }
      />

      {/* ---------- Error state ---------- */}
      {error && (
        <Card className="p-4 jarvis-panel border-[var(--j-red)]/40 bg-[var(--j-panel)]">
          <div className="text-xs text-[var(--j-red)]">
            Failed to load templates: {error}
          </div>
        </Card>
      )}

      {/* ---------- Template cards ---------- */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {loading && templates.length === 0
          ? Array.from({ length: 5 }).map((_, i) => (
              <Card
                key={i}
                className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-36 animate-pulse"
              />
            ))
          : templates.map((t, idx) => {
              const Icon = TEMPLATE_ICONS[t.id] ?? Box;
              const isSelected = t.id === templateId;
              return (
                <motion.button
                  key={t.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => setTemplateId(t.id)}
                  className={`text-left p-4 rounded-lg border transition-all jarvis-panel ${
                    isSelected
                      ? 'border-[var(--j-violet)] ring-1 ring-[var(--j-violet)]/40'
                      : 'border-[var(--j-border)] hover:border-[var(--j-violet)]/40'
                  }`}
                  style={{ background: 'var(--j-panel)' }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="flex h-7 w-7 items-center justify-center rounded-md"
                        style={{
                          background: `${JARVIS.colors.violet}1a`,
                          border: `1px solid ${JARVIS.colors.violet}33`,
                          color: JARVIS.colors.violet,
                        }}
                      >
                        <Icon className="h-3.5 w-3.5" />
                      </div>
                      <h3 className="font-display text-sm font-semibold text-[var(--j-text)]">
                        {t.name}
                      </h3>
                    </div>
                    {isSelected && (
                      <Check
                        className="h-4 w-4"
                        style={{ color: JARVIS.colors.violet }}
                      />
                    )}
                  </div>
                  <p className="text-[11px] leading-relaxed text-[var(--j-text-dim)] line-clamp-3">
                    {t.description}
                  </p>
                  <div className="mt-3 pt-2 border-t border-[var(--j-border-soft)] flex items-center justify-between text-[10px] text-[var(--j-text-mute)] jarvis-mono uppercase">
                    <span>Three.js · WebGL</span>
                    <span style={{ color: JARVIS.colors.violet }}>{t.id}</span>
                  </div>
                </motion.button>
              );
            })}
      </div>

      {/* ---------- Form + Preview ---------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form */}
        <Card className="lg:col-span-4 p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-fit">
          <div className="flex items-center gap-2 mb-4">
            <Wand2 className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Generate 3D Website
            </h3>
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Title
              </Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Nova — Next-Gen Analytics"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Description
              </Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A short paragraph shown in the hero overlay of the 3D scene."
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs min-h-[80px] resize-y"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Color Scheme
              </Label>
              <Select
                value={colorScheme}
                onValueChange={(v) =>
                  setColorScheme(v as typeof colorScheme)
                }
              >
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9 w-full">
                  <SelectValue placeholder="Select color scheme" />
                </SelectTrigger>
                <SelectContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)]">
                  {colorSchemes.map((s) => (
                    <SelectItem
                      key={s.id}
                      value={s.id}
                      className="text-xs focus:bg-[var(--j-panel-soft)] focus:text-[var(--j-violet)]"
                    >
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Template
              </Label>
              <Select
                value={templateId}
                onValueChange={(v) => setTemplateId(v as TemplateId)}
              >
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9 w-full">
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)]">
                  {templates.map((t) => {
                    const Icon = TEMPLATE_ICONS[t.id] ?? Box;
                    return (
                      <SelectItem
                        key={t.id}
                        value={t.id}
                        className="text-xs focus:bg-[var(--j-panel-soft)] focus:text-[var(--j-violet)]"
                      >
                        <span className="inline-flex items-center gap-2">
                          <Icon className="h-3 w-3" /> {t.name}
                        </span>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              {selectedTemplate && (
                <p className="text-[10px] text-[var(--j-text-mute)] leading-relaxed pt-1">
                  {selectedTemplate.description}
                </p>
              )}
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generating || !title.trim()}
              className="jarvis-btn-accent border-0 w-full"
              style={{
                background: `${JARVIS.colors.violet}1a`,
                color: JARVIS.colors.violet,
                border: `1px solid ${JARVIS.colors.violet}40`,
              }}
            >
              {generating ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Generating…
                </>
              ) : (
                <>
                  <Sparkles className="h-3.5 w-3.5 mr-1.5" /> Generate 3D Website
                </>
              )}
            </Button>
          </div>

          {/* Quick fills */}
          <div className="mt-4 pt-3 border-t border-[var(--j-border-soft)]">
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-2">
              Quick fills
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                { name: 'Nova Analytics', tmpl: 'product-showcase' as TemplateId, cs: 'dark' as const },
                { name: 'Studio Folio', tmpl: 'portfolio' as TemplateId, cs: 'violet' as const },
                { name: 'Lumen SaaS', tmpl: 'landing-page' as TemplateId, cs: 'ocean' as const },
                { name: 'Pixel Gallery', tmpl: 'gallery' as TemplateId, cs: 'light' as const },
              ].map((q) => (
                <button
                  key={q.name}
                  onClick={() => {
                    setTitle(q.name);
                    setTemplateId(q.tmpl);
                    setColorScheme(q.cs);
                  }}
                  className="jarvis-mono text-[9px] uppercase px-2 py-1 rounded border transition-all hover:scale-105"
                  style={{
                    borderColor: `${JARVIS.colors.violet}40`,
                    color: JARVIS.colors.violet,
                    background: `${JARVIS.colors.violet}10`,
                  }}
                >
                  {q.name}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Preview */}
        <Card className="lg:col-span-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] overflow-hidden">
          {/* Toolbar */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-[var(--j-border-soft)] bg-[var(--j-panel-soft)]">
            <div className="flex items-center gap-2">
              <Eye className="h-3.5 w-3.5" style={{ color: JARVIS.colors.violet }} />
              <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-dim)]">
                Live 3D Preview
              </span>
              {generatedInfo && (
                <Pill color={JARVIS.colors.green}>{generatedInfo.sizeKb} KB</Pill>
              )}
              {generatedInfo && (
                <Pill color={JARVIS.colors.violet}>{generatedInfo.templateId}</Pill>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={handleOpenInNewTab}
                disabled={!generatedHtml}
                className="border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)] h-7 text-[10px]"
              >
                <ExternalLink className="h-3 w-3 mr-1" /> New Tab
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopy}
                disabled={!generatedHtml}
                className="border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)] h-7 text-[10px]"
              >
                {copied ? (
                  <>
                    <Check className="h-3 w-3 mr-1" style={{ color: JARVIS.colors.green }} /> Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3 mr-1" /> Copy
                  </>
                )}
              </Button>
              <Button
                size="sm"
                onClick={handleDownload}
                disabled={!generatedHtml}
                className="border-0 h-7 text-[10px]"
                style={{
                  background: `${JARVIS.colors.violet}1a`,
                  color: JARVIS.colors.violet,
                  border: `1px solid ${JARVIS.colors.violet}40`,
                }}
              >
                <Download className="h-3 w-3 mr-1" /> Download
              </Button>
            </div>
          </div>

          {/* Iframe / Empty state */}
          <div
            className="relative bg-[var(--j-bg)]"
            style={{ minHeight: '620px' }}
          >
            {generatedHtml ? (
              <iframe
                ref={iframeRef}
                title="3D Website Preview"
                className="w-full border-0"
                style={{ height: '620px', background: '#08090A' }}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              />
            ) : (
              <div
                className="flex flex-col items-center justify-center text-center px-6"
                style={{ minHeight: '620px' }}
              >
                <div
                  className="flex h-16 w-16 items-center justify-center rounded-2xl mb-4 jarvis-enter"
                  style={{
                    background: `${JARVIS.colors.violet}1a`,
                    border: `1px solid ${JARVIS.colors.violet}33`,
                    color: JARVIS.colors.violet,
                  }}
                >
                  <Code2 className="h-8 w-8 opacity-70" />
                </div>
                <div className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text-dim)] mb-1">
                  {generating ? 'Generating 3D scene…' : 'No preview yet'}
                </div>
                <div className="text-[11px] text-[var(--j-text-mute)] max-w-sm">
                  {generating
                    ? 'Building your Three.js 3D website. This usually takes under a second.'
                    : 'Fill out the form and click "Generate 3D Website" to render an interactive Three.js scene here.'}
                </div>
              </div>
            )}
          </div>

          {/* Info bar */}
          {generatedInfo && (
            <div className="flex flex-wrap items-center gap-3 px-4 py-2 border-t border-[var(--j-border-soft)] bg-[var(--j-panel-soft)] text-[10px] jarvis-mono uppercase text-[var(--j-text-mute)]">
              <span>
                <span className="text-[var(--j-text-dim)]">Template:</span>{' '}
                {generatedInfo.templateId}
              </span>
              <span>
                <span className="text-[var(--j-text-dim)]">Scheme:</span>{' '}
                {generatedInfo.colorScheme}
              </span>
              <span className="ml-auto">
                {generatedInfo.sizeKb} KB · Three.js r128 + OrbitControls
              </span>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
