'use client';

import { useState, useMemo, useCallback, Fragment } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck, Plus, RefreshCw, ChevronDown, ChevronRight, Check, X,
  AlertTriangle, Clock, Zap, Loader2, Filter,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, StatCard, Pill, EmptyState } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from '@/components/ui/dialog';

interface Approval {
  id: string;
  category: string;
  title: string;
  description: string;
  requestedBy: string;
  payload: string;
  status: string; // pending | approved | rejected | expired
  decidedBy: string | null;
  decisionNote: string | null;
  escalationLevel: number;
  lastEscalatedAt: string | null;
  nextEscalateAt: string | null;
  resolvedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Stats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  expired: number;
  escalating: number;
}

interface Derived {
  approvedToday: number;
  rejectedToday: number;
  avgResponseMs: number;
  avgResponseMin: number;
}

interface ApiResponse {
  approvals: Approval[];
  stats: Stats;
  derived: Derived;
}

const STATUS_FILTERS = ['all', 'pending', 'approved', 'rejected', 'expired'] as const;
type StatusFilter = (typeof STATUS_FILTERS)[number];

const CATEGORIES = [
  'all', 'deployment', 'financial', 'security', 'access', 'configuration',
  'communication', 'data', 'other',
] as const;

const CATEGORY_COLORS: Record<string, string> = {
  deployment: JARVIS.colors.cyan,
  financial: JARVIS.colors.green,
  security: JARVIS.colors.red,
  access: JARVIS.colors.amber,
  configuration: JARVIS.colors.violet,
  communication: JARVIS.colors.cyan,
  data: JARVIS.colors.violet,
  other: JARVIS.colors.textMute,
};

const STATUS_COLORS: Record<string, string> = {
  pending: JARVIS.colors.amber,
  approved: JARVIS.colors.green,
  rejected: JARVIS.colors.red,
  expired: JARVIS.colors.textMute,
};

const ESCALATION_DOTS: Record<number, string> = {
  0: JARVIS.colors.textMute,
  1: JARVIS.colors.amber,
  2: '#FB923C', // orange-400
  3: JARVIS.colors.red,
};

function timeAgo(date: string | Date): string {
  const d = typeof date === 'object' ? date : new Date(date);
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 0) return 'just now';
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

function EscalationDots({ level }: { level: number }) {
  const color = ESCALATION_DOTS[level] ?? JARVIS.colors.textMute;
  return (
    <div className="flex items-center gap-1" title={`Escalation level ${level}/3`}>
      {[0, 1, 2, 3].map((i) => (
        <span
          key={i}
          className="inline-block rounded-full"
          style={{
            width: i === level ? 8 : 6,
            height: i === level ? 8 : 6,
            background: i <= level ? color : 'var(--j-border)',
            boxShadow: i <= level ? `0 0 6px ${color}` : 'none',
          }}
        />
      ))}
      <span className="jarvis-mono text-[10px] ml-1 tabular-nums" style={{ color }}>
        L{level}
      </span>
    </div>
  );
}

function fmtDuration(ms: number): string {
  if (!ms) return '—';
  if (ms < 60_000) return `${Math.round(ms / 1000)}s`;
  if (ms < 3_600_000) return `${Math.round(ms / 60_000)}m`;
  return `${(ms / 3_600_000).toFixed(1)}h`;
}

export default function ApprovalsTab() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [createOpen, setCreateOpen] = useState(false);
  const [escalating, setEscalating] = useState(false);

  // Form state for new approval
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: 'other',
    requestedBy: 'operator',
    timeoutMinutes: 30,
  });
  const [creating, setCreating] = useState(false);

  const url = `/api/approvals?status=${statusFilter === 'all' ? '' : statusFilter}`;
  const { data, loading, refresh } = useApi<ApiResponse>(url, 10000);
  const { toast } = useToast();

  const approvals = data?.approvals ?? [];
  const stats = data?.stats;
  const derived = data?.derived;

  // Apply category filter client-side (server already filtered by status)
  const filtered = useMemo(() => {
    if (categoryFilter === 'all') return approvals;
    return approvals.filter((a) => a.category === categoryFilter);
  }, [approvals, categoryFilter]);

  const toggleExpand = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const resolve = async (apv: Approval, decision: 'approved' | 'rejected') => {
    try {
      await postJson(`/api/approvals/${apv.id}`, {
        decision,
        decidedBy: 'operator',
      });
      toast({
        title: `Approval ${decision}`,
        description: apv.title.slice(0, 80),
      });
      refresh();
    } catch (e) {
      toast({
        title: `Failed to ${decision}`,
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    }
  };

  const runEscalation = async () => {
    setEscalating(true);
    try {
      const res = await postJson<{ escalated: number; details: unknown[] }>(
        '/api/approvals/escalate',
        {},
      );
      toast({
        title: 'Escalation sweep complete',
        description: `${res.escalated} approval(s) escalated`,
      });
      refresh();
    } catch (e) {
      toast({
        title: 'Escalation failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setEscalating(false);
    }
  };

  const submitCreate = async () => {
    if (!form.title.trim() || !form.description.trim()) {
      toast({ title: 'Title and description are required', variant: 'destructive' });
      return;
    }
    setCreating(true);
    try {
      await postJson('/api/approvals', form);
      toast({ title: 'Approval created', description: form.title.slice(0, 80) });
      setForm({
        title: '',
        description: '',
        category: 'other',
        requestedBy: 'operator',
        timeoutMinutes: 30,
      });
      setCreateOpen(false);
      refresh();
    } catch (e) {
      toast({
        title: 'Create failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Approvals — Escalation Queue"
        icon={ShieldCheck}
        accent={JARVIS.colors.red}
        action={
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={runEscalation}
              disabled={escalating}
              className="border-[var(--j-amber)]/40 text-[var(--j-amber)] bg-[var(--j-amber)]/10 hover:bg-[var(--j-amber)]/20"
            >
              {escalating ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Zap className="h-3.5 w-3.5 mr-1" />}
              Test Escalation
            </Button>
            <Button size="sm" variant="outline" onClick={refresh} className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]">
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
            <Button size="sm" className="jarvis-btn-accent border-0" onClick={() => setCreateOpen(true)}>
              <Plus className="h-3.5 w-3.5 mr-1" /> New Approval
            </Button>
          </div>
        }
      />

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard
          label="Pending"
          value={stats?.pending ?? 0}
          icon={Clock}
          accent={JARVIS.colors.amber}
          sub="awaiting decision"
        />
        <StatCard
          label="Escalating"
          value={stats?.escalating ?? 0}
          icon={AlertTriangle}
          accent={JARVIS.colors.red}
          sub="level ≥ 1"
        />
        <StatCard
          label="Approved Today"
          value={derived?.approvedToday ?? 0}
          icon={Check}
          accent={JARVIS.colors.green}
          sub={`total ${stats?.approved ?? 0}`}
        />
        <StatCard
          label="Rejected Today"
          value={derived?.rejectedToday ?? 0}
          icon={X}
          accent={JARVIS.colors.red}
          sub={`total ${stats?.rejected ?? 0}`}
        />
        <StatCard
          label="Avg Response"
          value={fmtDuration(derived?.avgResponseMs ?? 0)}
          icon={Clock}
          accent={JARVIS.colors.cyan}
          sub="7d rolling"
        />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <Filter className="h-3.5 w-3.5 text-[var(--j-text-mute)]" />
        {STATUS_FILTERS.map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`jarvis-mono text-[10px] uppercase px-3 py-1.5 rounded-md border transition-colors ${
              statusFilter === s
                ? 'jarvis-btn-accent border-0'
                : 'border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)]'
            }`}
          >
            {s}
          </button>
        ))}
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="jarvis-mono text-xs px-3 py-1.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text)] outline-none focus:border-[var(--j-cyan)] sm:ml-auto"
        >
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c === 'all' ? 'all categories' : c}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="jarvis-panel p-0 overflow-hidden">
        {loading && !data ? (
          <div className="flex items-center justify-center py-12 text-[var(--j-text-mute)] jarvis-mono text-[10px] uppercase">
            <Loader2 className="h-4 w-4 animate-spin mr-2" /> loading approvals…
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={ShieldCheck}
            message="No approvals match filter"
            hint="Adjust filters or create a new approval request."
            accent={JARVIS.colors.red}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-[var(--j-panel-soft)]/60 border-b border-[var(--j-border)]">
                <tr className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                  <th className="text-left px-3 py-2 w-8"></th>
                  <th className="text-left px-3 py-2">Title</th>
                  <th className="text-left px-3 py-2">Category</th>
                  <th className="text-left px-3 py-2">Requested By</th>
                  <th className="text-left px-3 py-2">Created</th>
                  <th className="text-left px-3 py-2">Escalation</th>
                  <th className="text-left px-3 py-2">Status</th>
                  <th className="text-right px-3 py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence initial={false}>
                  {filtered.map((apv) => {
                    const isOpen = expanded.has(apv.id);
                    const catColor = CATEGORY_COLORS[apv.category] ?? JARVIS.colors.textMute;
                    const stColor = STATUS_COLORS[apv.status] ?? JARVIS.colors.textMute;
                    const isPending = apv.status === 'pending';
                    return (
                      <Fragment key={apv.id}>
                        <motion.tr
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          onClick={() => toggleExpand(apv.id)}
                          className="border-b border-[var(--j-border-soft)] cursor-pointer hover:bg-[var(--j-panel-soft)]/40 transition-colors"
                        >
                          <td className="px-3 py-2 text-[var(--j-text-mute)]">
                            {isOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                          </td>
                          <td className="px-3 py-2 text-[var(--j-text)] font-medium max-w-xs truncate">
                            {apv.title}
                          </td>
                          <td className="px-3 py-2">
                            <Pill color={catColor}>{apv.category}</Pill>
                          </td>
                          <td className="px-3 py-2 jarvis-mono text-xs text-[var(--j-cyan)]">
                            {apv.requestedBy}
                          </td>
                          <td className="px-3 py-2 jarvis-mono text-xs text-[var(--j-text-mute)]">
                            {timeAgo(apv.createdAt)}
                          </td>
                          <td className="px-3 py-2">
                            <EscalationDots level={apv.escalationLevel} />
                          </td>
                          <td className="px-3 py-2">
                            <span
                              className="jarvis-mono text-[10px] uppercase px-2 py-0.5 rounded"
                              style={{ color: stColor, background: `${stColor}1a`, border: `1px solid ${stColor}33` }}
                            >
                              {apv.status}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-right">
                            {isPending ? (
                              <div className="flex gap-1 justify-end" onClick={(e) => e.stopPropagation()}>
                                <button
                                  onClick={() => resolve(apv, 'approved')}
                                  className="flex h-6 w-6 items-center justify-center rounded border border-[var(--j-green)]/40 text-[var(--j-green)] bg-[var(--j-green)]/10 hover:bg-[var(--j-green)]/20 transition-colors"
                                  title="Approve"
                                  aria-label={`Approve ${apv.title}`}
                                >
                                  <Check className="h-3 w-3" />
                                </button>
                                <button
                                  onClick={() => resolve(apv, 'rejected')}
                                  className="flex h-6 w-6 items-center justify-center rounded border border-[var(--j-red)]/40 text-[var(--j-red)] bg-[var(--j-red)]/10 hover:bg-[var(--j-red)]/20 transition-colors"
                                  title="Reject"
                                  aria-label={`Reject ${apv.title}`}
                                >
                                  <X className="h-3 w-3" />
                                </button>
                              </div>
                            ) : (
                              <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                                {apv.decidedBy ? `by ${apv.decidedBy}` : '—'}
                              </span>
                            )}
                          </td>
                        </motion.tr>
                        {isOpen && (
                          <motion.tr
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="bg-[var(--j-bg-soft)]/60"
                          >
                            <td colSpan={8} className="px-6 py-4 border-b border-[var(--j-border-soft)]">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="md:col-span-2">
                                  <div className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-1">Description</div>
                                  <div className="text-xs text-[var(--j-text-dim)] whitespace-pre-wrap">{apv.description}</div>
                                </div>
                                <div className="space-y-2">
                                  <div>
                                    <div className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Payload</div>
                                    <pre className="text-[10px] font-mono text-[var(--j-text-dim)] bg-[var(--j-panel)] border border-[var(--j-border)] rounded p-2 max-h-32 overflow-auto jarvis-scroll">
                                      {(() => {
                                        try { return JSON.stringify(JSON.parse(apv.payload), null, 2); }
                                        catch { return apv.payload || '{}'; }
                                      })()}
                                    </pre>
                                  </div>
                                  <div className="jarvis-mono text-[10px] text-[var(--j-text-mute)] space-y-0.5">
                                    {apv.nextEscalateAt && <div>Next escalate: {timeAgo(apv.nextEscalateAt)}</div>}
                                    {apv.lastEscalatedAt && <div>Last escalated: {timeAgo(apv.lastEscalatedAt)}</div>}
                                    {apv.resolvedAt && <div>Resolved: {timeAgo(apv.resolvedAt)}</div>}
                                    {apv.expiresAt && <div>Expires: {timeAgo(apv.expiresAt)}</div>}
                                    {apv.decisionNote && <div className="text-[var(--j-text-dim)]">Note: {apv.decisionNote}</div>}
                                  </div>
                                </div>
                              </div>
                            </td>
                          </motion.tr>
                        )}
                      </Fragment>
                    );
                  })}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* New approval dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)] max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-[var(--j-red)]" />
              <span className="jarvis-mono text-sm uppercase">New Approval Request</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Title</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                placeholder="Deploy v9.0.1 to production"
                className="bg-[var(--j-bg-soft)] border-[var(--j-border)] text-[var(--j-text)] mt-1"
                maxLength={300}
              />
            </div>
            <div>
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Describe what this approval is for and any context the operator needs…"
                className="bg-[var(--j-bg-soft)] border-[var(--j-border)] text-[var(--j-text)] mt-1 min-h-[100px]"
                maxLength={5000}
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Category</Label>
                <select
                  value={form.category}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="w-full mt-1 jarvis-mono text-xs px-3 py-2 rounded-md border border-[var(--j-border)] bg-[var(--j-bg-soft)] text-[var(--j-text)] outline-none focus:border-[var(--j-cyan)]"
                >
                  {CATEGORIES.filter((c) => c !== 'all').map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Requested By</Label>
                <Input
                  value={form.requestedBy}
                  onChange={(e) => setForm((f) => ({ ...f, requestedBy: e.target.value }))}
                  className="bg-[var(--j-bg-soft)] border-[var(--j-border)] text-[var(--j-text)] mt-1"
                  maxLength={64}
                />
              </div>
              <div>
                <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Timeout (min)</Label>
                <Input
                  type="number"
                  min={1}
                  max={1440}
                  value={form.timeoutMinutes}
                  onChange={(e) => setForm((f) => ({ ...f, timeoutMinutes: Number(e.target.value) || 30 }))}
                  className="bg-[var(--j-bg-soft)] border-[var(--j-border)] text-[var(--j-text)] mt-1"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]">
                Cancel
              </Button>
            </DialogClose>
            <Button onClick={submitCreate} disabled={creating} className="jarvis-btn-accent border-0">
              {creating ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Plus className="h-3.5 w-3.5 mr-1" />}
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
