'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Compass, RefreshCw, Loader2, TrendingUp, AlertTriangle, Lightbulb, Shield,
  Target, CheckCircle2, ArrowRight, Sparkles, XCircle, Rocket, Wand2, Bot,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { JARVIS, timeAgo } from '@/lib/config';

interface Strategy {
  generatedAt: string;
  horizon: string;
  headline: string;
  swot: { strengths: string[]; weaknesses: string[]; opportunities: string[]; threats: string[] };
  strategicInitiative: { title: string; rationale: string; steps: string[]; kpiTargets: string[] };
  focusAreas: string[];
}

interface ImprovementProposal {
  id: string;
  title: string;
  description: string;
  intent: string;
  status: 'pending' | 'approved' | 'rejected' | 'deployed';
  prompt: string;
  createdAt: string;
  plan?: { steps: { order: number; title: string; description: string }[] };
}

const SWOT_CARDS = [
  { key: 'strengths', label: 'Strengths', icon: Shield, color: JARVIS.colors.green, bg: 'rgba(52,211,153,0.08)' },
  { key: 'weaknesses', label: 'Weaknesses', icon: AlertTriangle, color: JARVIS.colors.red, bg: 'rgba(248,113,113,0.08)' },
  { key: 'opportunities', label: 'Opportunities', icon: Lightbulb, color: JARVIS.colors.cyan, bg: 'rgba(125,211,252,0.08)' },
  { key: 'threats', label: 'Threats', icon: TrendingUp, color: JARVIS.colors.amber, bg: 'rgba(251,191,36,0.08)' },
] as const;

export default function StrategyTab() {
  const { data, loading, refresh } = useApi<{ strategy: Strategy }>('/api/strategy', 0);
  const s = data?.strategy;

  if (loading && !s) {
    return (
      <div className="space-y-5">
        <div className="jarvis-panel p-6 h-28 jarvis-skeleton" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="jarvis-panel p-4 h-40 jarvis-skeleton" />)}
        </div>
        <div className="jarvis-panel p-5 h-64 jarvis-skeleton" />
      </div>
    );
  }
  if (!s) return <div className="jarvis-panel p-8 text-center text-[var(--j-text-mute)] text-sm">Failed to generate strategy.</div>;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Compass className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Strategic Planning · {s.horizon}</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">AI Strategy Advisor</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Long-horizon strategic planning — SWOT, prioritized initiative, KPI targets, and agent self-improvement proposals (how ARIA's agents improvise the app). · {timeAgo(new Date(s.generatedAt))}
          </p>
        </div>
        <button
          onClick={refresh}
          className="flex items-center gap-2 h-9 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-violet)] hover:border-[var(--j-violet)] transition-colors text-sm"
        >
          <RefreshCw className={loading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
          <span className="jarvis-mono text-[10px] uppercase">Regenerate</span>
        </button>
      </div>

      {/* Headline hero */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="jarvis-panel jarvis-scan p-5 md:p-6 relative overflow-hidden"
      >
        <div className="absolute inset-0 opacity-25 pointer-events-none" style={{ background: `radial-gradient(700px circle at 100% 0%, ${JARVIS.colors.violet}22, transparent 50%)` }} />
        <div className="relative z-10 flex items-center gap-3">
          <div className="h-10 w-10 rounded-md flex items-center justify-center shrink-0" style={{ background: 'rgba(196,181,253,0.15)', color: JARVIS.colors.violet }}>
            <Sparkles className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="jarvis-mono text-[9px] uppercase tracking-widest" style={{ color: JARVIS.colors.violet }}>Strategic Headline</span>
            <p className="text-base md:text-lg font-semibold leading-snug mt-0.5">{s.headline}</p>
          </div>
        </div>
      </motion.div>

      {/* SWOT grid */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Target className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">SWOT Analysis</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {SWOT_CARDS.map((card, i) => {
            const items = s.swot[card.key];
            return (
              <motion.div
                key={card.key}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="jarvis-panel p-4 relative overflow-hidden"
                style={{ background: card.bg }}
              >
                <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${card.color}55, transparent)` }} />
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-7 w-7 rounded-md flex items-center justify-center" style={{ background: `${card.color}1a`, color: card.color }}>
                    <card.icon className="h-3.5 w-3.5" />
                  </div>
                  <span className="jarvis-mono text-[10px] uppercase tracking-wider font-bold" style={{ color: card.color }}>{card.label}</span>
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-auto">{items.length}</span>
                </div>
                <div className="space-y-2">
                  {items.length === 0 ? (
                    <p className="text-[10px] text-[var(--j-text-mute)] italic">None identified.</p>
                  ) : (
                    items.map((item, j) => (
                      <div key={j} className="flex items-start gap-1.5">
                        <span className="h-1 w-1 rounded-full mt-1.5 shrink-0" style={{ background: card.color }} />
                        <span className="text-[11px] text-[var(--j-text-dim)] leading-snug">{item}</span>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Strategic Initiative */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="jarvis-panel p-5 relative overflow-hidden"
      >
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ background: `radial-gradient(600px circle at 0% 100%, ${JARVIS.colors.green}18, transparent 50%)` }} />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: 'rgba(52,211,153,0.12)', color: JARVIS.colors.green }}>
              <Target className="h-4 w-4" />
            </div>
            <div>
              <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Strategic Initiative</h4>
            </div>
          </div>
          <h5 className="text-base font-semibold text-[var(--j-text)] mb-2">{s.strategicInitiative.title}</h5>
          <p className="text-sm text-[var(--j-text-dim)] leading-relaxed mb-4">{s.strategicInitiative.rationale}</p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Steps */}
            <div>
              <div className="flex items-center gap-1.5 mb-2">
                <ArrowRight className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />
                <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">Action Steps</span>
              </div>
              <div className="space-y-1.5">
                {s.strategicInitiative.steps.map((step, i) => (
                  <div key={i} className="flex items-start gap-2 p-2 rounded-md bg-[var(--j-panel-soft)]/60">
                    <span className="jarvis-mono text-[10px] font-bold mt-0.5 shrink-0" style={{ color: JARVIS.colors.cyan }}>{String(i + 1).padStart(2, '0')}</span>
                    <span className="text-xs text-[var(--j-text-dim)] leading-snug">{step}</span>
                  </div>
                ))}
              </div>
            </div>
            {/* KPI targets */}
            <div>
              <div className="flex items-center gap-1.5 mb-2">
                <CheckCircle2 className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
                <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">KPI Targets</span>
              </div>
              <div className="space-y-1.5">
                {s.strategicInitiative.kpiTargets.map((kpi, i) => (
                  <div key={i} className="flex items-start gap-2 p-2 rounded-md bg-[var(--j-panel-soft)]/60 border-l-2" style={{ borderColor: JARVIS.colors.green }}>
                    <CheckCircle2 className="h-3 w-3 mt-0.5 shrink-0" style={{ color: JARVIS.colors.green }} />
                    <span className="text-xs text-[var(--j-text-dim)] leading-snug">{kpi}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Focus areas */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="h-3.5 w-3.5" style={{ color: JARVIS.colors.violet }} />
          <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Focus Areas</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {s.focusAreas.map((area, i) => (
            <span
              key={i}
              className="jarvis-mono text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md border"
              style={{ color: JARVIS.colors.violet, background: 'rgba(196,181,253,0.10)', borderColor: `${JARVIS.colors.violet}40` }}
            >
              {area}
            </span>
          ))}
        </div>
      </div>

      {/* Agent Self-Improvement proposals — where agents propose how to
          improvise the app itself. Promote → Task (stays on this tab). */}
      <SelfImprovementSection />
    </div>
  );
}

/* ---------- Agent Self-Improvement proposals ---------- */
function SelfImprovementSection() {
  const { toast } = useToast();
  const { data, loading, refresh } = useApi<{ proposals: ImprovementProposal[]; counts: { total: number; pending: number; approved: number; rejected: number } }>(
    '/api/strategy/proposals?status=all',
    30000,
  );
  const [busyId, setBusyId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');

  const proposals = (data?.proposals ?? []).filter((p) => (filter === 'all' ? true : p.status === filter));
  const counts = data?.counts ?? { total: 0, pending: 0, approved: 0, rejected: 0 };

  const act = async (proposal: ImprovementProposal, action: 'approve' | 'reject' | 'promote') => {
    setBusyId(proposal.id);
    try {
      const res = await postJson<{ task?: { id: string }; error?: string }>(`/api/strategy/proposals`, { proposalId: proposal.id, action });
      if (res.error) {
        toast({ title: 'Action failed', description: res.error, variant: 'destructive' });
      } else if (action === 'promote') {
        toast({ title: 'Promoted to task', description: `${proposal.title.slice(0, 70)}… — stays on this tab.` });
      } else {
        toast({ title: `Proposal ${action}d`, description: proposal.title.slice(0, 70) });
      }
      refresh();
    } catch (e) {
      toast({ title: 'Action failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  const FILTERS: { key: typeof filter; label: string; count: number; color: string }[] = [
    { key: 'pending', label: 'Pending', count: counts.pending, color: JARVIS.colors.amber },
    { key: 'approved', label: 'Approved', count: counts.approved, color: JARVIS.colors.green },
    { key: 'rejected', label: 'Rejected', count: counts.rejected, color: JARVIS.colors.red },
    { key: 'all', label: 'All', count: counts.total, color: JARVIS.colors.cyan },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="jarvis-panel p-5 relative overflow-hidden"
    >
      <div className="absolute inset-0 opacity-15 pointer-events-none" style={{ background: `radial-gradient(600px circle at 100% 0%, ${JARVIS.colors.cyan}22, transparent 50%)` }} />
      <div className="relative z-10">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-1">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: 'rgba(125,211,252,0.12)', color: JARVIS.colors.cyan }}>
              <Bot className="h-4 w-4" />
            </div>
            <div>
              <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Agent Self-Improvement</h4>
              <p className="text-[11px] text-[var(--j-text-mute)] mt-0.5">How ARIA's agents propose to improvise the app — auto-generated when an agent's success rate drops below 70%.</p>
            </div>
          </div>
          <button
            onClick={refresh}
            className="flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-xs"
          >
            <RefreshCw className={loading ? 'h-3 w-3 animate-spin' : 'h-3 w-3'} />
            <span className="jarvis-mono text-[9px] uppercase">Refresh</span>
          </button>
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-1.5 mb-3 flex-wrap">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`jarvis-mono text-[9px] uppercase tracking-wider px-2 py-1 rounded-md border transition-colors ${
                filter === f.key ? 'text-[var(--j-text)]' : 'text-[var(--j-text-mute)]'
              }`}
              style={filter === f.key ? { borderColor: f.color, background: `${f.color}1a`, color: f.color } : { borderColor: 'var(--j-border)' }}
            >
              {f.label} · {f.count}
            </button>
          ))}
        </div>

        {loading && proposals.length === 0 ? (
          <div className="space-y-2">
            {Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-20 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
          </div>
        ) : proposals.length === 0 ? (
          <div className="text-center py-8 text-xs text-[var(--j-text-mute)]">
            <Wand2 className="h-6 w-6 mx-auto mb-2 opacity-40" />
            No {filter !== 'all' ? filter : ''} self-improvement proposals. Agents are performing well — the self-improve engine will propose improvements here when an agent's success rate needs improvisation.
          </div>
        ) : (
          <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
            {proposals.map((p, i) => {
              const intentColor =
                p.intent === 'feature' ? JARVIS.colors.green :
                p.intent === 'skill' ? JARVIS.colors.cyan :
                p.intent === 'plugin' ? JARVIS.colors.violet : JARVIS.colors.amber;
              const isBusy = busyId === p.id;
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] p-3"
                >
                  <div className="flex items-start gap-3">
                    <div className="shrink-0 mt-0.5 h-7 w-7 rounded-md flex items-center justify-center" style={{ background: `${intentColor}1a`, color: intentColor }}>
                      <Sparkles className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color: intentColor, background: `${intentColor}1a` }}>{p.intent}</span>
                        <span className="jarvis-mono text-[9px] uppercase" style={{ color: p.status === 'pending' ? JARVIS.colors.amber : p.status === 'approved' ? JARVIS.colors.green : p.status === 'rejected' ? JARVIS.colors.red : JARVIS.colors.cyan }}>{p.status}</span>
                        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">· {timeAgo(new Date(p.createdAt))}</span>
                      </div>
                      <h6 className="text-sm font-medium text-[var(--j-text)] leading-snug">{p.title}</h6>
                      <p className="text-xs text-[var(--j-text-dim)] mt-1 leading-relaxed line-clamp-3">{p.description}</p>
                      {p.plan?.steps && p.plan.steps.length > 0 && (
                        <div className="mt-2 flex items-center gap-1 text-[10px] text-[var(--j-text-mute)]">
                          <Target className="h-2.5 w-2.5" />
                          <span className="jarvis-mono uppercase">{p.plan.steps.length}-step plan</span>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-1.5 shrink-0">
                      {p.status === 'pending' && (
                        <>
                          <button
                            onClick={() => act(p, 'promote')}
                            disabled={isBusy}
                            title="Create a task from this proposal (stays on this tab)"
                            className="flex items-center gap-1 h-7 px-2 rounded-md text-[10px] jarvis-mono uppercase border transition-colors disabled:opacity-50"
                            style={{ borderColor: `${JARVIS.colors.cyan}55`, color: JARVIS.colors.cyan, background: `${JARVIS.colors.cyan}12` }}
                          >
                            {isBusy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Rocket className="h-3 w-3" />}
                            Promote
                          </button>
                          <div className="flex gap-1">
                            <button onClick={() => act(p, 'approve')} disabled={isBusy} className="flex items-center justify-center h-7 w-7 rounded-md border border-[var(--j-border)] text-[var(--j-green)] hover:border-[var(--j-green)] transition-colors disabled:opacity-50" title="Approve">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            </button>
                            <button onClick={() => act(p, 'reject')} disabled={isBusy} className="flex items-center justify-center h-7 w-7 rounded-md border border-[var(--j-border)] text-[var(--j-red)] hover:border-[var(--j-red)] transition-colors disabled:opacity-50" title="Reject">
                              <XCircle className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                      {p.status !== 'pending' && (
                        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] uppercase text-center">{p.status}</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
}
