'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, Mail, Send, CheckCircle2, Clock, X, Plus, MessageSquareHeart } from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { SectionTitle, StatCard, Pill, EmptyState } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

/* ====================================================================
 *  Types — mirror the Prisma CsatSurvey model + CsatStats shape.
 * ==================================================================== */
interface CsatSurvey {
  id: string;
  invoiceId?: string | null;
  clientId?: string | null;
  clientName: string;
  clientEmail: string;
  rating: number;
  npsScore?: number | null;
  feedback?: string | null;
  sentiment?: string | null;
  status: string;
  sentAt?: string | null;
  completedAt?: string | null;
  expiresAt?: string | null;
  createdAt: string;
}
interface CsatStats {
  totalSent: number;
  totalCompleted: number;
  avgRating: number;
  avgNps: number;
  responseRate: number;
  sentimentBreakdown: { positive: number; neutral: number; negative: number };
}
interface CsatApiResponse {
  stats: CsatStats;
  recentSurveys: CsatSurvey[];
  pending: CsatSurvey[];
}

/* ====================================================================
 *  Color maps
 * ==================================================================== */
const SENTIMENT_COLORS: Record<string, string> = {
  positive: JARVIS.colors.green,
  neutral: JARVIS.colors.textMute,
  negative: JARVIS.colors.red,
};
const STATUS_COLORS: Record<string, string> = {
  pending: JARVIS.colors.amber,
  sent: JARVIS.colors.cyan,
  completed: JARVIS.colors.green,
  expired: JARVIS.colors.textMute,
};

/* ====================================================================
 *  Main tab
 * ==================================================================== */
export default function CsatTab() {
  const { data, loading, error, refresh } = useApi<CsatApiResponse>('/api/csat', 30000);
  const [scheduleOpen, setScheduleOpen] = useState(false);

  const stats = data?.stats;
  const recent = data?.recentSurveys ?? [];
  const pending = data?.pending ?? [];

  return (
    <div className="space-y-4">
      <SectionTitle
        title="CSAT — Customer Satisfaction"
        icon={Star}
        accent={JARVIS.colors.amber}
        action={
          <Button
            size="sm"
            variant="outline"
            className="jarvis-btn-accent border-0"
            onClick={() => setScheduleOpen(true)}
          >
            <Plus className="h-3.5 w-3.5 mr-1" /> Schedule survey
          </Button>
        }
      />

      {/* ── 5 stat cards ───────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatCard
          label="Surveys Sent"
          value={stats?.totalSent ?? 0}
          sub={`${pending.length} pending send`}
          icon={Send}
          accent={JARVIS.colors.cyan}
          delay={0}
        />
        <StatCard
          label="Response Rate"
          value={`${stats?.responseRate ?? 0}%`}
          sub={`${stats?.totalCompleted ?? 0} completed`}
          icon={CheckCircle2}
          accent={JARVIS.colors.green}
          delay={0.05}
        />
        <StatCard
          label="Avg Rating"
          value={stats ? `${stats.avgRating.toFixed(1)}★` : '—'}
          sub="1-5 stars"
          icon={Star}
          accent={JARVIS.colors.amber}
          delay={0.1}
        />
        <StatCard
          label="Avg NPS"
          value={stats ? stats.avgNps.toFixed(1) : '—'}
          sub="0-10 score"
          icon={MessageSquareHeart}
          accent={JARVIS.colors.violet}
          delay={0.15}
        />
        <StatCard
          label="Sentiment Split"
          value={
            stats ? (
              <span className="text-base font-semibold flex items-center gap-1.5">
                <span style={{ color: JARVIS.colors.green }}>+{stats.sentimentBreakdown.positive}</span>
                <span style={{ color: JARVIS.colors.textMute }}>~{stats.sentimentBreakdown.neutral}</span>
                <span style={{ color: JARVIS.colors.red }}>−{stats.sentimentBreakdown.negative}</span>
              </span>
            ) : '—'
          }
          sub="positive · neutral · negative"
          accent={JARVIS.colors.violet}
          delay={0.2}
        />
      </div>

      {/* ── Recent surveys table ──────────────────────────────────── */}
      <div className="flex items-center gap-2 mt-2">
        <h3 className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-dim)]">
          Recent Surveys
        </h3>
        {error && (
          <span className="jarvis-mono text-[9px] text-[var(--j-red)]">
            live feed error: {error}
          </span>
        )}
      </div>

      {loading && !data ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="jarvis-panel h-12 animate-pulse" />
          ))}
        </div>
      ) : recent.length > 0 ? (
        <div className="jarvis-panel p-0 overflow-hidden">
          <div className="grid grid-cols-12 gap-2 px-4 py-2 border-b border-[var(--j-border)] jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] bg-[var(--j-panel-soft)]/40">
            <div className="col-span-3">Client</div>
            <div className="col-span-1 text-center">Rating</div>
            <div className="col-span-1 text-center">NPS</div>
            <div className="col-span-2">Sentiment</div>
            <div className="col-span-3">Feedback</div>
            <div className="col-span-1">Status</div>
            <div className="col-span-1 text-right">Date</div>
          </div>
          <div className="max-h-[30rem] overflow-y-auto jarvis-scroll">
            {recent.map((s, i) => {
              const statusColor = STATUS_COLORS[s.status] ?? JARVIS.colors.textDim;
              const sentiment = s.sentiment ?? 'neutral';
              const sentimentColor = SENTIMENT_COLORS[sentiment] ?? JARVIS.colors.textMute;
              return (
                <motion.div
                  key={s.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.015 }}
                  className="grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[var(--j-border-soft)] hover:bg-[var(--j-panel-soft)]/40 items-center"
                >
                  <div className="col-span-3 min-w-0">
                    <div className="text-xs text-[var(--j-text)] truncate">{s.clientName}</div>
                    <div className="text-[10px] text-[var(--j-text-mute)] truncate flex items-center gap-1">
                      <Mail className="h-2.5 w-2.5 shrink-0" />
                      <span className="truncate">{s.clientEmail}</span>
                    </div>
                  </div>
                  <div className="col-span-1 text-center">
                    {s.status === 'completed' ? (
                      <span className="jarvis-mono text-xs" style={{ color: JARVIS.colors.amber }}>
                        {s.rating}★
                      </span>
                    ) : (
                      <span className="text-[var(--j-text-mute)] text-xs">—</span>
                    )}
                  </div>
                  <div className="col-span-1 text-center jarvis-mono text-xs" style={{ color: JARVIS.colors.violet }}>
                    {s.npsScore != null ? s.npsScore : '—'}
                  </div>
                  <div className="col-span-2">
                    {s.status === 'completed' ? (
                      <Pill color={sentimentColor}>{sentiment}</Pill>
                    ) : (
                      <span className="text-[var(--j-text-mute)] text-xs">—</span>
                    )}
                  </div>
                  <div className="col-span-3 text-xs text-[var(--j-text-dim)] truncate" title={s.feedback ?? ''}>
                    {s.feedback ? s.feedback.slice(0, 80) + (s.feedback.length > 80 ? '…' : '') : '—'}
                  </div>
                  <div className="col-span-1">
                    <Pill color={statusColor}>{s.status}</Pill>
                  </div>
                  <div className="col-span-1 text-right jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                    {timeAgo(s.createdAt)}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <EmptyState
          icon={Star}
          message="No CSAT surveys yet"
          hint="Schedule a survey for a client — it'll be sent 7 days after creation, then expire after 14 days."
          accent={JARVIS.colors.amber}
          action={{ label: 'Schedule survey', onClick: () => setScheduleOpen(true) }}
        />
      )}

      {/* ── Pending queue summary ─────────────────────────────────── */}
      {pending.length > 0 && (
        <div className="jarvis-panel p-3 flex items-center gap-3">
          <Clock className="h-4 w-4 text-[var(--j-amber)] shrink-0" />
          <div className="text-xs text-[var(--j-text-dim)]">
            <span className="jarvis-mono text-[var(--j-amber)]">{pending.length}</span> survey
            {pending.length === 1 ? '' : 's'} due to be sent (created &gt; 7 days ago, status=pending).
            The <code className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">csat-survey</code> cron
            will pick them up on its next tick.
          </div>
        </div>
      )}

      {/* ── Schedule dialog ───────────────────────────────────────── */}
      <ScheduleSurveyDialog
        open={scheduleOpen}
        onClose={() => setScheduleOpen(false)}
        onDone={() => {
          setScheduleOpen(false);
          refresh();
        }}
      />
    </div>
  );
}

/* ====================================================================
 *  Schedule survey dialog — email + name + optional invoice
 * ==================================================================== */
function ScheduleSurveyDialog({
  open,
  onClose,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  onDone: () => void;
}) {
  const { toast } = useToast();
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [invoiceId, setInvoiceId] = useState('');
  const [busy, setBusy] = useState(false);

  const reset = () => {
    setClientName('');
    setClientEmail('');
    setInvoiceId('');
  };

  const submit = async () => {
    if (!clientName.trim()) {
      toast({ title: 'Client name required', variant: 'destructive' });
      return;
    }
    if (!clientEmail.trim() || !clientEmail.includes('@')) {
      toast({ title: 'Valid client email required', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      await postJson('/api/csat/schedule', {
        invoiceId: invoiceId.trim() || undefined,
        clientEmail: clientEmail.trim(),
        clientName: clientName.trim(),
      });
      toast({
        title: 'CSAT survey scheduled',
        description: `Will be sent to ${clientEmail.trim()} in 7 days.`,
      });
      reset();
      onDone();
    } catch (e) {
      toast({
        title: 'Schedule failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) reset();
        onClose();
      }}
    >
      <DialogContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)] sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="jarvis-mono text-sm uppercase text-[var(--j-amber)] flex items-center gap-2">
            <Star className="h-4 w-4" /> Schedule CSAT Survey
          </DialogTitle>
          <DialogDescription className="text-[var(--j-text-dim)] text-xs">
            Creates a pending survey. It will be auto-sent 7 days from now and expire after 14 days.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="csat-name" className="jarvis-mono text-[10px] uppercase text-[var(--j-text-dim)]">
              Client name *
            </Label>
            <Input
              id="csat-name"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              placeholder="Jane Cooper"
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="csat-email" className="jarvis-mono text-[10px] uppercase text-[var(--j-text-dim)]">
              Client email *
            </Label>
            <Input
              id="csat-email"
              type="email"
              value={clientEmail}
              onChange={(e) => setClientEmail(e.target.value)}
              placeholder="jane@acme.com"
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="csat-invoice" className="jarvis-mono text-[10px] uppercase text-[var(--j-text-dim)]">
              Invoice ID (optional)
            </Label>
            <Input
              id="csat-invoice"
              value={invoiceId}
              onChange={(e) => setInvoiceId(e.target.value)}
              placeholder="INV-2025-0001"
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              reset();
              onClose();
            }}
            className="text-[var(--j-text-dim)] hover:text-[var(--j-text)]"
          >
            <X className="h-3.5 w-3.5 mr-1" /> Cancel
          </Button>
          <Button
            size="sm"
            onClick={submit}
            disabled={busy}
            className="jarvis-btn-accent border-0"
          >
            {busy ? (
              'Scheduling…'
            ) : (
              <>
                <Send className="h-3.5 w-3.5 mr-1" /> Schedule
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
