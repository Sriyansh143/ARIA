'use client';

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, Award, TrendingUp, Clock, CheckCircle2, XCircle, Loader2,
  RefreshCw, Bot, Sparkles, Target, Zap, Flame, Lock, Unlock, ArrowUp, ArrowDown,
  Minus, BarChart3, Calendar, Brain,
} from 'lucide-react';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface RecentTrainingEntry {
  agentCodename: string;
  skillKey: string;
  proficiency: number;
  preProficiency: number;
  bestProficiency: number;
  trainingCount: number;
  lastTrainedAt: string;
  cooldownUntil: string | null;
  lastRunSuccess: boolean | null;
  learnedFrom: string | null;
  improvement: number;
  onCooldown: boolean;
}

interface AgentProfile {
  agentCodename: string;
  skillCount: number;
  avgProficiency: number;
  bestProficiency: number;
  lastTrainedAt: string | null;
  onCooldownCount: number;
  totalTrainingRuns: number;
  masteredCount: number;
}

interface CooldownEntry {
  agentCodename: string;
  skillKey: string;
  proficiency: number;
  cooldownUntil: string;
  lastTrainedAt: string;
  trainingCount: number;
}

interface ReadyEntry {
  agentCodename: string;
  skillKey: string;
  proficiency: number;
  lastTrainedAt: string | null;
  trainingCount: number;
}

interface DashboardData {
  summary: {
    total: number;
    agentsWithTraining: number;
    avgProficiency: number;
    mastered: number;
    onCooldown: number;
    readyToRetrain: number;
    totalTrainingRuns: number;
  };
  agents: AgentProfile[];
  recentTraining: RecentTrainingEntry[];
  cooldowns: CooldownEntry[];
  readyToRetrain: ReadyEntry[];
}

function proficiencyColor(p: number): string {
  if (p >= 80) return JARVIS.colors.green;
  if (p >= 60) return JARVIS.colors.cyan;
  if (p >= 40) return JARVIS.colors.amber;
  return JARVIS.colors.red;
}

function ImprovementIcon({ delta }: { delta: number }) {
  if (delta > 0) return <ArrowUp className="h-3 w-3" style={{ color: JARVIS.colors.green }} />;
  if (delta < 0) return <ArrowDown className="h-3 w-3" style={{ color: JARVIS.colors.red }} />;
  return <Minus className="h-3 w-3 text-[var(--j-text-mute)]" />;
}

export default function TrainingDashboardTab() {
  const { data, loading, refresh } = useApi<DashboardData>('/api/training-dashboard', 30000);
  const d = data;

  const agents = d?.agents;
  const chartData = useMemo(() => {
    if (!agents) return [];
    return agents.slice(0, 12).map((a) => ({
      name: a.agentCodename.slice(0, 8),
      avg: a.avgProficiency,
      best: a.bestProficiency,
      fill: proficiencyColor(a.avgProficiency),
    }));
  }, [agents]);

  if (loading && !d) {
    return (
      <div className="space-y-4">
        <div className="jarvis-panel p-6 h-24 jarvis-skeleton" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="jarvis-panel p-4 h-28 jarvis-skeleton" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="jarvis-panel p-4 h-64 jarvis-skeleton" />
          <div className="jarvis-panel p-4 h-64 jarvis-skeleton" />
        </div>
      </div>
    );
  }

  if (!d) {
    return <div className="jarvis-panel p-8 text-center text-[var(--j-text-mute)] text-sm">Failed to load training dashboard.</div>;
  }

  const s = d.summary;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Agent Training Lifecycle</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Training Dashboard</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Proficiency, cooldowns, and improvement over time — agents are trained once, then retrained only when performance needs improvisation.
          </p>
        </div>
        <button
          onClick={refresh}
          className="flex items-center gap-2 h-9 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-sm"
        >
          <RefreshCw className={loading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
          <span className="jarvis-mono text-[10px] uppercase">Refresh</span>
        </button>
      </div>

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <StatCard icon={Brain} label="Skills Tracked" value={s.total} accent={JARVIS.colors.cyan} />
        <StatCard icon={Bot} label="Agents" value={s.agentsWithTraining} accent={JARVIS.colors.violet} />
        <StatCard icon={Target} label="Avg Proficiency" value={`${s.avgProficiency}%`} accent={proficiencyColor(s.avgProficiency)} />
        <StatCard icon={Award} label="Mastered" value={s.mastered} accent={JARVIS.colors.green} sub="≥80%" />
        <StatCard icon={Lock} label="On Cooldown" value={s.onCooldown} accent={JARVIS.colors.amber} sub="no retrain" />
        <StatCard icon={Unlock} label="Ready to Retrain" value={s.readyToRetrain} accent={JARVIS.colors.cyan} sub="cooldown expired" />
        <StatCard icon={Zap} label="Total Runs" value={s.totalTrainingRuns} accent={JARVIS.colors.green} />
      </div>

      {/* Proficiency chart + Agent leaderboard */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Chart */}
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Proficiency by Agent</h3>
          </div>
          {chartData.length === 0 ? (
            <EmptyState icon={BarChart3} text="No training data yet. Run an autonomy loop or teach an agent to populate this chart." />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--j-border-soft)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: 'var(--j-text-mute)', fontSize: 10 }} axisLine={{ stroke: 'var(--j-border)' }} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fill: 'var(--j-text-mute)', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  cursor={{ fill: 'rgba(125,211,252,0.06)' }}
                  contentStyle={{ background: 'var(--j-panel)', border: '1px solid var(--j-border)', borderRadius: 8, fontSize: 12, color: 'var(--j-text)' }}
                />
                <Bar dataKey="avg" radius={[4, 4, 0, 0]} name="Avg Proficiency">
                  {chartData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
                <Bar dataKey="best" radius={[4, 4, 0, 0]} fill="rgba(167,139,250,0.3)" name="Best Proficiency" />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>

        {/* Agent leaderboard */}
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-2 mb-3">
            <Bot className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Agent Leaderboard</h3>
          </div>
          {d.agents.length === 0 ? (
            <EmptyState icon={Bot} text="No agents have been trained yet." />
          ) : (
            <div className="space-y-1.5 max-h-[260px] overflow-y-auto pr-1">
              {d.agents.slice(0, 12).map((a, i) => {
                const color = proficiencyColor(a.avgProficiency);
                return (
                  <motion.div
                    key={a.agentCodename}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-center gap-3 p-2 rounded-md bg-[var(--j-panel-soft)] hover:bg-[var(--j-panel-soft)]/60 transition-colors group"
                  >
                    <span className="jarvis-mono text-[10px] font-bold w-5 text-center" style={{ color: i < 3 ? JARVIS.colors.amber : 'var(--j-text-mute)' }}>
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="jarvis-mono text-xs font-bold truncate" style={{ color }}>{a.agentCodename}</span>
                        {a.onCooldownCount > 0 && <Lock className="h-2.5 w-2.5 shrink-0" style={{ color: JARVIS.colors.amber }} />}
                        {a.masteredCount > 0 && <Award className="h-2.5 w-2.5 shrink-0" style={{ color: JARVIS.colors.green }} />}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <div className="flex-1 h-1.5 rounded-full bg-[var(--j-panel)] overflow-hidden">
                          <div className="h-full rounded-full transition-all" style={{ width: `${a.avgProficiency}%`, background: color }} />
                        </div>
                        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] shrink-0">{a.skillCount} skills · {a.totalTrainingRuns} runs</span>
                      </div>
                    </div>
                    <span className="jarvis-mono text-sm font-bold tabular-nums shrink-0" style={{ color }}>{a.avgProficiency}%</span>
                  </motion.div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      {/* Recent training events */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Recent Training Events</h3>
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-auto">{d.recentTraining.length} entries</span>
        </div>
        {d.recentTraining.length === 0 ? (
          <EmptyState icon={Clock} text="No training events yet. Run an autonomy loop or scheduled training to see events here." />
        ) : (
          <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
            <AnimatePresence initial={false}>
              {d.recentTraining.map((e, i) => {
                const color = proficiencyColor(e.proficiency);
                return (
                  <motion.div
                    key={`${e.agentCodename}-${e.skillKey}-${i}`}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className="flex items-center gap-3 p-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] hover:border-[var(--j-cyan)]/40 transition-colors"
                  >
                    {/* Status icon */}
                    <div className="shrink-0 h-7 w-7 rounded-md flex items-center justify-center" style={{ background: e.lastRunSuccess === false ? 'rgba(248,113,113,0.12)' : `${color}1a`, color: e.lastRunSuccess === false ? JARVIS.colors.red : color }}>
                      {e.lastRunSuccess === false ? <XCircle className="h-3.5 w-3.5" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                    </div>
                    {/* Agent + skill */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.cyan }}>{e.agentCodename}</span>
                        <span className="text-[10px] text-[var(--j-text-mute)]">→</span>
                        <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate">{e.skillKey}</span>
                        {e.learnedFrom && (
                          <span className="jarvis-mono text-[8px] uppercase px-1 py-0.5 rounded" style={{ color: JARVIS.colors.violet, background: 'rgba(167,139,250,0.10)' }}>{e.learnedFrom}</span>
                        )}
                        {e.onCooldown && <Lock className="h-2.5 w-2.5" style={{ color: JARVIS.colors.amber }} />}
                      </div>
                      <div className="flex items-center gap-3 mt-1">
                        {/* Proficiency bar with pre→post */}
                        <div className="flex-1 flex items-center gap-1.5">
                          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] tabular-nums">{e.preProficiency}%</span>
                          <div className="flex-1 h-1.5 rounded-full bg-[var(--j-panel)] overflow-hidden relative">
                            <div className="absolute inset-y-0 left-0 rounded-full opacity-30" style={{ width: `${e.preProficiency}%`, background: 'var(--j-text-mute)' }} />
                            <div className="h-full rounded-full transition-all relative" style={{ width: `${e.proficiency}%`, background: color }} />
                          </div>
                          <span className="jarvis-mono text-[9px] font-bold tabular-nums" style={{ color }}>{e.proficiency}%</span>
                          <ImprovementIcon delta={e.improvement} />
                        </div>
                      </div>
                    </div>
                    {/* Run count + time */}
                    <div className="shrink-0 text-right">
                      <div className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">run #{e.trainingCount}</div>
                      <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{e.lastTrainedAt ? timeAgo(new Date(e.lastTrainedAt)) : '—'}</div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Cooldowns + Ready to retrain */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* On Cooldown */}
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-2 mb-3">
            <Lock className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">On Cooldown</h3>
            <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded ml-auto" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.12)' }}>{d.cooldowns.length}</span>
          </div>
          <p className="text-[10px] text-[var(--j-text-mute)] mb-3">These skills won't be retrained until their cooldown expires (7-day default). Prevents repetitive training.</p>
          {d.cooldowns.length === 0 ? (
            <EmptyState icon={Lock} text="No skills on cooldown right now." small />
          ) : (
            <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
              {d.cooldowns.map((c, i) => (
                <motion.div
                  key={`${c.agentCodename}-${c.skillKey}-${i}`}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-2 p-2 rounded-md bg-[var(--j-panel-soft)] border-l-2"
                  style={{ borderColor: JARVIS.colors.amber }}
                >
                  <Lock className="h-3 w-3 shrink-0" style={{ color: JARVIS.colors.amber }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="jarvis-mono text-[10px] font-bold" style={{ color: JARVIS.colors.cyan }}>{c.agentCodename}</span>
                      <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate">{c.skillKey}</span>
                    </div>
                    <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-0.5">
                      {c.proficiency}% · run #{c.trainingCount} · expires {timeAgo(new Date(c.cooldownUntil))}
                    </div>
                  </div>
                  <Flame className="h-3 w-3 shrink-0" style={{ color: JARVIS.colors.amber }} />
                </motion.div>
              ))}
            </div>
          )}
        </Card>

        {/* Ready to Retrain */}
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-2 mb-3">
            <Unlock className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Ready to Retrain</h3>
            <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded ml-auto" style={{ color: JARVIS.colors.cyan, background: 'rgba(125,211,252,0.12)' }}>{d.readyToRetrain.length}</span>
          </div>
          <p className="text-[10px] text-[var(--j-text-mute)] mb-3">Cooldown expired AND proficiency below mastery (80%). These agents need improvisation — safe to retrain.</p>
          {d.readyToRetrain.length === 0 ? (
            <EmptyState icon={Unlock} text="No skills ready for retraining. All agents are either on cooldown or have mastered their skills." small />
          ) : (
            <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
              {d.readyToRetrain.map((r, i) => (
                <motion.div
                  key={`${r.agentCodename}-${r.skillKey}-${i}`}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-2 p-2 rounded-md bg-[var(--j-panel-soft)] border-l-2"
                  style={{ borderColor: proficiencyColor(r.proficiency) }}
                >
                  <Unlock className="h-3 w-3 shrink-0" style={{ color: proficiencyColor(r.proficiency) }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="jarvis-mono text-[10px] font-bold" style={{ color: JARVIS.colors.cyan }}>{r.agentCodename}</span>
                      <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate">{r.skillKey}</span>
                    </div>
                    <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-0.5">
                      {r.proficiency}% · run #{r.trainingCount} {r.lastTrainedAt ? `· trained ${timeAgo(new Date(r.lastTrainedAt))}` : ''}
                    </div>
                  </div>
                  <TrendingUp className="h-3 w-3 shrink-0" style={{ color: proficiencyColor(r.proficiency) }} />
                </motion.div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------- Stat card ---------- */
function StatCard({ icon: Icon, label, value, accent, sub }: { icon: typeof Bot; label: string; value: string | number; accent: string; sub?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="jarvis-panel p-3 relative overflow-hidden group hover:scale-[1.02] transition-transform"
    >
      <div className="absolute top-0 right-0 h-10 w-10 rounded-full opacity-10 blur-xl" style={{ background: accent }} />
      <div className="flex items-center gap-2 mb-1 relative z-10">
        <Icon className="h-3.5 w-3.5" style={{ color: accent }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <div className="text-xl font-bold jarvis-num relative z-10">{value}</div>
      {sub && <div className="jarvis-mono text-[8px] text-[var(--j-text-mute)] mt-0.5 relative z-10">{sub}</div>}
    </motion.div>
  );
}

/* ---------- Empty state ---------- */
function EmptyState({ icon: Icon, text, small }: { icon: typeof Bot; text: string; small?: boolean }) {
  return (
    <div className={`flex flex-col items-center justify-center text-center ${small ? 'py-6' : 'py-12'}`}>
      <Icon className={`${small ? 'h-5 w-5' : 'h-8 w-8'} mx-auto mb-2 text-[var(--j-text-mute)] opacity-40`} />
      <div className="text-xs text-[var(--j-text-dim)] max-w-xs">{text}</div>
    </div>
  );
}
