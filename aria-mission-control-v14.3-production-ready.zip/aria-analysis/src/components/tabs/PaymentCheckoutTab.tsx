'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CreditCard, Wallet, Loader2, CheckCircle2, XCircle, ArrowRight, ArrowLeft,
  ShieldCheck, Zap, Copy, ExternalLink, Receipt, IndianRupee, DollarSign,
  AlertTriangle, RefreshCw, Clock, Hash,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

// ─── Types ────────────────────────────────────────────────────────────
interface GatewayStatus {
  ok: boolean;
  razorpay: { configured: boolean; mode: string; webhook: { configured: boolean; hasWebhookSecret: boolean } };
  stripe: { configured: boolean; mode: string; webhook: { configured: boolean; hasWebhookSecret: boolean } };
}

interface Order {
  id: string;
  gateway: string;
  gatewayOrderId: string | null;
  paymentId: string | null;
  amount: number;
  currency: string;
  purpose: string | null;
  payerName: string | null;
  payerEmail: string | null;
  payerContact: string | null;
  status: string;
  receipt: string | null;
  attempts: number;
  createdAt: string;
  updatedAt: string;
}

interface CreateOrderResponse {
  ok: boolean;
  order?: { id: string; gatewayOrderId: string; amount: number; currency: string; gateway: string; clientSecret?: string };
  error?: string;
}

interface OrderStatusResponse {
  ok: boolean;
  order?: Order;
  liveStatus?: string;
  error?: string;
}

type Step = 'form' | 'processing' | 'result' | 'orders';

const GATEWAYS = [
  { key: 'razorpay', label: 'Razorpay', icon: IndianRupee, color: JARVIS.colors.cyan, desc: 'UPI · Cards · Net Banking · Wallets (INR)' },
  { key: 'stripe', label: 'Stripe', icon: DollarSign, color: JARVIS.colors.violet, desc: 'Cards · Apple Pay · Google Pay (USD)' },
];

const STATUS_CONFIG: Record<string, { color: string; icon: typeof CheckCircle2; label: string }> = {
  created: { color: JARVIS.colors.cyan, icon: Clock, label: 'Created' },
  attempted: { color: JARVIS.colors.amber, icon: AlertTriangle, label: 'Attempted' },
  paid: { color: JARVIS.colors.green, icon: CheckCircle2, label: 'Paid' },
  failed: { color: JARVIS.colors.red, icon: XCircle, label: 'Failed' },
  expired: { color: JARVIS.colors.textMute, icon: Clock, label: 'Expired' },
};

export default function PaymentCheckoutTab() {
  const { toast } = useToast();
  const [step, setStep] = useState<Step>('form');
  const [createdOrder, setCreatedOrder] = useState<CreateOrderResponse['order'] | null>(null);
  const [orderError, setOrderError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  // Form state
  const [gateway, setGateway] = useState<'razorpay' | 'stripe'>('razorpay');
  const [amount, setAmount] = useState('1000');
  const [purpose, setPurpose] = useState('Service subscription');
  const [payerName, setPayerName] = useState('');
  const [payerEmail, setPayerEmail] = useState('');
  const [payerContact, setPayerContact] = useState('');

  const { data: gwStatus } = useApi<GatewayStatus>('/api/payments/gateway-status', 60000);
  const { data: ordersData, loading: ordersLoading, refresh: refreshOrders } = useApi<{ orders: Order[] }>('/api/payments/orders', 15000);

  const handleCreateOrder = useCallback(async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) {
      toast({ title: 'Invalid amount', description: 'Enter a positive amount', variant: 'destructive' });
      return;
    }
    setCreating(true);
    setOrderError(null);
    setStep('processing');
    try {
      const res = await postJson<CreateOrderResponse>('/api/payments/create-order', {
        amount: amt,
        gateway,
        purpose: purpose || undefined,
        payerName: payerName || undefined,
        payerEmail: payerEmail || undefined,
        payerContact: payerContact || undefined,
      });
      if (res.ok && res.order) {
        setCreatedOrder(res.order);
        setStep('result');
        toast({ title: 'Order created', description: `${gateway} order ${res.order.gatewayOrderId.slice(0, 16)}…` });
        refreshOrders();
      } else {
        setOrderError(res.error ?? 'Unknown error');
        setStep('result');
        toast({ title: 'Order creation failed', description: res.error ?? 'unknown error', variant: 'destructive' });
      }
    } catch (err) {
      setOrderError(err instanceof Error ? err.message : 'network error');
      setStep('result');
      toast({ title: 'Order creation failed', description: err instanceof Error ? err.message : 'network error', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  }, [amount, gateway, purpose, payerName, payerEmail, payerContact, toast, refreshOrders]);

  const handleReset = useCallback(() => {
    setCreatedOrder(null);
    setOrderError(null);
    setStep('form');
  }, []);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CreditCard className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Production Revenue · Gateway Checkout</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Payment Checkout</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Create real gateway orders via Razorpay or Stripe. Tracks the full lifecycle: created → attempted → paid.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <GatewayBadge name="Razorpay" configured={gwStatus?.razorpay?.configured ?? false} mode={gwStatus?.razorpay?.mode} />
          <GatewayBadge name="Stripe" configured={gwStatus?.stripe?.configured ?? false} mode={gwStatus?.stripe?.mode} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Left: Checkout flow (3 cols) */}
        <div className="lg:col-span-3">
          <AnimatePresence mode="wait">
            {step === 'form' && (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 8 }}
                className="jarvis-panel p-5"
              >
                <CheckoutForm
                  gateway={gateway}
                  setGateway={setGateway}
                  amount={amount}
                  setAmount={setAmount}
                  purpose={purpose}
                  setPurpose={setPurpose}
                  payerName={payerName}
                  setPayerName={setPayerName}
                  payerEmail={payerEmail}
                  setPayerEmail={setPayerEmail}
                  payerContact={payerContact}
                  setPayerContact={setPayerContact}
                  gwStatus={gwStatus}
                  onSubmit={handleCreateOrder}
                  creating={creating}
                />
              </motion.div>
            )}
            {step === 'processing' && (
              <motion.div
                key="processing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="jarvis-panel p-10 flex flex-col items-center justify-center text-center"
              >
                <Loader2 className="h-10 w-10 animate-spin mb-4" style={{ color: JARVIS.colors.cyan }} />
                <p className="jarvis-mono text-sm text-[var(--j-text)]">Creating {gateway} order…</p>
                <p className="jarvis-mono text-[10px] text-[var(--j-text-mute)] mt-1">Calling gateway API · persisting order</p>
              </motion.div>
            )}
            {step === 'result' && (
              <motion.div
                key="result"
                initial={{ opacity: 0, x: 8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                className="jarvis-panel p-5"
              >
                <OrderResult order={createdOrder} error={orderError} gateway={gateway} onReset={handleReset} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right: Recent orders (2 cols) */}
        <div className="lg:col-span-2">
          <div className="jarvis-panel p-4 h-full">
            <div className="flex items-center gap-2 mb-3">
              <Receipt className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
              <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Recent Orders</h4>
              <button
                onClick={refreshOrders}
                className="ml-auto flex items-center gap-1 h-7 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-violet)] hover:border-[var(--j-violet)] transition-colors"
              >
                <RefreshCw className={`h-3 w-3 ${ordersLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
            {ordersLoading && !ordersData ? (
              <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
            ) : ordersData?.orders?.length ? (
              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                {ordersData.orders.map((order, i) => (
                  <OrderCard key={order.id} order={order} delay={i * 0.04} />
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <Receipt className="h-8 w-8 mx-auto mb-2 opacity-30" />
                <p className="text-xs text-[var(--j-text-mute)]">No gateway orders yet.</p>
                <p className="text-[10px] text-[var(--j-text-mute)] mt-1">Create one to get started.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick amount presets + security note */}
      <div className="jarvis-panel p-3 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-3.5 w-3.5" style={{ color: JARVIS.colors.green }} />
          <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">
            All gateway calls are server-side · webhook-verified · PCI-compliant
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mr-1">Quick:</span>
          {[500, 1000, 2500, 5000].map((amt) => (
            <button
              key={amt}
              onClick={() => { setAmount(String(amt)); setStep('form'); }}
              className="jarvis-mono text-[10px] px-2 py-1 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:border-[var(--j-cyan)] hover:text-[var(--j-cyan)] transition-colors"
            >
              ₹{amt.toLocaleString()}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Checkout Form ────────────────────────────────────────────────────
function CheckoutForm({
  gateway, setGateway, amount, setAmount, purpose, setPurpose,
  payerName, setPayerName, payerEmail, setPayerEmail, payerContact, setPayerContact,
  gwStatus, onSubmit, creating,
}: {
  gateway: 'razorpay' | 'stripe';
  setGateway: (g: 'razorpay' | 'stripe') => void;
  amount: string;
  setAmount: (s: string) => void;
  purpose: string;
  setPurpose: (s: string) => void;
  payerName: string;
  setPayerName: (s: string) => void;
  payerEmail: string;
  setPayerEmail: (s: string) => void;
  payerContact: string;
  setPayerContact: (s: string) => void;
  gwStatus?: GatewayStatus;
  onSubmit: () => void;
  creating: boolean;
}) {
  const currency = gateway === 'razorpay' ? 'INR' : 'USD';
  const CurrencyIcon = gateway === 'razorpay' ? IndianRupee : DollarSign;
  const gatewayConfigured = gateway === 'razorpay' ? gwStatus?.razorpay?.configured : gwStatus?.stripe?.configured;

  return (
    <div className="space-y-4">
      {/* Step 1: Gateway selection */}
      <div>
        <Label className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 block">
          1 · Select Gateway
        </Label>
        <div className="grid grid-cols-2 gap-2">
          {GATEWAYS.map((g) => {
            const configured = g.key === 'razorpay' ? gwStatus?.razorpay?.configured : gwStatus?.stripe?.configured;
            const active = gateway === g.key;
            return (
              <button
                key={g.key}
                onClick={() => setGateway(g.key as 'razorpay' | 'stripe')}
                className="relative p-3 rounded-lg border text-left transition-all"
                style={{
                  borderColor: active ? g.color : 'var(--j-border)',
                  background: active ? `${g.color}0a` : 'var(--j-panel-soft)',
                }}
              >
                {active && (
                  <motion.div
                    layoutId="gateway-active"
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-8 w-[2px] rounded-full"
                    style={{ background: g.color, boxShadow: `0 0 8px ${g.color}` }}
                  />
                )}
                <div className="flex items-center gap-2 mb-1">
                  <g.icon className="h-4 w-4" style={{ color: g.color }} />
                  <span className="font-semibold text-sm" style={{ color: active ? g.color : 'var(--j-text)' }}>{g.label}</span>
                  {configured ? (
                    <CheckCircle2 className="h-3 w-3 ml-auto" style={{ color: JARVIS.colors.green }} />
                  ) : (
                    <XCircle className="h-3 w-3 ml-auto" style={{ color: JARVIS.colors.amber }} />
                  )}
                </div>
                <p className="text-[10px] text-[var(--j-text-mute)] leading-tight">{g.desc}</p>
                {!configured && (
                  <p className="jarvis-mono text-[9px] mt-1.5" style={{ color: JARVIS.colors.amber }}>
                    Not configured · demo mode
                  </p>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Step 2: Amount + purpose */}
      <div>
        <Label className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 block">
          2 · Amount & Purpose
        </Label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <div className="relative col-span-1">
            <CurrencyIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="pl-9 jarvis-mono text-base font-bold"
            />
          </div>
          <div className="col-span-2">
            <Input
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="Purpose / description"
              className="text-sm"
            />
          </div>
        </div>
        <p className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-1">
          {gateway === 'razorpay' ? 'Amount in INR (₹) · charged in paise' : 'Amount in USD ($) · charged in cents'}
        </p>
      </div>

      {/* Step 3: Payer details */}
      <div>
        <Label className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 block">
          3 · Payer Details <span className="text-[var(--j-text-mute)] normal-case">(optional)</span>
        </Label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <Input value={payerName} onChange={(e) => setPayerName(e.target.value)} placeholder="Name" className="text-sm" />
          <Input value={payerEmail} onChange={(e) => setPayerEmail(e.target.value)} placeholder="Email" type="email" className="text-sm" />
          <Input value={payerContact} onChange={(e) => setPayerContact(e.target.value)} placeholder="Phone" className="text-sm" />
        </div>
      </div>

      {/* Submit */}
      <div className="pt-2 border-t border-[var(--j-border)]">
        <Button
          onClick={onSubmit}
          disabled={creating || !amount}
          className="w-full h-10 jarvis-btn-accent border-0"
          style={{ background: `linear-gradient(135deg, ${JARVIS.colors.cyan}, ${JARVIS.colors.green})`, color: '#05070A' }}
        >
          {creating ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Creating Order…</>
          ) : (
            <>Create {gateway === 'razorpay' ? '₹' : '$'}{amount || '0'} Order <ArrowRight className="h-4 w-4 ml-2" /></>
          )}
        </Button>
        {!gatewayConfigured && (
          <p className="jarvis-mono text-[9px] text-center mt-2" style={{ color: JARVIS.colors.amber }}>
            ⚠ {gateway} is not configured — the API will return an error. Set the env keys to enable live orders.
          </p>
        )}
      </div>
    </div>
  );
}

// ─── Order Result ─────────────────────────────────────────────────────
function OrderResult({ order, error, gateway, onReset }: { order: CreateOrderResponse['order'] | null; error: string | null; gateway: string; onReset: () => void }) {
  const { toast } = useToast();
  if (error || !order) {
    return (
      <div className="text-center py-6">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="h-14 w-14 rounded-full mx-auto mb-3 flex items-center justify-center"
          style={{ background: `${JARVIS.colors.red}1a`, color: JARVIS.colors.red }}
        >
          <XCircle className="h-7 w-7" />
        </motion.div>
        <h3 className="text-lg font-bold mb-1" style={{ color: JARVIS.colors.red }}>Order Failed</h3>
        <p className="text-xs text-[var(--j-text-dim)] mb-4 max-w-md mx-auto break-words">{error}</p>
        <Button onClick={onReset} variant="outline" className="jarvis-btn-accent border-0">
          <ArrowLeft className="h-3.5 w-3.5 mr-1.5" /> Try Again
        </Button>
      </div>
    );
  }
  const color = gateway === 'razorpay' ? JARVIS.colors.cyan : JARVIS.colors.violet;
  return (
    <div>
      <div className="text-center py-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="h-14 w-14 rounded-full mx-auto mb-3 flex items-center justify-center"
          style={{ background: `${JARVIS.colors.green}1a`, color: JARVIS.colors.green }}
        >
          <CheckCircle2 className="h-7 w-7" />
        </motion.div>
        <h3 className="text-lg font-bold mb-1">Order Created</h3>
        <p className="jarvis-mono text-[10px] text-[var(--j-text-mute)] mb-4">{gateway.toUpperCase()} gateway order ready for checkout</p>
      </div>

      <div className="space-y-2 mb-4">
        <ResultRow label="Order ID" value={order.id} copyable onCopy={() => toast({ title: 'Copied', description: 'Order ID copied' })} />
        <ResultRow label="Gateway Order" value={order.gatewayOrderId} copyable onCopy={() => toast({ title: 'Copied', description: 'Gateway order ID copied' })} accent={color} />
        <ResultRow label="Amount" value={`${order.currency} ${order.amount.toLocaleString()}`} />
        <ResultRow label="Gateway" value={order.gateway.toUpperCase()} accent={color} />
        {order.clientSecret && (
          <ResultRow label="Client Secret" value={order.clientSecret.slice(0, 24) + '…'} copyable onCopy={() => toast({ title: 'Copied', description: 'Client secret copied' })} accent={JARVIS.colors.amber} />
        )}
      </div>

      <div className="p-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]/60 mb-4">
        <div className="flex items-center gap-2 mb-1.5">
          <Zap className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />
          <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)]">Next Steps</span>
        </div>
        <p className="text-[11px] text-[var(--j-text-dim)] leading-relaxed">
          {gateway === 'razorpay'
            ? 'Hand the gatewayOrderId to the Razorpay Checkout SDK on the client. After payment, the webhook at /api/payments/webhook/razorpay will confirm it. Poll /api/payments/order/[id] for live status.'
            : 'Use the clientSecret with Stripe.js (confirmCardPayment) on the client. The webhook at /api/payments/webhook/stripe will confirm it. Poll /api/payments/order/[id] for live status.'}
        </p>
      </div>

      <div className="flex gap-2">
        <Button onClick={onReset} variant="outline" className="flex-1 jarvis-btn-accent border-0">
          <ArrowLeft className="h-3.5 w-3.5 mr-1.5" /> New Order
        </Button>
        <Button
          onClick={() => window.open(gateway === 'razorpay' ? 'https://dashboard.razorpay.com/app/orders' : 'https://dashboard.stripe.com/payments', '_blank')}
          variant="outline"
          className="flex-1 border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]"
        >
          View on Dashboard <ExternalLink className="h-3 w-3 ml-1.5" />
        </Button>
      </div>
    </div>
  );
}

function ResultRow({ label, value, copyable, onCopy, accent }: { label: string; value: string; copyable?: boolean; onCopy?: () => void; accent?: string }) {
  return (
    <div className="flex items-center gap-2 p-2 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]">
      <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] w-28 shrink-0">{label}</span>
      <span className="jarvis-mono text-[11px] flex-1 truncate" style={{ color: accent ?? 'var(--j-text)' }}>{value}</span>
      {copyable && (
        <button onClick={onCopy} className="shrink-0 h-6 w-6 rounded flex items-center justify-center hover:bg-[var(--j-panel-soft)] text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] transition-colors">
          <Copy className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}

// ─── Order Card (recent orders list) ──────────────────────────────────
function OrderCard({ order, delay }: { order: Order; delay: number }) {
  const config = STATUS_CONFIG[order.status] ?? STATUS_CONFIG.created;
  const Icon = config.icon;
  const gatewayColor = order.gateway === 'razorpay' ? JARVIS.colors.cyan : JARVIS.colors.violet;
  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="p-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]/60"
    >
      <div className="flex items-center gap-2 mb-1.5">
        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color: gatewayColor, background: `${gatewayColor}1a` }}>
          {order.gateway}
        </span>
        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase flex items-center gap-0.5" style={{ color: config.color, background: `${config.color}1a` }}>
          <Icon className="h-2.5 w-2.5" />{config.label}
        </span>
        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-auto">{timeAgo(new Date(order.createdAt))}</span>
      </div>
      <div className="flex items-baseline gap-1.5 mb-1">
        <span className="jarvis-mono text-base font-bold tabular-nums" style={{ color: 'var(--j-text)' }}>
          {order.currency} {order.amount.toLocaleString()}
        </span>
      </div>
      {order.purpose && <p className="text-[10px] text-[var(--j-text-dim)] truncate mb-1">{order.purpose}</p>}
      <div className="flex items-center gap-1 jarvis-mono text-[9px] text-[var(--j-text-mute)]">
        <Hash className="h-2.5 w-2.5" />
        <span className="truncate">{order.gatewayOrderId?.slice(0, 20) ?? order.id.slice(0, 12)}…</span>
      </div>
    </motion.div>
  );
}

// ─── Gateway Badge (header) ───────────────────────────────────────────
function GatewayBadge({ name, configured, mode }: { name: string; configured: boolean; mode?: string }) {
  const color = configured ? JARVIS.colors.green : JARVIS.colors.amber;
  return (
    <div
      className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border"
      style={{ borderColor: `${color}33`, background: `${color}0a` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color, boxShadow: `0 0 4px ${color}` }} />
      <span className="jarvis-mono text-[9px] uppercase tracking-wider" style={{ color }}>{name}</span>
      {mode && <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)] uppercase">{mode}</span>}
    </div>
  );
}
