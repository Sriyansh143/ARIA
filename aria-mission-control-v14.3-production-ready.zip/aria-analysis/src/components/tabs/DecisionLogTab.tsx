'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  History, Rocket, Clock, Satellite, Sunrise, ChevronDown, RefreshCw, Loader2,
  Bot, Zap, Brain, Activity, RotateCcw, Undo2, ShieldCheck,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';

interface Decision {
  id: string;
  action: string;
  actor: string;
  summary: string;
  meta: Record<string, unknown>;
  createdAt: string;
  reversible: boolean;
  reversed: boolean;
}

interface DecisionsData {
  decisions: Decision[];
  counts: { all: number; autopilot: number; briefing: number; standup: number };
  actionMeta: Record<string, { label: string; color: string; icon: string }>;
}

const COLOR_MAP: Record<string, string> = {
  green: JARVIS.colors.green,
  amber: JARVIS.colors.amber,
  cyan: JARVIS.colors.cyan,
  violet: JARVIS.colors.violet,
  red: JARVIS.colors.red,
};

const ICON_MAP: Record<string, typeof Rocket> = {
  rocket: Rocket,
  clock: Clock,
  satellite: Satellite,
  sunrise: Sunrise,
};

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'autopilot', label: 'Autopilot' },
  { key: 'briefing', label: 'Briefings' },
  { key: 'standup', label: 'Standups' },
] as const;

export default function DecisionLogTab() {
  const [filter, setFilter] = useState<string>('all');

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <History className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Autonomous Audit Trail</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Decision Log</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Every autonomous decision ARIA has made — autopilot cycles, briefings, and standups — for full operator auditability.
          </p>
        </div>
      </div>

      {/* Filter chips — always show the global counts regardless of active filter */}
      <FilterChips filter={filter} onChange={setFilter} />

      {/* Timeline — keyed by filter so it fully remounts (fresh useApi state) on filter change */}
      <DecisionTimeline key={filter} filter={filter} />
    </div>
  );
}

/* ---------- Filter chips ---------- */
function FilterChips({ filter, onChange }: { filter: string; onChange: (f: string) => void }) {
  // Fetch global counts once (separate from the filtered timeline data).
  const { data } = useApi<DecisionsData>('/api/decisions?limit=1', 20000);
  const counts = data?.counts ?? { all: 0, autopilot: 0, briefing: 0, standup: 0 };
  return (
    <div className="flex items-center gap-2 flex-wrap">
      {FILTERS.map((f) => {
        const count = counts[f.key as keyof typeof counts] ?? 0;
        const activeChip = filter === f.key;
        return (
          <button
            key={f.key}
            onClick={() => onChange(f.key)}
            className="flex items-center gap-2 h-8 px-3 rounded-md border transition-all text-sm"
            style={{
              borderColor: activeChip ? JARVIS.colors.cyan : 'var(--j-border)',
              background: activeChip ? 'rgba(125,211,252,0.10)' : 'var(--j-panel-soft)',
              color: activeChip ? JARVIS.colors.cyan : 'var(--j-text-dim)',
            }}
          >
            <span className="jarvis-mono text-[10px] uppercase tracking-wider">{f.label}</span>
            <span className="jarvis-mono text-[10px] tabular-nums px-1.5 py-0.5 rounded" style={{ background: activeChip ? 'rgba(125,211,252,0.15)' : 'var(--j-bg)', color: activeChip ? JARVIS.colors.cyan : 'var(--j-text-mute)' }}>{count}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Decision timeline (fetches filtered data) ---------- */
function DecisionTimeline({ filter }: { filter: string }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [reversing, setReversing] = useState<string | null>(null);
  const query = filter === 'all' ? '' : `?type=${filter}`;
  const { data, loading, refresh } = useApi<DecisionsData>(`/api/decisions${query}`, 15000);
  const { toast } = useToast();
  const decisions = data?.decisions ?? [];

  const toggle = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleReverse = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setReversing(id);
    try {
      const res = await postJson<{ result: { ok: boolean; detail: string }; error?: string }>(`/api/decisions/${id}/reverse`, { reversedBy: 'operator' });
      if (res.result?.ok) {
        toast({ title: 'Decision reversed', description: res.result.detail });
        refresh();
      } else {
        toast({ title: 'Reverse failed', description: res.error ?? res.result?.detail ?? 'unknown error', variant: 'destructive' });
      }
    } catch (err) {
      toast({ title: 'Reverse failed', description: err instanceof Error ? err.message : 'network error', variant: 'destructive' });
    } finally {
      setReversing(null);
    }
  };

  return (
    <>
      <div className="flex justify-end">
        <button
          onClick={refresh}
          className="flex items-center gap-2 h-8 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-sm"
        >
          <RefreshCw className={loading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
          <span className="jarvis-mono text-[10px] uppercase">Refresh</span>
        </button>
      </div>

      {/* Timeline */}
      {loading && decisions.length === 0 ? (
        <DecisionSkeleton />
      ) : decisions.length === 0 ? (
        <div className="jarvis-panel p-10 text-center">
          <History className="h-8 w-8 mx-auto mb-3 opacity-30" />
          <p className="text-sm text-[var(--j-text-mute)]">No autonomous decisions recorded yet for this filter.</p>
          <p className="text-xs text-[var(--j-text-mute)] mt-1">Engage the Autopilot or generate a briefing/standup to populate the log.</p>
        </div>
      ) : (
        <div className="relative">
          {/* Vertical timeline rail */}
          <div className="absolute left-[15px] top-2 bottom-2 w-px bg-gradient-to-b from-[var(--j-border)] via-[var(--j-border)] to-transparent" />
          <div className="space-y-2.5">
            <AnimatePresence initial={false}>
              {decisions.map((d, i) => {
                const meta = data?.actionMeta?.[d.action] ?? { label: d.action, color: 'cyan', icon: 'activity' };
                const color = COLOR_MAP[meta.color] ?? JARVIS.colors.cyan;
                const Icon = ICON_MAP[meta.icon] ?? Activity;
                const isOpen = expanded.has(d.id);
                const m = d.meta as Record<string, unknown>;
                return (
                  <motion.div
                    key={d.id}
                    layout
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -8 }}
                    transition={{ delay: Math.min(i * 0.03, 0.3) }}
                    className="relative pl-10"
                  >
                    {/* Timeline node */}
                    <div className="absolute left-[8px] top-3 h-3 w-3 rounded-full border-2 z-10" style={{ borderColor: color, background: 'var(--j-bg)', boxShadow: `0 0 8px ${color}55` }}>
                      <div className="absolute inset-0.5 rounded-full" style={{ background: color }} />
                    </div>
                    <div className="jarvis-panel p-3.5 hover:border-[var(--j-border)] transition-colors cursor-pointer group" onClick={() => toggle(d.id)}>
                      <div className="flex items-start gap-3">
                        <div className="shrink-0 mt-0.5 h-7 w-7 rounded-md flex items-center justify-center" style={{ background: `${color}1a`, color }}>
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-0.5">
                            <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold tracking-wider uppercase" style={{ color, background: `${color}1a` }}>{meta.label}</span>
                            <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{timeAgo(new Date(d.createdAt))}</span>
                            {m.dispatched === true && (
                              <span className="jarvis-mono text-[9px] text-[var(--j-green)] flex items-center gap-0.5"><Zap className="h-2.5 w-2.5" />dispatched</span>
                            )}
                            {typeof m.health === 'number' && (
                              <span className="jarvis-mono text-[9px] tabular-nums px-1 py-0.5 rounded" style={{ color: (m.health as number) >= 85 ? JARVIS.colors.green : (m.health as number) >= 60 ? JARVIS.colors.amber : JARVIS.colors.red, background: 'var(--j-panel-soft)' }}>health {(m.health as number)}</span>
                            )}
                            {d.reversed && (
                              <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded flex items-center gap-0.5 font-bold" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.12)' }}><Undo2 className="h-2.5 w-2.5" />REVERSED</span>
                            )}
                            {d.reversible && !d.reversed && (
                              <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded flex items-center gap-0.5" style={{ color: JARVIS.colors.cyan, background: 'rgba(125,211,252,0.08)' }}><ShieldCheck className="h-2.5 w-2.5" />reversible</span>
                            )}
                          </div>
                          <p className="text-sm text-[var(--j-text)] leading-snug font-medium">{d.summary}</p>
                          {/* Compact meta line */}
                          {!isOpen && (
                            <p className="text-[10px] text-[var(--j-text-mute)] mt-1 truncate jarvis-mono">
                              {typeof m.rationale === 'string' && m.rationale}
                              {typeof m.agentsDispatched === 'number' && ` · ${m.agentsDispatched} agent(s)`}
                              {typeof m.recommendationCount === 'number' && ` · ${m.recommendationCount} recs`}
                              {typeof m.accomplished === 'number' && ` · ${m.accomplished} done`}
                            </p>
                          )}
                          {/* Expanded detail */}
                          <AnimatePresence>
                            {isOpen && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.18 }}
                                className="overflow-hidden"
                              >
                                <div className="mt-2 pt-2 border-t border-[var(--j-border)] space-y-1.5">
                                  {typeof m.rationale === 'string' && m.rationale && (
                                    <MetaRow icon={Brain} label="Rationale" value={m.rationale as string} color={JARVIS.colors.violet} />
                                  )}
                                  {typeof m.agentsDispatched === 'number' && (
                                    <MetaRow icon={Bot} label="Agents dispatched" value={String(m.agentsDispatched)} color={JARVIS.colors.cyan} />
                                  )}
                                  {typeof m.runId === 'string' && m.runId && (
                                    <MetaRow icon={Activity} label="Run ID" value={m.runId as string} color={JARVIS.colors.textDim} />
                                  )}
                                  {typeof m.durationMs === 'number' && (
                                    <MetaRow icon={Clock} label="Duration" value={`${Math.round((m.durationMs as number) / 1000)}s`} color={JARVIS.colors.amber} />
                                  )}
                                  {typeof m.topRisk === 'string' && m.topRisk && (
                                    <MetaRow icon={Activity} label="Top risk" value={m.topRisk as string} color={JARVIS.colors.red} />
                                  )}
                                  {typeof m.headline === 'string' && m.headline && (
                                    <MetaRow icon={Satellite} label="Headline" value={m.headline as string} color={JARVIS.colors.cyan} />
                                  )}
                                  {typeof m.stats === 'object' && m.stats && (
                                    <MetaRow icon={Activity} label="Stats" value={JSON.stringify(m.stats)} color={JARVIS.colors.textDim} />
                                  )}
                                  {/* Quick-reverse action — one-click undo for faster auditing */}
                                  {d.reversible && !d.reversed && (
                                    <div className="pt-2 mt-1 border-t border-[var(--j-border)]">
                                      <button
                                        onClick={(e) => handleReverse(d.id, e)}
                                        disabled={reversing === d.id}
                                        className="flex items-center gap-1.5 h-7 px-3 rounded-md border text-[11px] font-medium transition-all disabled:opacity-50"
                                        style={{
                                          borderColor: 'rgba(251,113,133,0.4)',
                                          background: 'rgba(251,113,133,0.08)',
                                          color: JARVIS.colors.red,
                                        }}
                                      >
                                        {reversing === d.id ? (
                                          <Loader2 className="h-3 w-3 animate-spin" />
                                        ) : (
                                          <RotateCcw className="h-3 w-3" />
                                        )}
                                        <span className="jarvis-mono text-[10px] uppercase tracking-wider">Quick Reverse</span>
                                      </button>
                                      <p className="text-[9px] text-[var(--j-text-mute)] mt-1 jarvis-mono">
                                        Reverses this decision + auto-adjusts KPI targets based on the outcome.
                                      </p>
                                    </div>
                                  )}
                                  {d.reversed && (
                                    <div className="pt-2 mt-1 border-t border-[var(--j-border)] flex items-center gap-1.5">
                                      <Undo2 className="h-3 w-3" style={{ color: JARVIS.colors.amber }} />
                                      <span className="text-[10px] text-[var(--j-text-dim)] jarvis-mono">This decision was reversed — KPIs auto-adjusted.</span>
                                    </div>
                                  )}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                        <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-[var(--j-text-mute)] mt-1 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>
      )}
    </>
  );
}

function MetaRow({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string; color: string }) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="h-3 w-3 shrink-0 mt-0.5" style={{ color }} />
      <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] shrink-0 w-28">{label}</span>
      <span className="text-[11px] text-[var(--j-text-dim)] leading-snug break-words">{value}</span>
    </div>
  );
}

function DecisionSkeleton() {
  return (
    <div className="relative pl-10 space-y-2.5">
      <div className="absolute left-[15px] top-2 bottom-2 w-px bg-[var(--j-border)]" />
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="relative pl-0">
          <div className="absolute left-[-26px] top-3 h-3 w-3 rounded-full bg-[var(--j-panel-soft)] jarvis-skeleton" />
          <div className="jarvis-panel p-3.5">
            <div className="flex items-center gap-3">
              <div className="h-7 w-7 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />
              <div className="flex-1 space-y-1.5">
                <div className="h-2.5 w-24 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
                <div className="h-3 w-3/4 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
                <div className="h-2 w-1/2 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
