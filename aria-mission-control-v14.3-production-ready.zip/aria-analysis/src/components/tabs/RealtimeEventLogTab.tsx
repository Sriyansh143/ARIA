'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Radio, Activity, AlertTriangle, Bot, CheckSquare, Clock, Zap, Database,
  Wallet, RefreshCw, Loader2, Filter, ChevronDown, ChevronRight, Wifi,
  Cpu, TrendingUp, Server, Trash2, Send,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { useRealtimeConnection } from '@/lib/hooks/use-realtime';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

// ─── Types ────────────────────────────────────────────────────────────
interface RealtimeEvent {
  id: string;
  channel: string;
  event: string;
  payload: unknown;
  broadcastTo: string;
  createdAt: string;
}

interface EventsData {
  events: RealtimeEvent[];
  counts: Record<string, number>;
  total: number;
}

interface RealtimeStatus {
  running: boolean;
  connections: number;
  uptime: number;
  port: number;
  channels?: string[];
}

const CHANNEL_CONFIG: Record<string, { color: string; icon: typeof Bot; label: string }> = {
  'agent:heartbeat': { color: JARVIS.colors.cyan, icon: Bot, label: 'Heartbeat' },
  'agent:status': { color: JARVIS.colors.violet, icon: Activity, label: 'Status' },
  'task:update': { color: JARVIS.colors.amber, icon: CheckSquare, label: 'Task' },
  'decision:new': { color: JARVIS.colors.green, icon: Zap, label: 'Decision' },
  'alert:critical': { color: JARVIS.colors.red, icon: AlertTriangle, label: 'Alert' },
  'telemetry:tick': { color: JARVIS.colors.cyan, icon: Cpu, label: 'Telemetry' },
  'payment:update': { color: JARVIS.colors.green, icon: Wallet, label: 'Payment' },
  'sync:status': { color: JARVIS.colors.violet, icon: Database, label: 'Sync' },
};

export default function RealtimeEventLogTab() {
  const { toast } = useToast();
  const { connected } = useRealtimeConnection();
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const { data: status } = useApi<RealtimeStatus>('/api/realtime/status', 10000);
  const { data, loading, refresh } = useApi<EventsData>(
    `/api/realtime/events?limit=100${channelFilter !== 'all' ? `&channel=${channelFilter}` : ''}`,
    10000,
  );

  const events = data?.events ?? [];
  const counts = data?.counts ?? {};
  const total = data?.total ?? 0;

  const toggle = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleEmitTest = useCallback(async () => {
    try {
      const channels = Object.keys(CHANNEL_CONFIG);
      const ch = channels[Math.floor(Math.random() * channels.length)];
      await postJson('/api/realtime/events', {
        channel: ch,
        event: 'test-emit',
        payload: { source: 'manual', timestamp: new Date().toISOString(), test: true },
        broadcastTo: 'all',
      });
      toast({ title: 'Test event emitted', description: `Channel: ${ch}` });
      refresh();
    } catch (err) {
      toast({ title: 'Emit failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refresh]);

  const channels = status?.channels ?? Object.keys(CHANNEL_CONFIG);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Radio className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Socket.io Broadcast Log · Live Event Stream</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Realtime Event Log</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Every socket.io broadcast event — agent heartbeats, task updates, decisions, alerts, telemetry, payments, sync status.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={handleEmitTest} variant="outline" className="jarvis-btn-accent border-0">
            <Send className="h-3.5 w-3.5 mr-1.5" /> Emit Test Event
          </Button>
          <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]">
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Status strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatusCard
          icon={connected ? Wifi : AlertTriangle}
          label="Connection"
          value={connected ? 'LIVE' : status?.running ? 'Service Up' : 'Offline'}
          color={connected ? JARVIS.colors.green : status?.running ? JARVIS.colors.amber : JARVIS.colors.red}
          pulse={connected}
        />
        <StatusCard
          icon={Radio}
          label="Subscribers"
          value={status?.connections ?? 0}
          color={JARVIS.colors.cyan}
        />
        <StatusCard
          icon={Activity}
          label="Uptime"
          value={status ? `${Math.floor(status.uptime / 60)}m ${status.uptime % 60}s` : '—'}
          color={JARVIS.colors.violet}
        />
        <StatusCard
          icon={Server}
          label="Total Events"
          value={total}
          color={JARVIS.colors.amber}
        />
      </div>

      {/* Channel filter chips */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-3.5 w-3.5 text-[var(--j-text-mute)]" />
        <button
          onClick={() => setChannelFilter('all')}
          className="flex items-center gap-2 h-7 px-2.5 rounded-md border text-xs transition-all"
          style={{
            borderColor: channelFilter === 'all' ? JARVIS.colors.cyan : 'var(--j-border)',
            background: channelFilter === 'all' ? 'rgba(125,211,252,0.10)' : 'var(--j-panel-soft)',
            color: channelFilter === 'all' ? JARVIS.colors.cyan : 'var(--j-text-dim)',
          }}
        >
          <span className="jarvis-mono text-[10px] uppercase tracking-wider">All</span>
          <span className="jarvis-mono text-[10px] tabular-nums px-1 py-0.5 rounded" style={{ background: 'var(--j-bg)', color: 'var(--j-text-mute)' }}>{total}</span>
        </button>
        {channels.map((ch) => {
          const config = CHANNEL_CONFIG[ch] ?? { color: JARVIS.colors.cyan, icon: Activity, label: ch };
          const count = counts[ch] ?? 0;
          const active = channelFilter === ch;
          return (
            <button
              key={ch}
              onClick={() => setChannelFilter(active ? 'all' : ch)}
              className="flex items-center gap-2 h-7 px-2.5 rounded-md border text-xs transition-all"
              style={{
                borderColor: active ? config.color : 'var(--j-border)',
                background: active ? `${config.color}1a` : 'var(--j-panel-soft)',
                color: active ? config.color : 'var(--j-text-dim)',
              }}
            >
              <config.icon className="h-3 w-3" />
              <span className="jarvis-mono text-[10px] uppercase tracking-wider">{config.label}</span>
              <span className="jarvis-mono text-[10px] tabular-nums px-1 py-0.5 rounded" style={{ background: 'var(--j-bg)', color: 'var(--j-text-mute)' }}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Event timeline */}
      <div className="jarvis-panel p-0 overflow-hidden">
        {loading && events.length === 0 ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-12 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
          </div>
        ) : events.length === 0 ? (
          <div className="p-10 text-center">
            <Radio className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm text-[var(--j-text-mute)]">No realtime events logged yet.</p>
            <p className="text-[10px] text-[var(--j-text-mute)] mt-1">Click "Emit Test Event" to generate one.</p>
          </div>
        ) : (
          <div className="relative max-h-[700px] overflow-y-auto">
            {/* Timeline rail */}
            <div className="absolute left-[19px] top-2 bottom-2 w-px bg-gradient-to-b from-[var(--j-border)] via-[var(--j-border)] to-transparent" />
            <div className="space-y-1 p-2">
              <AnimatePresence initial={false}>
                {events.map((e, i) => {
                  const config = CHANNEL_CONFIG[e.channel] ?? { color: JARVIS.colors.cyan, icon: Activity, label: e.channel };
                  const isOpen = expanded.has(e.id);
                  const payloadStr = typeof e.payload === 'string' ? e.payload : JSON.stringify(e.payload, null, 2);
                  return (
                    <motion.div
                      key={e.id}
                      layout
                      initial={{ opacity: 0, x: -6 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -6 }}
                      transition={{ delay: Math.min(i * 0.015, 0.3) }}
                      className="relative pl-10"
                    >
                      {/* Timeline node */}
                      <div
                        className="absolute left-[12px] top-3 h-3 w-3 rounded-full border-2 z-10"
                        style={{ borderColor: config.color, background: 'var(--j-bg)', boxShadow: `0 0 8px ${config.color}55` }}
                      >
                        <div className="absolute inset-0.5 rounded-full" style={{ background: config.color }} />
                      </div>
                      <div
                        className="jarvis-panel p-3 hover:border-[var(--j-border)] transition-colors cursor-pointer group"
                        onClick={() => toggle(e.id)}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className="shrink-0 mt-0.5 h-7 w-7 rounded-md flex items-center justify-center"
                            style={{ background: `${config.color}1a`, color: config.color }}
                          >
                            <config.icon className="h-3.5 w-3.5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-0.5">
                              <span
                                className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold tracking-wider uppercase"
                                style={{ color: config.color, background: `${config.color}1a` }}
                              >
                                {e.channel}
                              </span>
                              <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{timeAgo(new Date(e.createdAt))}</span>
                              {e.broadcastTo !== 'all' && (
                                <span className="jarvis-mono text-[9px] px-1 py-0.5 rounded" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.1)' }}>
                                  → {e.broadcastTo}
                                </span>
                              )}
                            </div>
                            {/* Compact payload preview */}
                            {!isOpen && (
                              <p className="text-[11px] text-[var(--j-text-dim)] truncate jarvis-mono">
                                {payloadStr.slice(0, 80)}{payloadStr.length > 80 ? '…' : ''}
                              </p>
                            )}
                            {/* Expanded payload */}
                            <AnimatePresence>
                              {isOpen && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: 'auto', opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{ duration: 0.18 }}
                                  className="overflow-hidden"
                                >
                                  <div className="mt-2 pt-2 border-t border-[var(--j-border)]">
                                    <pre className="text-[10px] jarvis-mono text-[var(--j-text-dim)] bg-[var(--j-bg)] p-2.5 rounded-md overflow-x-auto max-h-48">
                                      {payloadStr}
                                    </pre>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                          <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-[var(--j-text-mute)] mt-1 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>

      {/* Channels reference */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3">
          <Server className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Available Channels · {channels.length}</h4>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {channels.map((ch) => {
            const config = CHANNEL_CONFIG[ch] ?? { color: JARVIS.colors.cyan, icon: Activity, label: ch };
            return (
              <div
                key={ch}
                className="flex items-center gap-2 p-2 rounded-md border"
                style={{ borderColor: `${config.color}33`, background: `${config.color}08` }}
              >
                <config.icon className="h-3.5 w-3.5 shrink-0" style={{ color: config.color }} />
                <div className="min-w-0">
                  <div className="jarvis-mono text-[10px] font-semibold truncate" style={{ color: config.color }}>{config.label}</div>
                  <div className="jarvis-mono text-[8px] text-[var(--j-text-mute)] truncate">{ch}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Status Card ──────────────────────────────────────────────────────
function StatusCard({
  icon: Icon,
  label,
  value,
  color,
  pulse,
}: {
  icon: typeof Wifi;
  label: string;
  value: string | number;
  color: string;
  pulse?: boolean;
}) {
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
        {pulse && (
          <span
            className="h-2 w-2 rounded-full"
            style={{ background: color, boxShadow: `0 0 6px ${color}`, animation: 'jarvis-pulse 2s ease-in-out infinite' }}
          />
        )}
      </div>
    </div>
  );
}
