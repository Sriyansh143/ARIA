'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, AlertTriangle, CheckCircle2, XCircle, Search, Filter,
  RefreshCw, Loader2, Bot, Target, Zap, TrendingUp, Award, ChevronDown,
  ChevronRight, Lightbulb, AlertOctagon, BookOpen,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
  Cell,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ─── Types ────────────────────────────────────────────────────────────
interface MissingSkill {
  key: string;
  name: string;
  category: string;
}

interface LowProficiencySkill {
  skill: string;
  proficiency: number;
}

interface AgentAnalysis {
  codename: string;
  name: string;
  role: string;
  status: string;
  load: number;
  successRate: number;
  taskCount: number;
  declaredSkills: string[];
  learnedSkills: string[];
  requiredSkills: string[];
  missingSkills: MissingSkill[];
  lowProficiencySkills: LowProficiencySkill[];
  gapScore: number;
  priority: 'critical' | 'high' | 'medium' | 'low';
  totalSkills: number;
}

interface GapData {
  analyses: AgentAnalysis[];
  summary: {
    totalAgents: number;
    agentsWithGaps: number;
    agentsCritical: number;
    agentsHigh: number;
    totalMissingSkills: number;
    totalLowProficiency: number;
    avgGapScore: number;
    mostCommonGaps: Array<{ key: string; name: string; count: number }>;
  };
}

const PRIORITY_CONFIG: Record<string, { color: string; icon: typeof AlertTriangle; label: string }> = {
  critical: { color: JARVIS.colors.red, icon: AlertOctagon, label: 'Critical' },
  high: { color: JARVIS.colors.amber, icon: AlertTriangle, label: 'High' },
  medium: { color: JARVIS.colors.cyan, icon: Zap, label: 'Medium' },
  low: { color: JARVIS.colors.green, icon: CheckCircle2, label: 'Low' },
};

export default function SkillGapAnalyzerTab() {
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);

  const { data, loading, refresh } = useApi<GapData>('/api/skills/gap-analysis', 30000);

  const analyses = data?.analyses ?? [];
  const summary = data?.summary;

  const filtered = useMemo(() => {
    return analyses.filter((a) => {
      if (priorityFilter !== 'all' && a.priority !== priorityFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        const haystack = `${a.codename} ${a.name} ${a.role}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [analyses, priorityFilter, search]);

  const chartData = useMemo(() => {
    return (summary?.mostCommonGaps ?? []).map((g) => ({
      skill: g.name.length > 12 ? g.name.slice(0, 11) + '…' : g.name,
      count: g.count,
    }));
  }, [summary]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Skill Gap Analysis · Training Recommendations</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Skill Gap Analyzer</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Identifies which agents are missing critical skills for their roles. Recommends training priority based on gap severity.
          </p>
        </div>
        <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''} mr-1.5`} /> Refresh
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <SummaryCard icon={Bot} label="Total Agents" value={summary?.totalAgents ?? 0} color={JARVIS.colors.cyan} />
        <SummaryCard icon={AlertTriangle} label="With Gaps" value={summary?.agentsWithGaps ?? 0} color={JARVIS.colors.amber} />
        <SummaryCard icon={AlertOctagon} label="Critical" value={summary?.agentsCritical ?? 0} color={JARVIS.colors.red} />
        <SummaryCard icon={Zap} label="High Priority" value={summary?.agentsHigh ?? 0} color={JARVIS.colors.amber} />
        <SummaryCard icon={XCircle} label="Missing Skills" value={summary?.totalMissingSkills ?? 0} color={JARVIS.colors.red} />
        <SummaryCard icon={TrendingUp} label="Low Proficiency" value={summary?.totalLowProficiency ?? 0} color={JARVIS.colors.violet} />
        <SummaryCard icon={Target} label="Avg Gap Score" value={summary?.avgGapScore ?? 0} color={JARVIS.colors.cyan} />
      </div>

      {/* Most common gaps chart + priority distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Most common gaps */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Award className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Most Common Skill Gaps</h4>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} horizontal={false} />
                <XAxis type="number" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="skill" tick={{ fill: '#94A3B8', fontSize: 10 }} axisLine={false} tickLine={false} width={80} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(v: number) => [`${v} agents missing`, 'Count']}
                  cursor={{ fill: 'rgba(248,113,113,0.05)' }}
                />
                <Bar dataKey="count" radius={[0, 3, 3, 0]}>
                  {chartData.map((_, i) => (
                    <Cell key={i} fill={JARVIS.colors.red} fillOpacity={0.3 + (i / Math.max(chartData.length, 1)) * 0.7} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Priority distribution */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Target className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Training Priority Distribution</h4>
          </div>
          <div className="space-y-3 mt-4">
            {(['critical', 'high', 'medium', 'low'] as const).map((p) => {
              const config = PRIORITY_CONFIG[p];
              const count = analyses.filter((a) => a.priority === p).length;
              const pct = analyses.length > 0 ? (count / analyses.length) * 100 : 0;
              return (
                <div key={p}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <config.icon className="h-3.5 w-3.5" style={{ color: config.color }} />
                      <span className="jarvis-mono text-[10px] uppercase tracking-wider" style={{ color: config.color }}>{config.label}</span>
                    </div>
                    <span className="jarvis-mono text-[11px] font-bold tabular-nums" style={{ color: config.color }}>{count}</span>
                  </div>
                  <div className="h-2 rounded-full bg-[var(--j-bg)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.5 }}
                      className="h-full rounded-full"
                      style={{ background: config.color, boxShadow: `0 0 6px ${config.color}66` }}
                    />
                  </div>
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-0.5 block">{pct.toFixed(0)}% of fleet</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="jarvis-panel p-3 flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--j-text-mute)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search agents by codename, name, or role…"
            className="pl-9 h-8 text-sm"
          />
        </div>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[150px] h-8 text-xs">
            <Filter className="h-3 w-3 mr-1" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] ml-auto">
          {filtered.length} / {analyses.length} agents
        </span>
      </div>

      {/* Agent gap list */}
      <div className="jarvis-panel p-0 overflow-hidden">
        {loading && analyses.length === 0 ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-16 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center">
            <GraduationCap className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm text-[var(--j-text-mute)]">No agents match the current filters.</p>
          </div>
        ) : (
          <div className="max-h-[700px] overflow-y-auto">
            {filtered.map((a, i) => {
              const config = PRIORITY_CONFIG[a.priority];
              const isOpen = expandedAgent === a.codename;
              return (
                <motion.div
                  key={a.codename}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.02, 0.4) }}
                  className="border-b border-[var(--j-border)] last:border-b-0"
                >
                  <div
                    className="flex items-center gap-3 p-3 hover:bg-[var(--j-panel-soft)]/40 cursor-pointer transition-colors"
                    onClick={() => setExpandedAgent(isOpen ? null : a.codename)}
                  >
                    {isOpen ? <ChevronDown className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" /> : <ChevronRight className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" />}
                    {/* Priority indicator */}
                    <div className="h-8 w-1 rounded-full shrink-0" style={{ background: config.color, boxShadow: `0 0 6px ${config.color}66` }} />
                    {/* Agent avatar */}
                    <div className="h-8 w-8 rounded-md flex items-center justify-center jarvis-mono text-[10px] font-bold shrink-0" style={{ background: `${config.color}1a`, color: config.color }}>
                      {a.codename.slice(0, 2)}
                    </div>
                    {/* Agent info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-semibold text-sm truncate">{a.codename}</span>
                        <span className="text-[10px] text-[var(--j-text-mute)] truncate">· {a.role}</span>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider" style={{ color: config.color, background: `${config.color}1a` }}>
                          {config.label}
                        </span>
                        {a.missingSkills.length > 0 && (
                          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">
                            <XCircle className="h-2.5 w-2.5 inline mr-0.5" style={{ color: JARVIS.colors.red }} />
                            {a.missingSkills.length} missing
                          </span>
                        )}
                        {a.lowProficiencySkills.length > 0 && (
                          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">
                            <AlertTriangle className="h-2.5 w-2.5 inline mr-0.5" style={{ color: JARVIS.colors.amber }} />
                            {a.lowProficiencySkills.length} low prof
                          </span>
                        )}
                        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">
                          <CheckCircle2 className="h-2.5 w-2.5 inline mr-0.5" style={{ color: JARVIS.colors.green }} />
                          {a.totalSkills} known
                        </span>
                      </div>
                    </div>
                    {/* Gap score */}
                    <div className="text-right shrink-0">
                      <div className="jarvis-mono text-lg font-bold tabular-nums" style={{ color: config.color }}>{a.gapScore}</div>
                      <div className="jarvis-mono text-[8px] uppercase text-[var(--j-text-mute)]">gap score</div>
                    </div>
                  </div>
                  {/* Expanded detail */}
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-[var(--j-panel-soft)]/30"
                      >
                        <div className="p-3 pl-12 space-y-3">
                          {/* Missing skills */}
                          {a.missingSkills.length > 0 && (
                            <div>
                              <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 flex items-center gap-1">
                                <XCircle className="h-3 w-3" style={{ color: JARVIS.colors.red }} /> Missing Skills ({a.missingSkills.length})
                              </p>
                              <div className="flex flex-wrap gap-1.5">
                                {a.missingSkills.map((s) => (
                                  <span key={s.key} className="jarvis-mono text-[10px] px-2 py-1 rounded-md border" style={{ borderColor: `${JARVIS.colors.red}33`, background: `${JARVIS.colors.red}0a`, color: JARVIS.colors.red }}>
                                    {s.name} <span className="text-[8px] opacity-60">· {s.category}</span>
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                          {/* Low proficiency */}
                          {a.lowProficiencySkills.length > 0 && (
                            <div>
                              <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" style={{ color: JARVIS.colors.amber }} /> Low Proficiency (&lt;40%)
                              </p>
                              <div className="space-y-1">
                                {a.lowProficiencySkills.map((lp) => (
                                  <div key={lp.skill} className="flex items-center gap-2">
                                    <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] w-32 truncate">{lp.skill}</span>
                                    <div className="flex-1 h-1.5 rounded-full bg-[var(--j-bg)] overflow-hidden max-w-[200px]">
                                      <div className="h-full rounded-full" style={{ width: `${lp.proficiency}%`, background: JARVIS.colors.amber }} />
                                    </div>
                                    <span className="jarvis-mono text-[10px] font-bold tabular-nums" style={{ color: JARVIS.colors.amber }}>{lp.proficiency}%</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          {/* Required skills */}
                          <div>
                            <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2 flex items-center gap-1">
                              <BookOpen className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} /> Required for Role
                            </p>
                            <div className="flex flex-wrap gap-1.5">
                              {a.requiredSkills.map((s) => {
                                const isMissing = a.missingSkills.some((m) => m.key === s);
                                const color = isMissing ? JARVIS.colors.red : JARVIS.colors.green;
                                return (
                                  <span key={s} className="jarvis-mono text-[10px] px-2 py-1 rounded-md border" style={{ borderColor: `${color}33`, background: `${color}0a`, color }}>
                                    {isMissing ? '✗' : '✓'} {s}
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                          {/* Training recommendation */}
                          <div className="p-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-bg)] flex items-start gap-2">
                            <Lightbulb className="h-3.5 w-3.5 shrink-0 mt-0.5" style={{ color: JARVIS.colors.amber }} />
                            <div>
                              <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-1">Training Recommendation</p>
                              <p className="text-[11px] text-[var(--j-text-dim)] leading-relaxed">
                                {a.priority === 'critical' && `URGENT: ${a.codename} has ${a.missingSkills.length} missing critical skills. Assign to an autonomy loop to learn: ${a.missingSkills.slice(0, 3).map((s) => s.name).join(', ')}.`}
                                {a.priority === 'high' && `Priority training needed. Focus on: ${a.missingSkills.slice(0, 2).map((s) => s.name).join(', ')} + improve ${a.lowProficiencySkills.length} low-proficiency skills.`}
                                {a.priority === 'medium' && `Moderate gaps. Improve proficiency on ${a.lowProficiencySkills.length} skills via skill runs.`}
                                {a.priority === 'low' && `Well-equipped. ${a.totalSkills} skills known, minimal gaps. Maintain current proficiency.`}
                              </p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}
