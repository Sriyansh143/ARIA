'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, Rocket, Calendar, Plus, Trash2, Play, Pause, RefreshCw,
  Loader2, Bot, AlertTriangle, CheckCircle2, XCircle, Clock, Zap, Target,
  Award, TrendingUp, BookOpen, ChevronRight, Sparkles,
} from 'lucide-react';
import { useApi, postJson, patchJson, deleteJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ─── Types ────────────────────────────────────────────────────────────
interface Schedule {
  id: string;
  agentCodename: string;
  topic: string;
  intervalMin: number;
  enabled: boolean;
  lastRun: string | null;
  runCount: number;
  lastResult: string | null;
  createdAt: string;
}

interface MissingSkill {
  key: string;
  name: string;
  category: string;
}

interface AgentAnalysis {
  codename: string;
  name: string;
  role: string;
  missingSkills: MissingSkill[];
  gapScore: number;
  priority: 'critical' | 'high' | 'medium' | 'low';
}

interface GapData {
  analyses: AgentAnalysis[];
  summary: { totalAgents: number; agentsWithGaps: number; agentsCritical: number; totalMissingSkills: number };
}

const PRIORITY_COLORS: Record<string, string> = {
  critical: JARVIS.colors.red,
  high: JARVIS.colors.amber,
  medium: JARVIS.colors.cyan,
  low: JARVIS.colors.green,
};

const INTERVAL_OPTIONS = [
  { value: 15, label: '15 min' },
  { value: 30, label: '30 min' },
  { value: 60, label: '1 hour' },
  { value: 120, label: '2 hours' },
  { value: 360, label: '6 hours' },
  { value: 720, label: '12 hours' },
  { value: 1440, label: '24 hours' },
];

export default function TrainingSchedulerTab() {
  const { toast } = useToast();
  const [creating, setCreating] = useState<string | null>(null);
  const [intervalMin, setIntervalMin] = useState(60);

  const { data: schedulesData, loading: schedLoading, refresh: refreshSchedules } = useApi<{ schedules: Schedule[] }>('/api/scheduled-autonomy', 15000);
  const { data: gapData, loading: gapLoading } = useApi<GapData>('/api/skills/gap-analysis', 30000);

  const schedules = schedulesData?.schedules ?? [];
  const analyses = gapData?.analyses ?? [];

  // Build training recommendations from gap analysis (critical + high priority agents)
  // FILTER OUT agents that already have a training schedule — once sent to
  // training, they're removed from the recommendations list (no repeat).
  const recommendations = useMemo(() => {
    return analyses
      .filter((a) => a.priority === 'critical' || a.priority === 'high')
      .filter((a) => !schedules.some((s) => s.agentCodename === a.codename))
      .slice(0, 12)
      .map((a) => ({
        codename: a.codename,
        role: a.role,
        priority: a.priority,
        gapScore: a.gapScore,
        primarySkill: a.missingSkills[0]?.name ?? 'general training',
        allMissing: a.missingSkills,
        topic: `Learn ${a.missingSkills.slice(0, 3).map((s) => s.name).join(', ')} — skill gap training for ${a.role}`,
        alreadyScheduled: false,
      }));
  }, [analyses, schedules]);

  const handleCreateSchedule = useCallback(async (codename: string, topic: string) => {
    setCreating(codename);
    try {
      const res = await postJson<{ error?: string; schedule?: Schedule }>('/api/scheduled-autonomy', {
        agentCodename: codename,
        topic,
        intervalMin,
      });
      if (res.schedule) {
        toast({ title: 'Training scheduled', description: `${codename} → every ${intervalMin}min` });
        refreshSchedules();
      } else {
        toast({ title: 'Failed', description: res.error ?? 'unknown', variant: 'destructive' });
      }
    } catch (err) {
      toast({ title: 'Failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    } finally {
      setCreating(null);
    }
  }, [intervalMin, toast, refreshSchedules]);

  const handleToggle = useCallback(async (schedule: Schedule) => {
    try {
      // PATCH toggles `enabled`. (POST would trigger a training run instead.)
      await patchJson(`/api/scheduled-autonomy/${schedule.id}`, { enabled: !schedule.enabled });
      toast({ title: schedule.enabled ? 'Paused' : 'Resumed', description: schedule.topic.slice(0, 50) });
      refreshSchedules();
    } catch (err) {
      toast({ title: 'Failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshSchedules]);

  const handleDelete = useCallback(async (id: string) => {
    try {
      await deleteJson(`/api/scheduled-autonomy/${id}`);
      toast({ title: 'Schedule deleted' });
      refreshSchedules();
    } catch (err) {
      toast({ title: 'Failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshSchedules]);

  const handleRunNow = useCallback(async (schedule: Schedule) => {
    try {
      // POST to the schedule's own route triggers a run NOW. The route
      // returns { schedule, lastResult, skillKey, training, runSuccess, skipped? }.
      const res = await postJson<{
        schedule?: Schedule;
        lastResult?: string;
        skillKey?: string;
        training?: { proficiency: number; preProficiency: number; trainingCount: number; onCooldown: boolean };
        runSuccess?: boolean;
        skipped?: boolean;
        reason?: string;
        error?: string;
      }>(`/api/scheduled-autonomy/${schedule.id}`, {});
      if (res.error) {
        toast({ title: 'Run failed', description: res.error, variant: 'destructive' });
      } else if (res.skipped) {
        toast({ title: 'Training skipped (cooldown)', description: res.reason ?? 'Agent already proficient — no retraining needed yet.' });
      } else {
        const t = res.training;
        toast({
          title: res.runSuccess ? 'Training complete' : 'Training ran (no task)',
          description: t
            ? `${schedule.agentCodename} · ${res.skillKey}: ${t.preProficiency}%→${t.proficiency}% (run #${t.trainingCount})`
            : res.lastResult?.slice(0, 90),
        });
      }
      refreshSchedules();
    } catch (err) {
      toast({ title: 'Run failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshSchedules]);

  const handleScheduleAll = useCallback(async () => {
    const unscheduled = recommendations.filter((r) => !r.alreadyScheduled);
    if (unscheduled.length === 0) {
      toast({ title: 'All recommendations already scheduled' });
      return;
    }
    let created = 0;
    for (const rec of unscheduled) {
      try {
        const res = await postJson<{ schedule?: Schedule }>('/api/scheduled-autonomy', {
          agentCodename: rec.codename,
          topic: rec.topic,
          intervalMin,
        });
        if (res.schedule) created++;
      } catch { /* skip duplicates */ }
    }
    toast({ title: 'Batch scheduled', description: `${created}/${unscheduled.length} training loops created` });
    refreshSchedules();
  }, [recommendations, intervalMin, toast, refreshSchedules]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Autonomy-Loop Training Scheduler · Auto-Skill Development</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Training Scheduler</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Schedule autonomy loops that train agents on missing skills. One-click creation from gap-analysis recommendations.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={String(intervalMin)} onValueChange={(v) => setIntervalMin(Number(v))}>
            <SelectTrigger className="w-[110px] h-8 text-xs">
              <Clock className="h-3 w-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {INTERVAL_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={String(o.value)}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleScheduleAll} className="jarvis-btn-accent border-0" disabled={recommendations.filter((r) => !r.alreadyScheduled).length === 0}>
            <Zap className="h-3.5 w-3.5 mr-1.5" /> Schedule All Gaps
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SummaryCard icon={Calendar} label="Active Schedules" value={schedules.filter((s) => s.enabled).length} color={JARVIS.colors.green} />
        <SummaryCard icon={Rocket} label="Total Schedules" value={schedules.length} color={JARVIS.colors.cyan} />
        <SummaryCard icon={AlertTriangle} label="Training Recommendations" value={recommendations.length} color={JARVIS.colors.amber} />
        <SummaryCard icon={CheckCircle2} label="Already Scheduled" value={recommendations.filter((r) => r.alreadyScheduled).length} color={JARVIS.colors.green} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: Training recommendations from gap analysis */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Recommended Training</h4>
            <span className="jarvis-mono text-[10px] ml-auto text-[var(--j-text-mute)]">from skill gap analysis</span>
          </div>
          {gapLoading && recommendations.length === 0 ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-14 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          ) : recommendations.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle2 className="h-8 w-8 mx-auto mb-2" style={{ color: JARVIS.colors.green }} />
              <p className="text-sm text-[var(--j-text-mute)]">No critical skill gaps — fleet is well-equipped.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {recommendations.map((rec, i) => {
                const color = PRIORITY_COLORS[rec.priority];
                return (
                  <motion.div
                    key={rec.codename}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="p-2.5 rounded-md border bg-[var(--j-panel-soft)]/60"
                    style={{ borderColor: `${color}33`, borderLeftWidth: 3, borderLeftColor: color }}
                  >
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="h-7 w-7 rounded-md flex items-center justify-center jarvis-mono text-[9px] font-bold shrink-0" style={{ background: `${color}1a`, color }}>
                        {rec.codename.slice(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-xs">{rec.codename}</span>
                          <span className="jarvis-mono text-[9px] px-1 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>{rec.priority}</span>
                          {rec.alreadyScheduled && <CheckCircle2 className="h-3 w-3" style={{ color: JARVIS.colors.green }} />}
                        </div>
                        <div className="text-[9px] text-[var(--j-text-mute)] truncate">{rec.role}</div>
                      </div>
                      <span className="jarvis-mono text-[10px] font-bold tabular-nums" style={{ color }}>{rec.gapScore}</span>
                    </div>
                    <p className="text-[10px] text-[var(--j-text-dim)] mb-2 line-clamp-2">{rec.topic}</p>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {rec.allMissing.slice(0, 4).map((s) => (
                        <span key={s.key} className="jarvis-mono text-[8px] px-1.5 py-0.5 rounded border border-[var(--j-border)] bg-[var(--j-bg)] text-[var(--j-text-mute)] uppercase">{s.name}</span>
                      ))}
                      {rec.allMissing.length > 4 && <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">+{rec.allMissing.length - 4}</span>}
                      <button
                        onClick={() => handleCreateSchedule(rec.codename, rec.topic)}
                        disabled={rec.alreadyScheduled || creating === rec.codename}
                        className="ml-auto flex items-center gap-1 h-6 px-2 rounded-md border text-[10px] font-medium transition-all disabled:opacity-50"
                        style={{ borderColor: `${color}44`, background: `${color}0a`, color }}
                      >
                        {creating === rec.codename ? <Loader2 className="h-2.5 w-2.5 animate-spin" /> : <Plus className="h-2.5 w-2.5" />}
                        <span className="jarvis-mono text-[9px] uppercase">{rec.alreadyScheduled ? 'Scheduled' : 'Schedule'}</span>
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Active training schedules */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Active Training Schedules</h4>
            <button onClick={refreshSchedules} className="ml-auto">
              <RefreshCw className={`h-3.5 w-3.5 text-[var(--j-text-mute)] hover:text-[var(--j-green)] ${schedLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          {schedLoading && schedules.length === 0 ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}</div>
          ) : schedules.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm text-[var(--j-text-mute)]">No training schedules yet.</p>
              <p className="text-[10px] text-[var(--j-text-mute)] mt-1">Click "Schedule" on a recommendation to create one.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              <AnimatePresence>
                {schedules.map((s, i) => {
                  const color = s.enabled ? JARVIS.colors.green : JARVIS.colors.textMute;
                  return (
                    <motion.div
                      key={s.id}
                      layout
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 8 }}
                      transition={{ delay: i * 0.02 }}
                      className="p-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]/60"
                    >
                      <div className="flex items-center gap-2 mb-1.5">
                        <div className="h-7 w-7 rounded-md flex items-center justify-center jarvis-mono text-[9px] font-bold shrink-0" style={{ background: `${color}1a`, color }}>
                          {s.agentCodename.slice(0, 2)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-xs">{s.agentCodename}</span>
                            <span className="jarvis-mono text-[9px] px-1 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>
                              {s.enabled ? 'Active' : 'Paused'}
                            </span>
                          </div>
                          <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] flex items-center gap-1">
                            <Clock className="h-2.5 w-2.5" /> every {s.intervalMin}min · {s.runCount} runs
                          </div>
                        </div>
                      </div>
                      <p className="text-[10px] text-[var(--j-text-dim)] mb-2 line-clamp-2">{s.topic}</p>
                      {s.lastRun && (
                        <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mb-2">
                          Last run: {timeAgo(new Date(s.lastRun))}
                          {s.lastResult && <span className="ml-2">· {s.lastResult.slice(0, 40)}</span>}
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRunNow(s)}
                          className="flex items-center gap-1 h-6 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-[10px]"
                          title="Run now"
                        >
                          <Play className="h-2.5 w-2.5" />
                          <span className="jarvis-mono text-[9px] uppercase">Run</span>
                        </button>
                        <button
                          onClick={() => handleToggle(s)}
                          className="flex items-center gap-1 h-6 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-amber)] hover:border-[var(--j-amber)] transition-colors text-[10px]"
                          title={s.enabled ? 'Pause' : 'Resume'}
                        >
                          {s.enabled ? <Pause className="h-2.5 w-2.5" /> : <Play className="h-2.5 w-2.5" />}
                          <span className="jarvis-mono text-[9px] uppercase">{s.enabled ? 'Pause' : 'Resume'}</span>
                        </button>
                        <button
                          onClick={() => handleDelete(s.id)}
                          className="flex items-center gap-1 h-6 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-red)] hover:border-[var(--j-red)] transition-colors text-[10px] ml-auto"
                          title="Delete"
                        >
                          <Trash2 className="h-2.5 w-2.5" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* How it works */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">How Training Loops Work</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {[
            { icon: AlertTriangle, title: '1 · Detect Gaps', desc: 'The Skill Gap Analyzer identifies missing skills per agent based on role requirements.', color: JARVIS.colors.red },
            { icon: Plus, title: '2 · Schedule Training', desc: 'Create an autonomy loop for the agent to learn the missing skill on a recurring interval.', color: JARVIS.colors.amber },
            { icon: Rocket, title: '3 · Autonomy Loop Runs', desc: 'The agent runs a research + learning cycle via GLM-4.6, saving results to SkillLearning.', color: JARVIS.colors.cyan },
            { icon: Award, title: '4 · Proficiency Improves', desc: 'Each run increments proficiency. The Skills Matrix tracks progress over time.', color: JARVIS.colors.green },
          ].map((step, i) => (
            <div key={i} className="p-3 rounded-md border bg-[var(--j-panel-soft)]/40" style={{ borderColor: `${step.color}33` }}>
              <div className="flex items-center gap-2 mb-2">
                <div className="h-7 w-7 rounded-md flex items-center justify-center shrink-0" style={{ background: `${step.color}1a`, color: step.color }}>
                  <step.icon className="h-3.5 w-3.5" />
                </div>
                <span className="jarvis-mono text-[10px] uppercase tracking-wider font-bold" style={{ color: step.color }}>{step.title}</span>
              </div>
              <p className="text-[10px] text-[var(--j-text-dim)] leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}
