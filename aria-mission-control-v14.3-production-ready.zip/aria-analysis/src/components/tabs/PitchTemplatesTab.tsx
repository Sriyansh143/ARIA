'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import {
  LayoutTemplate,
  Sparkles,
  Wand2,
  Download,
  Copy,
  Check,
  Loader2,
  Eye,
  Code2,
  ExternalLink,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

/* ---------- Types ---------- */

interface TemplateMetadata {
  id: 'aurora-3d' | 'cinematic-scroll' | 'sticky-parallax';
  name: string;
  description: string;
  industries: string[];
  features: string[];
  accent: string;
  estimatedSizeKb: number;
  bestFor: string;
}

interface IndustryOption {
  key: string;
  label: string;
}

interface TemplatesApiResponse {
  templates: TemplateMetadata[];
  industries: IndustryOption[];
  defaultTemplateId: string;
  defaultIndustry: string;
}

interface GenerateApiResponse {
  html: string;
  metadata: TemplateMetadata;
  businessName: string;
  industry: string;
  headline: string;
  templateId: string;
  sizeBytes: number;
  sizeKb: number;
}

/* ---------- Component ---------- */

export default function PitchTemplatesTab() {
  const { toast } = useToast();
  const { data, loading, error } = useApi<TemplatesApiResponse>(
    '/api/pitch-templates',
    -1,
  );

  const templates = data?.templates ?? [];
  const industries = data?.industries ?? [];

  // Form state
  const [businessName, setBusinessName] = useState('');
  const [industry, setIndustry] = useState('restaurant');
  const [headline, setHeadline] = useState('');
  const [templateId, setTemplateId] = useState<
    'aurora-3d' | 'cinematic-scroll' | 'sticky-parallax'
  >('aurora-3d');

  // Generation state
  const [generating, setGenerating] = useState(false);
  const [generatedHtml, setGeneratedHtml] = useState('');
  const [generatedMeta, setGeneratedMeta] = useState<TemplateMetadata | null>(null);
  const [generatedInfo, setGeneratedInfo] = useState<{
    businessName: string;
    headline: string;
    sizeKb: number;
  } | null>(null);

  // UI helpers
  const [copied, setCopied] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  /* Default form values once API responds */
  useEffect(() => {
    if (data) {
      if (!industry) setIndustry(data.defaultIndustry ?? 'restaurant');
      if (!templateId) setTemplateId((data.defaultTemplateId as typeof templateId) ?? 'aurora-3d');
    }
  }, [data, industry, templateId]);

  /* Write generated HTML into the iframe via srcdoc (works without same-origin
     headaches — the iframe gets a fresh document each render). */
  useEffect(() => {
    if (iframeRef.current && generatedHtml) {
      iframeRef.current.srcdoc = generatedHtml;
    }
  }, [generatedHtml]);

  /* ---------- Actions ---------- */

  const handleGenerate = async () => {
    if (!businessName.trim()) {
      toast({ title: 'Business name required', variant: 'destructive' });
      return;
    }
    if (!headline.trim()) {
      toast({ title: 'Headline required', variant: 'destructive' });
      return;
    }
    setGenerating(true);
    setGeneratedHtml('');
    setGeneratedMeta(null);
    setGeneratedInfo(null);
    try {
      const res = (await postJson('/api/pitch-templates/generate', {
        businessName: businessName.trim(),
        industry,
        headline: headline.trim(),
        templateId,
      })) as GenerateApiResponse;
      setGeneratedHtml(res.html);
      setGeneratedMeta(res.metadata);
      setGeneratedInfo({
        businessName: res.businessName,
        headline: res.headline,
        sizeKb: res.sizeKb,
      });
      toast({
        title: 'Template generated',
        description: `${res.metadata.name} · ${res.sizeKb} KB`,
      });
    } catch (e) {
      toast({
        title: 'Generation failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedHtml) return;
    const slug = (businessName || 'pitch')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    const blob = new Blob([generatedHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${slug}-${templateId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: 'Downloaded', description: a.download });
  };

  const handleCopy = async () => {
    if (!generatedHtml) return;
    try {
      await navigator.clipboard.writeText(generatedHtml);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      toast({ title: 'Copied', description: 'HTML copied to clipboard' });
    } catch {
      toast({
        title: 'Copy failed',
        description: 'Clipboard not available — try Download instead.',
        variant: 'destructive',
      });
    }
  };

  const handleOpenInNewTab = () => {
    if (!generatedHtml) return;
    const blob = new Blob([generatedHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'noopener,noreferrer');
    // Revoke after 30s (give the new tab time to load).
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  };

  /* ---------- Render ---------- */

  const selectedTemplate = useMemo(
    () => templates.find((t) => t.id === templateId) ?? null,
    [templates, templateId],
  );

  return (
    <div className="space-y-4">
      <SectionTitle
        title="3D Pitch Templates"
        icon={LayoutTemplate}
        accent={JARVIS.colors.cyan}
        action={
          <div className="flex items-center gap-2">
            <Pill color={JARVIS.colors.cyan}>{templates.length} templates</Pill>
            <Pill color={JARVIS.colors.violet}>{industries.length} industries</Pill>
          </div>
        }
      />

      {/* ---------- Error state ---------- */}
      {error && (
        <Card className="p-4 jarvis-panel border-[var(--j-red)]/40 bg-[var(--j-panel)]">
          <div className="text-xs text-[var(--j-red)]">
            Failed to load templates: {error}
          </div>
        </Card>
      )}

      {/* ---------- Template cards ---------- */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {loading && templates.length === 0
          ? Array.from({ length: 3 }).map((_, i) => (
              <Card
                key={i}
                className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-40 animate-pulse"
              />
            ))
          : templates.map((t, idx) => {
              const isSelected = t.id === templateId;
              return (
                <motion.button
                  key={t.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => setTemplateId(t.id)}
                  className={`text-left p-4 rounded-lg border transition-all jarvis-panel ${
                    isSelected
                      ? 'border-[var(--j-cyan)] ring-1 ring-[var(--j-cyan)]/40'
                      : 'border-[var(--j-border)] hover:border-[var(--j-cyan)]/40'
                  }`}
                  style={{ background: 'var(--j-panel)' }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="flex h-7 w-7 items-center justify-center rounded-md"
                        style={{
                          background: `${t.accent}1a`,
                          border: `1px solid ${t.accent}33`,
                          color: t.accent,
                        }}
                      >
                        <LayoutTemplate className="h-3.5 w-3.5" />
                      </div>
                      <h3 className="font-display text-sm font-semibold text-[var(--j-text)]">
                        {t.name}
                      </h3>
                    </div>
                    {isSelected && (
                      <Check
                        className="h-4 w-4"
                        style={{ color: t.accent }}
                      />
                    )}
                  </div>
                  <p className="text-[11px] leading-relaxed text-[var(--j-text-dim)] line-clamp-3 mb-3">
                    {t.description}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {t.features.slice(0, 3).map((f, i) => (
                      <span
                        key={i}
                        className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded"
                        style={{
                          color: t.accent,
                          background: `${t.accent}1a`,
                          border: `1px solid ${t.accent}33`,
                        }}
                      >
                        {f.split(' ').slice(0, 2).join(' ')}
                      </span>
                    ))}
                  </div>
                  <div className="mt-3 pt-2 border-t border-[var(--j-border-soft)] flex items-center justify-between text-[10px] text-[var(--j-text-mute)] jarvis-mono uppercase">
                    <span>~{t.estimatedSizeKb} KB</span>
                    <span style={{ color: t.accent }}>{t.id}</span>
                  </div>
                </motion.button>
              );
            })}
      </div>

      {/* ---------- Form + Preview ---------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form */}
        <Card className="lg:col-span-4 p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-fit">
          <div className="flex items-center gap-2 mb-4">
            <Wand2 className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Generate Pitch
            </h3>
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Business Name
              </Label>
              <Input
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Bella Italia"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Industry
              </Label>
              <Select value={industry} onValueChange={setIndustry}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9 w-full">
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)]">
                  {industries.map((ind) => (
                    <SelectItem
                      key={ind.key}
                      value={ind.key}
                      className="text-xs focus:bg-[var(--j-panel-soft)] focus:text-[var(--j-cyan)]"
                    >
                      {ind.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Hero Headline
              </Label>
              <Input
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                placeholder="e.g. Italian food, redefined."
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Template
              </Label>
              <Select
                value={templateId}
                onValueChange={(v) =>
                  setTemplateId(v as typeof templateId)
                }
              >
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9 w-full">
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)]">
                  {templates.map((t) => (
                    <SelectItem
                      key={t.id}
                      value={t.id}
                      className="text-xs focus:bg-[var(--j-panel-soft)] focus:text-[var(--j-cyan)]"
                    >
                      {t.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedTemplate && (
                <p className="text-[10px] text-[var(--j-text-mute)] leading-relaxed pt-1">
                  {selectedTemplate.bestFor}
                </p>
              )}
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generating || !businessName.trim() || !headline.trim()}
              className="jarvis-btn-accent border-0 w-full"
            >
              {generating ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Generating…
                </>
              ) : (
                <>
                  <Sparkles className="h-3.5 w-3.5 mr-1.5" /> Generate 3D Pitch
                </>
              )}
            </Button>
          </div>

          {/* Quick fill suggestions */}
          <div className="mt-4 pt-3 border-t border-[var(--j-border-soft)]">
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-2">
              Quick fills
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                { name: 'Bella Italia', ind: 'restaurant', head: 'Italian food, redefined.' },
                { name: 'FitCore Gym', ind: 'fitness', head: 'Stronger every day.' },
                { name: 'Skyline Realty', ind: 'real-estate', head: 'Find your next address.' },
                { name: 'MediCare Clinic', ind: 'healthcare', head: 'Care that listens.' },
              ].map((q) => (
                <button
                  key={q.name}
                  onClick={() => {
                    setBusinessName(q.name);
                    setIndustry(q.ind);
                    setHeadline(q.head);
                  }}
                  className="jarvis-mono text-[9px] uppercase px-2 py-1 rounded border transition-all hover:scale-105"
                  style={{
                    borderColor: `${JARVIS.colors.cyan}40`,
                    color: JARVIS.colors.cyan,
                    background: `${JARVIS.colors.cyan}10`,
                  }}
                >
                  {q.name}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Preview */}
        <Card className="lg:col-span-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] overflow-hidden">
          {/* Toolbar */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-[var(--j-border-soft)] bg-[var(--j-panel-soft)]">
            <div className="flex items-center gap-2">
              <Eye className="h-3.5 w-3.5" style={{ color: JARVIS.colors.cyan }} />
              <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-dim)]">
                Live Preview
              </span>
              {generatedInfo && (
                <Pill color={JARVIS.colors.green}>
                  {generatedInfo.sizeKb} KB
                </Pill>
              )}
              {generatedMeta && (
                <Pill color={generatedMeta.accent}>{generatedMeta.name}</Pill>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={handleOpenInNewTab}
                disabled={!generatedHtml}
                className="border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)] h-7 text-[10px]"
              >
                <ExternalLink className="h-3 w-3 mr-1" /> New Tab
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopy}
                disabled={!generatedHtml}
                className="border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)] h-7 text-[10px]"
              >
                {copied ? (
                  <>
                    <Check className="h-3 w-3 mr-1" style={{ color: JARVIS.colors.green }} /> Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3 mr-1" /> Copy
                  </>
                )}
              </Button>
              <Button
                size="sm"
                onClick={handleDownload}
                disabled={!generatedHtml}
                className="jarvis-btn-accent border-0 h-7 text-[10px]"
              >
                <Download className="h-3 w-3 mr-1" /> Download
              </Button>
            </div>
          </div>

          {/* Iframe / Empty state */}
          <div
            className="relative bg-[var(--j-bg)]"
            style={{ minHeight: '620px' }}
          >
            {generatedHtml ? (
              <iframe
                ref={iframeRef}
                title="Pitch Preview"
                className="w-full border-0"
                style={{ height: '620px', background: 'white' }}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              />
            ) : (
              <div
                className="flex flex-col items-center justify-center text-center px-6"
                style={{ minHeight: '620px' }}
              >
                <div
                  className="flex h-16 w-16 items-center justify-center rounded-2xl mb-4 jarvis-enter"
                  style={{
                    background: `${JARVIS.colors.cyan}1a`,
                    border: `1px solid ${JARVIS.colors.cyan}33`,
                    color: JARVIS.colors.cyan,
                  }}
                >
                  <Code2 className="h-8 w-8 opacity-70" />
                </div>
                <div className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text-dim)] mb-1">
                  {generating ? 'Generating preview…' : 'No preview yet'}
                </div>
                <div className="text-[11px] text-[var(--j-text-mute)] max-w-sm">
                  {generating
                    ? 'Building your 3D scroll-animation pitch website.'
                    : 'Fill out the form and click "Generate 3D Pitch" to see your pitch website rendered live here.'}
                </div>
              </div>
            )}
          </div>

          {/* Info bar */}
          {generatedInfo && (
            <div className="flex flex-wrap items-center gap-3 px-4 py-2 border-t border-[var(--j-border-soft)] bg-[var(--j-panel-soft)] text-[10px] jarvis-mono uppercase text-[var(--j-text-mute)]">
              <span>
                <span className="text-[var(--j-text-dim)]">Business:</span>{' '}
                {generatedInfo.businessName}
              </span>
              <span>
                <span className="text-[var(--j-text-dim)]">Headline:</span>{' '}
                {generatedInfo.headline}
              </span>
              <span className="ml-auto">
                {generatedInfo.sizeKb} KB · vanilla JS + Tailwind CDN
              </span>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
