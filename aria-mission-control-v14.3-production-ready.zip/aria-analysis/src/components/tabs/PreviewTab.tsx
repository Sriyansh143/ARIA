'use client';

import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Eye, Monitor, Smartphone, Tablet, RefreshCw, ExternalLink, Code2, Play, Loader2 } from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';

type ViewMode = 'desktop' | 'tablet' | 'mobile';

export default function PreviewTab() {
  const { toast } = useToast();
  const [url, setUrl] = useState('');
  const [html, setHtml] = useState('');
  const [mode, setMode] = useState<ViewMode>('desktop');
  const [loading, setLoading] = useState(false);
  const [buildPrompt, setBuildPrompt] = useState('');
  const [building, setBuilding] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const viewports: Record<ViewMode, { width: number; label: string; icon: typeof Monitor }> = {
    desktop: { width: 1280, label: 'Desktop', icon: Monitor },
    tablet: { width: 768, label: 'Tablet', icon: Tablet },
    mobile: { width: 375, label: 'Mobile', icon: Smartphone },
  };

  const loadUrl = async () => {
    if (!url.trim()) return;
    setLoading(true);
    // If it's HTML content, render directly
    if (url.trim().startsWith('<')) {
      setHtml(url);
      setLoading(false);
      return;
    }
    // If it's a URL, load in iframe
    setLoading(false);
  };

  const buildApp = async () => {
    if (!buildPrompt.trim()) return;
    setBuilding(true);
    setHtml('');
    try {
      // Ask the AI to build an app and return HTML
      const res = (await postJson('/api/chat', {
        message: `Build a complete single-page HTML app for: ${buildPrompt}\n\nReturn ONLY the full HTML code in a single code block. Include inline CSS and JavaScript. Make it look professional with a modern design. The HTML must be complete and self-contained.`,
      })) as { message: { content: string } };

      const content = res.message?.content ?? '';
      // Extract HTML from code blocks
      const htmlMatch = content.match(/```(?:html)?\s*([\s\S]*?)```/i);
      const extractedHtml = htmlMatch ? htmlMatch[1] : content;

      // Save the built app as an artifact
      await postJson('/api/agent-exec', {
        response: `\`\`\`action
{"method": "POST", "path": "/api/artifacts", "body": {"name": "built-app-${Date.now()}.html", "type": "code", "content": ${JSON.stringify(extractedHtml.slice(0, 100))}}}
\`\`\``,
      });

      setHtml(extractedHtml);
      toast({ title: 'App built!', description: 'Preview is ready below' });
    } catch (e) {
      toast({ title: 'Build failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBuilding(false);
    }
  };

  // Update iframe content when html changes
  useEffect(() => {
    if (iframeRef.current && html) {
      const doc = iframeRef.current.contentDocument;
      if (doc) {
        doc.open();
        doc.write(html);
        doc.close();
      }
    }
  }, [html, mode]);

  const currentViewport = viewports[mode];
  const ViewIcon = currentViewport.icon;

  return (
    <div className="space-y-4">
      <SectionTitle
        title="App Preview"
        icon={Eye}
        accent={JARVIS.colors.cyan}
        action={<Pill color={JARVIS.colors.cyan}>Live Preview</Pill>}
      />

      {/* Build an app section */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center gap-2 mb-3">
          <Code2 className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Build & Preview App</h3>
        </div>
        <div className="space-y-2">
          <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Describe what to build</Label>
          <div className="flex gap-2">
            <Input
              value={buildPrompt}
              onChange={(e) => setBuildPrompt(e.target.value)}
              placeholder="e.g. A todo list app with dark theme and local storage"
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
              onKeyDown={(e) => e.key === 'Enter' && buildApp()}
            />
            <Button onClick={buildApp} disabled={building || !buildPrompt.trim()} className="jarvis-btn-accent border-0 shrink-0">
              {building ? <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Building...</> : <><Play className="h-3.5 w-3.5 mr-1.5" /> Build</>}
            </Button>
          </div>
        </div>
      </Card>

      {/* URL loader */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center gap-2 mb-3">
          <ExternalLink className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Or Load a URL / Paste HTML</h3>
        </div>
        <div className="flex gap-2">
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com or paste HTML directly"
            className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
            onKeyDown={(e) => e.key === 'Enter' && loadUrl()}
          />
          <Button onClick={loadUrl} disabled={loading || !url.trim()} variant="outline" className="border-[var(--j-border)] text-[var(--j-text-dim)] shrink-0">
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5 mr-1.5" />}
            Load
          </Button>
        </div>
      </Card>

      {/* Viewport controls */}
      <div className="flex items-center gap-2">
        {(Object.keys(viewports) as ViewMode[]).map((m) => {
          const v = viewports[m];
          const VIcon = v.icon;
          return (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs jarvis-mono uppercase transition-all ${
                mode === m
                  ? 'bg-[var(--j-cyan)]/20 border border-[var(--j-cyan)] text-[var(--j-cyan)]'
                  : 'bg-[var(--j-panel-soft)] border border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-text)]'
              }`}
            >
              <VIcon className="h-3 w-3" />
              {v.label}
            </button>
          );
        })}
        <div className="ml-auto text-[10px] text-[var(--j-text-mute)] jarvis-mono">
          {currentViewport.width}px
        </div>
      </div>

      {/* Preview area */}
      <Card className="jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] overflow-hidden" style={{ minHeight: '500px' }}>
        {html || url ? (
          <div className="flex justify-center p-4 bg-[var(--j-bg)]" style={{ minHeight: '500px' }}>
            <motion.div
              key={mode}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.2 }}
              style={{ width: currentViewport.width, maxWidth: '100%' }}
              className="bg-white rounded-lg shadow-2xl overflow-hidden"
            >
              {html ? (
                <iframe
                  ref={iframeRef}
                  title="App Preview"
                  className="w-full border-0"
                  style={{ height: '500px', background: 'white' }}
                  sandbox="allow-scripts allow-same-origin allow-forms"
                />
              ) : (
                <iframe
                  src={url.startsWith('http') ? url : `https://${url}`}
                  title="URL Preview"
                  className="w-full border-0"
                  style={{ height: '500px', background: 'white' }}
                  sandbox="allow-scripts allow-same-origin allow-forms"
                />
              )}
            </motion.div>
          </div>
        ) : (
          <div className="flex items-center justify-center" style={{ minHeight: '500px' }}>
            <div className="text-center">
              <Eye className="h-10 w-10 mx-auto mb-3 text-[var(--j-text-mute)] opacity-50" />
              <div className="text-sm text-[var(--j-text-dim)]">Build an app or load a URL to see the preview</div>
              <div className="text-[11px] text-[var(--j-text-mute)] mt-1">Like z.ai — build and preview in real-time</div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
