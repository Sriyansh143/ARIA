'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Globe, ExternalLink, Search, Filter, RefreshCw, Loader2, Bot,
  MessageSquare, Eye, Code2, Brain, Sparkles, Image, Volume2, Clock,
  CheckCircle2, Lock, Zap, Star, ChevronRight,
} from 'lucide-react';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

interface BrowserModel {
  id: string;
  name: string;
  provider: string;
  url: string;
  category: string;
  description: string;
  requiresLogin: boolean;
  loginUrl?: string;
  free: boolean;
  contextWindow?: number;
  capabilities: string[];
  automatable: boolean;
  notes?: string;
}

interface BrowserModelData {
  models: BrowserModel[];
  stats: {
    total: number;
    free: number;
    noLogin: number;
    automatable: number;
    byProvider: Record<string, number>;
    byCategory: Record<string, number>;
  };
}

const CATEGORY_CONFIG: Record<string, { color: string; icon: typeof Bot; label: string }> = {
  chat: { color: JARVIS.colors.cyan, icon: MessageSquare, label: 'Chat' },
  vision: { color: JARVIS.colors.violet, icon: Eye, label: 'Vision' },
  code: { color: JARVIS.colors.green, icon: Code2, label: 'Code' },
  reasoning: { color: JARVIS.colors.amber, icon: Brain, label: 'Reasoning' },
  creative: { color: JARVIS.colors.red, icon: Sparkles, label: 'Creative' },
  'image-gen': { color: JARVIS.colors.violet, icon: Image, label: 'Image Gen' },
  audio: { color: JARVIS.colors.cyan, icon: Volume2, label: 'Audio' },
  'long-context': { color: JARVIS.colors.green, icon: Clock, label: 'Long Context' },
};

const PROVIDER_COLORS: Record<string, string> = {
  huggingface: '#FFD21E',
  google: '#4285F4',
  poe: '#667EEA',
  groq: '#F55036',
  together: '#0F6FFF',
  vercel: '#000000',
  perplexity: '#20808D',
  duckduckgo: '#DE5833',
  cloudflare: '#F38020',
  lmsys: '#7C3AED',
};

export default function BrowserModelsTab() {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [noLoginOnly, setNoLoginOnly] = useState(false);

  const { data, loading, refresh } = useApi<BrowserModelData>('/api/models/browser', 60000);

  const models = data?.models ?? [];
  const stats = data?.stats;

  const filtered = useMemo(() => {
    return models.filter((m) => {
      if (categoryFilter !== 'all' && m.category !== categoryFilter) return false;
      if (noLoginOnly && m.requiresLogin) return false;
      if (search) {
        const q = search.toLowerCase();
        const haystack = `${m.name} ${m.provider} ${m.description} ${m.capabilities.join(' ')}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [models, categoryFilter, noLoginOnly, search]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Globe className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Free Browser-Accessible Model Playgrounds</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Browser Models</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Free model playgrounds from Hugging Face, Google AI Studio, Poe, Groq, LMSYS, and more. No API key needed — login and use directly in browser.
          </p>
        </div>
        <button
          onClick={refresh}
          className="flex items-center gap-2 h-8 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-sm"
        >
          <RefreshCw className={loading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
          <span className="jarvis-mono text-[10px] uppercase">Refresh</span>
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SummaryCard icon={Globe} label="Total Models" value={stats?.total ?? 0} color={JARVIS.colors.cyan} />
        <SummaryCard icon={CheckCircle2} label="Free" value={stats?.free ?? 0} color={JARVIS.colors.green} />
        <SummaryCard icon={Lock} label="No Login Needed" value={stats?.noLogin ?? 0} color={JARVIS.colors.violet} />
        <SummaryCard icon={Zap} label="Automatable" value={stats?.automatable ?? 0} color={JARVIS.colors.amber} />
      </div>

      {/* Provider breakdown */}
      {stats?.byProvider && (
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Star className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Providers · {Object.keys(stats.byProvider).length} sites</h4>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-2">
            {Object.entries(stats.byProvider).map(([prov, count]) => {
              const color = PROVIDER_COLORS[prov] ?? JARVIS.colors.cyan;
              return (
                <div
                  key={prov}
                  className="p-2 rounded-md border text-center"
                  style={{ borderColor: `${color}33`, background: `${color}08` }}
                >
                  <div className="jarvis-mono text-[9px] uppercase font-bold truncate" style={{ color }}>{prov}</div>
                  <div className="jarvis-mono text-xs tabular-nums text-[var(--j-text-dim)]">{count}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="jarvis-panel p-3 flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--j-text-mute)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search models, providers, capabilities…"
            className="pl-9 h-8 text-sm"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[140px] h-8 text-xs">
            <Filter className="h-3 w-3 mr-1" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="chat">Chat</SelectItem>
            <SelectItem value="vision">Vision</SelectItem>
            <SelectItem value="code">Code</SelectItem>
            <SelectItem value="reasoning">Reasoning</SelectItem>
            <SelectItem value="creative">Creative</SelectItem>
            <SelectItem value="image-gen">Image Gen</SelectItem>
            <SelectItem value="long-context">Long Context</SelectItem>
          </SelectContent>
        </Select>
        <button
          onClick={() => setNoLoginOnly((v) => !v)}
          className="flex items-center gap-1.5 h-8 px-3 rounded-md border text-xs transition-all"
          style={{
            borderColor: noLoginOnly ? JARVIS.colors.green : 'var(--j-border)',
            background: noLoginOnly ? 'rgba(52,211,153,0.10)' : 'var(--j-panel-soft)',
            color: noLoginOnly ? JARVIS.colors.green : 'var(--j-text-dim)',
          }}
        >
          <Lock className="h-3 w-3" />
          <span className="jarvis-mono text-[10px] uppercase">{noLoginOnly ? 'No Login ✓' : 'No Login Only'}</span>
        </button>
        <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] ml-auto">
          {filtered.length} / {models.length} models
        </span>
      </div>

      {/* Model cards */}
      {loading && models.length === 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-40 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          <AnimatePresence>
            {filtered.map((m, i) => {
              const catConfig = CATEGORY_CONFIG[m.category] ?? CATEGORY_CONFIG.chat;
              const CatIcon = catConfig.icon;
              const provColor = PROVIDER_COLORS[m.provider] ?? JARVIS.colors.cyan;
              return (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ delay: Math.min(i * 0.03, 0.4) }}
                  className="jarvis-panel p-4 relative overflow-hidden hover:border-[var(--j-cyan)] transition-colors group"
                  style={{ borderTop: `2px solid ${provColor}` }}
                >
                  {/* Provider badge */}
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-6 w-6 rounded-md flex items-center justify-center" style={{ background: `${provColor}1a` }}>
                      <span className="jarvis-mono text-[8px] font-bold uppercase" style={{ color: provColor }}>{m.provider.slice(0, 3)}</span>
                    </div>
                    <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">{m.provider}</span>
                    {m.free && <CheckCircle2 className="h-3 w-3 ml-auto" style={{ color: JARVIS.colors.green }} />}
                  </div>

                  {/* Name */}
                  <h4 className="font-semibold text-sm mb-1 truncate">{m.name}</h4>

                  {/* Category badge */}
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider" style={{ color: catConfig.color, background: `${catConfig.color}1a` }}>
                      <CatIcon className="h-2.5 w-2.5 inline mr-0.5" />{catConfig.label}
                    </span>
                    {m.contextWindow && (
                      <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">
                        {m.contextWindow >= 1000000 ? `${m.contextWindow / 1000000}M ctx` : `${Math.round(m.contextWindow / 1000)}K ctx`}
                      </span>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-[11px] text-[var(--j-text-dim)] leading-relaxed mb-3 line-clamp-2">{m.description}</p>

                  {/* Capabilities */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {m.capabilities.slice(0, 4).map((c) => (
                      <span key={c} className="jarvis-mono text-[8px] px-1.5 py-0.5 rounded border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-mute)] uppercase">{c}</span>
                    ))}
                  </div>

                  {/* Login / automatable indicators */}
                  <div className="flex items-center gap-2 mb-3 text-[9px] jarvis-mono">
                    {m.requiresLogin ? (
                      <span className="flex items-center gap-0.5 text-[var(--j-amber)]">
                        <Lock className="h-2.5 w-2.5" />Login
                      </span>
                    ) : (
                      <span className="flex items-center gap-0.5 text-[var(--j-green)]">
                        <CheckCircle2 className="h-2.5 w-2.5" />No Login
                      </span>
                    )}
                    {m.automatable && (
                      <span className="flex items-center gap-0.5 text-[var(--j-cyan)]">
                        <Zap className="h-2.5 w-2.5" />Automatable
                      </span>
                    )}
                  </div>

                  {/* Notes */}
                  {m.notes && (
                    <p className="text-[9px] text-[var(--j-text-mute)] mb-3 italic line-clamp-1">💡 {m.notes}</p>
                  )}

                  {/* Open button */}
                  <a
                    href={m.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-1.5 h-8 rounded-md border text-xs font-medium transition-all"
                    style={{
                      borderColor: `${provColor}44`,
                      background: `${provColor}0a`,
                      color: provColor,
                    }}
                  >
                    <ExternalLink className="h-3 w-3" />
                    <span className="jarvis-mono text-[10px] uppercase">Open Playground</span>
                    <ChevronRight className="h-3 w-3 group-hover:translate-x-0.5 transition-transform" />
                  </a>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}
