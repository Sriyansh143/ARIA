'use client';

/* ──────────────────────────────────────────────────────────────────────────
 * Task ID: 2-b (Part 2)
 * ARIA IDE — VS Code-like editing experience.
 *
 * Features:
 *   • Multi-tab editor (open many files, switch tabs, close X, dirty dot)
 *   • Find / Replace bar (Ctrl+F or Ctrl+H) with live match count + Replace All
 *   • Word-wrap toggle + Go-to-Line input (textarea-based editor)
 *   • Keyboard shortcuts: Ctrl+S save · Ctrl+F find · Ctrl+H replace · Esc close
 *   • Shortcuts help tooltip
 *   • Status bar: file path · line:col cursor · size · language mode · saved/unsaved
 *   • New file + Delete file (with confirm) in the file tree toolbar
 * ────────────────────────────────────────────────────────────────────────── */

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Code2, FolderOpen, FilePlus, Save, X, Loader2,
  Search, Replace, WrapText, CornerDownLeft, Trash2, Keyboard,
} from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

interface FileEntry {
  name: string;
  type: 'file' | 'directory';
  size: number;
}

interface OpenTab {
  path: string;
  name: string;
  content: string;
  dirty: boolean;
}

/* ---------- file helpers ---------- */
function getExt(name: string): string {
  const dot = name.lastIndexOf('.');
  return dot === -1 ? '' : name.slice(dot + 1).toLowerCase();
}

function languageMode(name: string): string {
  const ext = getExt(name);
  const map: Record<string, string> = {
    ts: 'TypeScript', tsx: 'TypeScript JSX',
    js: 'JavaScript', jsx: 'JavaScript JSX',
    json: 'JSON', md: 'Markdown', txt: 'Plain Text',
    css: 'CSS', scss: 'SCSS', html: 'HTML',
    yml: 'YAML', yaml: 'YAML', prisma: 'Prisma',
    sh: 'Shell', toml: 'TOML', sql: 'SQL',
    py: 'Python', go: 'Go', rs: 'Rust',
    vue: 'Vue', svelte: 'Svelte',
  };
  return map[ext] ?? (ext ? ext.toUpperCase() : 'Plain Text');
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/* ============================================================================ */
/* MAIN COMPONENT                                                               */
/* ============================================================================ */
export default function IdeTab() {
  const { toast } = useToast();
  const [currentDir, setCurrentDir] = useState('.');
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [openTabs, setOpenTabs] = useState<OpenTab[]>([]);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [newFileName, setNewFileName] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);

  /* Find / Replace */
  const [findOpen, setFindOpen] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [findCaseSensitive, setFindCaseSensitive] = useState(false);
  const findInputRef = useRef<HTMLInputElement>(null);

  /* Editor settings */
  const [wordWrap, setWordWrap] = useState(true);
  const [showGotoLine, setShowGotoLine] = useState(false);
  const [gotoLineValue, setGotoLineValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  /* Cursor position */
  const [cursor, setCursor] = useState({ line: 1, col: 1 });

  /* Shortcuts help */
  const [showShortcuts, setShowShortcuts] = useState(false);

  /* Deleting */
  const [deleting, setDeleting] = useState(false);

  const activeTabData = openTabs.find((t) => t.path === activeTab);

  /* ---------- file tree ---------- */
  const loadDir = useCallback(async (dir: string) => {
    setLoadingFiles(true);
    try {
      const res = (await postJson('/api/workspace/list', { path: dir })) as {
        items?: Array<{ name: string; type: string; size: number }>;
        entries?: FileEntry[];
      };
      const rawItems = res.items ?? res.entries ?? [];
      const normalized: FileEntry[] = rawItems.map((item) => ({
        name: item.name,
        type: (item.type === 'dir' ? 'directory' : 'file') as 'file' | 'directory',
        size: item.size,
      }));
      setFiles(normalized.filter((e) => !e.name.startsWith('.') && !['node_modules', '.next', '.git', 'dist', 'sandbox-tmp'].includes(e.name)));
      setCurrentDir(dir);
    } catch (e) {
      toast({ title: 'Load failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setLoadingFiles(false);
    }
  }, [toast]);

  useEffect(() => {
    loadDir('.');
  }, [loadDir]);

  /* ---------- open / close / save ---------- */
  const openFile = useCallback(async (name: string) => {
    const path = currentDir === '.' ? name : `${currentDir}/${name}`;
    const existing = openTabs.find((t) => t.path === path);
    if (existing) {
      setActiveTab(path);
      return;
    }
    try {
      const res = (await postJson('/api/file/read', { path })) as { content: string };
      setOpenTabs((prev) => [...prev, { path, name, content: res.content, dirty: false }]);
      setActiveTab(path);
    } catch (e) {
      toast({ title: 'Open failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  }, [currentDir, openTabs, toast]);

  const closeTab = useCallback((path: string) => {
    setOpenTabs((prev) => {
      const next = prev.filter((t) => t.path !== path);
      setActiveTab((curr) => (curr === path ? (next.length > 0 ? next[0].path : null) : curr));
      return next;
    });
  }, []);

  const updateContent = useCallback((path: string, content: string) => {
    setOpenTabs((prev) => prev.map((t) => (t.path === path ? { ...t, content, dirty: true } : t)));
  }, []);

  const saveFile = useCallback(async (path: string) => {
    const tab = openTabs.find((t) => t.path === path);
    if (!tab) return;
    try {
      await postJson('/api/file/write', { path, content: tab.content });
      setOpenTabs((prev) => prev.map((t) => (t.path === path ? { ...t, dirty: false } : t)));
      toast({ title: 'Saved', description: path });
      loadDir(currentDir);
    } catch (e) {
      toast({ title: 'Save failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  }, [openTabs, currentDir, toast, loadDir]);

  const createFile = useCallback(async () => {
    if (!newFileName.trim()) return;
    const path = currentDir === '.' ? newFileName : `${currentDir}/${newFileName}`;
    try {
      await postJson('/api/file/write', { path, content: '' });
      setOpenTabs((prev) => [...prev, { path, name: newFileName, content: '', dirty: false }]);
      setActiveTab(path);
      setShowNewFile(false);
      setNewFileName('');
      loadDir(currentDir);
      toast({ title: 'File created', description: path });
    } catch (e) {
      toast({ title: 'Create failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  }, [newFileName, currentDir, loadDir, toast]);

  const deleteFile = useCallback(async (name: string) => {
    const path = currentDir === '.' ? name : `${currentDir}/${name}`;
    if (!window.confirm(`Delete "${path}"?\n\nThis action cannot be undone.`)) return;
    setDeleting(true);
    try {
      const res = await fetch('/api/file', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path }),
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status}: ${txt}`);
      }
      setOpenTabs((prev) => prev.filter((t) => t.path !== path));
      setActiveTab((curr) => (curr === path ? null : curr));
      toast({ title: 'Deleted', description: path });
      loadDir(currentDir);
    } catch (e) {
      toast({ title: 'Delete failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  }, [currentDir, loadDir, toast]);

  /* ---------- cursor tracking ---------- */
  const updateCursor = useCallback(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    const pos = ta.selectionStart ?? 0;
    const upto = ta.value.slice(0, pos);
    const line = upto.split('\n').length;
    const col = pos - upto.lastIndexOf('\n');
    setCursor({ line, col });
  }, []);

  /* ---------- find / replace ---------- */
  const matchCount = useMemo(() => {
    if (!findText || !activeTabData) return 0;
    const content = activeTabData.content;
    const needle = findCaseSensitive ? findText : findText.toLowerCase();
    const hay = findCaseSensitive ? content : content.toLowerCase();
    if (!needle) return 0;
    let count = 0;
    let idx = 0;
    while ((idx = hay.indexOf(needle, idx)) !== -1) {
      count++;
      idx += needle.length;
    }
    return count;
  }, [findText, findCaseSensitive, activeTabData]);

  const replaceAll = useCallback(() => {
    if (!activeTabData || !findText) {
      toast({ title: 'Nothing to replace', description: 'Enter find text first', variant: 'destructive' });
      return;
    }
    const content = activeTabData.content;
    let result: string;
    if (findCaseSensitive) {
      result = content.split(findText).join(replaceText);
    } else {
      result = content.replace(new RegExp(escapeRegex(findText), 'gi'), replaceText);
    }
    const replaced = matchCount;
    updateContent(activeTabData.path, result);
    toast({ title: 'Replaced all', description: `${replaced} match${replaced === 1 ? '' : 'es'} → "${replaceText || '(empty)'}"` });
  }, [activeTabData, findText, replaceText, findCaseSensitive, matchCount, updateContent, toast]);

  /* ---------- go to line ---------- */
  const gotoLine = useCallback(() => {
    const n = parseInt(gotoLineValue, 10);
    const ta = textareaRef.current;
    if (!Number.isFinite(n) || n < 1 || !ta) return;
    const lines = ta.value.split('\n');
    if (n > lines.length) {
      toast({ title: 'Out of range', description: `File has ${lines.length} lines`, variant: 'destructive' });
      return;
    }
    let pos = 0;
    for (let i = 0; i < n - 1; i++) pos += lines[i].length + 1;
    ta.focus();
    ta.setSelectionRange(pos, pos);
    setCursor({ line: n, col: 1 });
    setShowGotoLine(false);
    setGotoLineValue('');
  }, [gotoLineValue, toast]);

  /* ---------- keyboard shortcuts ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        if (activeTab) saveFile(activeTab);
      } else if (mod && (e.key === 'f' || e.key === 'F')) {
        e.preventDefault();
        setFindOpen(true);
        setTimeout(() => findInputRef.current?.focus(), 50);
      } else if (mod && (e.key === 'h' || e.key === 'H')) {
        e.preventDefault();
        setFindOpen(true);
        setTimeout(() => findInputRef.current?.focus(), 50);
      } else if (e.key === 'Escape') {
        setFindOpen(false);
        setShowGotoLine(false);
        setShowShortcuts(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeTab, saveFile]);

  /* ---------- derived status bar info ---------- */
  const fileSize = activeTabData
    ? new Blob([activeTabData.content]).size
    : 0;
  const lineCount = activeTabData
    ? activeTabData.content.split('\n').length
    : 0;
  const langMode = activeTabData ? languageMode(activeTabData.name) : '—';

  return (
    <div className="space-y-3">
      <SectionTitle
        title="ARIA IDE"
        icon={Code2}
        accent={JARVIS.colors.cyan}
        action={
          <div className="flex gap-2 items-center">
            <div className="relative">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowShortcuts((s) => !s)}
                className="border-[var(--j-border)] text-[var(--j-text-dim)] h-8"
                title="Keyboard shortcuts"
              >
                <Keyboard className="h-3.5 w-3.5 mr-1" /> Shortcuts
              </Button>
              <AnimatePresence>
                {showShortcuts && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="absolute right-0 top-10 z-30 w-56 jarvis-panel p-3 text-[11px] space-y-1.5"
                    style={{ background: 'rgba(12,15,20,0.97)' }}
                  >
                    <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-2">Shortcuts</div>
                    {[
                      ['Ctrl/⌘ + S', 'Save file'],
                      ['Ctrl/⌘ + F', 'Find'],
                      ['Ctrl/⌘ + H', 'Find & Replace'],
                      ['Esc', 'Close bars'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between gap-2">
                        <span className="jarvis-mono text-[var(--j-cyan)] text-[10px]">{k}</span>
                        <span className="text-[var(--j-text-dim)]">{v}</span>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowNewFile(!showNewFile)}
              className="border-[var(--j-border)] text-[var(--j-text-dim)] h-8"
            >
              <FilePlus className="h-3.5 w-3.5 mr-1" /> New
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => loadDir(currentDir)}
              className="border-[var(--j-border)] text-[var(--j-text-dim)] h-8"
            >
              <FolderOpen className="h-3.5 w-3.5 mr-1" /> Refresh
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 h-[640px]">
        {/* ── File Tree ── */}
        <Card className="lg:col-span-1 p-3 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] overflow-y-auto">
          <div className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-2 flex items-center justify-between">
            <span className="truncate max-w-[60%]" title={currentDir}>{currentDir}</span>
            {currentDir !== '.' && (
              <button onClick={() => loadDir('.')} className="text-[var(--j-cyan)] hover:underline shrink-0">↑ root</button>
            )}
          </div>
          {showNewFile && (
            <div className="mb-2 flex gap-1">
              <Input
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                placeholder="filename.ts"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-8"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') createFile();
                  if (e.key === 'Escape') { setShowNewFile(false); setNewFileName(''); }
                }}
                autoFocus
              />
              <Button size="sm" onClick={createFile} className="jarvis-btn-accent border-0 h-8 px-2">✓</Button>
            </div>
          )}
          {loadingFiles ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="h-4 w-4 animate-spin text-[var(--j-text-mute)]" /></div>
          ) : (
            <div className="space-y-0.5">
              {files.map((f) => (
                <div
                  key={f.name}
                  className={`group flex items-center gap-1 w-full text-left px-2 py-1 rounded text-xs transition-colors ${
                    activeTabData?.path === (currentDir === '.' ? f.name : `${currentDir}/${f.name}`)
                      ? 'bg-[var(--j-panel-soft)] text-[var(--j-text)]'
                      : 'hover:bg-[var(--j-panel-soft)]/60 text-[var(--j-text-dim)]'
                  }`}
                >
                  <button
                    onClick={() => (f.type === 'directory' ? loadDir(currentDir === '.' ? f.name : `${currentDir}/${f.name}`) : openFile(f.name))}
                    className="flex items-center gap-2 flex-1 min-w-0"
                  >
                    <span className="text-[var(--j-text-mute)] shrink-0">{f.type === 'directory' ? '📁' : '📄'}</span>
                    <span className={`truncate ${f.type === 'directory' ? 'text-[var(--j-cyan)]' : ''}`}>{f.name}</span>
                  </button>
                  {f.type === 'file' && (
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteFile(f.name); }}
                      disabled={deleting}
                      className="opacity-0 group-hover:opacity-100 text-[var(--j-text-mute)] hover:text-[var(--j-red)] transition-opacity shrink-0"
                      title={`Delete ${f.name}`}
                      aria-label={`Delete ${f.name}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* ── Editor ── */}
        <Card className="lg:col-span-3 p-0 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] flex flex-col overflow-hidden">
          {/* Editor toolbar (above tabs) */}
          <div className="flex items-center gap-1 px-2 py-1.5 border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
            <button
              onClick={() => setFindOpen((v) => !v)}
              className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] jarvis-mono uppercase ${findOpen ? 'text-[var(--j-cyan)] bg-[var(--j-cyan)]/10' : 'text-[var(--j-text-dim)] hover:text-[var(--j-text)]'}`}
              title="Find / Replace (Ctrl+F)"
            >
              <Search className="h-3 w-3" /> Find
            </button>
            <button
              onClick={replaceAll}
              disabled={!activeTabData || !findText}
              className="flex items-center gap-1 px-2 py-1 rounded text-[10px] jarvis-mono uppercase text-[var(--j-text-dim)] hover:text-[var(--j-amber)] disabled:opacity-30"
              title="Replace All"
            >
              <Replace className="h-3 w-3" /> Replace All
            </button>
            <button
              onClick={() => setWordWrap((v) => !v)}
              className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] jarvis-mono uppercase ${wordWrap ? 'text-[var(--j-cyan)] bg-[var(--j-cyan)]/10' : 'text-[var(--j-text-dim)] hover:text-[var(--j-text)]'}`}
              title="Toggle word wrap"
            >
              <WrapText className="h-3 w-3" /> Wrap
            </button>
            <button
              onClick={() => setShowGotoLine((v) => !v)}
              className="flex items-center gap-1 px-2 py-1 rounded text-[10px] jarvis-mono uppercase text-[var(--j-text-dim)] hover:text-[var(--j-text)]"
              title="Go to line"
            >
              <CornerDownLeft className="h-3 w-3" /> Go To
            </button>
            {activeTabData && (
              <div className="ml-auto flex gap-1">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => saveFile(activeTabData.path)}
                  disabled={!activeTabData.dirty}
                  className="h-7 text-[11px] text-[var(--j-green)] hover:bg-[var(--j-green)]/10"
                  title="Save (Ctrl+S)"
                >
                  <Save className="h-3 w-3 mr-1" /> Save
                </Button>
              </div>
            )}
          </div>

          {/* Tab bar */}
          <div className="flex items-stretch border-b border-[var(--j-border)] overflow-x-auto jarvis-scroll">
            {openTabs.length === 0 && (
              <div className="px-3 py-2 text-[10px] jarvis-mono uppercase text-[var(--j-text-mute)]">
                No files open
              </div>
            )}
            {openTabs.map((tab) => (
              <div
                key={tab.path}
                onClick={() => setActiveTab(tab.path)}
                className={`flex items-center gap-2 px-3 py-2 border-r border-[var(--j-border)] cursor-pointer text-xs whitespace-nowrap transition-colors ${
                  activeTab === tab.path
                    ? 'bg-[var(--j-panel)] text-[var(--j-text)] border-t-2 border-t-[var(--j-cyan)] -mt-px'
                    : 'text-[var(--j-text-mute)] hover:text-[var(--j-text)] hover:bg-[var(--j-panel-soft)]/40'
                }`}
              >
                <span
                  className="inline-block h-1.5 w-1.5 rounded-full"
                  style={{ background: tab.dirty ? JARVIS.colors.amber : 'transparent', border: tab.dirty ? 'none' : '1px solid var(--j-text-mute)' }}
                  title={tab.dirty ? 'Unsaved changes' : 'Saved'}
                />
                <span className="jarvis-mono">{tab.name}</span>
                <button
                  onClick={(e) => { e.stopPropagation(); closeTab(tab.path); }}
                  className="text-[var(--j-text-mute)] hover:text-[var(--j-red)] rounded p-0.5 hover:bg-[var(--j-red)]/10"
                  aria-label={`Close ${tab.name}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>

          {/* Find / Replace bar */}
          <AnimatePresence>
            {findOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/60"
              >
                <div className="p-2 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Search className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" />
                    <Input
                      ref={findInputRef}
                      value={findText}
                      onChange={(e) => setFindText(e.target.value)}
                      placeholder="Find…"
                      className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-7 flex-1"
                    />
                    <button
                      onClick={() => setFindCaseSensitive((v) => !v)}
                      className={`px-2 py-1 rounded text-[10px] jarvis-mono uppercase border ${findCaseSensitive ? 'text-[var(--j-cyan)] border-[var(--j-cyan)] bg-[var(--j-cyan)]/10' : 'text-[var(--j-text-mute)] border-[var(--j-border)]'}`}
                      title="Match case"
                    >Aa</button>
                    <Pill color={matchCount > 0 ? JARVIS.colors.green : JARVIS.colors.textMute}>
                      {matchCount} match{matchCount === 1 ? '' : 'es'}
                    </Pill>
                    <button
                      onClick={() => setFindOpen(false)}
                      className="text-[var(--j-text-mute)] hover:text-[var(--j-text)] p-1"
                      aria-label="Close find bar"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Replace className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" />
                    <Input
                      value={replaceText}
                      onChange={(e) => setReplaceText(e.target.value)}
                      placeholder="Replace with…"
                      className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-7 flex-1"
                      onKeyDown={(e) => { if (e.key === 'Enter') replaceAll(); }}
                    />
                    <Button
                      size="sm"
                      onClick={replaceAll}
                      disabled={!findText || matchCount === 0}
                      className="jarvis-btn-accent border-0 h-7 text-[11px]"
                    >
                      Replace All
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Go to line bar */}
          <AnimatePresence>
            {showGotoLine && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/60"
              >
                <div className="p-2 flex items-center gap-2">
                  <CornerDownLeft className="h-3.5 w-3.5 text-[var(--j-text-mute)]" />
                  <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-dim)]">Line:</span>
                  <Input
                    value={gotoLineValue}
                    onChange={(e) => setGotoLineValue(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="1"
                    className="bg-[var(--j-panel)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-7 w-24"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') gotoLine();
                      if (e.key === 'Escape') { setShowGotoLine(false); setGotoLineValue(''); }
                    }}
                    autoFocus
                  />
                  <Button size="sm" onClick={gotoLine} className="jarvis-btn-accent border-0 h-7 text-[11px]">Go</Button>
                  <span className="text-[10px] text-[var(--j-text-mute)] ml-auto">{lineCount} lines</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Editor content */}
          {activeTabData ? (
            <textarea
              ref={textareaRef}
              value={activeTabData.content}
              onChange={(e) => updateContent(activeTabData.path, e.target.value)}
              onKeyUp={updateCursor}
              onClick={updateCursor}
              onSelect={updateCursor}
              className="flex-1 w-full bg-[var(--j-panel)] text-[var(--j-text)] p-3 font-mono text-xs resize-none focus:outline-none border-0 jarvis-scroll"
              spellCheck={false}
              style={{
                fontFamily: 'var(--font-geist-mono), monospace',
                whiteSpace: wordWrap ? 'pre-wrap' : 'pre',
                overflowWrap: wordWrap ? 'break-word' : 'normal',
              }}
            />
          ) : (
            <div className="flex-1 flex items-center justify-center text-[var(--j-text-mute)]">
              <div className="text-center">
                <Code2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <div className="text-sm">Open a file to start editing</div>
                <div className="text-[10px] jarvis-mono uppercase mt-1 text-[var(--j-text-mute)]">
                  Ctrl+F find · Ctrl+S save · Ctrl+H replace
                </div>
              </div>
            </div>
          )}

          {/* Status bar */}
          <div className="flex items-center gap-3 px-3 py-1.5 border-t border-[var(--j-border)] bg-[var(--j-panel-soft)]/40 text-[10px] jarvis-mono">
            <span
              className="flex items-center gap-1"
              style={{ color: activeTabData?.dirty ? JARVIS.colors.amber : JARVIS.colors.green }}
            >
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{ background: activeTabData?.dirty ? JARVIS.colors.amber : JARVIS.colors.green }}
              />
              {activeTabData?.dirty ? 'Unsaved' : 'Saved'}
            </span>
            <span className="text-[var(--j-text-dim)] truncate flex-1 min-w-0" title={activeTabData?.path}>
              {activeTabData?.path ?? '—'}
            </span>
            <span className="text-[var(--j-text-dim)] hidden sm:inline">Ln {cursor.line}, Col {cursor.col}</span>
            <span className="text-[var(--j-text-dim)] hidden sm:inline">{formatBytes(fileSize)}</span>
            <span className="text-[var(--j-text-dim)]">{langMode}</span>
            <span className="text-[var(--j-text-mute)] hidden md:inline">{wordWrap ? 'Wrap' : 'No wrap'}</span>
          </div>
        </Card>
      </div>
    </div>
  );
}
