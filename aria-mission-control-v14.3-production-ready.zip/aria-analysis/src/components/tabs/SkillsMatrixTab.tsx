'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, Award, TrendingUp, DollarSign, Star, Search, Filter,
  RefreshCw, Loader2, Bot, Sparkles, Target, Zap, ChevronDown, ChevronRight,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
  Cell,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ─── Types ────────────────────────────────────────────────────────────
interface SkillRecord {
  id: string;
  agentCodename: string;
  skillKey: string;
  proficiency: number;
  learnedFrom: string | null;
  earnings: number;
  lastUsed: string | null;
  createdAt: string;
  updatedAt: string;
}

interface LearningData {
  records: SkillRecord[];
  stats: { total: number; totalEarnings: number; avgProficiency: number; mastered: number };
  earningsByAgent: Array<{ agent: string; earnings: number }>;
  proficiencyBySkill: Array<{ skill: string; proficiency: number }>;
}

// Proficiency → color gradient (red → amber → cyan → green)
function proficiencyColor(p: number): string {
  if (p >= 80) return JARVIS.colors.green;
  if (p >= 60) return JARVIS.colors.cyan;
  if (p >= 40) return JARVIS.colors.amber;
  return JARVIS.colors.red;
}

function proficiencyBg(p: number): string {
  const c = proficiencyColor(p);
  const opacity = 0.15 + (p / 100) * 0.5;
  return `${c}${Math.round(opacity * 255).toString(16).padStart(2, '0')}`;
}

const MASTERY_TIERS = [
  { label: 'Novice', min: 0, max: 39, color: JARVIS.colors.red },
  { label: 'Apprentice', min: 40, max: 59, color: JARVIS.colors.amber },
  { label: 'Proficient', min: 60, max: 79, color: JARVIS.colors.cyan },
  { label: 'Expert', min: 80, max: 100, color: JARVIS.colors.green },
];

export default function SkillsMatrixTab() {
  const [search, setSearch] = useState('');
  const [sortMode, setSortMode] = useState<'agent' | 'proficiency' | 'earnings'>('agent');
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);

  const { data, loading, refresh } = useApi<LearningData>('/api/learning', 30000);

  const records = data?.records ?? [];

  // Build matrix: agents × skills
  const { agents, skills, matrix, agentStats } = useMemo(() => {
    const agentSet = new Set<string>();
    const skillSet = new Set<string>();
    for (const r of records) {
      agentSet.add(r.agentCodename);
      skillSet.add(r.skillKey);
    }
    const agentsArr = Array.from(agentSet).sort();
    const skillsArr = Array.from(skillSet).sort();

    // matrix[agent][skill] = record
    const matrixMap: Record<string, Record<string, SkillRecord | undefined>> = {};
    const statsMap: Record<string, { avg: number; total: number; earnings: number; count: number }> = {};
    for (const r of records) {
      if (!matrixMap[r.agentCodename]) matrixMap[r.agentCodename] = {};
      matrixMap[r.agentCodename][r.skillKey] = r;
      if (!statsMap[r.agentCodename]) statsMap[r.agentCodename] = { avg: 0, total: 0, earnings: 0, count: 0 };
      statsMap[r.agentCodename].avg += r.proficiency;
      statsMap[r.agentCodename].earnings += r.earnings;
      statsMap[r.agentCodename].count += 1;
    }
    for (const a of agentsArr) {
      if (statsMap[a]) statsMap[a].avg = Math.round(statsMap[a].avg / statsMap[a].count);
    }

    return { agents: agentsArr, skills: skillsArr, matrix: matrixMap, agentStats: statsMap };
  }, [records]);

  // Apply search filter
  const filteredAgents = useMemo(() => {
    if (!search) return agents;
    const q = search.toLowerCase();
    return agents.filter((a) => a.toLowerCase().includes(q));
  }, [agents, search]);

  // Sort agents
  const sortedAgents = useMemo(() => {
    const arr = [...filteredAgents];
    if (sortMode === 'proficiency') arr.sort((a, b) => (agentStats[b]?.avg ?? 0) - (agentStats[a]?.avg ?? 0));
    else if (sortMode === 'earnings') arr.sort((a, b) => (agentStats[b]?.earnings ?? 0) - (agentStats[a]?.earnings ?? 0));
    else arr.sort();
    return arr;
  }, [filteredAgents, sortMode, agentStats]);

  const stats = data?.stats;
  const earningsByAgent = data?.earningsByAgent ?? [];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Agent Skills · Proficiency Heatmap + Earnings</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Skills Proficiency Matrix</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Heatmap of every agent's skill proficiency. Spot experts, find gaps, track earnings per skill.
          </p>
        </div>
        <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''} mr-1.5`} /> Refresh
        </Button>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SummaryCard icon={Bot} label="Agents Tracked" value={agents.length} color={JARVIS.colors.cyan} />
        <SummaryCard icon={Sparkles} label="Skills Tracked" value={skills.length} color={JARVIS.colors.violet} />
        <SummaryCard icon={Target} label="Avg Proficiency" value={`${stats?.avgProficiency ?? 0}%`} color={JARVIS.colors.green} />
        <SummaryCard icon={DollarSign} label="Total Earnings" value={`₹${Math.round(stats?.totalEarnings ?? 0).toLocaleString()}`} color={JARVIS.colors.amber} />
      </div>

      {/* Earnings by agent bar chart */}
      {earningsByAgent.length > 0 && (
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <DollarSign className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Earnings by Agent · Top 12</h4>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={earningsByAgent} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} horizontal={false} />
                <XAxis type="number" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v.toLocaleString()}`} />
                <YAxis type="category" dataKey="agent" tick={{ fill: '#94A3B8', fontSize: 10 }} axisLine={false} tickLine={false} width={70} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(v: number) => [`₹${v.toLocaleString()}`, 'Earnings']}
                  cursor={{ fill: 'rgba(52,211,153,0.05)' }}
                />
                <Bar dataKey="earnings" radius={[0, 3, 3, 0]}>
                  {earningsByAgent.map((entry, i) => (
                    <Cell key={i} fill={JARVIS.colors.green} fillOpacity={0.3 + (i / earningsByAgent.length) * 0.7} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="jarvis-panel p-3 flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--j-text-mute)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search agents…"
            className="pl-9 h-8 text-sm"
          />
        </div>
        <Select value={sortMode} onValueChange={(v) => setSortMode(v as 'agent' | 'proficiency' | 'earnings')}>
          <SelectTrigger className="w-[150px] h-8 text-xs">
            <Filter className="h-3 w-3 mr-1" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="agent">Sort: Agent A-Z</SelectItem>
            <SelectItem value="proficiency">Sort: Proficiency</SelectItem>
            <SelectItem value="earnings">Sort: Earnings</SelectItem>
          </SelectContent>
        </Select>
        <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] ml-auto">
          {sortedAgents.length} agents × {skills.length} skills
        </span>
      </div>

      {/* Mastery tier legend */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">Mastery:</span>
        {MASTERY_TIERS.map((t) => (
          <div key={t.label} className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-sm" style={{ background: t.color }} />
            <span className="jarvis-mono text-[9px] uppercase" style={{ color: t.color }}>{t.label} ({t.min}-{t.max})</span>
          </div>
        ))}
      </div>

      {/* Heatmap matrix */}
      <div className="jarvis-panel p-4 overflow-x-auto">
        {loading && records.length === 0 ? (
          <div className="h-40 flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: JARVIS.colors.cyan }} />
          </div>
        ) : sortedAgents.length === 0 ? (
          <div className="p-10 text-center">
            <GraduationCap className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm text-[var(--j-text-mute)]">No skill-learning records found.</p>
          </div>
        ) : (
          <div className="min-w-[600px]">
            {/* Skill headers */}
            <div className="flex items-center sticky top-0 z-10 mb-2" style={{ background: 'var(--j-panel)' }}>
              <div className="w-24 shrink-0 jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] pr-2 text-right">Agent</div>
              <div className="flex-1 grid gap-1" style={{ gridTemplateColumns: `repeat(${Math.min(skills.length, 12)}, minmax(0, 1fr))` }}>
                {skills.slice(0, 12).map((s) => (
                  <div key={s} className="jarvis-mono text-[8px] uppercase tracking-wider text-[var(--j-text-mute)] text-center truncate" title={s}>
                    {s.length > 8 ? s.slice(0, 7) + '…' : s}
                  </div>
                ))}
              </div>
              <div className="w-16 shrink-0 jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] pl-2 text-center">Avg</div>
              <div className="w-16 shrink-0 jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] pl-2 text-center">₹</div>
            </div>
            {/* Agent rows */}
            <div className="space-y-1">
              {sortedAgents.map((agent, i) => {
                const agentRow = matrix[agent] ?? {};
                const stat = agentStats[agent];
                const isOpen = expandedAgent === agent;
                return (
                  <div key={agent}>
                    <div
                      className="flex items-center group cursor-pointer rounded-md hover:bg-[var(--j-panel-soft)]/40 transition-colors p-1"
                      onClick={() => setExpandedAgent(isOpen ? null : agent)}
                    >
                      <div className="w-24 shrink-0 flex items-center gap-1 pr-2 justify-end">
                        {isOpen ? <ChevronDown className="h-2.5 w-2.5 text-[var(--j-text-mute)]" /> : <ChevronRight className="h-2.5 w-2.5 text-[var(--j-text-mute)]" />}
                        <span className="jarvis-mono text-[10px] font-semibold text-[var(--j-text-dim)] truncate">{agent}</span>
                      </div>
                      <div className="flex-1 grid gap-1" style={{ gridTemplateColumns: `repeat(${Math.min(skills.length, 12)}, minmax(0, 1fr))` }}>
                        {skills.slice(0, 12).map((skill) => {
                          const rec = agentRow[skill];
                          if (!rec) {
                            return <div key={skill} className="h-6 rounded-sm bg-[var(--j-bg)]" title={`${agent} · ${skill}: not learned`} />;
                          }
                          return (
                            <motion.div
                              key={skill}
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: Math.min(i * 0.02, 0.3) }}
                              className="h-6 rounded-sm flex items-center justify-center jarvis-mono text-[9px] font-bold tabular-nums"
                              style={{ background: proficiencyBg(rec.proficiency), color: proficiencyColor(rec.proficiency), border: `1px solid ${proficiencyColor(rec.proficiency)}33` }}
                              title={`${agent} · ${skill}: ${rec.proficiency}% · ₹${rec.earnings.toLocaleString()} · ${timeAgo(new Date(rec.updatedAt))}`}
                            >
                              {rec.proficiency}
                            </motion.div>
                          );
                        })}
                      </div>
                      <div className="w-16 shrink-0 text-center">
                        <span className="jarvis-mono text-[10px] font-bold tabular-nums" style={{ color: proficiencyColor(stat?.avg ?? 0) }}>
                          {stat?.avg ?? 0}
                        </span>
                      </div>
                      <div className="w-16 shrink-0 text-center">
                        <span className="jarvis-mono text-[10px] tabular-nums text-[var(--j-text-dim)]">
                          {(stat?.earnings ?? 0) > 0 ? `₹${Math.round(stat.earnings / 1000)}k` : '—'}
                        </span>
                      </div>
                    </div>
                    {/* Expanded detail */}
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="ml-26 pl-1 pr-2 py-2 bg-[var(--j-panel-soft)]/30 rounded-md mt-1 mb-2">
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 p-2">
                              {skills.map((skill) => {
                                const rec = agentRow[skill];
                                if (!rec) return null;
                                const color = proficiencyColor(rec.proficiency);
                                return (
                                  <div key={skill} className="p-2 rounded-md border" style={{ borderColor: `${color}33`, background: `${color}08` }}>
                                    <div className="flex items-center justify-between mb-1">
                                      <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] truncate flex-1">{skill}</span>
                                      <span className="jarvis-mono text-[11px] font-bold tabular-nums" style={{ color }}>{rec.proficiency}%</span>
                                    </div>
                                    <div className="h-1 rounded-full bg-[var(--j-bg)] overflow-hidden mb-1">
                                      <div className="h-full rounded-full" style={{ width: `${rec.proficiency}%`, background: color }} />
                                    </div>
                                    <div className="flex items-center justify-between jarvis-mono text-[8px] text-[var(--j-text-mute)]">
                                      <span>₹{rec.earnings.toLocaleString()}</span>
                                      <span>{rec.lastUsed ? timeAgo(new Date(rec.lastUsed)) : 'never'}</span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Top skills by avg proficiency */}
      {(data?.proficiencyBySkill ?? []).length > 0 && (
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Award className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Skill Proficiency Rankings</h4>
          </div>
          <div className="space-y-1.5">
            {(data?.proficiencyBySkill ?? []).sort((a, b) => b.proficiency - a.proficiency).map((s, i) => {
              const color = proficiencyColor(s.proficiency);
              return (
                <div key={s.skill} className="flex items-center gap-2">
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] w-5 text-right">{i + 1}.</span>
                  <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-dim)] w-32 truncate">{s.skill}</span>
                  <div className="flex-1 h-4 rounded-full bg-[var(--j-bg)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${s.proficiency}%` }}
                      transition={{ duration: 0.5, delay: i * 0.03 }}
                      className="h-full rounded-full flex items-center justify-end pr-1.5"
                      style={{ background: `${color}22`, borderRight: `2px solid ${color}` }}
                    >
                      <span className="jarvis-mono text-[9px] font-bold tabular-nums" style={{ color }}>{s.proficiency}%</span>
                    </motion.div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-2xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}
