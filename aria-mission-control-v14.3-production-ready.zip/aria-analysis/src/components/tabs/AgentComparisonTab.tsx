'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GitCompare, Bot, X, Plus, Search, CheckCircle2, AlertTriangle,
  TrendingUp, Zap, Cpu, Target, Award, Activity, Loader2, ChevronRight,
} from 'lucide-react';
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

// ─── Types ────────────────────────────────────────────────────────────
interface Agent {
  id: string;
  name: string;
  codename: string;
  role: string;
  status: string;
  skills: string;
  model: string;
  taskCount: number;
  logCount: number;
  successRate: number;
  load: number;
  lastActive: string;
}

const STATUS_COLORS: Record<string, string> = {
  idle: JARVIS.colors.cyan,
  thinking: JARVIS.colors.violet,
  working: JARVIS.colors.green,
  error: JARVIS.colors.red,
  offline: JARVIS.colors.textMute,
};

const AGENT_COLORS = [
  JARVIS.colors.cyan,
  JARVIS.colors.violet,
  JARVIS.colors.green,
  JARVIS.colors.amber,
  JARVIS.colors.red,
  '#FB923C', // orange
  '#A78BFA', // light violet
  '#34D399', // emerald
  '#60A5FA', // blue
  '#F472B6', // pink
  '#FBBF24', // yellow
  '#94A3B8', // slate
];

// Metrics for the radar chart (normalized 0-100)
const RADAR_METRICS = [
  { key: 'successRate', label: 'Success', max: 100 },
  { key: 'load', label: 'Load', max: 100, invert: true }, // lower is better
  { key: 'taskCount', label: 'Tasks', max: 50 },
  { key: 'logCount', label: 'Activity', max: 50 },
];

function normalize(value: number, max: number, invert = false): number {
  const pct = Math.min(100, (value / max) * 100);
  return invert ? 100 - pct : pct;
}

export default function AgentComparisonTab() {
  const { data } = useApi<{ agents: Agent[] }>('/api/agents', 30000);
  const [selected, setSelected] = useState<string[]>(['ORION', 'VEGA', 'ATLAS']);
  const [search, setSearch] = useState('');
  const [showPicker, setShowPicker] = useState(false);

  const agents = data?.agents ?? [];
  const agentMap = useMemo(() => new Map(agents.map((a) => [a.codename, a])), [agents]);
  const selectedAgents = useMemo(() => selected.map((c) => agentMap.get(c)).filter(Boolean) as Agent[], [selected, agentMap]);

  const radarData = useMemo(() => {
    return RADAR_METRICS.map((m) => {
      const point: Record<string, unknown> = { metric: m.label };
      selectedAgents.forEach((a) => {
        const val = (a as unknown as Record<string, number>)[m.key] ?? 0;
        point[a.codename] = Math.round(normalize(val, m.max, m.invert));
      });
      return point;
    });
  }, [selectedAgents]);

  const barData = useMemo(() => {
    return selectedAgents.map((a) => ({
      name: a.codename,
      Success: a.successRate,
      Load: a.load,
      Tasks: a.taskCount,
    }));
  }, [selectedAgents]);

  const toggleAgent = (codename: string) => {
    setSelected((prev) => {
      if (prev.includes(codename)) return prev.filter((c) => c !== codename);
      if (prev.length >= 12) return prev; // max 12 (was 4 — now allows all agents)
      return [...prev, codename];
    });
  };

  const filteredAgents = useMemo(() => {
    if (!search) return agents;
    const q = search.toLowerCase();
    return agents.filter((a) => `${a.codename} ${a.name} ${a.role}`.toLowerCase().includes(q));
  }, [agents, search]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GitCompare className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Side-by-Side Agent Metrics · Up to 4 Agents</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Agent Comparison</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Compare agents across success rate, load, tasks, activity. Radar + bar charts surface strengths and gaps at a glance.
          </p>
        </div>
        <Button
          onClick={() => setShowPicker((s) => !s)}
          className="jarvis-btn-accent border-0"
          disabled={selected.length >= 12 && !showPicker}
        >
          <Plus className="h-3.5 w-3.5 mr-1.5" /> Add Agent
        </Button>
      </div>

      {/* Selected agents chips */}
      <div className="flex items-center gap-2 flex-wrap">
        {selectedAgents.map((a, i) => {
          const color = AGENT_COLORS[i % AGENT_COLORS.length];
          return (
            <motion.div
              key={a.codename}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex items-center gap-2 h-8 pl-2.5 pr-1.5 rounded-md border"
              style={{ borderColor: `${color}44`, background: `${color}0a` }}
            >
              <div className="h-5 w-5 rounded flex items-center justify-center jarvis-mono text-[9px] font-bold" style={{ background: `${color}22`, color }}>
                {a.codename.slice(0, 2)}
              </div>
              <span className="text-xs font-semibold" style={{ color }}>{a.codename}</span>
              <span className="text-[10px] text-[var(--j-text-mute)] hidden sm:inline">{a.role}</span>
              <button
                onClick={() => toggleAgent(a.codename)}
                className="h-5 w-5 rounded flex items-center justify-center hover:bg-[var(--j-panel-soft)] text-[var(--j-text-mute)] hover:text-[var(--j-red)] transition-colors"
              >
                <X className="h-3 w-3" />
              </button>
            </motion.div>
          );
        })}
        {selectedAgents.length === 0 && (
          <p className="text-xs text-[var(--j-text-mute)]">No agents selected. Click "Add Agent" to pick up to 12.</p>
        )}
      </div>

      {/* Agent picker dropdown */}
      <AnimatePresence>
        {showPicker && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="jarvis-panel p-3">
              <div className="relative mb-2">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--j-text-mute)]" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search agents by codename, name, or role…"
                  className="pl-9 h-8 text-sm"
                  autoFocus
                />
              </div>
              <div className="flex items-center gap-2 mb-2">
                <button
                  onClick={() => setSelected(filteredAgents.slice(0, 12).map((a) => a.codename))}
                  className="jarvis-mono text-[9px] uppercase tracking-wider px-2 py-1 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors"
                >
                  Select All (max 12)
                </button>
                <button
                  onClick={() => setSelected([])}
                  className="jarvis-mono text-[9px] uppercase tracking-wider px-2 py-1 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-red)] hover:border-[var(--j-red)] transition-colors"
                >
                  Clear
                </button>
                <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-auto">{selected.length}/12 selected</span>
              </div>
              <div className="max-h-64 overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-1.5">
                {filteredAgents.map((a) => {
                  const isSelected = selected.includes(a.codename);
                  const color = AGENT_COLORS[selected.indexOf(a.codename) % AGENT_COLORS.length];
                  return (
                    <button
                      key={a.codename}
                      onClick={() => toggleAgent(a.codename)}
                      className="flex items-center gap-2 p-2 rounded-md border text-left transition-all"
                      style={{
                        borderColor: isSelected ? `${color}66` : 'var(--j-border)',
                        background: isSelected ? `${color}0a` : 'var(--j-panel-soft)',
                      }}
                    >
                      <div
                        className="h-6 w-6 rounded flex items-center justify-center jarvis-mono text-[8px] font-bold shrink-0"
                        style={{ background: isSelected ? `${color}22` : 'var(--j-bg)', color: isSelected ? color : 'var(--j-text-mute)' }}
                      >
                        {a.codename.slice(0, 2)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] font-semibold truncate">{a.codename}</div>
                        <div className="text-[9px] text-[var(--j-text-mute)] truncate">{a.role}</div>
                      </div>
                      {isSelected && <CheckCircle2 className="h-3.5 w-3.5 shrink-0" style={{ color }} />}
                    </button>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Charts + detail cards */}
      {selectedAgents.length === 0 ? (
        <div className="jarvis-panel p-10 text-center">
          <GitCompare className="h-8 w-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm text-[var(--j-text-mute)]">Select agents to compare.</p>
        </div>
      ) : (
        <>
          {/* Radar + Bar charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Radar chart */}
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <Target className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Capability Radar</h4>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData} margin={{ top: 8, right: 30, left: 30, bottom: 8 }}>
                    <PolarGrid stroke="#1B2330" />
                    <PolarAngleAxis dataKey="metric" tick={{ fill: '#94A3B8', fontSize: 10 }} />
                    <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#64748B', fontSize: 8 }} angle={90} />
                    {selectedAgents.map((a, i) => {
                      const color = AGENT_COLORS[i % AGENT_COLORS.length];
                      return (
                        <Radar
                          key={a.codename}
                          name={a.codename}
                          dataKey={a.codename}
                          stroke={color}
                          fill={color}
                          fillOpacity={0.15}
                          strokeWidth={2}
                        />
                      );
                    })}
                    <Tooltip
                      contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: '#94A3B8' }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              {/* Legend */}
              <div className="flex items-center gap-3 justify-center mt-2 flex-wrap">
                {selectedAgents.map((a, i) => {
                  const color = AGENT_COLORS[i % AGENT_COLORS.length];
                  return (
                    <div key={a.codename} className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
                      <span className="jarvis-mono text-[9px] uppercase" style={{ color }}>{a.codename}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bar chart */}
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Metrics Comparison</h4>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} vertical={false} />
                    <XAxis dataKey="name" tick={{ fill: '#64748B', fontSize: 9 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: '#64748B', fontSize: 9 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: '#94A3B8' }}
                      cursor={{ fill: 'rgba(125,211,252,0.05)' }}
                    />
                    <Bar dataKey="Success" fill={JARVIS.colors.green} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="Load" fill={JARVIS.colors.amber} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="Tasks" fill={JARVIS.colors.cyan} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center gap-3 justify-center mt-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: JARVIS.colors.green }} />
                  <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Success %</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: JARVIS.colors.amber }} />
                  <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Load %</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: JARVIS.colors.cyan }} />
                  <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Tasks</span>
                </div>
              </div>
            </div>
          </div>

          {/* Side-by-side detail cards */}
          <div className={`grid grid-cols-1 ${selectedAgents.length === 1 ? 'sm:grid-cols-1' : selectedAgents.length === 2 ? 'sm:grid-cols-2' : selectedAgents.length === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2 lg:grid-cols-4'} gap-3`}>
            {selectedAgents.map((a, i) => {
              const color = AGENT_COLORS[i % AGENT_COLORS.length];
              const statusColor = STATUS_COLORS[a.status] ?? JARVIS.colors.cyan;
              const skills = JSON.parse(a.skills || '[]') as string[];
              return (
                <motion.div
                  key={a.codename}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="jarvis-panel p-4 relative overflow-hidden"
                  style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}
                >
                  <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
                  {/* Agent header */}
                  <div className="flex items-center gap-2 mb-3">
                    <div className="h-10 w-10 rounded-md flex items-center justify-center jarvis-mono text-xs font-bold" style={{ background: `${color}1a`, color }}>
                      {a.codename.slice(0, 2)}
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-sm truncate">{a.codename}</div>
                      <div className="text-[10px] text-[var(--j-text-mute)] truncate">{a.role}</div>
                    </div>
                  </div>
                  {/* Status badge */}
                  <div className="flex items-center gap-1.5 mb-3">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: statusColor, boxShadow: `0 0 4px ${statusColor}` }} />
                    <span className="jarvis-mono text-[9px] uppercase font-bold" style={{ color: statusColor }}>{a.status}</span>
                  </div>
                  {/* Metrics */}
                  <div className="space-y-2">
                    <MetricRow icon={Award} label="Success" value={`${a.successRate}%`} color={JARVIS.colors.green} pct={a.successRate} />
                    <MetricRow icon={Zap} label="Load" value={`${a.load}%`} color={JARVIS.colors.amber} pct={a.load} />
                    <MetricRow icon={CheckCircle2} label="Tasks" value={String(a.taskCount)} color={JARVIS.colors.cyan} pct={Math.min(100, a.taskCount * 5)} />
                    <MetricRow icon={Activity} label="Logs" value={String(a.logCount)} color={JARVIS.colors.violet} pct={Math.min(100, a.logCount * 5)} />
                  </div>
                  {/* Model */}
                  <div className="mt-3 pt-3 border-t border-[var(--j-border)] flex items-center gap-2">
                    <Cpu className="h-3 w-3 text-[var(--j-text-mute)]" />
                    <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate">{a.model}</span>
                  </div>
                  {/* Skills */}
                  {skills.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {skills.slice(0, 4).map((s) => (
                        <span key={s} className="jarvis-mono text-[8px] px-1.5 py-0.5 rounded border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-mute)] uppercase tracking-wider">{s}</span>
                      ))}
                      {skills.length > 4 && <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">+{skills.length - 4}</span>}
                    </div>
                  )}
                  {/* Last active */}
                  <div className="mt-2 flex items-center gap-1 text-[9px] text-[var(--j-text-mute)] jarvis-mono">
                    <span>active {timeAgo(new Date(a.lastActive))}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Winner badges */}
          {selectedAgents.length >= 2 && (
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <Award className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Leaderboard</h4>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <LeaderboardCard
                  label="Highest Success"
                  agents={selectedAgents}
                  metric={(a) => a.successRate}
                  format={(v) => `${v.toFixed(1)}%`}
                  color={JARVIS.colors.green}
                  icon={Award}
                  higherIsBetter
                />
                <LeaderboardCard
                  label="Lowest Load"
                  agents={selectedAgents}
                  metric={(a) => a.load}
                  format={(v) => `${v.toFixed(0)}%`}
                  color={JARVIS.colors.cyan}
                  icon={TrendingUp}
                  higherIsBetter={false}
                />
                <LeaderboardCard
                  label="Most Tasks"
                  agents={selectedAgents}
                  metric={(a) => a.taskCount}
                  format={(v) => String(v)}
                  color={JARVIS.colors.amber}
                  icon={CheckCircle2}
                  higherIsBetter
                />
                <LeaderboardCard
                  label="Most Active"
                  agents={selectedAgents}
                  metric={(a) => a.logCount}
                  format={(v) => String(v)}
                  color={JARVIS.colors.violet}
                  icon={Activity}
                  higherIsBetter
                />
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── Metric Row ───────────────────────────────────────────────────────
function MetricRow({ icon: Icon, label, value, color, pct }: { icon: typeof Award; label: string; value: string; color: string; pct: number }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="h-3 w-3" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] flex-1">{label}</span>
        <span className="jarvis-mono text-[11px] font-bold tabular-nums" style={{ color }}>{value}</span>
      </div>
      <div className="h-1 rounded-full bg-[var(--j-bg)] overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, pct)}%` }}
          transition={{ duration: 0.5 }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
    </div>
  );
}

// ─── Leaderboard Card ─────────────────────────────────────────────────
function LeaderboardCard({
  label,
  agents,
  metric,
  format,
  color,
  icon: Icon,
  higherIsBetter,
}: {
  label: string;
  agents: Agent[];
  metric: (a: Agent) => number;
  format: (v: number) => string;
  color: string;
  icon: typeof Award;
  higherIsBetter: boolean;
}) {
  const sorted = [...agents].sort((a, b) => higherIsBetter ? metric(b) - metric(a) : metric(a) - metric(b));
  const winner = sorted[0];
  return (
    <div className="p-3 rounded-md border bg-[var(--j-panel-soft)]/60" style={{ borderColor: `${color}33` }}>
      <div className="flex items-center gap-1.5 mb-2">
        <Icon className="h-3 w-3" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">{label}</span>
      </div>
      <div className="flex items-center gap-2 mb-2">
        <div className="h-8 w-8 rounded-md flex items-center justify-center jarvis-mono text-[10px] font-bold" style={{ background: `${color}1a`, color }}>
          {winner.codename.slice(0, 2)}
        </div>
        <div>
          <div className="text-sm font-bold" style={{ color }}>{winner.codename}</div>
          <div className="jarvis-mono text-[10px] tabular-nums" style={{ color }}>{format(metric(winner))}</div>
        </div>
      </div>
      {/* Ranked list */}
      <div className="space-y-0.5">
        {sorted.map((a, i) => (
          <div key={a.codename} className="flex items-center gap-1.5 text-[9px] jarvis-mono">
            <span className="text-[var(--j-text-mute)] w-3">{i + 1}.</span>
            <span className="text-[var(--j-text-dim)] flex-1 truncate">{a.codename}</span>
            <span className="text-[var(--j-text-mute)] tabular-nums">{format(metric(a))}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
