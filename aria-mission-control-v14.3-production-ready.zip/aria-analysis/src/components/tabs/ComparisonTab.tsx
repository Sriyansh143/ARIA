'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { GitCompare, Play, Loader2, CheckCircle2, XCircle, Clock, Copy, Check, ChevronsUpDown, Search, CheckCheck } from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill, StatCard } from '@/components/jarvis/shared';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '@/components/ui/command';
import { MODEL_CATALOG, type CatalogEntry } from '@/lib/catalog';

interface CompareResponse {
  model: string;
  content: string;
  latencyMs: number;
  error: string | null;
}

interface CompareResult {
  prompt: string;
  models: string[];
  responses: CompareResponse[];
}

interface DbModel {
  modelId: string;
  displayName?: string;
  providerKey: string;
  tier?: string;
}

const ACCENTS = [JARVIS.colors.cyan, JARVIS.colors.violet, JARVIS.colors.green, JARVIS.colors.amber];

/** A single searchable model option. */
interface ModelOption {
  modelId: string;
  displayName: string;
  providerKey: string;
  tier?: string;
  capabilities?: string[];
  source: 'catalog' | 'db';
}

/**
 * Merge the built-in MODEL_CATALOG (447+ models across 22 providers) with any
 * models discovered live in the DB (via /api/models sync). DB models take
 * precedence (they reflect what's actually configured), catalog models fill
 * the long tail so the operator can pick ANY known model.
 */
function useModelOptions(): ModelOption[] {
  const { data } = useApi<{ models: DbModel[] }>('/api/models', 60000);
  return useMemo(() => {
    const map = new Map<string, ModelOption>();
    for (const m of MODEL_CATALOG) {
      map.set(m.modelId, {
        modelId: m.modelId,
        displayName: m.displayName,
        providerKey: m.providerKey,
        tier: m.tier,
        capabilities: m.capabilities,
        source: 'catalog',
      });
    }
    if (data?.models) {
      for (const m of data.models) {
        map.set(m.modelId, {
          modelId: m.modelId,
          displayName: m.displayName || m.modelId,
          providerKey: m.providerKey,
          tier: m.tier,
          source: 'db',
        });
      }
    }
    return Array.from(map.values()).sort((a, b) => {
      // DB-discovered models first, then alphabetical by provider then id.
      if (a.source !== b.source) return a.source === 'db' ? -1 : 1;
      if (a.providerKey !== b.providerKey) return a.providerKey.localeCompare(b.providerKey);
      return a.modelId.localeCompare(b.modelId);
    });
  }, [data]);
}

/** Searchable model combobox — a dropdown of EVERY model with a filter box. */
function ModelCombobox({
  value,
  onChange,
  options,
  placeholder,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  options: ModelOption[];
  placeholder: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const selected = options.find((o) => o.modelId === value);

  // Group filtered options by provider for a clean, scannable list.
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? options.filter(
          (o) =>
            o.modelId.toLowerCase().includes(q) ||
            o.displayName.toLowerCase().includes(q) ||
            o.providerKey.toLowerCase().includes(q) ||
            (o.tier || '').toLowerCase().includes(q),
        )
      : options;
    const groups = new Map<string, ModelOption[]>();
    for (const o of list) {
      const arr = groups.get(o.providerKey) || [];
      arr.push(o);
      groups.set(o.providerKey, arr);
    }
    return Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [options, query]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          role="combobox"
          aria-expanded={open}
          aria-controls="model-combobox-list"
          aria-haspopup="listbox"
          className="flex w-full items-center justify-between gap-2 h-9 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] px-3 text-xs text-left text-[var(--j-text)] hover:border-[var(--j-cyan)] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span className="flex items-center gap-2 min-w-0">
            {selected ? (
              <>
                <span className="jarvis-mono text-[10px] font-bold shrink-0 px-1.5 py-0.5 rounded" style={{ color: JARVIS.colors.cyan, background: 'rgba(125,211,252,0.10)' }}>
                  {selected.providerKey}
                </span>
                <span className="truncate">{selected.displayName}</span>
                {selected.source === 'db' && (
                  <span className="jarvis-mono text-[8px] uppercase px-1 py-0.5 rounded shrink-0" style={{ color: JARVIS.colors.green, background: 'rgba(52,211,153,0.10)' }}>live</span>
                )}
              </>
            ) : (
              <span className="text-[var(--j-text-mute)]">{placeholder}</span>
            )}
          </span>
          <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 opacity-60" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] min-w-[320px] p-0" align="start">
        <Command shouldFilter={false}>
          <div className="flex items-center border-b border-[var(--j-border)] px-3" cmdk-input-wrapper="">
            <Search className="h-3.5 w-3.5 shrink-0 opacity-50" />
            <CommandInput
              placeholder="Search models, providers, tiers…"
              value={query}
              onValueChange={setQuery}
              className="h-9 text-xs bg-transparent border-0 focus:ring-0"
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} className="text-[var(--j-text-mute)] hover:text-[var(--j-text)] text-[10px]">clear</button>
            )}
          </div>
          <CommandList className="max-h-[320px]">
            <CommandEmpty className="py-6 text-center text-xs text-[var(--j-text-mute)]">
              No models match “{query}”.
            </CommandEmpty>
            {filtered.map(([provider, models]) => (
              <CommandGroup key={provider} heading={provider} className="text-[var(--j-text-dim)]">
                {models.map((m) => (
                  <CommandItem
                    key={`${provider}:${m.modelId}`}
                    value={`${m.providerKey}:${m.modelId}:${m.displayName}`}
                    onSelect={() => {
                      onChange(m.modelId === value ? '' : m.modelId);
                      setOpen(false);
                      setQuery('');
                    }}
                    className="gap-2 text-xs aria-selected:bg-[var(--j-panel-soft)]"
                  >
                    <Check
                      className={`h-3.5 w-3.5 shrink-0 ${value === m.modelId ? 'opacity-100' : 'opacity-0'}`}
                      style={{ color: JARVIS.colors.green }}
                    />
                    <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] w-20 shrink-0 truncate">{m.tier || '—'}</span>
                    <span className="truncate flex-1">{m.displayName}</span>
                    {m.source === 'db' && (
                      <span className="jarvis-mono text-[8px] uppercase px-1 py-0.5 rounded shrink-0" style={{ color: JARVIS.colors.green, background: 'rgba(52,211,153,0.10)' }}>live</span>
                    )}
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export default function ComparisonTab() {
  const { toast } = useToast();
  const options = useModelOptions();
  const [prompt, setPrompt] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [modelInputs, setModelInputs] = useState(['glm-4.6', 'glm-4.5-flash']);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<CompareResult | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const validModels = modelInputs.filter((m) => m.trim().length > 0);
  const canRun = prompt.trim().length > 0 && validModels.length >= 2 && !running;

  const runComparison = async () => {
    if (!canRun) return;
    setRunning(true);
    setResult(null);
    try {
      const res = (await postJson('/api/compare', {
        prompt,
        models: validModels,
        systemPrompt: systemPrompt || undefined,
      })) as CompareResult;
      setResult(res);
      const successCount = res.responses.filter((r) => !r.error).length;
      toast({ title: 'Comparison complete', description: `${successCount}/${res.responses.length} responded` });
    } catch (e) {
      toast({ title: 'Comparison failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setRunning(false);
    }
  };

  const copyContent = (model: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopied(model);
    setTimeout(() => setCopied(null), 2000);
  };

  const stats = result
    ? {
        total: result.responses.length,
        success: result.responses.filter((r) => !r.error).length,
        avgLatency: Math.round(
          result.responses.filter((r) => !r.error).reduce((s, r) => s + r.latencyMs, 0) /
            Math.max(1, result.responses.filter((r) => !r.error).length),
        ),
        failed: result.responses.filter((r) => r.error).length,
      }
    : null;

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Model Comparison"
        icon={GitCompare}
        accent={JARVIS.colors.violet}
        action={
          <div className="flex items-center gap-2">
            <Pill color={JARVIS.colors.cyan}>{options.length} models</Pill>
            <Pill color={JARVIS.colors.violet}>A/B/C/D</Pill>
          </div>
        }
      />

      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] space-y-3">
        <div>
          <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-1.5 block">Prompt (sent to all models)</Label>
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Enter a prompt to compare..." className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] min-h-[80px] text-sm" />
        </div>
        <div>
          <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-1.5 block">System Prompt (optional)</Label>
          <Input value={systemPrompt} onChange={(e) => setSystemPrompt(e.target.value)} placeholder="e.g. 'Be concise and technical.'" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9" />
        </div>
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Models to Compare (2-4) · searchable</Label>
            <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{validModels.length}/4 selected</span>
          </div>
          <div className="space-y-2">
            {modelInputs.map((m, i) => (
              <div key={i} className="flex gap-2 items-center">
                <span className="jarvis-mono text-[10px] font-bold w-5 shrink-0 text-center" style={{ color: ACCENTS[i % ACCENTS.length] }}>{i + 1}</span>
                <div className="flex-1">
                  <ModelCombobox
                    value={m}
                    onChange={(v) => setModelInputs((prev) => prev.map((x, idx) => (idx === i ? v : x)))}
                    options={options}
                    placeholder={`Select model ${i + 1}…`}
                    disabled={running}
                  />
                </div>
                {modelInputs.length > 2 && (
                  <Button size="sm" variant="ghost" onClick={() => setModelInputs((prev) => prev.filter((_, idx) => idx !== i))} className="text-[var(--j-red)] h-9 px-2">✕</Button>
                )}
              </div>
            ))}
            {modelInputs.length < 4 && (
              <Button size="sm" variant="outline" onClick={() => setModelInputs((prev) => [...prev, ''])} className="border-[var(--j-border)] text-[var(--j-text-dim)] h-7 text-xs">+ Add Model Slot</Button>
            )}
          </div>
        </div>
        <div className="flex justify-end">
          <Button onClick={runComparison} disabled={!canRun} className="jarvis-btn-accent border-0">
            {running ? <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Running...</> : <><Play className="h-3.5 w-3.5 mr-1.5" /> Run Comparison</>}
          </Button>
        </div>
      </Card>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard label="Models Run" value={stats.total} icon={GitCompare} accent={JARVIS.colors.cyan} />
          <StatCard label="Succeeded" value={stats.success} icon={CheckCircle2} accent={JARVIS.colors.green} />
          <StatCard label="Avg Latency" value={`${stats.avgLatency}ms`} icon={Clock} accent={JARVIS.colors.amber} />
          <StatCard label="Failed" value={stats.failed} icon={XCircle} accent={JARVIS.colors.red} />
        </div>
      )}

      {result && (
        <div className={`grid gap-3 ${result.responses.length === 2 ? 'grid-cols-1 md:grid-cols-2' : result.responses.length === 3 ? 'grid-cols-1 md:grid-cols-3' : 'grid-cols-1 md:grid-cols-2'}`}>
          {result.responses.map((r, i) => {
            const accent = ACCENTS[i % ACCENTS.length];
            return (
              <motion.div key={r.model} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-full flex flex-col" style={{ borderColor: r.error ? `${JARVIS.colors.red}55` : `${accent}44` }}>
                  <div className="flex items-center gap-2 mb-3 pb-2 border-b border-[var(--j-border-soft)]">
                    <div className="flex h-6 w-6 items-center justify-center rounded shrink-0" style={{ background: `${accent}1a`, border: `1px solid ${accent}33`, color: accent }}>
                      <span className="jarvis-mono text-[10px] font-bold">{i + 1}</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="jarvis-mono text-xs font-bold truncate" style={{ color: accent }}>{r.model}</div>
                    </div>
                    {r.error ? <XCircle className="h-4 w-4 text-[var(--j-red)] shrink-0" /> : <CheckCircle2 className="h-4 w-4 text-[var(--j-green)] shrink-0" />}
                  </div>
                  {!r.error && (
                    <div className="flex items-center gap-2 mb-2">
                      <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{r.latencyMs}ms</span>
                      <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">· {r.content.length} chars</span>
                      <button onClick={() => copyContent(r.model, r.content)} className="ml-auto text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] transition-colors">
                        {copied === r.model ? <Check className="h-3 w-3 text-[var(--j-green)]" /> : <Copy className="h-3 w-3" />}
                      </button>
                    </div>
                  )}
                  <div className="flex-1 overflow-y-auto max-h-80">
                    {r.error ? (
                      <div className="text-xs text-[var(--j-red)] p-3 rounded bg-[var(--j-red)]/5 border border-[var(--j-red)]/30">{r.error}</div>
                    ) : (
                      <div className="text-xs text-[var(--j-text-dim)] whitespace-pre-wrap leading-relaxed">{r.content}</div>
                    )}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {!result && !running && (
        <Card className="p-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] text-center">
          <GitCompare className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)]" />
          <div className="text-sm text-[var(--j-text-dim)]">Pick 2-4 models from the searchable dropdowns above and run a comparison.</div>
          <div className="mt-2 flex items-center justify-center gap-1.5 text-[10px] text-[var(--j-text-mute)]">
            <CheckCheck className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
            <span className="jarvis-mono uppercase tracking-wider">{options.length} models available · grouped by provider · fuzzy search</span>
          </div>
        </Card>
      )}
    </div>
  );
}
