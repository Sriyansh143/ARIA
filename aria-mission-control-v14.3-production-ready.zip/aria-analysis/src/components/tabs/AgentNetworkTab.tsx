'use client';

/* ──────────────────────────────────────────────────────────────────────────
 * Task ID: 3-NETWORK-CIRCLES
 * Agent Network tab — small-circles radial visualization with hover info,
 * click-to-open detail panel, animated edges, and a mobile card fallback.
 *
 * Data: live from /api/agents (polled every 10s). Department / seniority /
 * title metadata is looked up from AGENT_ROSTER in config.ts (pure
 * metadata, never used for status / load / successRate — those come from the
 * live API). This honors the "use the live API" rule while still letting us
 * color-by-department and size-by-seniority.
 * ────────────────────────────────────────────────────────────────────────── */

import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Share2, RefreshCw, X, Activity, Cpu, Gauge, Trophy, ListTodo,
  Bot, Radio, Zap, ShieldAlert, Pause, Power, Sparkles, ChevronRight,
} from 'lucide-react';
import { useApi } from '@/lib/hooks/use-api';
import {
  JARVIS, STATUS_COLORS, AGENT_ROSTER, DEPARTMENTS, timeAgo,
  type AgentStatus,
} from '@/lib/config';
import { SectionTitle, StatusDot, Pill, EmptyState } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';

/* ---------- types ---------- */
interface Agent {
  id: string;
  name: string;
  codename: string;
  role: string;
  status: string;
  skills: string; // JSON array
  model: string;
  taskCount: number;
  logCount: number;
  successRate: number;
  load: number;
  lastActive: string;
  createdAt: string;
}

interface AgentLog {
  id: string;
  level: string;
  message: string;
  createdAt: string;
}

interface AgentDetail extends Agent {
  logs?: AgentLog[];
}

/* ---------- static metadata lookup (DEPARTMENT / SENIORITY / TITLE) ---------- */
type Meta = {
  department: string;
  seniority: string;
  title: string;
  skills: string[];
};

const ROSTER_INDEX: Record<string, Meta> = (() => {
  const map: Record<string, Meta> = {};
  for (const r of AGENT_ROSTER) {
    map[r.codename] = {
      department: r.department,
      seniority: r.seniority,
      title: r.title,
      skills: r.skills,
    };
  }
  return map;
})();

const DEPT_COLOR: Record<string, string> = Object.fromEntries(
  DEPARTMENTS.map((d) => [d.key, d.color]),
);
const DEPT_NAME: Record<string, string> = Object.fromEntries(
  DEPARTMENTS.map((d) => [d.key, d.name]),
);

/** Derive department / seniority / title for an agent — uses AGENT_ROSTER
 *  metadata, with a role-keyword fallback for runtime-spawned agents
 *  (e.g. ORIO-RESE-* sub-agents) that aren't in the static roster. */
function metaFor(a: Agent): Meta {
  const fromRoster = ROSTER_INDEX[a.codename];
  if (fromRoster) return fromRoster;
  // Fallback: infer department from the codename / role keywords.
  const role = (a.role || '').toLowerCase();
  const code = (a.codename || '').toLowerCase();
  let dept = 'operations';
  if (code.startsWith('orio-rese') || role.includes('research')) dept = 'research';
  else if (role.includes('engineer') || role.includes('code')) dept = 'engineering';
  else if (role.includes('data') || role.includes('analyst')) dept = 'data';
  else if (role.includes('design')) dept = 'design';
  else if (role.includes('security') || role.includes('compliance')) dept = 'security';
  else if (role.includes('support')) dept = 'support';
  else if (role.includes('market') || role.includes('content')) dept = 'marketing';
  return {
    department: dept,
    seniority: 'junior',
    title: a.role,
    skills: parseSkills(a.skills),
  };
}

function parseSkills(s: string): string[] {
  try {
    const v = JSON.parse(s || '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

/* ---------- positioning ---------- */
interface NodePos { x: number; y: number; }

const CSUITE = ['ATLAS', 'ECHO', 'APEX', 'PULSE'];
const VIEW = 100; // SVG viewBox size
const CENTER = VIEW / 2;
const CSUITE_RADIUS = 14; // % from center
const OUTER_RADIUS = 37; // % from center
const CLUSTER_RADIUS = 4.2; // % spread within a dept cluster

function computeLayout(agents: Agent[]) {
  const positions: Record<string, NodePos> = {};
  const ceo = agents.find((a) => a.codename === 'ORION');
  if (ceo) positions[ceo.id] = { x: CENTER, y: CENTER };

  // C-Suite inner ring
  CSUITE.forEach((codename, i) => {
    const a = agents.find((x) => x.codename === codename);
    if (!a) return;
    const angle = (i / CSUITE.length) * 2 * Math.PI - Math.PI / 2;
    positions[a.id] = {
      x: CENTER + CSUITE_RADIUS * Math.cos(angle),
      y: CENTER + CSUITE_RADIUS * Math.sin(angle),
    };
  });

  // Group remaining agents by department
  const byDept: Record<string, Agent[]> = {};
  for (const a of agents) {
    if (a.codename === 'ORION' || CSUITE.includes(a.codename)) continue;
    const dept = metaFor(a).department;
    (byDept[dept] ??= []).push(a);
  }

  const deptKeys = Object.keys(byDept);
  const deptCount = deptKeys.length || 1;
  // Sort departments alphabetically so they appear at stable angles.
  deptKeys.sort();
  deptKeys.forEach((dept, di) => {
    const deptAngle = (di / deptCount) * 2 * Math.PI - Math.PI / 2;
    const cx = CENTER + OUTER_RADIUS * Math.cos(deptAngle);
    const cy = CENTER + OUTER_RADIUS * Math.sin(deptAngle);
    const members = byDept[dept];
    // Place each member around the cluster center.
    members.forEach((a, i) => {
      const subAngle = (i / Math.max(members.length, 1)) * 2 * Math.PI + di;
      positions[a.id] = {
        x: cx + CLUSTER_RADIUS * Math.cos(subAngle),
        y: cy + CLUSTER_RADIUS * Math.sin(subAngle),
      };
    });
  });

  return positions;
}

/* ---------- radius (circle size) by seniority ---------- */
function radiusFor(a: Agent, meta: Meta): number {
  if (a.codename === 'ORION') return 3.0; // CEO — large
  if (CSUITE.includes(a.codename)) return 2.0; // C-Suite
  switch (meta.seniority) {
    case 'c-suite': return 2.2;
    case 'director': return 1.6;
    case 'vp': return 1.6;
    case 'lead': return 1.5;
    case 'senior': return 1.4;
    case 'mid': return 1.2;
    case 'junior': return 1.05;
    case 'intern': return 0.95;
    default: return 1.1;
  }
}

/* ---------- edges ---------- */
interface Edge { from: string; to: string; }

function computeEdges(agents: Agent[]): Edge[] {
  const ceo = agents.find((a) => a.codename === 'ORION');
  const ceoId = ceo?.id;
  const csuiteIds = agents.filter((a) => CSUITE.includes(a.codename)).map((a) => a.id);
  const edges: Edge[] = [];
  // CEO → C-Suite
  if (ceoId) for (const id of csuiteIds) edges.push({ from: ceoId, to: id });

  // Each C-Suite "owns" 4 of the 16 departments. Map them by index.
  // (ATLAS → engineering/research/data/qa, ECHO → design/product/marketing/content,
  //  APEX → finance/legal/hr/operations, PULSE → sales/security/support/infrastructure)
  const deptGroups: Record<string, string[]> = {
    ATLAS: ['engineering', 'research', 'data', 'qa'],
    ECHO: ['design', 'product', 'marketing', 'content'],
    APEX: ['finance', 'legal', 'hr', 'operations'],
    PULSE: ['sales', 'security', 'support', 'infrastructure'],
  };

  // Index agents by dept
  const byDept: Record<string, Agent[]> = {};
  for (const a of agents) {
    if (a.codename === 'ORION' || CSUITE.includes(a.codename)) continue;
    const dept = metaFor(a).department;
    (byDept[dept] ??= []).push(a);
  }

  // For each C-Suite, link to the senior-most agent of each owned department.
  CSUITE.forEach((codename) => {
    const head = agents.find((a) => a.codename === codename);
    if (!head) return;
    const owned = deptGroups[codename] || [];
    for (const dept of owned) {
      const members = byDept[dept] || [];
      if (members.length === 0) continue;
      // pick senior-most (or first)
      const sorted = [...members].sort((x, y) => {
        const sx = metaFor(x).seniority;
        const sy = metaFor(y).seniority;
        const order = ['c-suite', 'director', 'vp', 'lead', 'senior', 'mid', 'junior', 'intern'];
        return order.indexOf(sx) - order.indexOf(sy);
      });
      edges.push({ from: head.id, to: sorted[0].id });
    }
  });

  return edges;
}

/* ---------- department legend ---------- */
const DEPT_LEGEND = DEPARTMENTS.map((d) => ({ key: d.key, name: d.name, color: d.color }));

/* ============================================================================ */
/* MAIN COMPONENT                                                               */
/* ============================================================================ */
export default function AgentNetworkTab() {
  const { data, loading, error, refresh } = useApi<{ agents: Agent[] }>('/api/agents', 10000);
  const agents = data?.agents ?? [];

  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number; wrapW: number; wrapH: number } | null>(null);
  const svgWrapRef = useRef<HTMLDivElement>(null);

  /* Compute layout + edges (memoized against agents array identity) */
  const { positions, edges, agentById } = useMemo(() => {
    const pos = computeLayout(agents);
    const edg = computeEdges(agents);
    const byId: Record<string, Agent> = {};
    for (const a of agents) byId[a.id] = a;
    return { positions: pos, edges: edg, agentById: byId };
  }, [agents]);

  const hoveredAgent = hoveredId ? agentById[hoveredId] : null;
  const hoveredMeta = hoveredAgent ? metaFor(hoveredAgent) : null;

  /* Stats — 6 tiles */
  const stats = useMemo(() => {
    const total = agents.length;
    const byStatus: Record<string, number> = {};
    let loadedCount = 0;
    for (const a of agents) {
      byStatus[a.status] = (byStatus[a.status] ?? 0) + 1;
      if (a.load > 50) loadedCount++;
    }
    return {
      total,
      working: byStatus['working'] ?? 0,
      thinking: byStatus['thinking'] ?? 0,
      error: byStatus['error'] ?? 0,
      idle: byStatus['idle'] ?? 0,
      offline: byStatus['offline'] ?? 0,
      loaded: loadedCount,
    };
  }, [agents]);

  /* Active edges = (edges where from/to agent is working|thinking) ∪
   *                 (edges connected to hoveredId, for inspection).
   * This drives BOTH the line color/stroke boost AND the animated
   * <animateMotion> data packets. Idle agents therefore show no flows
   * unless the user is actively inspecting them. */
  const activeEdges = useMemo(() => {
    const set = new Set<string>();
    for (const e of edges) {
      const fromA = agentById[e.from];
      const toA = agentById[e.to];
      const fromActive = fromA && (fromA.status === 'working' || fromA.status === 'thinking');
      const toActive = toA && (toA.status === 'working' || toA.status === 'thinking');
      const hovered = hoveredId && (e.from === hoveredId || e.to === hoveredId);
      if (fromActive || toActive || hovered) {
        set.add(`${e.from}->${e.to}`);
      }
    }
    return set;
  }, [edges, agentById, hoveredId]);

  /* Pre-compute the set of agent IDs that are working|thinking so we can
   * dim idle agents in the SVG render. Recomputed on every agents-array
   * identity change (i.e. every 10s poll when statuses update). */
  const activeAgentIds = useMemo(() => {
    const set = new Set<string>();
    for (const a of agents) {
      if (a.status === 'working' || a.status === 'thinking') set.add(a.id);
    }
    return set;
  }, [agents]);

  /* Track mouse over the SVG wrapper for tooltip placement */
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = svgWrapRef.current?.getBoundingClientRect();
    if (!rect) return;
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      wrapW: rect.width,
      wrapH: rect.height,
    });
  };

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Agent Network"
        icon={Share2}
        accent={JARVIS.colors.cyan}
        action={
          <button
            onClick={refresh}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]/50 transition-colors"
            title="Refresh"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* ── 6 stat tiles ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatTile label="Total Agents" value={stats.total} icon={Bot} color={JARVIS.colors.cyan} delay={0} />
        <StatTile label="Executing" value={stats.working} icon={Zap} color={JARVIS.colors.green} delay={0.05} />
        <StatTile label="Monitoring" value={stats.thinking} icon={Radio} color={JARVIS.colors.violet} delay={0.1} />
        <StatTile label="Error Handlers" value={stats.error} icon={ShieldAlert} color={JARVIS.colors.red} delay={0.15} />
        <StatTile label="Working" value={stats.loaded} icon={Activity} color={JARVIS.colors.amber} delay={0.2} />
        <StatTile label="Idle" value={stats.idle} icon={Pause} color={JARVIS.colors.textDim} delay={0.25} />
      </div>

      {error && (
        <div className="jarvis-panel p-3 text-xs text-[var(--j-red)] border-[var(--j-red)]/30">
          ⚠ Failed to load agents: {error}
        </div>
      )}

      {loading && agents.length === 0 ? (
        <div className="jarvis-panel p-8">
          <EmptyState icon={Share2} message="Building network graph" hint="Fetching live agent data from /api/agents" />
        </div>
      ) : (
        <>
          {/* ── Network SVG (desktop / tablet) ── */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="hidden md:block jarvis-panel p-3 relative overflow-hidden"
          >
            {/* Department legend */}
            <div className="absolute top-3 left-3 z-10 flex flex-wrap gap-1.5 max-w-[60%]">
              {DEPT_LEGEND.map((d) => (
                <span
                  key={d.key}
                  className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded flex items-center gap-1"
                  style={{ color: d.color, background: `${d.color}12`, border: `1px solid ${d.color}33` }}
                >
                  <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ background: d.color }} />
                  {d.name}
                </span>
              ))}
            </div>

            {/* Status legend */}
            <div className="absolute top-3 right-3 z-10 flex flex-col gap-1 items-end">
              <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Status</span>
              {(['working', 'thinking', 'idle', 'error', 'offline'] as AgentStatus[]).map((s) => (
                <span key={s} className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-dim)]">
                  <span
                    className="inline-block w-2 h-2 rounded-full"
                    style={{ background: STATUS_COLORS[s], boxShadow: `0 0 6px ${STATUS_COLORS[s]}` }}
                  />
                  {s}
                </span>
              ))}
            </div>

            <div
              ref={svgWrapRef}
              onMouseMove={handleMouseMove}
              onMouseLeave={() => { setHoveredId(null); setMousePos(null); }}
              className="relative w-full"
              style={{ aspectRatio: '1 / 1', maxHeight: '70vh' }}
            >
              <svg
                viewBox={`0 0 ${VIEW} ${VIEW}`}
                className="w-full h-full"
                preserveAspectRatio="xMidYMid meet"
              >
                {/* Background concentric guides */}
                <circle cx={CENTER} cy={CENTER} r={CSUITE_RADIUS} fill="none" stroke="rgba(125,211,252,0.06)" strokeWidth={0.15} strokeDasharray="0.5 0.5" />
                <circle cx={CENTER} cy={CENTER} r={OUTER_RADIUS} fill="none" stroke="rgba(125,211,252,0.06)" strokeWidth={0.15} strokeDasharray="0.5 0.5" />
                <circle cx={CENTER} cy={CENTER} r={(CSUITE_RADIUS + OUTER_RADIUS) / 2} fill="none" stroke="rgba(125,211,252,0.04)" strokeWidth={0.1} />

                {/* Edges */}
                <g>
                  {edges.map((e, i) => {
                    const p1 = positions[e.from];
                    const p2 = positions[e.to];
                    if (!p1 || !p2) return null;
                    const isActive = activeEdges.has(`${e.from}->${e.to}`);
                    return (
                      <g key={`edge-${i}`}>
                        <line
                          x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                          stroke={isActive ? 'rgba(125,211,252,0.85)' : 'rgba(125,211,252,0.18)'}
                          strokeWidth={isActive ? 0.35 : 0.15}
                          strokeLinecap="round"
                        />
                        {/* Data packet animation along active edges */}
                        {isActive && (
                          <circle r={0.4} fill={JARVIS.colors.cyan}>
                            <animateMotion dur="1.4s" repeatCount="indefinite" path={`M${p1.x},${p1.y} L${p2.x},${p2.y}`} />
                          </circle>
                        )}
                      </g>
                    );
                  })}
                </g>

                {/* Department cluster labels */}
                {(() => {
                  const byDept: Record<string, Agent[]> = {};
                  for (const a of agents) {
                    if (a.codename === 'ORION' || CSUITE.includes(a.codename)) continue;
                    (byDept[metaFor(a).department] ??= []).push(a);
                  }
                  const deptKeys = Object.keys(byDept).sort();
                  const deptCount = deptKeys.length || 1;
                  return deptKeys.map((dept, di) => {
                    const angle = (di / deptCount) * 2 * Math.PI - Math.PI / 2;
                    // label sits slightly outside the cluster
                    const lx = CENTER + (OUTER_RADIUS + 7) * Math.cos(angle);
                    const ly = CENTER + (OUTER_RADIUS + 7) * Math.sin(angle);
                    const color = DEPT_COLOR[dept] ?? JARVIS.colors.textDim;
                    const rotate = (angle * 180) / Math.PI;
                    // keep text upright on the left half
                    const flip = Math.cos(angle) < 0;
                    return (
                      <text
                        key={`label-${dept}`}
                        x={lx} y={ly}
                        fontSize={1.6}
                        fill={color}
                        opacity={0.7}
                        textAnchor={flip ? 'end' : 'start'}
                        transform={`rotate(${flip ? rotate + 180 : rotate} ${lx} ${ly})`}
                        className="jarvis-mono"
                        style={{ letterSpacing: '0.1em', textTransform: 'uppercase' }}
                      >
                        {DEPT_NAME[dept] ?? dept}
                      </text>
                    );
                  });
                })()}

                {/* Agent circles */}
                <g>
                  {agents.map((a, i) => {
                    const pos = positions[a.id];
                    if (!pos) return null;
                    const meta = metaFor(a);
                    const r = radiusFor(a, meta);
                    const deptColor = DEPT_COLOR[meta.department] ?? JARVIS.colors.textDim;
                    const statusColor = STATUS_COLORS[a.status as AgentStatus] ?? JARVIS.colors.textDim;
                    const isHovered = hoveredId === a.id;
                    const isSelected = selectedId === a.id;
                    const isCEO = a.codename === 'ORION';
                    const isCSuite = CSUITE.includes(a.codename);
                    const pulse = a.status === 'working' || a.status === 'thinking';
                    // Idle / offline / error agents are dimmed; working/thinking
                    // agents render at full opacity with a subtle glow.
                    const isActive = activeAgentIds.has(a.id);
                    const dimmed = !isActive && a.status !== 'error';
                    const nodeOpacity = dimmed ? 0.5 : 1;
                    return (
                      <motion.g
                        key={a.id}
                        initial={{ opacity: 0, scale: 0 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, delay: Math.min(i * 0.008, 0.8) }}
                        style={{ cursor: 'pointer', transformOrigin: `${pos.x}px ${pos.y}px` }}
                        onMouseEnter={() => setHoveredId(a.id)}
                        onClick={() => setSelectedId(a.id)}
                      >
                        {/* Dimming wrapper — applies to all child shapes so idle
                          * agents fade into the background while working/thinking
                          * agents stay bright. SVG `opacity` cascades. */}
                        <g opacity={nodeOpacity}>
                        {/* Subtle glow halo for active agents */}
                        {isActive && (
                          <circle cx={pos.x} cy={pos.y} r={r + 0.8} fill={statusColor} opacity={0.18} />
                        )}
                        {/* Pulsing aura for active agents */}
                        {pulse && (
                          <circle cx={pos.x} cy={pos.y} r={r} fill="none" stroke={statusColor} strokeWidth={0.2} opacity={0.5}>
                            <animate attributeName="r" values={`${r};${r * 1.8};${r}`} dur="2s" repeatCount="indefinite" />
                            <animate attributeName="opacity" values="0.6;0;0.6" dur="2s" repeatCount="indefinite" />
                          </circle>
                        )}
                        {/* Outer status ring */}
                        <circle
                          cx={pos.x} cy={pos.y} r={r + 0.35}
                          fill="none"
                          stroke={isHovered || isSelected ? statusColor : `${statusColor}66`}
                          strokeWidth={isHovered || isSelected ? 0.5 : 0.25}
                        />
                        {/* Main circle (dept color) */}
                        <circle
                          cx={pos.x} cy={pos.y} r={r}
                          fill={`${deptColor}33`}
                          stroke={isHovered || isSelected ? JARVIS.colors.text : deptColor}
                          strokeWidth={isHovered || isSelected ? 0.45 : 0.2}
                        />
                        {/* Status dot at center for non-CEO */}
                        {!isCEO && (
                          <circle cx={pos.x} cy={pos.y} r={r * 0.35} fill={statusColor}>
                            {pulse && (
                              <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite" />
                            )}
                          </circle>
                        )}
                        {/* CEO — inner glyph */}
                        {isCEO && (
                          <text x={pos.x} y={pos.y + 0.6} fontSize={2.6} fill={JARVIS.colors.text} textAnchor="middle" className="jarvis-mono" style={{ fontWeight: 700 }}>
                            ★
                          </text>
                        )}
                        {/* Label: only for CEO + C-Suite (others too crowded) */}
                        {(isCEO || isCSuite) && (
                          <text
                            x={pos.x} y={pos.y + r + 2.2}
                            fontSize={1.7}
                            fill={isCEO ? JARVIS.colors.text : deptColor}
                            textAnchor="middle"
                            className="jarvis-mono"
                            style={{ letterSpacing: '0.1em', fontWeight: 600 }}
                          >
                            {a.codename}
                          </text>
                        )}
                        </g>
                      </motion.g>
                    );
                  })}
                </g>
              </svg>

              {/* Hover tooltip (mouse-following) */}
              <AnimatePresence>
                {hoveredAgent && hoveredMeta && mousePos && (
                  <HoverTooltip
                    agent={hoveredAgent}
                    meta={hoveredMeta}
                    mousePos={mousePos}
                  />
                )}
              </AnimatePresence>
            </div>

            <div className="mt-2 px-1 flex items-center justify-between text-[10px] jarvis-mono uppercase text-[var(--j-text-mute)]">
              <span>{agents.length} agents · {edges.length} edges · {activeAgentIds.size} active</span>
              <span className="hidden lg:inline">Flows on working/thinking agents · Hover to inspect</span>
              <span>Polls every 10s</span>
            </div>
          </motion.div>

          {/* ── Mobile card grid fallback ── */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="md:hidden grid grid-cols-2 gap-2"
          >
            {agents.map((a, i) => {
              const meta = metaFor(a);
              const color = DEPT_COLOR[meta.department] ?? JARVIS.colors.textDim;
              const statusColor = STATUS_COLORS[a.status as AgentStatus] ?? JARVIS.colors.textDim;
              return (
                <motion.button
                  key={a.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.01, 0.5) }}
                  onClick={() => setSelectedId(a.id)}
                  className="jarvis-panel p-3 text-left flex items-start gap-2.5"
                >
                  <div
                    className="shrink-0 mt-0.5 rounded-full flex items-center justify-center"
                    style={{
                      width: 32, height: 32,
                      background: `${color}1f`, border: `1.5px solid ${color}`,
                      boxShadow: `0 0 8px ${statusColor}55`,
                    }}
                  >
                    <span className="w-2 h-2 rounded-full" style={{ background: statusColor }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="jarvis-mono text-[11px] font-semibold truncate" style={{ color }}>{a.codename}</div>
                    <div className="text-[10px] text-[var(--j-text-dim)] truncate">{a.role}</div>
                    <div className="text-[9px] text-[var(--j-text-mute)] mt-0.5">{DEPT_NAME[meta.department] ?? meta.department} · {a.load}% load</div>
                  </div>
                </motion.button>
              );
            })}
          </motion.div>
        </>
      )}

      {/* ── Right detail panel ── */}
      <AnimatePresence>
        {selectedId && (
          <DetailPanel
            agentId={selectedId}
            onClose={() => setSelectedId(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ============================================================================ */
/* STAT TILE                                                                    */
/* ============================================================================ */
function StatTile({
  label, value, icon: Icon, color, delay,
}: {
  label: string;
  value: number;
  icon: typeof Bot;
  color: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay }}
      className="jarvis-panel p-3 relative overflow-hidden"
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">{label}</div>
          <div className="mt-0.5 text-2xl font-semibold tracking-tight" style={{ color }}>{value}</div>
        </div>
        <div
          className="flex h-8 w-8 items-center justify-center rounded-md"
          style={{ background: `${color}1a`, border: `1px solid ${color}33`, color }}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div
        className="absolute bottom-0 left-0 h-[2px]"
        style={{ width: '50%', background: `linear-gradient(90deg, ${color}, transparent)` }}
      />
    </motion.div>
  );
}

/* ============================================================================ */
/* HOVER TOOLTIP                                                                */
/* ============================================================================ */
function HoverTooltip({
  agent, meta, mousePos,
}: {
  agent: Agent;
  meta: Meta;
  mousePos: { x: number; y: number; wrapW: number; wrapH: number };
}) {
  const deptColor = DEPT_COLOR[meta.department] ?? JARVIS.colors.textDim;
  const statusColor = STATUS_COLORS[agent.status as AgentStatus] ?? JARVIS.colors.textDim;
  const skills = meta.skills.length > 0 ? meta.skills : parseSkills(agent.skills);

  // Position: prefer right of cursor, flip if too close to right edge.
  const { x, y, wrapW, wrapH } = mousePos;
  const tooltipW = 240;
  const tooltipH = 200;
  let left = x + 16;
  let top = y + 16;
  if (left + tooltipW > wrapW) left = x - tooltipW - 16;
  if (top + tooltipH > wrapH) top = y - tooltipH - 16;
  if (left < 4) left = 4;
  if (top < 4) top = 4;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92 }}
      transition={{ duration: 0.14 }}
      className="absolute z-30 pointer-events-none"
      style={{ left, top, width: tooltipW }}
    >
      <div
        className="jarvis-panel p-3 backdrop-blur-md"
        style={{
          background: 'rgba(12,15,20,0.95)',
          borderColor: `${deptColor}55`,
          boxShadow: `0 8px 32px rgba(0,0,0,0.6), 0 0 0 1px ${deptColor}22`,
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="jarvis-mono text-sm font-bold tracking-wide truncate" style={{ color: deptColor }}>
              {agent.codename}
            </div>
            <div className="text-[11px] text-[var(--j-text)] truncate">{agent.name}</div>
            <div className="text-[10px] text-[var(--j-text-dim)] truncate">{meta.title || agent.role}</div>
          </div>
          <div className="shrink-0 flex flex-col items-end gap-1">
            <span className="flex items-center gap-1 jarvis-mono text-[9px] uppercase" style={{ color: statusColor }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: statusColor, boxShadow: `0 0 6px ${statusColor}` }} />
              {agent.status}
            </span>
            <Pill color={deptColor}>{DEPT_NAME[meta.department] ?? meta.department}</Pill>
          </div>
        </div>

        {/* Load bar */}
        <div className="mt-2">
          <div className="flex items-center justify-between jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
            <span>Load</span>
            <span style={{ color: deptColor }}>{Math.round(agent.load)}%</span>
          </div>
          <div className="mt-1 h-1.5 rounded-full bg-[var(--j-panel-soft)] overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(100, agent.load)}%` }}
              transition={{ duration: 0.4 }}
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${deptColor}, ${statusColor})` }}
            />
          </div>
        </div>

        {/* Stats row */}
        <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]">
          <div className="flex items-center gap-1">
            <Trophy className="h-3 w-3 text-[var(--j-text-mute)]" />
            <span className="text-[var(--j-text-dim)]">Success</span>
            <span className="ml-auto jarvis-mono" style={{ color: agent.successRate >= 95 ? JARVIS.colors.green : agent.successRate >= 90 ? JARVIS.colors.amber : JARVIS.colors.red }}>
              {agent.successRate.toFixed(1)}%
            </span>
          </div>
          <div className="flex items-center gap-1">
            <ListTodo className="h-3 w-3 text-[var(--j-text-mute)]" />
            <span className="text-[var(--j-text-dim)]">Tasks</span>
            <span className="ml-auto jarvis-mono text-[var(--j-text)]">{agent.taskCount}</span>
          </div>
        </div>

        {/* Skills */}
        {skills.length > 0 && (
          <div className="mt-2">
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-1">Skills</div>
            <div className="flex flex-wrap gap-1">
              {skills.slice(0, 3).map((s) => (
                <span
                  key={s}
                  className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded"
                  style={{ color: deptColor, background: `${deptColor}12`, border: `1px solid ${deptColor}33` }}
                >
                  {s}
                </span>
              ))}
              {skills.length > 3 && (
                <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">+{skills.length - 3}</span>
              )}
            </div>
          </div>
        )}

        {/* Footer hint */}
        <div className="mt-2 pt-2 border-t border-[var(--j-border)] flex items-center gap-1 text-[9px] jarvis-mono uppercase text-[var(--j-text-mute)]">
          <Sparkles className="h-2.5 w-2.5" />
          Click to inspect
        </div>
      </div>
    </motion.div>
  );
}

/* ============================================================================ */
/* DETAIL PANEL (right sidebar)                                                 */
/* ============================================================================ */
function DetailPanel({ agentId, onClose }: { agentId: string; onClose: () => void }) {
  const { toast } = useToast();
  // useApi with intervalMs=0 fetches once when agentId changes (no polling).
  const { data, loading, error } = useApi<{ agent: AgentDetail }>(`/api/agents/${agentId}`, 0);
  const detail = data?.agent ?? null;
  const err = error;

  if (!detail && loading) {
    return (
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 26, stiffness: 240 }}
        className="fixed top-0 right-0 z-40 h-full w-full max-w-md jarvis-panel border-l border-[var(--j-border)] p-6 flex items-center justify-center"
        style={{ background: 'rgba(8,9,10,0.96)', backdropFilter: 'blur(12px)' }}
      >
        <div className="flex flex-col items-center gap-3">
          <RefreshCw className="h-6 w-6 animate-spin text-[var(--j-cyan)]" />
          <div className="jarvis-mono text-[10px] uppercase text-[var(--j-text-dim)]">Loading agent details…</div>
        </div>
      </motion.div>
    );
  }

  if (err || !detail) {
    return (
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 26, stiffness: 240 }}
        className="fixed top-0 right-0 z-40 h-full w-full max-w-md jarvis-panel border-l border-[var(--j-border)] p-6"
        style={{ background: 'rgba(8,9,10,0.96)', backdropFilter: 'blur(12px)' }}
      >
        <div className="flex items-center justify-between mb-4">
          <span className="jarvis-mono text-xs uppercase text-[var(--j-red)]">Error</span>
          <button onClick={onClose} className="text-[var(--j-text-dim)] hover:text-[var(--j-text)]"><X className="h-4 w-4" /></button>
        </div>
        <div className="text-sm text-[var(--j-text-dim)]">{err || 'Agent not found'}</div>
      </motion.div>
    );
  }

  const meta = metaFor(detail);
  const deptColor = DEPT_COLOR[meta.department] ?? JARVIS.colors.textDim;
  const statusColor = STATUS_COLORS[detail.status as AgentStatus] ?? JARVIS.colors.textDim;
  const skills = meta.skills.length > 0 ? meta.skills : parseSkills(detail.skills);
  const logs = detail.logs ?? [];

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-30 bg-black/40 backdrop-blur-[2px]"
      />
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 26, stiffness: 240 }}
        className="fixed top-0 right-0 z-40 h-full w-full max-w-md overflow-y-auto"
        style={{
          background: 'rgba(8,9,10,0.98)',
          backdropFilter: 'blur(12px)',
          borderLeft: `1px solid ${deptColor}55`,
          boxShadow: `-8px 0 32px rgba(0,0,0,0.6), 0 0 0 1px ${deptColor}22`,
        }}
      >
        {/* Header */}
        <div
          className="sticky top-0 z-10 px-5 py-4 flex items-start justify-between gap-3"
          style={{
            background: 'rgba(8,9,10,0.95)',
            borderBottom: `1px solid ${deptColor}33`,
          }}
        >
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <div
                className="flex items-center justify-center rounded-full shrink-0"
                style={{
                  width: 36, height: 36,
                  background: `${deptColor}1f`,
                  border: `2px solid ${deptColor}`,
                  boxShadow: `0 0 12px ${statusColor}66`,
                }}
              >
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: statusColor }} />
              </div>
              <div className="min-w-0">
                <div className="jarvis-mono text-base font-bold tracking-wide truncate" style={{ color: deptColor }}>
                  {detail.codename}
                </div>
                <div className="text-xs text-[var(--j-text)] truncate">{detail.name}</div>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="shrink-0 text-[var(--j-text-dim)] hover:text-[var(--j-text)] rounded-md p-1 hover:bg-[var(--j-panel-soft)]"
            aria-label="Close panel"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Role + title */}
          <div className="flex flex-wrap items-center gap-1.5">
            <Pill color={deptColor}>{DEPT_NAME[meta.department] ?? meta.department}</Pill>
            <Pill color={JARVIS.colors.violet}>{meta.seniority}</Pill>
            <span className="flex items-center gap-1 jarvis-mono text-[9px] uppercase" style={{ color: statusColor }}>
              <StatusDot status={detail.status as AgentStatus} size={8} />
              {detail.status}
            </span>
          </div>

          <div>
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">Role</div>
            <div className="text-sm text-[var(--j-text)]">{detail.role}</div>
            {meta.title && meta.title !== detail.role && (
              <div className="text-xs text-[var(--j-text-dim)] mt-0.5">{meta.title}</div>
            )}
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="jarvis-panel p-3">
              <div className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                <Gauge className="h-3 w-3" /> Load
              </div>
              <div className="mt-1 text-lg font-semibold" style={{ color: deptColor }}>{Math.round(detail.load)}%</div>
              <div className="mt-1 h-1 rounded-full bg-[var(--j-panel-soft)] overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${Math.min(100, detail.load)}%`, background: deptColor }} />
              </div>
            </div>
            <div className="jarvis-panel p-3">
              <div className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                <Trophy className="h-3 w-3" /> Success Rate
              </div>
              <div className="mt-1 text-lg font-semibold" style={{ color: detail.successRate >= 95 ? JARVIS.colors.green : detail.successRate >= 90 ? JARVIS.colors.amber : JARVIS.colors.red }}>
                {detail.successRate.toFixed(1)}%
              </div>
            </div>
            <div className="jarvis-panel p-3">
              <div className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                <ListTodo className="h-3 w-3" /> Tasks
              </div>
              <div className="mt-1 text-lg font-semibold text-[var(--j-text)]">{detail.taskCount}</div>
            </div>
            <div className="jarvis-panel p-3">
              <div className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                <Cpu className="h-3 w-3" /> Logs
              </div>
              <div className="mt-1 text-lg font-semibold text-[var(--j-text)]">{detail.logCount}</div>
            </div>
          </div>

          {/* Model */}
          <div className="jarvis-panel p-3">
            <div className="flex items-center gap-1.5 jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-1">
              <Cpu className="h-3 w-3" /> Model Preference
            </div>
            <div className="text-sm text-[var(--j-text)] jarvis-mono">{detail.model}</div>
          </div>

          {/* Skills */}
          <div>
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-2">Skills ({skills.length})</div>
            {skills.length === 0 ? (
              <div className="text-xs text-[var(--j-text-mute)] italic">No skills assigned</div>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="jarvis-mono text-[10px] uppercase px-2 py-1 rounded"
                    style={{ color: deptColor, background: `${deptColor}12`, border: `1px solid ${deptColor}33` }}
                  >
                    {s}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Recent logs */}
          <div>
            <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-2 flex items-center justify-between">
              <span>Recent Logs</span>
              {logs.length > 0 && <span className="text-[var(--j-text-mute)]">{logs.length} shown</span>}
            </div>
            {logs.length === 0 ? (
              <div className="text-xs text-[var(--j-text-mute)] italic">No recent logs</div>
            ) : (
              <div className="max-h-72 overflow-y-auto space-y-1.5 pr-1 jarvis-scroll">
                {logs.map((l) => {
                  const lc = (LEVEL_MAP[l.level] ?? JARVIS.colors.textDim);
                  return (
                    <div
                      key={l.id}
                      className="jarvis-panel p-2 text-[11px]"
                      style={{ borderLeft: `2px solid ${lc}` }}
                    >
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="jarvis-mono text-[9px] uppercase" style={{ color: lc }}>{l.level}</span>
                        <span className="text-[9px] text-[var(--j-text-mute)]">{timeAgo(l.createdAt)}</span>
                      </div>
                      <div className="text-[var(--j-text-dim)] break-words leading-snug">{l.message}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="pt-2 border-t border-[var(--j-border)] flex items-center justify-between text-[10px] jarvis-mono uppercase text-[var(--j-text-mute)]">
            <span>Last active {timeAgo(detail.lastActive)}</span>
            <button
              onClick={() => {
                navigator.clipboard?.writeText(detail.codename).then(() => toast({ title: `${detail.codename} copied` }));
              }}
              className="hover:text-[var(--j-cyan)] flex items-center gap-1"
            >
              <ChevronRight className="h-3 w-3" /> Copy ID
            </button>
          </div>
        </div>
      </motion.aside>
    </>
  );
}

const LEVEL_MAP: Record<string, string> = {
  info: JARVIS.colors.cyan,
  success: JARVIS.colors.green,
  warn: JARVIS.colors.amber,
  error: JARVIS.colors.red,
  debug: JARVIS.colors.textMute,
};
