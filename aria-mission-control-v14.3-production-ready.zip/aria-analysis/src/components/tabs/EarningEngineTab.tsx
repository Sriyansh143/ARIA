'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign, Rocket, Target, Loader2, Sparkles, AlertCircle, CheckCircle2, Zap } from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, StatCard, Pill } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface EarningStats {
  totalMethods: number;
  approvedMethods: number;
  deployedMethods: number;
  totalRevenue: number;
  monthlyProjected: number;
  topEarners: Array<{ name: string; revenue: number }>;
  pendingApprovals: number;
  activeAgents: number;
}

interface Opportunity {
  title: string;
  description: string;
  category: string;
  estimatedRevenue: number;
  estimatedTimeHours: number;
  riskLevel: string;
  skillsRequired: string[];
  method: string;
  marketDemand: string;
  competition: string;
  priority: number;
}

interface PipelineResult {
  found: number;
  qualified: number;
  created: number;
  opportunities: Array<{ title: string; score: number; qualified: boolean }>;
}

export default function EarningEngineTab() {
  const { toast } = useToast();
  const { data: stats, refresh: refreshStats } = useApi<EarningStats>('/api/earning-engine', 30000);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [pipelineResult, setPipelineResult] = useState<PipelineResult | null>(null);
  const [loading, setLoading] = useState<'find' | 'pipeline' | null>(null);

  const s = stats ?? {
    totalMethods: 0, approvedMethods: 0, deployedMethods: 0,
    totalRevenue: 0, monthlyProjected: 0, topEarners: [], pendingApprovals: 0, activeAgents: 0,
  };

  const findOpportunities = async () => {
    setLoading('find');
    setOpportunities([]);
    try {
      const res = (await postJson('/api/earning-engine', { action: 'find', count: 5 })) as { opportunities: Opportunity[] };
      setOpportunities(res.opportunities ?? []);
      toast({ title: `Found ${res.opportunities?.length ?? 0} opportunities` });
    } catch (e) {
      toast({ title: 'Search failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setLoading(null);
    }
  };

  const runPipeline = async () => {
    setLoading('pipeline');
    setPipelineResult(null);
    try {
      const res = (await postJson('/api/earning-engine', { action: 'pipeline', count: 3 })) as PipelineResult;
      setPipelineResult(res);
      refreshStats();
      toast({ title: `Pipeline complete: ${res.created} methods created` });
    } catch (e) {
      toast({ title: 'Pipeline failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Earning Engine"
        icon={TrendingUp}
        accent={JARVIS.colors.green}
        action={
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={findOpportunities} disabled={loading !== null} className="border-[var(--j-border)] text-[var(--j-text-dim)] h-8">
              {loading === 'find' ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Sparkles className="h-3.5 w-3.5 mr-1" />}
              Find Opportunities
            </Button>
            <Button size="sm" onClick={runPipeline} disabled={loading !== null} className="jarvis-btn-accent border-0 h-8">
              {loading === 'pipeline' ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Rocket className="h-3.5 w-3.5 mr-1" />}
              Run Pipeline
            </Button>
          </div>
        }
      />

      {/* Revenue stats — the #1 most important metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Revenue" value={`₹${s.totalRevenue.toLocaleString()}`} icon={DollarSign} accent={JARVIS.colors.green} />
        <StatCard label="Monthly Projected" value={`₹${s.monthlyProjected.toLocaleString()}`} icon={TrendingUp} accent={JARVIS.colors.cyan} />
        <StatCard label="Deployed Methods" value={s.deployedMethods} icon={Rocket} accent={JARVIS.colors.violet} />
        <StatCard label="Active Agents" value={s.activeAgents} icon={Zap} accent={JARVIS.colors.amber} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Methods" value={s.totalMethods} icon={Target} accent={JARVIS.colors.cyan} />
        <StatCard label="Approved" value={s.approvedMethods} icon={CheckCircle2} accent={JARVIS.colors.green} />
        <StatCard label="Pending Approval" value={s.pendingApprovals} icon={AlertCircle} accent={JARVIS.colors.amber} />
        <StatCard label="Net Revenue" value={`₹${s.totalRevenue.toLocaleString()}`} icon={DollarSign} accent={JARVIS.colors.green} />
      </div>

      {/* Top earners */}
      {s.topEarners.length > 0 && (
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)] mb-3 flex items-center gap-2">
            <TrendingUp className="h-3.5 w-3.5" style={{ color: JARVIS.colors.green }} />
            Top Earning Methods
          </h3>
          <div className="space-y-2">
            {s.topEarners.map((earner, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-[var(--j-panel-soft)]">
                <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.green }}>#{i + 1}</span>
                <span className="text-sm text-[var(--j-text)] flex-1 truncate">{earner.name}</span>
                <span className="jarvis-mono text-sm font-bold text-[var(--j-green)]">₹{earner.revenue.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Pipeline result */}
      {pipelineResult && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)] mb-3">Pipeline Result</h3>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="text-center p-2 rounded-lg bg-[var(--j-panel-soft)]">
                <div className="text-2xl font-bold text-[var(--j-cyan)]">{pipelineResult.found}</div>
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Found</div>
              </div>
              <div className="text-center p-2 rounded-lg bg-[var(--j-panel-soft)]">
                <div className="text-2xl font-bold text-[var(--j-amber)]">{pipelineResult.qualified}</div>
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Qualified</div>
              </div>
              <div className="text-center p-2 rounded-lg bg-[var(--j-panel-soft)]">
                <div className="text-2xl font-bold text-[var(--j-green)]">{pipelineResult.created}</div>
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Created</div>
              </div>
            </div>
            <div className="space-y-1">
              {pipelineResult.opportunities.map((opp, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  {opp.qualified ? <CheckCircle2 className="h-3 w-3 text-[var(--j-green)]" /> : <XCircle className="h-3 w-3 text-[var(--j-red)]" />}
                  <span className="text-[var(--j-text-dim)] flex-1 truncate">{opp.title}</span>
                  <span className="jarvis-mono text-[10px]" style={{ color: opp.score >= 60 ? JARVIS.colors.green : JARVIS.colors.amber }}>{opp.score}/100</span>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      )}

      {/* Found opportunities */}
      {opportunities.length > 0 && (
        <div className="space-y-2">
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)] flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5" style={{ color: JARVIS.colors.violet }} />
            AI-Found Opportunities ({opportunities.length})
          </h3>
          {opportunities.map((opp, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
                <div className="flex items-start gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-md shrink-0" style={{ background: `${JARVIS.colors.green}1a`, border: `1px solid ${JARVIS.colors.green}33`, color: JARVIS.colors.green }}>
                    <span className="jarvis-mono text-xs font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-sm font-medium text-[var(--j-text)]">{opp.title}</span>
                      <Pill color={JARVIS.colors.cyan}>{opp.category}</Pill>
                      <Pill color={opp.riskLevel === 'low' ? JARVIS.colors.green : opp.riskLevel === 'medium' ? JARVIS.colors.amber : JARVIS.colors.red}>{opp.riskLevel} risk</Pill>
                      <Pill color={JARVIS.colors.violet}>demand: {opp.marketDemand}</Pill>
                    </div>
                    <p className="text-xs text-[var(--j-text-dim)] mb-2">{opp.description}</p>
                    <div className="flex items-center gap-4 text-[11px] text-[var(--j-text-mute)] jarvis-mono">
                      <span className="text-[var(--j-green)] font-bold">₹{opp.estimatedRevenue.toLocaleString()}/mo</span>
                      <span>⏱ {opp.estimatedTimeHours}h to build</span>
                      <span>skills: {opp.skillsRequired.slice(0, 3).join(', ')}</span>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Empty state */}
      {opportunities.length === 0 && !pipelineResult && !loading && (
        <Card className="p-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] text-center">
          <Rocket className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)]" />
          <div className="text-sm text-[var(--j-text-dim)]">Click "Find Opportunities" or "Run Pipeline" to start earning.</div>
          <div className="text-[11px] text-[var(--j-text-mute)] mt-1">The AI will research, qualify, and create earning methods autonomously.</div>
        </Card>
      )}
    </div>
  );
}

function XCircle({ className }: { className: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}
