'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Gauge, TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Zap,
  Bot, Activity, Layers, ArrowUp, ArrowDown, ArrowRight, RefreshCw,
  Loader2, Cpu, MemoryStick, Target, Rocket, AlertOctagon, Lightbulb,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
  Cell, RadialBarChart, RadialBar, PolarAngleAxis,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { Button } from '@/components/ui/button';

// ─── Types ────────────────────────────────────────────────────────────
interface CapacitySummary {
  totalAgents: number;
  idle: number;
  active: number;
  error: number;
  overloaded: number;
  nearCapacity: number;
  totalCapacity: number;
  usedCapacity: number;
  headroom: number;
  utilizationPct: number;
  avgLoad: number;
  avgSuccessRate: number;
  systemCpu: number;
  systemMem: number;
}

interface Backlog {
  pending: number;
  inProgress: number;
  blocked: number;
  critical: number;
  high: number;
  dispatchCapacity: number;
  backlogRatio: number;
}

interface Recommendation {
  type: 'rebalance' | 'scale-out' | 'scale-in' | 'dispatch' | 'investigate';
  title: string;
  detail: string;
  impact: 'low' | 'medium' | 'high';
  agents?: string[];
}

interface Scenario {
  name: string;
  agents: number;
  capacity: number;
  utilized: number;
  headroom: number;
  utilizationPct: number;
}

interface Bucket {
  range: string;
  count: number;
  color: string;
}

interface AgentRow {
  codename: string;
  role: string;
  load: number;
  status: string;
  successRate: number;
}

interface CapacityData {
  summary: CapacitySummary;
  backlog: Backlog;
  recommendations: Recommendation[];
  scenarios: Scenario[];
  buckets: Bucket[];
  topLoaded: AgentRow[];
  mostIdle: AgentRow[];
  overloadedAgents: AgentRow[];
  idleAgents: AgentRow[];
}

const BUCKET_COLORS: Record<string, string> = {
  green: JARVIS.colors.green,
  cyan: JARVIS.colors.cyan,
  amber: JARVIS.colors.amber,
  orange: '#FB923C',
  red: JARVIS.colors.red,
};

const REC_CONFIG: Record<string, { color: string; icon: typeof Zap; label: string }> = {
  rebalance: { color: JARVIS.colors.amber, icon: ArrowRight, label: 'Rebalance' },
  'scale-out': { color: JARVIS.colors.green, icon: ArrowUp, label: 'Scale Out' },
  'scale-in': { color: JARVIS.colors.violet, icon: ArrowDown, label: 'Scale In' },
  dispatch: { color: JARVIS.colors.cyan, icon: Rocket, label: 'Dispatch' },
  investigate: { color: JARVIS.colors.red, icon: AlertOctagon, label: 'Investigate' },
};

const IMPACT_COLORS: Record<string, string> = {
  high: JARVIS.colors.red,
  medium: JARVIS.colors.amber,
  low: JARVIS.colors.green,
};

export default function CapacityPlannerTab() {
  const [selectedScenario, setSelectedScenario] = useState<number | null>(null);
  const { data, loading, refresh } = useApi<CapacityData>('/api/fleet/capacity', 30000);

  const summary = data?.summary;
  const backlog = data?.backlog;
  const recommendations = data?.recommendations ?? [];
  const scenarios = data?.scenarios ?? [];
  const buckets = data?.buckets ?? [];
  const topLoaded = data?.topLoaded ?? [];
  const mostIdle = data?.mostIdle ?? [];

  const utilizationColor = useMemo(() => {
    if (!summary) return JARVIS.colors.cyan;
    if (summary.utilizationPct > 75) return JARVIS.colors.red;
    if (summary.utilizationPct > 50) return JARVIS.colors.amber;
    if (summary.utilizationPct < 25) return JARVIS.colors.violet;
    return JARVIS.colors.green;
  }, [summary]);

  const gaugeData = useMemo(() => ([
    { name: 'utilization', value: summary?.utilizationPct ?? 0, fill: utilizationColor },
  ]), [summary, utilizationColor]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Gauge className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Fleet Utilization · Capacity Planning · Scale Scenarios</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Capacity Planner</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Monitor fleet utilization, identify overload risks, simulate scaling scenarios, and get rebalancing recommendations.
          </p>
        </div>
        <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''} mr-1.5`} /> Refresh
        </Button>
      </div>

      {/* Top row: Utilization gauge + summary cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Utilization gauge */}
        <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${utilizationColor}08, transparent 60%)` }}>
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${utilizationColor}55, transparent)` }} />
          <div className="flex items-center gap-2 mb-2">
            <Gauge className="h-4 w-4" style={{ color: utilizationColor }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Fleet Utilization</span>
          </div>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart innerRadius="70%" outerRadius="100%" data={gaugeData} startAngle={90} endAngle={-270}>
                <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                <RadialBar background={{ fill: '#1B2330' }} dataKey="value" cornerRadius={10} />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-center -mt-24 mb-12">
            <span className="jarvis-mono text-4xl font-bold tabular-nums" style={{ color: utilizationColor }}>
              {summary?.utilizationPct.toFixed(1)}%
            </span>
          </div>
          <div className="flex items-center justify-between mt-2 text-[10px] jarvis-mono">
            <span className="text-[var(--j-text-mute)]">Used: <span style={{ color: utilizationColor }}>{summary?.usedCapacity}</span></span>
            <span className="text-[var(--j-text-mute)]">Headroom: <span style={{ color: JARVIS.colors.green }}>{summary?.headroom}</span></span>
          </div>
        </div>

        {/* Summary cards */}
        <div className="lg:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-3">
          <MiniStat icon={Bot} label="Total Agents" value={summary?.totalAgents ?? 0} color={JARVIS.colors.cyan} />
          <MiniStat icon={CheckCircle2} label="Idle" value={summary?.idle ?? 0} color={JARVIS.colors.green} />
          <MiniStat icon={Activity} label="Active" value={summary?.active ?? 0} color={JARVIS.colors.cyan} />
          <MiniStat icon={AlertTriangle} label="Overloaded" value={summary?.overloaded ?? 0} color={JARVIS.colors.red} />
          <MiniStat icon={AlertOctagon} label="Errors" value={summary?.error ?? 0} color={JARVIS.colors.amber} />
          <MiniStat icon={Target} label="Avg Success" value={`${summary?.avgSuccessRate ?? 0}%`} color={JARVIS.colors.green} />
          <MiniStat icon={Cpu} label="System CPU" value={`${Math.round(summary?.systemCpu ?? 0)}%`} color={JARVIS.colors.cyan} />
          <MiniStat icon={MemoryStick} label="System MEM" value={`${Math.round(summary?.systemMem ?? 0)}%`} color={JARVIS.colors.violet} />
          <MiniStat icon={Gauge} label="Avg Load" value={`${summary?.avgLoad ?? 0}%`} color={JARVIS.colors.amber} />
        </div>
      </div>

      {/* Recommendations + Load distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recommendations */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Recommendations</h4>
            <span className="jarvis-mono text-[10px] ml-auto px-1.5 py-0.5 rounded" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.12)' }}>{recommendations.length}</span>
          </div>
          {recommendations.length === 0 ? (
            <div className="text-center py-6">
              <CheckCircle2 className="h-8 w-8 mx-auto mb-2" style={{ color: JARVIS.colors.green }} />
              <p className="text-sm text-[var(--j-text-mute)]">No recommendations — fleet is balanced.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recommendations.map((rec, i) => {
                const config = REC_CONFIG[rec.type] ?? REC_CONFIG.rebalance;
                const Icon = config.icon;
                const impactColor = IMPACT_COLORS[rec.impact];
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="p-3 rounded-md border bg-[var(--j-panel-soft)]/60"
                    style={{ borderColor: `${config.color}33`, borderLeftWidth: 3, borderLeftColor: config.color }}
                  >
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="h-7 w-7 rounded-md flex items-center justify-center shrink-0" style={{ background: `${config.color}1a`, color: config.color }}>
                        <Icon className="h-3.5 w-3.5" />
                      </div>
                      <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider" style={{ color: config.color, background: `${config.color}1a` }}>
                        {config.label}
                      </span>
                      <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color: impactColor, background: `${impactColor}1a` }}>
                        {rec.impact}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-[var(--j-text)] mb-1">{rec.title}</p>
                    <p className="text-[11px] text-[var(--j-text-dim)] leading-relaxed">{rec.detail}</p>
                    {rec.agents && rec.agents.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {rec.agents.slice(0, 6).map((a) => (
                          <span key={a} className="jarvis-mono text-[8px] px-1.5 py-0.5 rounded border border-[var(--j-border)] bg-[var(--j-bg)] text-[var(--j-text-mute)] uppercase">{a}</span>
                        ))}
                        {rec.agents.length > 6 && <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">+{rec.agents.length - 6}</span>}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {/* Load distribution chart */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Layers className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Load Distribution</h4>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={buckets} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} vertical={false} />
                <XAxis dataKey="range" tick={{ fill: '#64748B', fontSize: 9 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#64748B', fontSize: 9 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(v: number) => [`${v} agents`, 'Count']}
                  cursor={{ fill: 'rgba(125,211,252,0.05)' }}
                />
                <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                  {buckets.map((b, i) => (
                    <Cell key={i} fill={BUCKET_COLORS[b.color] ?? JARVIS.colors.cyan} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Backlog summary */}
          <div className="mt-3 pt-3 border-t border-[var(--j-border)] grid grid-cols-4 gap-2">
            <BacklogStat label="Pending" value={backlog?.pending ?? 0} color={JARVIS.colors.amber} />
            <BacklogStat label="In Progress" value={backlog?.inProgress ?? 0} color={JARVIS.colors.cyan} />
            <BacklogStat label="Blocked" value={backlog?.blocked ?? 0} color={JARVIS.colors.red} />
            <BacklogStat label="Dispatch Cap" value={backlog?.dispatchCapacity ?? 0} color={JARVIS.colors.green} />
          </div>
        </div>
      </div>

      {/* What-if scenarios */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">What-If Scaling Scenarios</h4>
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-1">Click to compare</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {scenarios.map((sc, i) => {
            const isCurrent = sc.name === 'Current';
            const isSelected = selectedScenario === i;
            const color = sc.utilizationPct > 75 ? JARVIS.colors.red : sc.utilizationPct > 50 ? JARVIS.colors.amber : sc.utilizationPct < 25 ? JARVIS.colors.violet : JARVIS.colors.green;
            const isScaleOut = sc.name.includes('+');
            const isScaleIn = sc.name.includes('-');
            return (
              <motion.button
                key={sc.name}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => setSelectedScenario(isSelected ? null : i)}
                className="p-3 rounded-lg border text-left transition-all"
                style={{
                  borderColor: isSelected ? color : 'var(--j-border)',
                  background: isSelected ? `${color}0a` : 'var(--j-panel-soft)',
                  boxShadow: isSelected ? `0 0 0 1px ${color}44` : undefined,
                }}
              >
                <div className="flex items-center gap-1.5 mb-2">
                  {isScaleOut && <ArrowUp className="h-3 w-3" style={{ color: JARVIS.colors.green }} />}
                  {isScaleIn && <ArrowDown className="h-3 w-3" style={{ color: JARVIS.colors.violet }} />}
                  {isCurrent && <Gauge className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />}
                  <span className="jarvis-mono text-[10px] uppercase tracking-wider font-bold" style={{ color: isCurrent ? JARVIS.colors.cyan : isScaleOut ? JARVIS.colors.green : JARVIS.colors.violet }}>{sc.name}</span>
                </div>
                <div className="flex items-baseline gap-1 mb-1">
                  <span className="jarvis-mono text-2xl font-bold tabular-nums" style={{ color }}>{sc.utilizationPct.toFixed(1)}%</span>
                </div>
                <div className="space-y-0.5 jarvis-mono text-[9px] text-[var(--j-text-mute)]">
                  <div className="flex justify-between"><span>Agents:</span><span className="text-[var(--j-text-dim)]">{sc.agents}</span></div>
                  <div className="flex justify-between"><span>Capacity:</span><span className="text-[var(--j-text-dim)]">{sc.capacity}</span></div>
                  <div className="flex justify-between"><span>Headroom:</span><span style={{ color: JARVIS.colors.green }}>{sc.headroom}</span></div>
                </div>
                {/* Mini utilization bar */}
                <div className="mt-2 h-1 rounded-full bg-[var(--j-bg)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${sc.utilizationPct}%` }}
                    transition={{ duration: 0.5, delay: i * 0.05 }}
                    className="h-full rounded-full"
                    style={{ background: color }}
                  />
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Top loaded + Most idle agents */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top loaded */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-4 w-4" style={{ color: JARVIS.colors.red }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Highest Load · Top 10</h4>
          </div>
          <div className="space-y-1.5 max-h-80 overflow-y-auto">
            {topLoaded.map((a, i) => {
              const color = a.load > 70 ? JARVIS.colors.red : a.load > 50 ? JARVIS.colors.amber : JARVIS.colors.cyan;
              return (
                <motion.div
                  key={a.codename}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-2 p-2 rounded-md bg-[var(--j-panel-soft)]/40"
                >
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] w-4">{i + 1}</span>
                  <div className="h-6 w-6 rounded flex items-center justify-center jarvis-mono text-[8px] font-bold shrink-0" style={{ background: `${color}1a`, color }}>
                    {a.codename.slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="jarvis-mono text-[10px] font-semibold truncate">{a.codename}</div>
                    <div className="text-[9px] text-[var(--j-text-mute)] truncate">{a.role}</div>
                  </div>
                  <div className="w-20 h-1.5 rounded-full bg-[var(--j-bg)] overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${a.load}%`, background: color }} />
                  </div>
                  <span className="jarvis-mono text-[10px] font-bold tabular-nums w-8 text-right" style={{ color }}>{a.load}%</span>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Most idle */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Most Idle · Available for Dispatch</h4>
          </div>
          <div className="space-y-1.5 max-h-80 overflow-y-auto">
            {mostIdle.map((a, i) => {
              const color = a.load < 20 ? JARVIS.colors.green : a.load < 40 ? JARVIS.colors.cyan : JARVIS.colors.amber;
              return (
                <motion.div
                  key={a.codename}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-2 p-2 rounded-md bg-[var(--j-panel-soft)]/40"
                >
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] w-4">{i + 1}</span>
                  <div className="h-6 w-6 rounded flex items-center justify-center jarvis-mono text-[8px] font-bold shrink-0" style={{ background: `${color}1a`, color }}>
                    {a.codename.slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="jarvis-mono text-[10px] font-semibold truncate">{a.codename}</div>
                    <div className="text-[9px] text-[var(--j-text-mute)] truncate">{a.role}</div>
                  </div>
                  <div className="w-20 h-1.5 rounded-full bg-[var(--j-bg)] overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${a.load}%`, background: color }} />
                  </div>
                  <span className="jarvis-mono text-[10px] font-bold tabular-nums w-8 text-right" style={{ color }}>{a.load}%</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Mini Stat ────────────────────────────────────────────────────────
function MiniStat({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}

// ─── Backlog Stat ─────────────────────────────────────────────────────
function BacklogStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="text-center p-2 rounded-md bg-[var(--j-panel-soft)]/40 border border-[var(--j-border)]">
      <div className="jarvis-mono text-lg font-bold tabular-nums" style={{ color }}>{value}</div>
      <div className="jarvis-mono text-[8px] uppercase tracking-wider text-[var(--j-text-mute)] mt-0.5">{label}</div>
    </div>
  );
}
