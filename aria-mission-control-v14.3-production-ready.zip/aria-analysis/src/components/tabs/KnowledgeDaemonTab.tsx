'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Share2,
  RefreshCw,
  Plus,
  Server,
  Cloud,
  HardDrive,
  Info,
  Loader2,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  ArrowLeftRight,
  History,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronDown,
  ChevronUp,
  Activity,
  AlertTriangle,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import {
  SectionTitle,
  StatCard,
  Pill,
  EmptyState,
} from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';

/* ---------- Types ---------- */

type NodeType = 'local' | 'remote' | 'daemon';
type NodeStatus = 'online' | 'offline' | 'syncing';
type SyncStatus = 'success' | 'partial' | 'offline';

interface KnowledgeNode {
  id: string;
  nodeType: NodeType;
  name: string;
  status: NodeStatus;
  lastSync: string;
  knowledgeCount: number;
  sharedEntries: number;
  endpoint?: string;
}

interface KnowledgeEntry {
  id: string;
  title: string;
  content: string;
  source: string;
  tags: string[];
  confidence: number;
  contributedBy: string;
  createdAt: string;
  shared: boolean;
}

interface KnowledgeStats {
  totalNodes: number;
  onlineNodes: number;
  totalEntries: number;
  entriesShared: number;
  lastSyncAt: string | null;
}

interface SyncSentEntry {
  title: string;
  toNode: string;
}

interface SyncReceivedEntry {
  title: string;
  fromNode: string;
  tags: string[];
  confidence: number;
}

interface SyncConflict {
  title: string;
  kept: 'local' | 'remote';
  localConfidence: number;
  remoteConfidence: number;
}

interface SyncReport {
  ok: boolean;
  at: string;
  startedAt: string;
  durationMs: number;
  nodesContacted: number;
  nodesSucceeded: number;
  entriesSent: SyncSentEntry[];
  entriesReceived: SyncReceivedEntry[];
  conflictsResolved: SyncConflict[];
  status: SyncStatus;
  note: string;
  persistenceLayer: 'db' | 'memory-only';
}

interface SyncHistoryEntry {
  id: string;
  startedAt: string;
  completedAt: string;
  nodesContacted: number;
  entriesSent: number;
  entriesReceived: number;
  status: SyncStatus;
  note: string;
}

interface KnowledgeFlow {
  outboundPending: number;
  inboundAvailable: number;
  lastSync: string | null;
  flowDirection: 'bidirectional';
}

interface DaemonApiResponse {
  nodes: KnowledgeNode[];
  entries: KnowledgeEntry[];
  stats: KnowledgeStats;
}

interface ContributeApiResponse {
  entry: KnowledgeEntry;
}

interface SyncApiResponse {
  report: SyncReport;
  stats: KnowledgeStats;
}

interface FlowApiResponse {
  flow: KnowledgeFlow;
  history: SyncHistoryEntry[];
}

/* ---------- Helpers ---------- */

const NODE_ICONS: Record<NodeType, typeof Server> = {
  local: HardDrive,
  remote: Cloud,
  daemon: Server,
};

function statusColor(s: NodeStatus): string {
  if (s === 'online') return JARVIS.colors.green;
  if (s === 'syncing') return JARVIS.colors.amber;
  return JARVIS.colors.textMute;
}

function confidenceColor(c: number): string {
  if (c >= 0.9) return JARVIS.colors.green;
  if (c >= 0.75) return JARVIS.colors.cyan;
  if (c >= 0.5) return JARVIS.colors.amber;
  return JARVIS.colors.red;
}

function syncStatusColor(s: SyncStatus): string {
  if (s === 'success') return JARVIS.colors.green;
  if (s === 'partial') return JARVIS.colors.amber;
  return JARVIS.colors.textMute;
}

function syncStatusLabel(s: SyncStatus): string {
  if (s === 'success') return 'success';
  if (s === 'partial') return 'partial';
  return 'peers offline';
}

/* ---------- Component ---------- */

export default function KnowledgeDaemonTab() {
  const { toast } = useToast();
  const { data, loading, error, refresh } = useApi<DaemonApiResponse>(
    '/api/knowledge-daemon',
    30000,
  );
  const {
    data: flowData,
    loading: flowLoading,
    refresh: refreshFlow,
  } = useApi<FlowApiResponse>('/api/knowledge-daemon/flow', 15000);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [contributing, setContributing] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [lastReport, setLastReport] = useState<SyncReport | null>(null);
  const [reportOpen, setReportOpen] = useState(false);

  const nodes = data?.nodes ?? [];
  const entries = data?.entries ?? [];
  const stats = data?.stats ?? null;
  const flow = flowData?.flow ?? null;
  const history = flowData?.history ?? [];

  /* ---------- Actions ---------- */

  const handleContribute = async () => {
    if (!title.trim()) {
      toast({ title: 'Title required', variant: 'destructive' });
      return;
    }
    if (!content.trim()) {
      toast({ title: 'Content required', variant: 'destructive' });
      return;
    }
    setContributing(true);
    try {
      const tags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      await postJson<ContributeApiResponse>(
        '/api/knowledge-daemon/contribute',
        { title: title.trim(), content: content.trim(), tags },
      );
      toast({
        title: 'Knowledge contributed',
        description: 'Entry added to store + persisted to DB (scope=knowledge-shared). Run sync to retrieve it back as inbound.',
      });
      setTitle('');
      setContent('');
      setTagsInput('');
      refresh();
      refreshFlow();
    } catch (e) {
      toast({
        title: 'Contribute failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setContributing(false);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const res = (await postJson('/api/knowledge-daemon/sync', {})) as SyncApiResponse;
      setLastReport(res.report);
      setReportOpen(true);
      toast({
        title: `Sync ${syncStatusLabel(res.report.status)}`,
        description: `${res.report.entriesSent.length} out · ${res.report.entriesReceived.length} in (DB) · ${res.report.conflictsResolved.length} conflicts · ${res.report.persistenceLayer === 'db' ? 'DB-backed' : 'memory-only'}`,
      });
      refresh();
      refreshFlow();
    } catch (e) {
      toast({
        title: 'Sync failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setSyncing(false);
    }
  };

  /* ---------- Render ---------- */

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Knowledge Daemon"
        icon={Share2}
        accent={JARVIS.colors.cyan}
        action={
          <div className="flex items-center gap-2">
            <Pill color={JARVIS.colors.cyan}>
              {stats ? `${stats.totalNodes} nodes` : '— nodes'}
            </Pill>
            <Button
              size="sm"
              onClick={handleSync}
              disabled={syncing}
              className="jarvis-btn-accent border-0 h-7 text-[10px]"
            >
              {syncing ? (
                <>
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" /> Syncing…
                </>
              ) : (
                <>
                  <RefreshCw className="h-3 w-3 mr-1" /> Sync with Peers
                </>
              )}
            </Button>
          </div>
        }
      />

      {/* ---------- Info panel ---------- */}
      <Card
        className="p-3 border"
        style={{
          background: `${JARVIS.colors.cyan}08`,
          borderColor: `${JARVIS.colors.cyan}30`,
        }}
      >
        <div className="flex items-start gap-3">
          <Info
            className="h-4 w-4 mt-0.5 shrink-0"
            style={{ color: JARVIS.colors.cyan }}
          />
          <div className="text-[11px] leading-relaxed text-[var(--j-text-dim)]">
            <span className="text-[var(--j-text)] font-semibold">
              Inspired by{' '}
              <a
                href="https://github.com/open-jarvis/OpenJarvis"
                target="_blank"
                rel="noopener noreferrer"
                className="underline"
                style={{ color: JARVIS.colors.cyan }}
              >
                open-jarvis
              </a>{' '}
              (personal AI daemon) and{' '}
              <a
                href="https://github.com/microsoft/JARVIS"
                target="_blank"
                rel="noopener noreferrer"
                className="underline"
                style={{ color: JARVIS.colors.cyan }}
              >
                microsoft/JARVIS
              </a>{' '}
              (LLM↔ML orchestration).
            </span>{' '}
            <span className="text-[var(--j-text)] font-semibold">
              The bidirectional flow is now DB-backed (v10.3.0+):
            </span>{' '}
            contributing an entry persists it as a MemoryItem
            (scope=&apos;knowledge-shared&apos;), and sync ACTUALLY retrieves
            new entries from the DB into the daemon store (real inbound).
            Real peer-to-peer network with external ARIA instances still
            requires a protocol (gRPC, libp2p, WebSocket relay, signed
            messages, conflict resolution).{' '}
            <span className="text-[var(--j-text-mute)]">
              Peer nodes remain offline in this sandbox; sync reports show
              what WOULD be fanned out to them — but the local DB persistence
              + retrieval loop is real and survives server restarts.
            </span>
          </div>
        </div>
      </Card>

      {/* ---------- Error state ---------- */}
      {error && (
        <Card className="p-4 jarvis-panel border-[var(--j-red)]/40 bg-[var(--j-panel)]">
          <div className="text-xs text-[var(--j-red)]">
            Failed to load daemon state: {error}
          </div>
        </Card>
      )}

      {/* ---------- Stats ---------- */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard
            label="Total Nodes"
            value={stats.totalNodes}
            sub={`${stats.onlineNodes} online`}
            icon={Server}
            accent={JARVIS.colors.cyan}
          />
          <StatCard
            label="Online Nodes"
            value={stats.onlineNodes}
            sub="local daemon only"
            icon={CheckCircle2}
            accent={JARVIS.colors.green}
          />
          <StatCard
            label="Total Entries"
            value={stats.totalEntries}
            sub="in local store"
            icon={BookOpen}
            accent={JARVIS.colors.violet}
          />
          <StatCard
            label="Entries Shared"
            value={stats.entriesShared}
            sub={
              stats.lastSyncAt
                ? `last sync ${timeAgo(stats.lastSyncAt)}`
                : 'never synced'
            }
            icon={Share2}
            accent={JARVIS.colors.amber}
          />
        </div>
      )}

      {/* ---------- Bidirectional Flow panel ---------- */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <ArrowLeftRight
            className="h-4 w-4"
            style={{ color: JARVIS.colors.cyan }}
          />
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
            Bidirectional Flow
          </h3>
          <Pill color={JARVIS.colors.cyan}>bidirectional</Pill>
          <Pill color={JARVIS.colors.green}>DB-backed</Pill>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
          {/* SVG diagram */}
          <div className="lg:col-span-7 flex items-center justify-center">
            <svg
              viewBox="0 0 420 140"
              className="w-full max-w-[420px] h-auto"
              role="img"
              aria-label="Bidirectional knowledge flow: main daemon and peer nodes"
            >
              {/* Main node box (left) */}
              <rect
                x="14"
                y="40"
                width="120"
                height="60"
                rx="8"
                fill={`${JARVIS.colors.cyan}14`}
                stroke={JARVIS.colors.cyan}
                strokeWidth="1.5"
              />
              <text
                x="74"
                y="64"
                textAnchor="middle"
                fill={JARVIS.colors.cyan}
                fontSize="10"
                fontFamily="monospace"
                fontWeight="700"
              >
                MAIN
              </text>
              <text
                x="74"
                y="80"
                textAnchor="middle"
                fill={JARVIS.colors.textDim}
                fontSize="9"
                fontFamily="monospace"
              >
                local-daemon
              </text>

              {/* Peers node box (right) */}
              <rect
                x="286"
                y="40"
                width="120"
                height="60"
                rx="8"
                fill={`${JARVIS.colors.violet}14`}
                stroke={JARVIS.colors.violet}
                strokeWidth="1.5"
              />
              <text
                x="346"
                y="64"
                textAnchor="middle"
                fill={JARVIS.colors.violet}
                fontSize="10"
                fontFamily="monospace"
                fontWeight="700"
              >
                PEERS
              </text>
              <text
                x="346"
                y="80"
                textAnchor="middle"
                fill={JARVIS.colors.textDim}
                fontSize="9"
                fontFamily="monospace"
              >
                4 nodes · offline
              </text>

              {/* Outbound arrow (top): main → peers */}
              <line
                x1="134"
                y1="56"
                x2="286"
                y2="56"
                stroke={JARVIS.colors.amber}
                strokeWidth="2"
                markerEnd="url(#arrow-out)"
              />
              <text
                x="210"
                y="48"
                textAnchor="middle"
                fill={JARVIS.colors.amber}
                fontSize="9"
                fontFamily="monospace"
              >
                outbound · {flow?.outboundPending ?? '—'} pending
              </text>

              {/* Inbound arrow (bottom): peers → main */}
              <line
                x1="286"
                y1="84"
                x2="134"
                y2="84"
                stroke={JARVIS.colors.green}
                strokeWidth="2"
                markerEnd="url(#arrow-in)"
              />
              <text
                x="210"
                y="98"
                textAnchor="middle"
                fill={JARVIS.colors.green}
                fontSize="9"
                fontFamily="monospace"
              >
                inbound · {flow?.inboundAvailable ?? '—'} available
              </text>

              {/* Arrow markers */}
              <defs>
                <marker
                  id="arrow-out"
                  markerWidth="8"
                  markerHeight="8"
                  refX="6"
                  refY="4"
                  orient="auto"
                >
                  <path d="M0,0 L8,4 L0,8 Z" fill={JARVIS.colors.amber} />
                </marker>
                <marker
                  id="arrow-in"
                  markerWidth="8"
                  markerHeight="8"
                  refX="6"
                  refY="4"
                  orient="auto"
                >
                  <path d="M0,0 L8,4 L0,8 Z" fill={JARVIS.colors.green} />
                </marker>
              </defs>
            </svg>
          </div>

          {/* Flow stats */}
          <div className="lg:col-span-5 space-y-2">
            <FlowStatRow
              icon={ArrowUpRight}
              color={JARVIS.colors.amber}
              label="Outbound pending"
              value={flow ? String(flow.outboundPending) : '—'}
              hint="local entries waiting to sync (main → peers)"
              loading={flowLoading && !flow}
            />
            <FlowStatRow
              icon={ArrowDownLeft}
              color={JARVIS.colors.green}
              label="Inbound available"
              value={flow ? String(flow.inboundAvailable) : '—'}
              hint="DB entries (scope='knowledge-shared') not yet pulled into store"
              loading={flowLoading && !flow}
            />
            <FlowStatRow
              icon={History}
              color={JARVIS.colors.cyan}
              label="Last sync"
              value={flow?.lastSync ? timeAgo(flow.lastSync) : 'never'}
              hint={flow?.lastSync ? new Date(flow.lastSync).toLocaleString() : 'no sync run yet'}
              loading={flowLoading && !flow}
            />
          </div>
        </div>
      </Card>

      {/* ---------- Last sync report (expandable) ---------- */}
      <AnimatePresence>
        {lastReport && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            <Card
              className="p-4 jarvis-panel border"
              style={{
                background: `${JARVIS.colors.cyan}06`,
                borderColor: `${JARVIS.colors.cyan}30`,
              }}
            >
              <button
                type="button"
                onClick={() => setReportOpen((v) => !v)}
                className="flex items-center gap-2 w-full text-left"
              >
                <Activity
                  className="h-4 w-4 shrink-0"
                  style={{ color: JARVIS.colors.cyan }}
                />
                <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)] flex-1">
                  Last Sync Report — {new Date(lastReport.at).toLocaleTimeString()}
                </h3>
                <Pill color={syncStatusColor(lastReport.status)}>
                  {syncStatusLabel(lastReport.status)}
                </Pill>
                <Pill
                  color={
                    lastReport.persistenceLayer === 'db'
                      ? JARVIS.colors.green
                      : JARVIS.colors.amber
                  }
                >
                  {lastReport.persistenceLayer === 'db'
                    ? 'DB-backed'
                    : 'memory-only'}
                </Pill>
                {reportOpen ? (
                  <ChevronUp className="h-4 w-4 text-[var(--j-text-mute)]" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-[var(--j-text-mute)]" />
                )}
              </button>

              <AnimatePresence>
                {reportOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="mt-4 space-y-3">
                      {/* Summary row */}
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-center">
                        <ReportStat
                          label="Sent"
                          value={lastReport.entriesSent.length}
                          color={JARVIS.colors.amber}
                        />
                        <ReportStat
                          label="Received"
                          value={lastReport.entriesReceived.length}
                          color={JARVIS.colors.green}
                        />
                        <ReportStat
                          label="Conflicts"
                          value={lastReport.conflictsResolved.length}
                          color={JARVIS.colors.red}
                        />
                        <ReportStat
                          label="Peers OK"
                          value={`${lastReport.nodesSucceeded}/${lastReport.nodesContacted}`}
                          color={JARVIS.colors.cyan}
                        />
                        <ReportStat
                          label="Duration"
                          value={`${lastReport.durationMs}ms`}
                          color={JARVIS.colors.violet}
                        />
                      </div>

                      {/* Note */}
                      <div
                        className="text-[10px] leading-relaxed p-2 rounded border"
                        style={{
                          background: `${JARVIS.colors.amber}08`,
                          borderColor: `${JARVIS.colors.amber}30`,
                          color: JARVIS.colors.textDim,
                        }}
                      >
                        <span
                          className="font-semibold"
                          style={{ color: JARVIS.colors.amber }}
                        >
                          NOTE:{' '}
                        </span>
                        {lastReport.note}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {/* Entries sent */}
                        <div>
                          <div className="flex items-center gap-1.5 mb-2">
                            <ArrowUpRight
                              className="h-3 w-3"
                              style={{ color: JARVIS.colors.amber }}
                            />
                            <span
                              className="jarvis-mono text-[10px] uppercase tracking-wider"
                              style={{ color: JARVIS.colors.amber }}
                            >
                              Outbound · entries sent
                            </span>
                          </div>
                          {lastReport.entriesSent.length === 0 ? (
                            <div className="text-[10px] text-[var(--j-text-mute)] italic">
                              Nothing queued — all local entries already shared.
                            </div>
                          ) : (
                            <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                              {lastReport.entriesSent.map((s, i) => (
                                <div
                                  key={i}
                                  className="text-[10px] p-1.5 rounded border bg-[var(--j-panel-soft)]"
                                  style={{
                                    borderColor: 'var(--j-border-soft)',
                                  }}
                                >
                                  <div className="text-[var(--j-text)] truncate">
                                    {s.title}
                                  </div>
                                  <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                                    → {s.toNode}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Entries received */}
                        <div>
                          <div className="flex items-center gap-1.5 mb-2">
                            <ArrowDownLeft
                              className="h-3 w-3"
                              style={{ color: JARVIS.colors.green }}
                            />
                            <span
                              className="jarvis-mono text-[10px] uppercase tracking-wider"
                              style={{ color: JARVIS.colors.green }}
                            >
                              Inbound · entries received (DB → store)
                            </span>
                          </div>
                          {lastReport.entriesReceived.length === 0 ? (
                            <div className="text-[10px] text-[var(--j-text-mute)] italic">
                              No new DB entries to pull this round.
                            </div>
                          ) : (
                            <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                              {lastReport.entriesReceived.map((r, i) => (
                                <div
                                  key={i}
                                  className="text-[10px] p-1.5 rounded border bg-[var(--j-panel-soft)]"
                                  style={{
                                    borderColor: 'var(--j-border-soft)',
                                  }}
                                >
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="text-[var(--j-text)] truncate">
                                      {r.title}
                                    </span>
                                    <span
                                      className="jarvis-mono text-[9px] shrink-0"
                                      style={{
                                        color: confidenceColor(r.confidence),
                                      }}
                                    >
                                      {Math.round(r.confidence * 100)}%
                                    </span>
                                  </div>
                                  <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                                    ← {r.fromNode}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Conflicts */}
                      {lastReport.conflictsResolved.length > 0 && (
                        <div>
                          <div className="flex items-center gap-1.5 mb-2">
                            <AlertTriangle
                              className="h-3 w-3"
                              style={{ color: JARVIS.colors.red }}
                            />
                            <span
                              className="jarvis-mono text-[10px] uppercase tracking-wider"
                              style={{ color: JARVIS.colors.red }}
                            >
                              Conflicts resolved (keep highest confidence)
                            </span>
                          </div>
                          <div className="space-y-1">
                            {lastReport.conflictsResolved.map((c, i) => (
                              <div
                                key={i}
                                className="text-[10px] p-1.5 rounded border bg-[var(--j-panel-soft)] flex items-center justify-between gap-2"
                                style={{ borderColor: 'var(--j-border-soft)' }}
                              >
                                <span className="text-[var(--j-text)] truncate">
                                  {c.title}
                                </span>
                                <span
                                  className="jarvis-mono text-[9px] uppercase shrink-0"
                                  style={{
                                    color:
                                      c.kept === 'local'
                                        ? JARVIS.colors.amber
                                        : JARVIS.colors.green,
                                  }}
                                >
                                  kept {c.kept} ({c.kept === 'local'
                                    ? c.localConfidence
                                    : c.remoteConfidence}
                                  )
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---------- Sync Activity (history) ---------- */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History
              className="h-4 w-4"
              style={{ color: JARVIS.colors.cyan }}
            />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Sync Activity
            </h3>
          </div>
          <Pill color={JARVIS.colors.cyan}>{history.length} of 20</Pill>
        </div>

        {flowLoading && history.length === 0 ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div
                key={i}
                className="h-10 rounded-lg bg-[var(--j-panel-soft)] animate-pulse"
              />
            ))}
          </div>
        ) : history.length === 0 ? (
          <EmptyState
            icon={History}
            message="No sync attempts yet"
            hint="Click “Sync with Peers” above to record the first sync."
            accent={JARVIS.colors.cyan}
          />
        ) : (
          <div className="space-y-1.5">
            {history.map((h, idx) => {
              const color = syncStatusColor(h.status);
              return (
                <motion.div
                  key={h.id}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.02 }}
                  className="flex items-center gap-3 p-2 rounded-lg border bg-[var(--j-panel-soft)]"
                  style={{ borderColor: 'var(--j-border-soft)' }}
                >
                  <span
                    className="rounded-full shrink-0"
                    style={{
                      width: 8,
                      height: 8,
                      background: color,
                      boxShadow: `0 0 6px ${color}`,
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className="jarvis-mono text-[9px] uppercase"
                        style={{ color }}
                      >
                        {syncStatusLabel(h.status)}
                      </span>
                      <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                        {h.id}
                      </span>
                      <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                        {timeAgo(h.startedAt)}
                      </span>
                    </div>
                    <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-dim)] mt-0.5 flex items-center gap-2 flex-wrap">
                      <span style={{ color: JARVIS.colors.amber }}>
                        ↑ {h.entriesSent} sent
                      </span>
                      <span>·</span>
                      <span style={{ color: JARVIS.colors.green }}>
                        ↓ {h.entriesReceived} recv
                      </span>
                      <span>·</span>
                      <span>{h.nodesContacted} peers</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* ---------- Node topology ---------- */}
        <Card className="lg:col-span-5 p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-2 mb-4">
            <Share2
              className="h-4 w-4"
              style={{ color: JARVIS.colors.cyan }}
            />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Node Topology
            </h3>
          </div>

          {loading && nodes.length === 0 ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div
                  key={i}
                  className="h-16 rounded-lg bg-[var(--j-panel-soft)] animate-pulse"
                />
              ))}
            </div>
          ) : nodes.length === 0 ? (
            <EmptyState
              icon={AlertCircle}
              message="No nodes registered"
              hint="The local daemon registers itself on first boot."
              accent={JARVIS.colors.amber}
            />
          ) : (
            <div className="space-y-2">
              {nodes.map((n, idx) => {
                const Icon = NODE_ICONS[n.nodeType] ?? Server;
                const color = statusColor(n.status);
                const isLocal = n.nodeType === 'local';
                return (
                  <motion.div
                    key={n.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.04 }}
                    className="flex items-center gap-3 p-3 rounded-lg border"
                    style={{
                      background: isLocal
                        ? `${JARVIS.colors.cyan}08`
                        : 'var(--j-panel-soft)',
                      borderColor: isLocal
                        ? `${JARVIS.colors.cyan}30`
                        : 'var(--j-border-soft)',
                    }}
                  >
                    <div
                      className="relative flex h-9 w-9 items-center justify-center rounded-md shrink-0"
                      style={{
                        background: `${color}1a`,
                        border: `1px solid ${color}33`,
                        color,
                      }}
                    >
                      <Icon className="h-4 w-4" />
                      <span
                        className="absolute -bottom-0.5 -right-0.5 rounded-full"
                        style={{
                          width: 9,
                          height: 9,
                          background: color,
                          boxShadow: `0 0 6px ${color}`,
                          border: '1.5px solid var(--j-panel)',
                        }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-display text-xs font-semibold text-[var(--j-text)] truncate">
                          {n.name}
                        </span>
                        <span
                          className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded"
                          style={{
                            color,
                            background: `${color}14`,
                            border: `1px solid ${color}33`,
                          }}
                        >
                          {n.nodeType}
                        </span>
                      </div>
                      <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mt-0.5 flex items-center gap-2 flex-wrap">
                        <span>{n.knowledgeCount} entries</span>
                        <span>·</span>
                        <span>{n.sharedEntries} shared</span>
                        <span>·</span>
                        <span>sync {timeAgo(n.lastSync)}</span>
                      </div>
                      {n.endpoint && (
                        <div className="text-[9px] text-[var(--j-text-mute)] font-mono mt-0.5 truncate">
                          {n.endpoint}
                        </div>
                      )}
                    </div>
                    <span
                      className="jarvis-mono text-[9px] uppercase px-2 py-1 rounded shrink-0"
                      style={{
                        color,
                        background: `${color}14`,
                        border: `1px solid ${color}33`,
                      }}
                    >
                      {n.status}
                    </span>
                  </motion.div>
                );
              })}
            </div>
          )}
        </Card>

        {/* ---------- Contribute form ---------- */}
        <Card className="lg:col-span-7 p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] h-fit">
          <div className="flex items-center gap-2 mb-4">
            <Plus className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Contribute Knowledge
            </h3>
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Title
              </Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Local agents outperform cloud for single-turn chat"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Content
              </Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="What did you learn? Why is it useful? Cite a source if possible."
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs min-h-[120px] resize-y"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
                Tags (comma-separated)
              </Label>
              <Input
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="e.g. benchmark, local-first, research"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
              />
            </div>
            <Button
              onClick={handleContribute}
              disabled={contributing || !title.trim() || !content.trim()}
              className="w-full border-0"
              style={{
                background: `${JARVIS.colors.violet}1a`,
                color: JARVIS.colors.violet,
                border: `1px solid ${JARVIS.colors.violet}40`,
              }}
            >
              {contributing ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Contributing…
                </>
              ) : (
                <>
                  <Plus className="h-3.5 w-3.5 mr-1.5" /> Add Entry
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>

      {/* ---------- Knowledge feed ---------- */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BookOpen
              className="h-4 w-4"
              style={{ color: JARVIS.colors.violet }}
            />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">
              Knowledge Feed
            </h3>
          </div>
          <Pill color={JARVIS.colors.violet}>{entries.length} entries</Pill>
        </div>

        {loading && entries.length === 0 ? (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="h-28 rounded-lg bg-[var(--j-panel-soft)] animate-pulse"
              />
            ))}
          </div>
        ) : entries.length === 0 ? (
          <EmptyState
            icon={BookOpen}
            message="No knowledge entries yet"
            hint="Contribute an entry above to seed the local store."
            accent={JARVIS.colors.violet}
          />
        ) : (
          <div className="space-y-2">
            {entries.map((e, idx) => {
              const conf = Math.round(e.confidence * 100);
              const cColor = confidenceColor(e.confidence);
              return (
                <motion.div
                  key={`${e.id}-${idx}`}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.03 }}
                  className="p-3 rounded-lg border bg-[var(--j-panel-soft)]"
                  style={{ borderColor: 'var(--j-border-soft)' }}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-display text-sm font-semibold text-[var(--j-text)]">
                          {e.title}
                        </h4>
                        {e.shared ? (
                          <Pill color={JARVIS.colors.green}>shared</Pill>
                        ) : (
                          <Pill color={JARVIS.colors.amber}>local-only</Pill>
                        )}
                      </div>
                      <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mt-0.5 flex items-center gap-2 flex-wrap">
                        <span>by {e.contributedBy}</span>
                        <span>·</span>
                        <span>{timeAgo(e.createdAt)}</span>
                        <span>·</span>
                        <span className="text-[var(--j-text-dim)]">
                          src: {e.source}
                        </span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">
                        confidence
                      </div>
                      <div
                        className="font-display text-sm font-bold"
                        style={{ color: cColor }}
                      >
                        {conf}%
                      </div>
                      <div
                        className="w-16 h-1 rounded-full mt-1"
                        style={{
                          background: `${cColor}22`,
                          position: 'relative',
                          overflow: 'hidden',
                        }}
                      >
                        <div
                          style={{
                            position: 'absolute',
                            inset: 0,
                            width: `${conf}%`,
                            background: cColor,
                            boxShadow: `0 0 6px ${cColor}`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <p className="text-[11px] leading-relaxed text-[var(--j-text-dim)] line-clamp-4">
                    {e.content}
                  </p>
                  {e.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {e.tags.map((t, i) => (
                        <span
                          key={i}
                          className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded"
                          style={{
                            color: JARVIS.colors.cyan,
                            background: `${JARVIS.colors.cyan}12`,
                            border: `1px solid ${JARVIS.colors.cyan}30`,
                          }}
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

/* ---------- Small inline sub-components ---------- */

function FlowStatRow({
  icon: Icon,
  color,
  label,
  value,
  hint,
  loading,
}: {
  icon: typeof ArrowUpRight;
  color: string;
  label: string;
  value: string;
  hint: string;
  loading: boolean;
}) {
  return (
    <div
      className="flex items-center gap-3 p-2.5 rounded-lg border bg-[var(--j-panel-soft)]"
      style={{ borderColor: `${color}30` }}
    >
      <div
        className="flex h-8 w-8 items-center justify-center rounded-md shrink-0"
        style={{ background: `${color}14`, border: `1px solid ${color}33`, color }}
      >
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Icon className="h-4 w-4" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">
          {label}
        </div>
        <div className="font-display text-sm font-bold text-[var(--j-text)]">
          {value}
        </div>
        <div className="text-[9px] text-[var(--j-text-mute)] truncate">
          {hint}
        </div>
      </div>
    </div>
  );
}

function ReportStat({
  label,
  value,
  color,
}: {
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <div
      className="p-2 rounded-lg border"
      style={{ background: `${color}08`, borderColor: `${color}30` }}
    >
      <div
        className="jarvis-mono text-[9px] uppercase tracking-wider"
        style={{ color }}
      >
        {label}
      </div>
      <div
        className="font-display text-lg font-bold"
        style={{ color }}
      >
        {value}
      </div>
    </div>
  );
}
