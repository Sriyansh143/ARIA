'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, DollarSign, Wallet, Cpu, Server, Bot,
  RefreshCw, Loader2, Award, Target, Percent, ArrowUp, ArrowDown,
  CreditCard, Smartphone, QrCode, Landmark, Banknote, PieChart, Clock,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  ResponsiveContainer, Tooltip, Cell, PieChart as RechartsPie, Pie,
  LineChart, Line, Legend,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { Button } from '@/components/ui/button';

// ─── Types ────────────────────────────────────────────────────────────
interface RevenueDashboard {
  revenue: {
    confirmed: number;
    pending: number;
    refunded: number;
    skillEarnings: number;
    projectedMonthly: number;
    earningMethodTotal: number;
    total: number;
    byMethod: Record<string, number>;
    daily: Array<{ day: string; revenue: number; count: number }>;
  };
  costs: {
    llmCost: number;
    infraMonthly: number;
    infraDaily: number;
    agentDaily: number;
    workingAgents: number;
    totalDaily: number;
    totalMonthly: number;
  };
  profit: {
    netProfit: number;
    margin: number;
    totalRevenue: number;
    totalCost: number;
  };
  earningMethods: Array<{
    key: string; name: string; category: string;
    estimatedMonthly: number; earningPotential: string;
    totalEarnings: number; executionCount: number;
  }>;
  topEarningAgents: Array<{ agent: string; earnings: number }>;
  paymentCounts: { confirmed: number; pending: number; failed: number; refunded: number; total: number };
}

const METHOD_ICONS: Record<string, typeof CreditCard> = {
  upi: Smartphone,
  card: CreditCard,
  qr: QrCode,
  netbanking: Landmark,
  wallet: Wallet,
};

const METHOD_COLORS: Record<string, string> = {
  upi: JARVIS.colors.cyan,
  card: JARVIS.colors.violet,
  qr: JARVIS.colors.green,
  netbanking: JARVIS.colors.amber,
  wallet: JARVIS.colors.cyan,
};

const POTENTIAL_COLORS: Record<string, string> = {
  high: JARVIS.colors.green,
  medium: JARVIS.colors.amber,
  low: JARVIS.colors.red,
};

export default function RevenueDashboardTab() {
  const { data, loading, refresh } = useApi<RevenueDashboard>('/api/revenue/dashboard', 30000);

  const rev = data?.revenue;
  const costs = data?.costs;
  const profit = data?.profit;
  const earningMethods = data?.earningMethods ?? [];
  const topAgents = data?.topEarningAgents ?? [];

  const methodPieData = useMemo(() => {
    if (!rev?.byMethod) return [];
    return Object.entries(rev.byMethod).map(([method, value]) => ({ name: method, value }));
  }, [rev]);

  const costBreakdown = useMemo(() => {
    if (!costs) return [];
    return [
      { name: 'Infrastructure', value: costs.infraMonthly, color: JARVIS.colors.cyan },
      { name: 'Agent LLM', value: costs.agentDaily * 30, color: JARVIS.colors.violet },
      { name: 'LLM Tokens', value: costs.llmCost, color: JARVIS.colors.amber },
    ];
  }, [costs]);

  const profitColor = (profit?.margin ?? 0) >= 30 ? JARVIS.colors.green : (profit?.margin ?? 0) >= 0 ? JARVIS.colors.amber : JARVIS.colors.red;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Revenue · Costs · Profit · Projections</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Revenue Dashboard</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Consolidated view of all revenue streams, estimated costs (LLM + infra + agents), and net profit margin.
          </p>
        </div>
        <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-green)] hover:border-[var(--j-green)]">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''} mr-1.5`} /> Refresh
        </Button>
      </div>

      {/* Top row: Net profit + key metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-3">
        {/* Net profit (big) */}
        <div className="jarvis-panel p-5 relative overflow-hidden lg:col-span-1" style={{ background: `linear-gradient(180deg, ${profitColor}10, transparent 60%)` }}>
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${profitColor}55, transparent)` }} />
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4" style={{ color: profitColor }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Net Profit</span>
          </div>
          <div className="flex items-baseline gap-1.5 mb-2">
            <span className="jarvis-mono text-3xl font-bold tabular-nums" style={{ color: profitColor }}>₹{(profit?.netProfit ?? 0).toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="jarvis-mono text-xs" style={{ color: profitColor }}>{profit?.margin ?? 0}% margin</span>
            {(profit?.margin ?? 0) >= 0 ? (
              <ArrowUp className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
            ) : (
              <ArrowDown className="h-3 w-3" style={{ color: JARVIS.colors.red }} />
            )}
          </div>
        </div>

        {/* Revenue breakdown */}
        <div className="jarvis-panel p-4 lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricCard icon={DollarSign} label="Confirmed" value={`₹${(rev?.confirmed ?? 0).toLocaleString()}`} sub={`${data?.paymentCounts.confirmed ?? 0} payments`} color={JARVIS.colors.green} />
          <MetricCard icon={Clock} label="Pending" value={`₹${(rev?.pending ?? 0).toLocaleString()}`} sub={`${data?.paymentCounts.pending ?? 0} payments`} color={JARVIS.colors.amber} />
          <MetricCard icon={Bot} label="Skill Earnings" value={`₹${(rev?.skillEarnings ?? 0).toLocaleString()}`} sub="agent output value" color={JARVIS.colors.cyan} />
          <MetricCard icon={Wallet} label="Total Revenue" value={`₹${(rev?.total ?? 0).toLocaleString()}`} sub="all sources" color={JARVIS.colors.violet} />
        </div>
      </div>

      {/* Revenue trend + method breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Daily revenue trend */}
        <div className="jarvis-panel p-4 lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Revenue Trend · Last 7 Days</h4>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={rev?.daily ?? []} margin={{ top: 4, right: 12, left: -8, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={JARVIS.colors.green} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={JARVIS.colors.green} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} vertical={false} />
                <XAxis dataKey="day" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v}`} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(v: number, name: string) => name === 'revenue' ? [`₹${v}`, 'Revenue'] : [v, name]}
                />
                <Area type="monotone" dataKey="revenue" stroke={JARVIS.colors.green} strokeWidth={2.5} fill="url(#revGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Payment method pie */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <PieChart className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">By Payment Method</h4>
          </div>
          {methodPieData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-[var(--j-text-mute)] text-xs">No payment data</div>
          ) : (
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPie>
                  <Pie data={methodPieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={3}>
                    {methodPieData.map((entry, i) => (
                      <Cell key={i} fill={METHOD_COLORS[entry.name] ?? JARVIS.colors.cyan} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                    formatter={(v: number) => `₹${v}`}
                  />
                </RechartsPie>
              </ResponsiveContainer>
            </div>
          )}
          <div className="flex items-center justify-center gap-3 mt-2 flex-wrap">
            {methodPieData.map((m) => {
              const Icon = METHOD_ICONS[m.name] ?? Banknote;
              const color = METHOD_COLORS[m.name] ?? JARVIS.colors.cyan;
              return (
                <div key={m.name} className="flex items-center gap-1">
                  <Icon className="h-2.5 w-2.5" style={{ color }} />
                  <span className="jarvis-mono text-[9px] uppercase" style={{ color }}>{m.name}</span>
                  <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">₹{m.value}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Costs breakdown + profit summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cost breakdown */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Server className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Cost Breakdown · Monthly</h4>
            <span className="jarvis-mono text-[10px] ml-auto text-[var(--j-text-mute)]">₹{costs?.totalMonthly?.toLocaleString() ?? 0}/mo</span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costBreakdown} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} horizontal={false} />
                <XAxis type="number" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v}`} />
                <YAxis type="category" dataKey="name" tick={{ fill: '#94A3B8', fontSize: 10 }} axisLine={false} tickLine={false} width={80} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 11 }}
                  formatter={(v: number) => [`₹${v.toLocaleString()}`, 'Cost']}
                  cursor={{ fill: 'rgba(251,191,36,0.05)' }}
                />
                <Bar dataKey="value" radius={[0, 3, 3, 0]}>
                  {costBreakdown.map((c, i) => <Cell key={i} fill={c.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-[var(--j-border)]">
            <CostStat label="Infra/day" value={`₹${costs?.infraDaily ?? 0}`} color={JARVIS.colors.cyan} />
            <CostStat label="Agents/day" value={`₹${costs?.agentDaily ?? 0}`} color={JARVIS.colors.violet} sub={`${costs?.workingAgents ?? 0} working`} />
            <CostStat label="LLM tokens" value={`₹${costs?.llmCost ?? 0}`} color={JARVIS.colors.amber} />
          </div>
        </div>

        {/* Profit summary */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Percent className="h-4 w-4" style={{ color: profitColor }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Profit Summary</h4>
          </div>
          <div className="space-y-3">
            {/* Revenue vs Cost bars */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Revenue</span>
                <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.green }}>₹{(profit?.totalRevenue ?? 0).toLocaleString()}</span>
              </div>
              <div className="h-3 rounded-full bg-[var(--j-bg)] overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: '100%' }} transition={{ duration: 0.6 }} className="h-full rounded-full" style={{ background: JARVIS.colors.green }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Costs</span>
                <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.red }}>₹{(profit?.totalCost ?? 0).toLocaleString()}</span>
              </div>
              <div className="h-3 rounded-full bg-[var(--j-bg)] overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${profit?.totalRevenue ? (profit.totalCost / profit.totalRevenue) * 100 : 0}%` }}
                  transition={{ duration: 0.6 }}
                  className="h-full rounded-full"
                  style={{ background: JARVIS.colors.red }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Net Profit</span>
                <span className="jarvis-mono text-xs font-bold" style={{ color: profitColor }}>₹{(profit?.netProfit ?? 0).toLocaleString()}</span>
              </div>
              <div className="h-3 rounded-full bg-[var(--j-bg)] overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.max(0, Math.min(100, profit?.margin ?? 0))}%` }}
                  transition={{ duration: 0.6 }}
                  className="h-full rounded-full"
                  style={{ background: profitColor }}
                />
              </div>
            </div>
            {/* Margin badge */}
            <div className="flex items-center justify-center gap-3 pt-3 border-t border-[var(--j-border)]">
              <div className="text-center">
                <div className="jarvis-mono text-2xl font-bold" style={{ color: profitColor }}>{profit?.margin ?? 0}%</div>
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Profit Margin</div>
              </div>
              <div className="h-8 w-px bg-[var(--j-border)]" />
              <div className="text-center">
                <div className="jarvis-mono text-2xl font-bold" style={{ color: JARVIS.colors.cyan }}>{data?.paymentCounts.total ?? 0}</div>
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Total Payments</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Top earning agents + earning methods */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top earning agents */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Award className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Top Earning Agents</h4>
          </div>
          {topAgents.length === 0 ? (
            <div className="text-center py-6 text-[var(--j-text-mute)] text-xs">No agent earnings recorded yet.</div>
          ) : (
            <div className="space-y-1.5">
              {topAgents.map((a, i) => {
                const maxEarnings = topAgents[0]?.earnings ?? 1;
                const pct = (a.earnings / maxEarnings) * 100;
                const color = i === 0 ? JARVIS.colors.amber : i === 1 ? JARVIS.colors.cyan : i === 2 ? JARVIS.colors.violet : JARVIS.colors.textMute;
                return (
                  <motion.div
                    key={a.agent}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-center gap-2"
                  >
                    <span className="jarvis-mono text-[10px] font-bold w-5 text-right" style={{ color }}>{i + 1}</span>
                    <span className="jarvis-mono text-[10px] font-semibold w-20 truncate" style={{ color: i < 3 ? color : 'var(--j-text-dim)' }}>{a.agent}</span>
                    <div className="flex-1 h-4 rounded-full bg-[var(--j-bg)] overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.5, delay: i * 0.03 }}
                        className="h-full rounded-full flex items-center justify-end pr-1.5"
                        style={{ background: `${color}22`, borderRight: `2px solid ${color}` }}
                      >
                        <span className="jarvis-mono text-[9px] font-bold tabular-nums" style={{ color }}>₹{a.earnings.toLocaleString()}</span>
                      </motion.div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {/* Earning methods projections */}
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Target className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Earning Methods · Monthly Projection</h4>
          </div>
          {earningMethods.length === 0 ? (
            <div className="text-center py-6 text-[var(--j-text-mute)] text-xs">No approved earning methods yet.</div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {earningMethods.map((m, i) => {
                const color = POTENTIAL_COLORS[m.earningPotential] ?? JARVIS.colors.cyan;
                return (
                  <motion.div
                    key={m.key}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="p-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]/60"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-xs flex-1 truncate">{m.name}</span>
                      <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>{m.earningPotential}</span>
                    </div>
                    <div className="flex items-center justify-between jarvis-mono text-[10px]">
                      <span style={{ color: JARVIS.colors.green }}>₹{(m.estimatedMonthly ?? 0).toLocaleString()}/mo</span>
                      <span className="text-[var(--j-text-mute)]">{m.executionCount ?? 0} runs</span>
                      <span className="text-[var(--j-text-mute)]">₹{(m.totalEarnings ?? 0).toLocaleString()} earned</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Metric Card ──────────────────────────────────────────────────────
function MetricCard({ icon: Icon, label, value, sub, color }: { icon: typeof DollarSign; label: string; value: string; sub?: string; color: string }) {
  return (
    <div className="p-3 rounded-md border bg-[var(--j-panel-soft)]/60" style={{ borderColor: `${color}33` }}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <div className="jarvis-mono text-base font-bold tabular-nums" style={{ color }}>{value}</div>
      {sub && <div className="jarvis-mono text-[8px] text-[var(--j-text-mute)] mt-0.5">{sub}</div>}
    </div>
  );
}

// ─── Cost Stat ────────────────────────────────────────────────────────
function CostStat({ label, value, color, sub }: { label: string; value: string; color: string; sub?: string }) {
  return (
    <div className="text-center p-2 rounded-md bg-[var(--j-panel-soft)]/40 border border-[var(--j-border)]">
      <div className="jarvis-mono text-sm font-bold tabular-nums" style={{ color }}>{value}</div>
      <div className="jarvis-mono text-[8px] uppercase tracking-wider text-[var(--j-text-mute)] mt-0.5">{label}</div>
      {sub && <div className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">{sub}</div>}
    </div>
  );
}

// Need Clock import for the MetricCard usage above
// (moved to top-level imports above)
