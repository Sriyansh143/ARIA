'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Play, Trash2, ChevronUp, ChevronDown, Loader2, AlertTriangle } from 'lucide-react';
import { postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, EmptyState } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';

interface ExecResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  blocked?: boolean;
  blockReason?: string;
  command: string;
  error?: string;
}

interface OutputLine {
  id: string;
  type: 'command' | 'stdout' | 'stderr' | 'blocked' | 'system' | 'exit';
  text: string;
  exitCode?: number;
  durationMs?: number;
}

const MAX_HISTORY = 100;
const MAX_OUTPUT_LINES = 500;

export default function TerminalTab() {
  const [input, setInput] = useState('');
  const [lines, setLines] = useState<OutputLine[]>([
    { id: 'boot-1', type: 'system', text: 'JARVIS Mission Control — sandboxed shell' },
    { id: 'boot-2', type: 'system', text: 'Blocked patterns: rm -rf /, sudo, mkfs, dd if=, fork bomb. 30s timeout.' },
    { id: 'boot-3', type: 'system', text: 'Type a command and press Enter. ↑/↓ to navigate history.' },
  ]);
  const [history, setHistory] = useState<string[]>([]);
  const [histIdx, setHistIdx] = useState<number>(-1);
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lineIdRef = useRef(0);

  // Auto-scroll to bottom on new lines
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [lines]);

  const pushLines = useCallback((newLines: Omit<OutputLine, 'id'>[]) => {
    setLines((prev) => {
      const withIds = newLines.map((l) => ({ ...l, id: `line-${lineIdRef.current++}` }));
      const merged = [...prev, ...withIds];
      // Trim oldest if over cap (keep boot lines + recent)
      if (merged.length > MAX_OUTPUT_LINES) {
        return merged.slice(-MAX_OUTPUT_LINES);
      }
      return merged;
    });
  }, []);

  const runCommand = useCallback(async (raw: string) => {
    const command = raw.trim();
    if (!command) return;
    if (busy) return;

    pushLines([{ type: 'command', text: command }]);
    setHistory((prev) => {
      const next = [...prev, command];
      return next.slice(-MAX_HISTORY);
    });
    setHistIdx(-1);
    setInput('');
    setBusy(true);

    try {
      const res = await postJson<ExecResult>('/api/terminal/exec', { command });
      if (res.error) {
        pushLines([{ type: 'stderr', text: res.error }]);
        return;
      }
      if (res.blocked) {
        pushLines([
          { type: 'blocked', text: res.blockReason ?? 'command blocked by safety filter' },
        ]);
        return;
      }
      const newLines: Omit<OutputLine, 'id'>[] = [];
      if (res.stdout) {
        newLines.push(...res.stdout.split('\n').map((t) => ({ type: 'stdout' as const, text: t })));
      }
      if (res.stderr) {
        newLines.push(...res.stderr.split('\n').map((t) => ({ type: 'stderr' as const, text: t })));
      }
      newLines.push({
        type: 'exit',
        text: `exit ${res.exitCode} · ${res.durationMs}ms`,
        exitCode: res.exitCode,
        durationMs: res.durationMs,
      });
      pushLines(newLines);
    } catch (e) {
      pushLines([
        { type: 'stderr', text: e instanceof Error ? e.message : 'execution failed' },
      ]);
      toast({ title: 'Command failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
      // Refocus input
      setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [busy, pushLines, toast]);

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      runCommand(input);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length === 0) return;
      const nextIdx = histIdx === -1 ? history.length - 1 : Math.max(0, histIdx - 1);
      setHistIdx(nextIdx);
      setInput(history[nextIdx] ?? '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (history.length === 0 || histIdx === -1) return;
      const nextIdx = histIdx + 1;
      if (nextIdx >= history.length) {
        setHistIdx(-1);
        setInput('');
      } else {
        setHistIdx(nextIdx);
        setInput(history[nextIdx] ?? '');
      }
    } else if (e.key === 'l' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      setLines([]);
    }
  };

  const clearOutput = () => {
    setLines([
      { id: `line-${lineIdRef.current++}`, type: 'system', text: 'Terminal cleared.' },
    ]);
    inputRef.current?.focus();
  };

  const lineColor = (line: OutputLine): string => {
    switch (line.type) {
      case 'command': return 'text-[var(--j-cyan)]';
      case 'stdout': return 'text-[var(--j-green)]';
      case 'stderr': return 'text-[var(--j-red)]';
      case 'blocked': return 'text-[var(--j-amber)]';
      case 'exit':
        return line.exitCode === 0
          ? 'text-[var(--j-text-mute)]'
          : 'text-[var(--j-red)]';
      case 'system':
      default:
        return 'text-[var(--j-text-mute)]';
    }
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      <SectionTitle
        title="Terminal — Sandboxed Shell"
        icon={Terminal}
        accent={JARVIS.colors.green}
        action={
          <button
            onClick={clearOutput}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-red)] transition-colors"
            title="Clear output (Ctrl+L)"
            aria-label="Clear terminal output"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        }
      />

      <div className="jarvis-panel p-0 overflow-hidden flex flex-col flex-1 min-h-[60vh]">
        {/* Title bar */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
          <Terminal className="h-3.5 w-3.5 text-[var(--j-green)]" />
          <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
            jarvis@mission-control:~$ shell
          </span>
          <span className="ml-auto flex items-center gap-2">
            <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
              {history.length} cmds
            </span>
            {busy && (
              <span className="flex items-center gap-1 jarvis-mono text-[10px] text-[var(--j-amber)]">
                <Loader2 className="h-3 w-3 animate-spin" /> running
              </span>
            )}
          </span>
        </div>

        {/* Output */}
        <div
          ref={outputRef}
          className="flex-1 overflow-y-auto jarvis-scroll font-mono text-xs bg-[var(--j-bg-soft)] min-h-[40vh] max-h-[55vh]"
          onClick={() => inputRef.current?.focus()}
        >
          <AnimatePresence initial={false}>
            {lines.map((line) => (
              <motion.div
                key={line.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`px-4 py-0.5 whitespace-pre-wrap break-all ${lineColor(line)}`}
              >
                {line.type === 'command' && (
                  <span className="text-[var(--j-text-mute)] mr-2 select-none">$</span>
                )}
                {line.type === 'blocked' && (
                  <AlertTriangle className="inline h-3 w-3 mr-1 -mt-0.5 text-[var(--j-amber)]" />
                )}
                {line.text}
                {line.type === 'exit' && line.exitCode !== undefined && line.exitCode !== 0 && (
                  <span className="ml-2 text-[var(--j-red)]">⚠ non-zero exit</span>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
          {lines.length === 0 && (
            <EmptyState
              icon={Terminal}
              message="No output yet"
              hint="Type a command below to begin."
              accent={JARVIS.colors.green}
            />
          )}
        </div>

        {/* Input row */}
        <div className="flex items-center gap-2 px-4 py-2 border-t border-[var(--j-border)] bg-[var(--j-panel-soft)]/60">
          <span className="jarvis-mono text-xs text-[var(--j-green)] select-none">$</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            disabled={busy}
            spellCheck={false}
            autoComplete="off"
            autoCapitalize="off"
            placeholder={busy ? 'executing…' : 'enter a command (try: ls, pwd, date)'}
            className="flex-1 bg-transparent border-0 outline-none font-mono text-xs text-[var(--j-text)] placeholder:text-[var(--j-text-mute)] disabled:opacity-50"
            autoFocus
          />
          <button
            onClick={() => runCommand(input)}
            disabled={busy || !input.trim()}
            className="jarvis-mono text-[10px] uppercase px-2 py-1 rounded-md border transition-all disabled:opacity-40 border-[var(--j-green)]/40 text-[var(--j-green)] bg-[var(--j-green)]/10 hover:bg-[var(--j-green)]/20"
            aria-label="Run command"
          >
            <Play className="h-3 w-3" />
          </button>
        </div>

        {/* Footer hint */}
        <div className="flex items-center justify-between px-4 py-1.5 border-t border-[var(--j-border-soft)] bg-[var(--j-panel)]">
          <div className="flex items-center gap-3 jarvis-mono text-[10px] text-[var(--j-text-mute)]">
            <span className="flex items-center gap-1"><ChevronUp className="h-3 w-3" /><ChevronDown className="h-3 w-3" /> history</span>
            <span>Ctrl+L clear</span>
            <span>Enter run</span>
          </div>
          <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
            cwd: workspace
          </span>
        </div>
      </div>
    </div>
  );
}
