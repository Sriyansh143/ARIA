'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, Trash2, Sparkles, Zap, Bot, User, Copy, Check, ChevronDown, ChevronRight, Brain, Lightbulb, ChevronUp, ArrowUp, ArrowDown, Paperclip, X, FileText, Image as ImageIcon, File as FileIcon, Loader2 } from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface Msg {
  id: string;
  role: string;
  content: string;
  reasoning?: string | null;
  latency?: number;
  model?: string;
  createdAt: string;
}

const QUICK_PROMPTS = [
  'Summarize the current fleet status',
  'Write a Python function to dedupe a list',
  'Research top 3 AI chatbot competitors',
  'Create a task: deploy earning method',
];

/** Supported text-mime extensions (read as UTF-8 + appended as code block). */
const TEXT_EXT = new Set(['txt', 'md', 'json', 'js', 'ts', 'tsx', 'jsx', 'py', 'csv', 'xml', 'yaml', 'yml', 'html', 'css', 'sql', 'sh', 'env', 'log']);
const IMAGE_EXT = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp']);

interface Attachment {
  id: string;
  filename: string;
  sizeBytes: number;
  mimeType: string;
  kind: 'text' | 'image' | 'binary' | 'pending';
  base64?: string; // raw base64 (no data: prefix)
  /** Filled after server analysis: */
  text?: string;       // for text attachments
  language?: string;   // language hint for code block
  description?: string; // for image attachments (VLM)
  error?: string;
}

function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** Read a File as raw base64 (no data: prefix). */
function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip `data:...;base64,` prefix.
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function CodeBlock({ language, value }: { language: string; value: string }) {
  const [collapsed, setCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const copy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    toast({ title: 'Copied', description: `${value.length} chars` });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-2 rounded-lg border border-[var(--j-border)] bg-[var(--j-bg)] overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-1.5 bg-[var(--j-panel-soft)] border-b border-[var(--j-border-soft)]">
        <button onClick={() => setCollapsed(!collapsed)} className="flex items-center gap-1.5 text-[10px] uppercase jarvis-mono text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] transition-colors">
          {collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          {language || 'code'}
        </button>
        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{value.split('\n').length} lines</span>
        <button onClick={copy} className="ml-auto flex items-center gap-1 text-[10px] jarvis-mono text-[var(--j-text-mute)] hover:text-[var(--j-green)] transition-colors">
          {copied ? <Check className="h-3 w-3 text-[var(--j-green)]" /> : <Copy className="h-3 w-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      {!collapsed && (
        <div className="overflow-x-auto max-h-96 jarvis-scroll">
          <SyntaxHighlighter language={language || 'text'} style={atomDark} customStyle={{ margin: 0, padding: '12px', fontSize: '12px', background: 'transparent' }} wrapLongLines={false}>
            {value}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}

/**
 * Collapsible "ARIA is thinking..." panel that reveals the model's reasoning trace.
 * Shows a glowing brain animation when collapsed, full reasoning text when expanded.
 * The reasoning is rendered as plain text (preserving line breaks) — not markdown —
 * because reasoning_content is the model's internal chain-of-thought, not user-facing prose.
 */
function ThinkingPanel({ reasoning, isThinking }: { reasoning?: string | null; isThinking?: boolean }) {
  const [expanded, setExpanded] = useState(false);
  if (!reasoning && !isThinking) return null;

  const preview = reasoning ? reasoning.slice(0, 140) + (reasoning.length > 140 ? '…' : '') : '';
  const lineCount = reasoning ? reasoning.split('\n').length : 0;

  return (
    <div className="mb-2 rounded-lg border border-[var(--j-violet)]/30 bg-[var(--j-violet)]/5 overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-[var(--j-violet)]/10 transition-colors"
      >
        <div className="relative flex items-center">
          <Brain className={`h-3.5 w-3.5 text-[var(--j-violet)] ${isThinking ? 'jarvis-pulse' : ''}`} />
          {isThinking && (
            <span className="absolute -inset-1 rounded-full bg-[var(--j-violet)]/30 jarvis-pulse" />
          )}
        </div>
        <span className="text-[10px] uppercase jarvis-mono font-semibold text-[var(--j-violet)] tracking-wider">
          {isThinking ? 'ARIA is thinking…' : 'Reasoning trace'}
        </span>
        {!isThinking && reasoning && (
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">{lineCount} lines · {reasoning.length} chars</span>
        )}
        {expanded ? <ChevronDown className="h-3 w-3 text-[var(--j-text-mute)] ml-auto" /> : <ChevronRight className="h-3 w-3 text-[var(--j-text-mute)] ml-auto" />}
      </button>
      {expanded && reasoning && (
        <div className="px-3 pb-2.5 pt-1 max-h-64 overflow-y-auto jarvis-scroll">
          <pre className="text-[11px] leading-relaxed jarvis-mono text-[var(--j-text-dim)] whitespace-pre-wrap break-words">{reasoning}</pre>
        </div>
      )}
      {!expanded && preview && (
        <div className="px-3 pb-1.5 -mt-1">
          <p className="text-[10px] text-[var(--j-text-mute)] italic line-clamp-1">{preview}</p>
        </div>
      )}
    </div>
  );
}

/** Animated "thinking…" indicator shown while waiting for the LLM response. */
function ThinkingIndicator({ thinkingMode }: { thinkingMode: boolean }) {
  return (
    <div className="space-y-2">
      {thinkingMode && (
        <div className="rounded-lg border border-[var(--j-violet)]/30 bg-[var(--j-violet)]/5 px-3 py-2">
          <div className="flex items-center gap-2 mb-1.5">
            <div className="relative">
              <Lightbulb className="h-3.5 w-3.5 text-[var(--j-violet)] jarvis-pulse" />
              <span className="absolute -inset-1 rounded-full bg-[var(--j-violet)]/30 jarvis-pulse" />
            </div>
            <span className="text-[10px] uppercase jarvis-mono font-semibold text-[var(--j-violet)] tracking-wider">ARIA is thinking…</span>
          </div>
          <div className="space-y-1">
            <div className="h-1.5 w-3/4 rounded bg-[var(--j-violet)]/20 jarvis-thinking-shimmer text-[var(--j-violet)]" />
            <div className="h-1.5 w-1/2 rounded bg-[var(--j-violet)]/15 jarvis-thinking-shimmer text-[var(--j-violet)]" style={{ animationDelay: '0.3s' }} />
            <div className="h-1.5 w-2/3 rounded bg-[var(--j-violet)]/10 jarvis-thinking-shimmer text-[var(--j-violet)]" style={{ animationDelay: '0.6s' }} />
          </div>
        </div>
      )}
      <div className="flex items-center gap-1 py-1">
        <span className="jarvis-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--j-violet)]" style={{ animationDelay: '0s' }} />
        <span className="jarvis-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--j-violet)]" style={{ animationDelay: '0.2s' }} />
        <span className="jarvis-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--j-violet)]" style={{ animationDelay: '0.4s' }} />
      </div>
    </div>
  );
}

export default function ChatTab() {
  const { data, refresh } = useApi<{ messages: Msg[] }>('/api/chat?limit=30', 0);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Msg | null>(null);
  const [thinkingMode, setThinkingMode] = useState(true);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  };
  const scrollToTop = () => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  };
  const { toast } = useToast();

  const messages = data?.messages ?? [];

  // Sync local thinking toggle with the global server-side flag on mount.
  useEffect(() => {
    fetch('/api/thinking-mode').then((r) => r.json()).then((d: { enabled?: boolean }) => {
      if (typeof d.enabled === 'boolean') setThinkingMode(d.enabled);
    }).catch(() => { /* best-effort */ });
  }, []);

  const toggleThinking = async () => {
    const next = !thinkingMode;
    setThinkingMode(next);
    try {
      await postJson('/api/thinking-mode', { enabled: next });
      toast({ title: next ? 'Thinking mode ON' : 'Thinking mode OFF', description: next ? 'ARIA will reason before every response' : 'Complex tasks still get thinking automatically' });
    } catch {
      /* best-effort — local state already updated */
    }
  };

  // Auto-scroll to last message on mount, on new messages, and on draft change.
  // This ensures the latest message is always visible on page reload.
  useEffect(() => {
    scrollToBottom();
  }, [messages.length, draft]);

  // Also scroll to bottom on initial data load (page reload).
  useEffect(() => {
    if (data && messages.length > 0) {
      // Small delay to ensure DOM is fully rendered.
      const t = setTimeout(scrollToBottom, 100);
      return () => clearTimeout(t);
    }
  }, [data]);

  /** Open the OS file picker (multi-select). */
  const pickFiles = () => fileInputRef.current?.click();

  /** Handle selected files: classify, read as base64, send to /api/chat/attach for analysis. */
  const onFilesPicked = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setAnalyzing(true);
    try {
      const newOnes: Attachment[] = [];
      for (const file of Array.from(files)) {
        const ext = extOf(file.name);
        const isImage = IMAGE_EXT.has(ext) || file.type.startsWith('image/');
        const isText = TEXT_EXT.has(ext) || file.type.startsWith('text/') || file.type === 'application/json' || file.type === 'application/xml';
        const kind: Attachment['kind'] = isImage ? 'image' : isText ? 'text' : 'binary';
        const base64 = await readFileAsBase64(file).catch(() => undefined);
        const att: Attachment = {
          id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          filename: file.name,
          sizeBytes: file.size,
          mimeType: file.type || (isImage ? 'image/png' : isText ? 'text/plain' : 'application/octet-stream'),
          kind,
          base64,
        };
        newOnes.push(att);
      }
      setAttachments((prev) => [...prev, ...newOnes]);

      // Analyze each new attachment server-side (best-effort, parallel).
      await Promise.all(newOnes.map(async (att) => {
        if (!att.base64) return;
        try {
          const res = await fetch('/api/chat/attach', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: att.filename, mimeType: att.mimeType, base64: att.base64 }),
          });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const data = await res.json() as { kind?: string; text?: string; language?: string; description?: string };
          setAttachments((prev) => prev.map((p) => p.id === att.id ? {
            ...p,
            kind: (data.kind as Attachment['kind']) || p.kind,
            text: data.text,
            language: data.language,
            description: data.description,
          } : p));
        } catch (e) {
          setAttachments((prev) => prev.map((p) => p.id === att.id ? { ...p, error: e instanceof Error ? e.message : 'analyze failed' } : p));
        }
      }));
    } finally {
      setAnalyzing(false);
      if (fileInputRef.current) fileInputRef.current.value = ''; // allow re-pick of same file
    }
  };

  const removeAttachment = (id: string) => setAttachments((prev) => prev.filter((a) => a.id !== id));

  /** Build the final chat message: user text + attachment context (text→code block, image→VLM desc prepend, binary→footnote). */
  const buildMessageWithAttachments = (text: string): string => {
    if (attachments.length === 0) return text;
    const parts: string[] = [];
    const imageDescs = attachments.filter((a) => a.kind === 'image' && a.description).map((a) => `**[Image: ${a.filename}]** ${a.description}`);
    if (imageDescs.length) parts.push(imageDescs.join('\n\n'));
    if (text.trim()) parts.push(text);
    const textBlocks = attachments.filter((a) => a.kind === 'text' && a.text).map((a) => `**[Attached file: ${a.filename}]**\n\n\`\`\`${a.language || ''}\n${a.text}\n\`\`\``);
    if (textBlocks.length) parts.push(textBlocks.join('\n\n'));
    const binaries = attachments.filter((a) => a.kind === 'binary');
    if (binaries.length) parts.push(`_[Attached binary files: ${binaries.map((b) => `${b.filename} (${fmtBytes(b.sizeBytes)})`).join(', ')} — content not parsed]_`);
    return parts.join('\n\n');
  };

  const send = async (text?: string) => {
    const content = (text ?? input).trim();
    if ((!content && attachments.length === 0) || busy) return;
    // Build the full message including attachment context.
    const fullMessage = buildMessageWithAttachments(content);
    if (!fullMessage) return;
    setInput('');
    const sentAttachments = attachments;
    setAttachments([]);
    setBusy(true);
    const userMsg: Msg = { id: `u-${Date.now()}`, role: 'user', content: fullMessage, createdAt: new Date().toISOString() };
    setDraft(userMsg);
    try {
      const history = messages.map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
      await postJson('/api/chat', { message: fullMessage, history, enableThinking: thinkingMode });
      setDraft(null);
      refresh();
    } catch (e) {
      setDraft(null);
      // Restore attachments on failure so the user can retry.
      setAttachments(sentAttachments);
      toast({ title: 'Chat error', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const shown: Msg[] = [...messages];
  if (draft) shown.push(draft);
  if (busy && draft) shown.push({ id: 'typing', role: 'assistant', content: '', createdAt: new Date().toISOString() });

  return (
    <div className="space-y-4 h-full flex flex-col">
      <SectionTitle
        title="ARIA Chat"
        icon={MessageSquare}
        accent={JARVIS.colors.violet}
        action={
          <div className="flex items-center gap-2">
            <button
              onClick={toggleThinking}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] jarvis-mono uppercase border transition-all ${
                thinkingMode
                  ? 'bg-[var(--j-violet)]/20 border-[var(--j-violet)] text-[var(--j-violet)]'
                  : 'border-[var(--j-border)] text-[var(--j-text-mute)] hover:text-[var(--j-text)]'
              }`}
              title="Extended thinking mode — AI reasons before responding. Global setting (affects all AI calls)."
            >
              <Brain className={`h-3 w-3 ${thinkingMode ? 'jarvis-pulse' : ''}`} />
              {thinkingMode ? 'Thinking ON' : 'Thinking OFF'}
            </button>
            <div className="flex items-center gap-0.5 border border-[var(--j-border)] rounded-md">
              <button
                onClick={scrollToTop}
                className="flex items-center justify-center h-7 w-7 text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] hover:bg-[var(--j-panel-soft)] transition-colors rounded-l-md"
                title="Jump to first message"
              >
                <ArrowUp className="h-3 w-3" />
              </button>
              <button
                onClick={scrollToBottom}
                className="flex items-center justify-center h-7 w-7 text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] hover:bg-[var(--j-panel-soft)] transition-colors rounded-r-md border-l border-[var(--j-border)]"
                title="Jump to last message"
              >
                <ArrowDown className="h-3 w-3" />
              </button>
            </div>
            <Pill color={JARVIS.colors.green}>AI Engine</Pill>
            <Button size="sm" variant="outline" onClick={() => { refresh(); toast({ title: 'Chat refreshed' }); }} className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]">
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        }
      />

      <div className="flex-1 min-h-0 jarvis-panel flex flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto jarvis-scroll p-4 space-y-4 min-h-[300px]">
          {shown.length === 0 && !busy && (
            <div className="flex flex-col items-center justify-center h-full text-center py-10">
              <div className="relative mb-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl jarvis-btn-accent">
                  <Bot className="h-7 w-7" />
                </div>
                <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-[var(--j-green)] jarvis-blink" />
              </div>
              <h3 className="text-lg font-semibold jarvis-text-gradient">ARIA Online</h3>
              <p className="text-sm text-[var(--j-text-dim)] mt-1 max-w-sm">
                Autonomous orchestration assistant. Ask me to plan, code, research, or coordinate the fleet.
              </p>
              <div className="flex flex-wrap gap-2 mt-5 justify-center max-w-lg">
                {QUICK_PROMPTS.map((p) => (
                  <button key={p} onClick={() => send(p)} className="text-xs px-3 py-1.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:border-[var(--j-cyan)] hover:text-[var(--j-cyan)] transition-colors">
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence initial={false}>
            {shown.map((m) => (
              <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md" style={{ background: m.role === 'user' ? `${JARVIS.colors.cyan}1a` : `${JARVIS.colors.violet}1a`, border: `1px solid ${m.role === 'user' ? JARVIS.colors.cyan : JARVIS.colors.violet}33`, color: m.role === 'user' ? JARVIS.colors.cyan : JARVIS.colors.violet }}>
                  {m.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                </div>
                <div className={`max-w-[80%] ${m.role === 'user' ? 'items-end text-right' : ''} flex flex-col`}>
                  <div className={`rounded-lg px-3.5 py-2.5 text-sm ${m.role === 'user' ? 'bg-[var(--j-cyan)]/10 border border-[var(--j-cyan)]/30' : 'bg-[var(--j-panel-soft)] border border-[var(--j-border)]'} group relative`} style={{ color: 'var(--j-text)' }}>
                    {m.id === 'typing' ? (
                      <ThinkingIndicator thinkingMode={thinkingMode} />
                    ) : m.role === 'assistant' ? (
                      <div className="prose-chat">
                        {m.reasoning && <ThinkingPanel reasoning={m.reasoning} />}
                        <ReactMarkdown
                          components={{
                            code({ inline, className, children, ...props }) {
                              const match = /language-(\w+)/.exec(className || '');
                              const value = String(children).replace(/\n$/, '');
                              if (!inline && match) return <CodeBlock language={match[1]} value={value} />;
                              return <code className={className} {...props}>{children}</code>;
                            },
                            ul({ children }) { return <ul className="list-disc list-inside space-y-1 my-2 text-sm">{children}</ul>; },
                            ol({ children }) { return <ol className="list-decimal list-inside space-y-1 my-2 text-sm">{children}</ol>; },
                            li({ children }) { return <li className="text-[var(--j-text-dim)]">{children}</li>; },
                            p({ children }) { return <p className="leading-relaxed mb-2">{children}</p>; },
                            h1({ children }) { return <h1 className="text-base font-bold mt-3 mb-2 text-[var(--j-text)]">{children}</h1>; },
                            h2({ children }) { return <h2 className="text-sm font-bold mt-3 mb-2 text-[var(--j-text)]">{children}</h2>; },
                            h3({ children }) { return <h3 className="text-sm font-semibold mt-2 mb-1 text-[var(--j-text-dim)]">{children}</h3>; },
                            a({ href, children }) { return <a href={href} target="_blank" rel="noopener noreferrer" className="text-[var(--j-cyan)] underline hover:text-[var(--j-cyan)]/80">{children}</a>; },
                            blockquote({ children }) { return <blockquote className="border-l-2 border-[var(--j-cyan)]/40 pl-3 my-2 text-[var(--j-text-mute)] italic">{children}</blockquote>; },
                            table({ children }) { return <div className="overflow-x-auto my-2"><table className="w-full text-xs border border-[var(--j-border)]">{children}</table></div>; },
                            th({ children }) { return <th className="border border-[var(--j-border)] px-2 py-1 bg-[var(--j-panel-soft)] text-[var(--j-text)] font-semibold">{children}</th>; },
                            td({ children }) { return <td className="border border-[var(--j-border)] px-2 py-1 text-[var(--j-text-dim)]">{children}</td>; },
                          }}
                        >
                          {m.content}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      <span className="whitespace-pre-wrap">{m.content}</span>
                    )}
                    {m.id !== 'typing' && m.content && (
                      <button onClick={() => { navigator.clipboard.writeText(m.content); toast({ title: 'Copied' }); }} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded text-[var(--j-text-mute)] hover:text-[var(--j-cyan)]" title="Copy">
                        <Copy className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  {m.latency != null && (
                    <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-1 flex items-center gap-1.5">
                      <Zap className="h-2.5 w-2.5" /> {m.latency}ms · {m.model}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="border-t border-[var(--j-border)] p-3 space-y-2">
          {/* Hidden file input — opened by the paperclip button. */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => onFilesPicked(e.target.files)}
          />

          {/* Attachment chips row - only shown when there are attachments. */}
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pb-1">
              {attachments.map((a) => {
                const Icon = a.kind === 'image' ? ImageIcon : a.kind === 'text' ? FileText : FileIcon;
                const label =
                  a.kind === 'image' ? (a.description ? '✓ ' : (a.error ? '⚠ ' : '… ')) + a.filename :
                  a.kind === 'text'  ? (a.text ? '✓ ' : '… ') + a.filename :
                  /* binary */         a.filename;
                const accent =
                  a.kind === 'image' ? 'var(--j-violet)' :
                  a.kind === 'text'  ? 'var(--j-cyan)' :
                  'var(--j-text-mute)';
                return (
                  <div
                    key={a.id}
                    className="flex items-center gap-1.5 px-2 py-1 rounded-md border text-[10px] jarvis-mono bg-[var(--j-panel-soft)]"
                    style={{ borderColor: `${accent}55`, color: 'var(--j-text-dim)' }}
                    title={
                      a.kind === 'image' ? (a.description || a.error || 'Analyzing…') :
                      a.kind === 'text'  ? (a.text ? `${a.text.length} chars` : (a.error || 'Analyzing…')) :
                      `${fmtBytes(a.sizeBytes)} — binary, not parsed`
                    }
                  >
                    {a.kind === 'image' && !a.description && !a.error ? (
                      <Loader2 className="h-3 w-3 animate-spin" style={{ color: accent }} />
                    ) : (
                      <Icon className="h-3 w-3" style={{ color: accent }} />
                    )}
                    <span className="max-w-[160px] truncate">{label}</span>
                    {a.kind === 'binary' && <span className="text-[9px] text-[var(--j-text-mute)]">{fmtBytes(a.sizeBytes)}</span>}
                    <button
                      onClick={() => removeAttachment(a.id)}
                      className="ml-0.5 text-[var(--j-text-mute)] hover:text-[var(--j-red)] transition-colors"
                      title="Remove attachment"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="flex items-end gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder={attachments.length ? 'Add a note (optional)…' : 'Message ARIA…  (⏎ to send, ⇧⏎ for newline)'}
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)] min-h-[44px] max-h-32 resize-none text-sm"
              rows={1}
            />
            <Button
              onClick={pickFiles}
              disabled={analyzing || busy}
              className="border border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] h-11 w-11 p-0 shrink-0"
              title="Attach files (text, images, or any binary)"
            >
              {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Paperclip className="h-4 w-4" />}
            </Button>
            <Button
              onClick={() => send()}
              disabled={busy || analyzing || (!input.trim() && attachments.length === 0)}
              className="jarvis-btn-accent border-0 h-11 w-11 p-0 shrink-0"
            >
              {busy ? <Sparkles className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
