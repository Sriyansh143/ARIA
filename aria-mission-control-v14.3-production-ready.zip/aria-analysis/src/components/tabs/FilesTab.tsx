'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FolderArchive, Folder, FileText, FileCode, ChevronUp, ChevronRight,
  Save, RefreshCw, Loader2, FolderOpen, FileWarning, FileJson,
  Upload, FilePlus, FolderPlus, Trash2,
} from 'lucide-react';
import { postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, EmptyState, Pill } from '@/components/jarvis/shared';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

interface DirEntry {
  name: string;
  type: 'dir' | 'file';
  size: number;
}

interface ListResponse {
  path: string;
  resolvedPath: string;
  items: DirEntry[];
  count: number;
}

interface ReadResponse {
  path: string;
  content: string;
  size: number;
  truncated: boolean;
}

interface WriteResponse {
  ok: boolean;
  path: string;
  bytes: number;
}

interface DeleteResponse {
  ok: boolean;
  path: string;
  deletedBytes: number;
}

interface MkdirResponse {
  ok: boolean;
  path: string;
  existed: boolean;
}

const TEXTUAL_EXTS = new Set([
  'ts', 'tsx', 'js', 'jsx', 'json', 'md', 'txt', 'css', 'scss', 'html',
  'yml', 'yaml', 'prisma', 'sh', 'env', 'gitignore', 'toml', 'lock',
  'svg', 'xml', 'sql', 'py', 'rb', 'go', 'rs', 'java', 'kt', 'c', 'h',
  'cpp', 'hpp', 'php', 'vue', 'svelte',
]);

function getExt(name: string): string {
  const dot = name.lastIndexOf('.');
  if (dot === -1) return '';
  return name.slice(dot + 1).toLowerCase();
}

function isTextual(name: string): boolean {
  const ext = getExt(name);
  if (TEXTUAL_EXTS.has(ext)) return true;
  // dotfiles like .env, .gitignore, .eslintrc
  if (name.startsWith('.') && !name.startsWith('..')) return true;
  // files with no extension often text (README, LICENSE)
  if (!ext && !name.includes('.')) return true;
  return false;
}

function fileIcon(name: string): typeof FileText {
  const ext = getExt(name);
  if (['ts', 'tsx', 'js', 'jsx', 'json'].includes(ext)) return FileCode;
  if (['md', 'txt'].includes(ext)) return FileText;
  if (ext === 'json') return FileJson;
  if (ext === 'env') return FileWarning;
  return FileText;
}

function formatSize(bytes: number): string {
  if (bytes === 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function joinPath(base: string, name: string): string {
  if (base === '.' || base === '') return name;
  if (base.endsWith('/')) return base + name;
  return base + '/' + name;
}

function parentPath(p: string): string {
  if (p === '.' || p === '' || !p.includes('/')) return '.';
  const parts = p.split('/');
  parts.pop();
  return parts.join('/') || '.';
}

export default function FilesTab() {
  const [cwd, setCwd] = useState<string>('.');
  const [entries, setEntries] = useState<DirEntry[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [listError, setListError] = useState<string | null>(null);

  const [activeFile, setActiveFile] = useState<{ path: string; name: string } | null>(null);
  const [fileContent, setFileContent] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [loadingFile, setLoadingFile] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  /* Upload / new-file / new-folder / delete state */
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [deletingPath, setDeletingPath] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragDepthRef = useRef(0);

  const { toast } = useToast();

  const refreshList = useCallback(async (path: string) => {
    setLoadingList(true);
    setListError(null);
    try {
      const res = await postJson<ListResponse>('/api/workspace/list', { path });
      setEntries(res.items ?? []);
    } catch (e) {
      setListError(e instanceof Error ? e.message : 'list failed');
      setEntries([]);
    } finally {
      setLoadingList(false);
    }
  }, []);

  useEffect(() => {
    refreshList(cwd);
  }, [cwd, refreshList]);

  const openFile = useCallback(async (entry: DirEntry) => {
    if (entry.type !== 'file') return;
    if (!isTextual(entry.name)) {
      toast({
        title: 'Cannot open binary file',
        description: `${entry.name} is not a text file`,
        variant: 'destructive',
      });
      return;
    }
    const fullPath = joinPath(cwd, entry.name);
    setActiveFile({ path: fullPath, name: entry.name });
    setFileContent('');
    setOriginalContent('');
    setDirty(false);
    setFileError(null);
    setLoadingFile(true);
    try {
      const res = await postJson<ReadResponse>('/api/file/read', { path: fullPath });
      setFileContent(res.content);
      setOriginalContent(res.content);
    } catch (e) {
      setFileError(e instanceof Error ? e.message : 'read failed');
    } finally {
      setLoadingFile(false);
    }
  }, [cwd, toast]);

  const saveFile = useCallback(async () => {
    if (!activeFile) return;
    setSaving(true);
    try {
      const res = await postJson<WriteResponse>('/api/file/write', {
        path: activeFile.path,
        content: fileContent,
      });
      if (res.ok) {
        setOriginalContent(fileContent);
        setDirty(false);
        toast({ title: `Saved ${activeFile.name}`, description: `${res.bytes} bytes` });
        refreshList(cwd);
      } else {
        toast({ title: 'Save failed', variant: 'destructive' });
      }
    } catch (e) {
      toast({
        title: 'Save failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  }, [activeFile, fileContent, refreshList, cwd, toast]);

  const breadcrumbs = useMemo(() => {
    if (cwd === '.' || cwd === '') return [{ label: 'workspace', path: '.' }];
    const parts = cwd.split('/').filter(Boolean);
    const crumbs = [{ label: 'workspace', path: '.' }];
    let acc = '';
    for (const p of parts) {
      acc = acc ? `${acc}/${p}` : p;
      crumbs.push({ label: p, path: acc });
    }
    return crumbs;
  }, [cwd]);

  const onContentChange = (v: string) => {
    setFileContent(v);
    setDirty(v !== originalContent);
  };

  /* ---------- Upload local files into the current directory ---------- */
  const uploadFiles = useCallback(async (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;
    setUploading(true);
    let success = 0;
    let failed = 0;
    for (const file of files) {
      const targetPath = joinPath(cwd, file.name);
      try {
        const content = await file.text();
        await postJson<WriteResponse>('/api/file/write', { path: targetPath, content });
        success++;
        toast({
          title: `Uploaded ${file.name}`,
          description: `${(file.size / 1024).toFixed(1)} KB → ${targetPath}`,
        });
      } catch (e) {
        failed++;
        toast({
          title: `Upload failed: ${file.name}`,
          description: e instanceof Error ? e.message : '',
          variant: 'destructive',
        });
      }
    }
    setUploading(false);
    if (success > 0) {
      refreshList(cwd);
      toast({
        title: 'Upload complete',
        description: `${success} file${success === 1 ? '' : 's'} uploaded${failed ? `, ${failed} failed` : ''}`,
      });
    }
  }, [cwd, refreshList, toast]);

  /* ---------- New empty file ---------- */
  const createNewFile = useCallback(async () => {
    const name = window.prompt('New file name (e.g. notes.md):');
    if (!name || !name.trim()) return;
    const cleanName = name.trim().replace(/^\/+/, '');
    const targetPath = joinPath(cwd, cleanName);
    try {
      await postJson<WriteResponse>('/api/file/write', { path: targetPath, content: '' });
      toast({ title: 'File created', description: targetPath });
      refreshList(cwd);
    } catch (e) {
      toast({
        title: 'Create failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    }
  }, [cwd, refreshList, toast]);

  /* ---------- New folder ---------- */
  const createNewFolder = useCallback(async () => {
    const name = window.prompt('New folder name:');
    if (!name || !name.trim()) return;
    const cleanName = name.trim().replace(/^\/+/, '').replace(/\/+$/, '');
    const targetPath = joinPath(cwd, cleanName);
    try {
      const res = await postJson<MkdirResponse>('/api/file/mkdir', { path: targetPath });
      toast({
        title: res.existed ? 'Folder already exists' : 'Folder created',
        description: targetPath,
      });
      refreshList(cwd);
    } catch (e) {
      toast({
        title: 'Folder create failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    }
  }, [cwd, refreshList, toast]);

  /* ---------- Delete a file (with confirm) ---------- */
  const deleteEntry = useCallback(async (entry: DirEntry) => {
    const targetPath = joinPath(cwd, entry.name);
    if (!window.confirm(`Delete "${targetPath}"?\n\nThis action cannot be undone.`)) return;
    setDeletingPath(targetPath);
    try {
      const res = await fetch('/api/file', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: targetPath }),
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status}: ${txt}`);
      }
      const data = (await res.json()) as DeleteResponse;
      toast({
        title: `Deleted ${entry.name}`,
        description: `${data.deletedBytes} bytes removed`,
      });
      // If we were editing this file, clear the editor.
      if (activeFile?.path === targetPath) {
        setActiveFile(null);
        setFileContent('');
        setOriginalContent('');
        setDirty(false);
      }
      refreshList(cwd);
    } catch (e) {
      toast({
        title: 'Delete failed',
        description: e instanceof Error ? e.message : '',
        variant: 'destructive',
      });
    } finally {
      setDeletingPath(null);
    }
  }, [cwd, activeFile, refreshList, toast]);

  /* ---------- Drag-and-drop handlers ---------- */
  const onDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!e.dataTransfer?.types?.includes('Files')) return;
    dragDepthRef.current += 1;
    setDragging(true);
  }, []);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragDepthRef.current = Math.max(0, dragDepthRef.current - 1);
    if (dragDepthRef.current === 0) setDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragDepthRef.current = 0;
    setDragging(false);
    const files = e.dataTransfer?.files;
    if (files && files.length > 0) {
      uploadFiles(files);
    }
  }, [uploadFiles]);

  return (
    <div className="space-y-4 h-full flex flex-col">
      <SectionTitle
        title="File Explorer — Workspace"
        icon={FolderArchive}
        accent={JARVIS.colors.amber}
        action={
          <div className="flex gap-1.5 flex-wrap">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  uploadFiles(e.target.files);
                }
                // reset so the same file can be re-selected later
                e.target.value = '';
              }}
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)] jarvis-btn-accent"
              title="Upload local files into this directory"
            >
              {uploading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1" />}
              Upload
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={createNewFile}
              className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]"
              title="Create a new empty file"
            >
              <FilePlus className="h-3.5 w-3.5 mr-1" /> New File
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={createNewFolder}
              className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]"
              title="Create a new folder"
            >
              <FolderPlus className="h-3.5 w-3.5 mr-1" /> New Folder
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => refreshList(cwd)}
              className="border-[var(--j-border)] bg-transparent hover:bg-[var(--j-panel-soft)]"
              aria-label="Refresh listing"
            >
              <RefreshCw className="h-3.5 w-3.5 mr-1" /> Refresh
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-[60vh]">
        {/* ─── Left panel: file tree ─── */}
        <div className="lg:col-span-4 jarvis-panel p-0 overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
            <FolderOpen className="h-3.5 w-3.5 text-[var(--j-amber)]" />
            <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">
              directory browser
            </span>
            <button
              onClick={() => setCwd(parentPath(cwd))}
              disabled={cwd === '.'}
              className="ml-auto flex h-6 w-6 items-center justify-center rounded border border-[var(--j-border)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] disabled:opacity-30"
              aria-label="Up one directory"
              title="Up one directory"
            >
              <ChevronUp className="h-3 w-3" />
            </button>
          </div>

          {/* Breadcrumbs */}
          <div className="flex items-center gap-1 px-3 py-2 border-b border-[var(--j-border-soft)] overflow-x-auto jarvis-scroll">
            {breadcrumbs.map((c, i) => (
              <span key={c.path} className="flex items-center gap-1 shrink-0">
                {i > 0 && <ChevronRight className="h-3 w-3 text-[var(--j-text-mute)]" />}
                <button
                  onClick={() => setCwd(c.path)}
                  className={`jarvis-mono text-[10px] px-1.5 py-0.5 rounded transition-colors ${
                    i === breadcrumbs.length - 1
                      ? 'text-[var(--j-amber)] bg-[var(--j-amber)]/10'
                      : 'text-[var(--j-text-dim)] hover:text-[var(--j-cyan)]'
                  }`}
                >
                  {c.label}
                </button>
              </span>
            ))}
          </div>

          {/* Listing — also a drop target for drag-and-drop uploads */}
          <div
            className="relative flex-1 overflow-y-auto jarvis-scroll min-h-[40vh]"
            onDragEnter={onDragEnter}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
          >
            {loadingList ? (
              <div className="flex items-center justify-center py-8 text-[var(--j-text-mute)] jarvis-mono text-[10px] uppercase">
                <Loader2 className="h-4 w-4 animate-spin mr-2" /> loading…
              </div>
            ) : listError ? (
              <EmptyState icon={FileWarning} message="List failed" hint={listError} accent={JARVIS.colors.red} />
            ) : entries.length === 0 ? (
              <EmptyState icon={Folder} message="Empty directory" hint="Upload or drag files here to get started." accent={JARVIS.colors.amber} />
            ) : (
              entries.map((entry) => {
                const Icon = entry.type === 'dir' ? Folder : fileIcon(entry.name);
                const isActive = activeFile?.name === entry.name;
                const textual = entry.type === 'file' ? isTextual(entry.name) : true;
                const entryPath = joinPath(cwd, entry.name);
                const isDeleting = deletingPath === entryPath;
                return (
                  <div
                    key={entry.name}
                    className={`group w-full flex items-center gap-2 px-3 py-1.5 border-b border-[var(--j-border-soft)] transition-colors ${
                      isActive
                        ? 'bg-[var(--j-amber)]/10 text-[var(--j-amber)]'
                        : 'hover:bg-[var(--j-panel-soft)]/60 text-[var(--j-text-dim)]'
                    } ${isDeleting ? 'opacity-50 pointer-events-none' : ''}`}
                  >
                    <button
                      onClick={() => {
                        if (entry.type === 'dir') {
                          setCwd(joinPath(cwd, entry.name));
                        } else {
                          openFile(entry);
                        }
                      }}
                      className="flex items-center gap-2 flex-1 min-w-0 text-left"
                    >
                      <Icon className={`h-3.5 w-3.5 shrink-0 ${entry.type === 'dir' ? 'text-[var(--j-amber)]' : 'text-[var(--j-cyan)]'}`} />
                      <span className="jarvis-mono text-xs truncate flex-1">{entry.name}</span>
                      {entry.type === 'file' && !textual && (
                        <span className="text-[9px] uppercase text-[var(--j-text-mute)]">bin</span>
                      )}
                      {entry.type === 'file' && (
                        <span className="text-[10px] text-[var(--j-text-mute)] tabular-nums shrink-0">
                          {formatSize(entry.size)}
                        </span>
                      )}
                      {entry.type === 'dir' && (
                        <ChevronRight className="h-3 w-3 text-[var(--j-text-mute)] shrink-0" />
                      )}
                    </button>
                    {entry.type === 'file' && (
                      <button
                        onClick={(e) => { e.stopPropagation(); deleteEntry(entry); }}
                        disabled={isDeleting}
                        className="opacity-0 group-hover:opacity-100 text-[var(--j-text-mute)] hover:text-[var(--j-red)] transition-opacity shrink-0 p-0.5"
                        title={`Delete ${entry.name}`}
                        aria-label={`Delete ${entry.name}`}
                      >
                        {isDeleting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                      </button>
                    )}
                  </div>
                );
              })
            )}

            {/* Drag-and-drop overlay */}
            <AnimatePresence>
              {dragging && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none"
                  style={{
                    background: `${JARVIS.colors.amber}1a`,
                    border: `2px dashed ${JARVIS.colors.amber}`,
                  }}
                >
                  <div className="flex flex-col items-center gap-2 text-[var(--j-amber)]">
                    <Upload className="h-8 w-8" />
                    <span className="jarvis-mono text-xs uppercase tracking-wider">
                      Drop files to upload to {cwd}
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center justify-between px-3 py-1.5 border-t border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
            <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
              {entries.length} entries
            </span>
            <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">{cwd}</span>
          </div>
        </div>

        {/* ─── Right panel: editor ─── */}
        <div className="lg:col-span-8 jarvis-panel p-0 overflow-hidden flex flex-col">
          {!activeFile ? (
            <EmptyState
              icon={FileText}
              message="No file selected"
              hint="Pick a file from the directory listing to view and edit it."
              accent={JARVIS.colors.cyan}
            />
          ) : (
            <>
              {/* Editor header */}
              <div className="flex items-center gap-2 px-4 py-2 border-b border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
                {(() => {
                  const Icon = fileIcon(activeFile.name);
                  return <Icon className="h-3.5 w-3.5 text-[var(--j-cyan)]" />;
                })()}
                <span className="jarvis-mono text-xs text-[var(--j-text)] truncate">{activeFile.path}</span>
                {dirty && (
                  <span className="flex items-center gap-1 jarvis-mono text-[10px] text-[var(--j-amber)]">
                    <span className="h-1.5 w-1.5 rounded-full bg-[var(--j-amber)] inline-block" />
                    unsaved
                  </span>
                )}
                <div className="ml-auto flex items-center gap-2">
                  {fileError && <Pill color={JARVIS.colors.red}>error</Pill>}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={saveFile}
                    disabled={saving || !dirty}
                    className="jarvis-btn-accent border-0 disabled:opacity-30"
                  >
                    {saving ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Save className="h-3.5 w-3.5 mr-1" />}
                    Save
                  </Button>
                </div>
              </div>

              {/* Editor body */}
              <div className="flex-1 relative min-h-[40vh]">
                {loadingFile ? (
                  <div className="flex items-center justify-center h-full text-[var(--j-text-mute)] jarvis-mono text-[10px] uppercase">
                    <Loader2 className="h-4 w-4 animate-spin mr-2" /> reading…
                  </div>
                ) : fileError ? (
                  <EmptyState icon={FileWarning} message="Read failed" hint={fileError} accent={JARVIS.colors.red} />
                ) : (
                  <textarea
                    value={fileContent}
                    onChange={(e) => onContentChange(e.target.value)}
                    spellCheck={false}
                    className="w-full h-full min-h-[50vh] bg-[var(--j-bg-soft)] text-[var(--j-text)] font-mono text-xs p-4 outline-none resize-none jarvis-scroll border-0"
                    placeholder="file is empty"
                  />
                )}
              </div>

              {/* Editor footer */}
              <div className="flex items-center justify-between px-4 py-1.5 border-t border-[var(--j-border)] bg-[var(--j-panel-soft)]/40">
                <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                  {fileContent.length} chars · {fileContent.split('\n').length} lines
                </span>
                <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">
                  {dirty ? 'modified' : 'clean'}
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
