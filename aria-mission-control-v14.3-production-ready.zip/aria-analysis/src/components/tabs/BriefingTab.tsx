'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowRight, Bot, Brain, CheckCircle2, Cpu,
  Gauge, Loader2, RefreshCw, Sparkles, Target, TrendingUp, TrendingDown, Wallet, Zap, AlertOctagon,
  Rocket, Database, Wand2, Network, Sunrise, CheckCircle2 as CheckIcon, CircleDashed, ListChecks,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';

/**
 * Persisted set of recommendation titles that have already been promoted to a
 * task. Stored in localStorage so they STAY hidden across tab switches, page
 * reloads and briefing regenerations — this is what previously caused the
 * "same recommendation / error coming again and again even after making a task"
 * loop: the in-memory Set was wiped on every remount, so the regenerated
 * briefing re-surfaced the identical recommendations.
 *
 * NOTE: making a task must NOT navigate away from the Briefing tab. The action
 * is performed in place — the operator stays exactly where they are.
 */
const CONVERTED_RECS_KEY = 'aria.briefing.convertedRecs.v1';
const TRAINING_COOLDOWN_KEY = 'aria.briefing.lastConvertedAt';

function loadConvertedRecs(): Set<string> {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = window.localStorage.getItem(CONVERTED_RECS_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? new Set(arr.filter((x) => typeof x === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

function saveConvertedRecs(set: Set<string>) {
  if (typeof window === 'undefined') return;
  try {
    // Keep the set bounded — only the most recent 100 converted titles.
    const arr = Array.from(set).slice(-100);
    window.localStorage.setItem(CONVERTED_RECS_KEY, JSON.stringify(arr));
    window.localStorage.setItem(TRAINING_COOLDOWN_KEY, String(Date.now()));
  } catch { /* localStorage may be unavailable */ }
}

interface Recommendation {
  title: string;
  rationale: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  suggestedAssignee?: string;
  category: 'performance' | 'revenue' | 'reliability' | 'capacity' | 'knowledge' | 'ops';
}

interface Forecast {
  metric: string;
  horizon: string;
  current: number;
  forecast: number;
  confidence: number;
  trend: 'up' | 'down' | 'stable';
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  detail: Record<string, unknown>;
}

interface Briefing {
  generatedAt: string;
  headline: string;
  healthScore: number;
  summary: string;
  metrics: {
    agents: number;
    activeAgents: number;
    overloadedAgents: string[];
    idleAgents: number;
    pendingTasks: number;
    inProgressTasks: number;
    blockedTasks: number;
    unreadComms: number;
    openApprovals: number;
    criticalFindings: number;
    cpu: number;
    memPct: number;
    confirmedRevenue: number;
    pendingRevenue: number;
    successRate: number;
  };
  topRisks: string[];
  recommendations: Recommendation[];
  forecasts?: Forecast[];
}

const PRIORITY_STYLE: Record<Recommendation['priority'], { color: string; bg: string; label: string; icon: typeof AlertTriangle }> = {
  critical: { color: JARVIS.colors.red, bg: 'rgba(248,113,113,0.12)', label: 'CRITICAL', icon: AlertOctagon },
  high: { color: JARVIS.colors.amber, bg: 'rgba(251,191,36,0.12)', label: 'HIGH', icon: AlertTriangle },
  medium: { color: JARVIS.colors.cyan, bg: 'rgba(125,211,252,0.12)', label: 'MEDIUM', icon: Zap },
  low: { color: JARVIS.colors.green, bg: 'rgba(52,211,153,0.12)', label: 'LOW', icon: CheckCircle2 },
};

const CATEGORY_ICON: Record<Recommendation['category'], typeof Bot> = {
  performance: Gauge,
  revenue: Wallet,
  reliability: AlertTriangle,
  capacity: Bot,
  knowledge: Brain,
  ops: Activity,
};

export default function BriefingTab() {
  // intervalMs=0 means one-shot on mount (no polling) — the SSE subscription
  // below drives live updates instead. The manual `refresh` is wired to the
  // `?force=1` cache-bypass endpoint so the Regenerate button actually
  // triggers a fresh LLM call rather than re-serving the cached briefing.
  const { data, loading, refresh } = useApi<{ briefing: Briefing }>('/api/briefing', 0);
  const { toast } = useToast();
  const [creatingIdx, setCreatingIdx] = useState<number | null>(null);
  // Track recommendation titles that have been converted to tasks — persisted
  // to localStorage so they survive tab switches / remounts (which previously
  // reset this Set and re-surfaced the same recommendations over and over).
  const [convertedRecs, setConvertedRecs] = useState<Set<string>>(() => loadConvertedRecs());
  const [sseConnected, setSseConnected] = useState(false);
  const refreshRef = useRef(refresh);
  refreshRef.current = refresh;

  // SSE subscription — when the server recomputes the briefing (whether due
  // to a state change, the autopilot scheduler ticking, or another client
  // hitting Regenerate), this tab refreshes within milliseconds.
  useEffect(() => {
    let es: EventSource | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let closed = false;

    const connect = () => {
      if (closed) return;
      try {
        es = new EventSource('/api/briefing/stream');
        es.addEventListener('open', () => setSseConnected(true));
        es.addEventListener('error', () => {
          setSseConnected(false);
          try { es?.close(); } catch { /* ignore */ }
          es = null;
          if (!closed) reconnectTimer = setTimeout(connect, 5000);
        });
        es.addEventListener('briefing:updated', () => refreshRef.current());
        es.addEventListener('briefing:invalidated', () => refreshRef.current());
        es.addEventListener('ping', () => { /* keep-alive */ });
      } catch {
        // EventSource unavailable — fall back to manual refresh only.
      }
    };
    connect();

    return () => {
      closed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      try { es?.close(); } catch { /* ignore */ }
    };
  }, []);

  /** Regenerate — clears the converted-recs memory, invalidates the server-
   *  side briefing cache (via ?force=1), and triggers a fresh LLM synthesis.
   *  The new briefing will be pushed to ALL open clients (including this one)
   *  via the SSE briefing:updated event.
   *
   *  NOTE: defined as a plain function (not useCallback) to avoid the
   *  temporal-dead-zone issue with `clearConvertedRecs` which is defined
   *  below. React re-creates this on every render which is fine — it's only
   *  called from a button onClick. */
  const regenerate = () => {
    clearConvertedRecs();
    // Force-bypass the cache by hitting the ?force=1 endpoint. The useApi
    // hook's refresh() goes to /api/briefing (no query) so we do a manual
    // fetch and then call refresh() to update the hook's state.
    (async () => {
      try {
        await fetch('/api/briefing?force=1', { cache: 'no-store' });
        refreshRef.current();
      } catch (e) {
        toast({ title: 'Regenerate failed', description: e instanceof Error ? e.message : 'unknown', variant: 'destructive' });
      }
    })();
  };

  const briefing = data?.briefing;
  const health = briefing?.healthScore ?? 0;
  const healthColor = health >= 85 ? JARVIS.colors.green : health >= 60 ? JARVIS.colors.amber : JARVIS.colors.red;
  const healthLabel = health >= 85 ? 'NOMINAL' : health >= 60 ? 'STABLE' : 'DEGRADED';

  const createTaskFromRec = useCallback(async (rec: Recommendation, idx: number) => {
    setCreatingIdx(idx);
    try {
      const res = await postJson('/api/tasks', {
        title: rec.title,
        description: rec.rationale + (rec.suggestedAssignee ? `\n\nSuggested assignee: ${rec.suggestedAssignee}` : ''),
        priority: rec.priority === 'low' ? 'low' : rec.priority,
        tags: ['briefing', rec.category],
      });
      if (res?.task) {
        toast({
          title: 'Task created from recommendation',
          description: rec.title.slice(0, 80) + (rec.title.length > 80 ? '…' : ''),
        });
        // Mark this recommendation as converted so it's hidden from the briefing,
        // and PERSIST it so a remount / tab switch does not bring it back.
        setConvertedRecs((prev) => {
          const next = new Set(prev).add(rec.title);
          saveConvertedRecs(next);
          return next;
        });
        // Stay on the Briefing tab — do NOT navigate away. Just refresh the
        // briefing so the heuristic metrics (pending tasks, load, …) recompute.
        refresh();
      } else {
        toast({ title: 'Failed to create task', description: 'Unexpected response from server', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Failed to create task', description: e instanceof Error ? e.message : 'Unknown error', variant: 'destructive' });
    } finally {
      setCreatingIdx(null);
    }
  }, [toast, refresh]);

  /** Clear the persisted converted-recs memory (e.g. when regenerating a fresh briefing). */
  const clearConvertedRecs = useCallback(() => {
    setConvertedRecs(new Set());
    saveConvertedRecs(new Set());
  }, []);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Autonomous Synthesis</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Mission Briefing</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            ARIA's live situational assessment of the autonomous company — synthesized from fleet state, telemetry, tasks, comms & revenue.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {convertedRecs.size > 0 && (
            <button
              onClick={clearConvertedRecs}
              title="Clear the hidden (already-converted) recommendations so they reappear in the briefing"
              className="flex items-center gap-2 h-9 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-mute)] hover:text-[var(--j-amber)] hover:border-[var(--j-amber)] transition-colors text-sm"
            >
              <ListChecks className="h-3.5 w-3.5" />
              <span className="jarvis-mono text-[10px] uppercase">Reset ({convertedRecs.size})</span>
            </button>
          )}
          <button
            onClick={regenerate}
            className="flex items-center gap-2 h-9 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] transition-colors text-sm"
            title={sseConnected ? 'Connected to live briefing stream' : 'Live stream disconnected — using polling fallback'}
          >
            <RefreshCw className={loading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
            <span className="jarvis-mono text-[10px] uppercase">Regenerate</span>
            {sseConnected && <span className="h-1.5 w-1.5 rounded-full jarvis-blink" style={{ background: JARVIS.colors.green }} />}
          </button>
        </div>
      </div>

      {/* Quick Actions — one-click autonomous operations */}
      <QuickActions
        onRefresh={refresh}
        onDone={(msg) => toast({ title: msg })}
        onError={(msg) => toast({ title: 'Action failed', description: msg, variant: 'destructive' })}
      />

      {loading && !briefing ? (
        <BriefingSkeleton />
      ) : !briefing ? (
        <div className="jarvis-panel p-8 text-center text-[var(--j-text-mute)] text-sm">Failed to generate briefing.</div>
      ) : (
        <>
          {/* Hero: headline + health gauge */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="jarvis-panel jarvis-scan p-5 md:p-6 relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-30 pointer-events-none" style={{ background: `radial-gradient(800px circle at 0% 0%, ${healthColor}22, transparent 50%)` }} />
            <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-5">
              {/* Health ring */}
              <div className="flex items-center justify-center shrink-0">
                <HealthRing score={health} color={healthColor} label={healthLabel} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="h-2 w-2 rounded-full jarvis-blink" style={{ background: healthColor, boxShadow: `0 0 8px ${healthColor}` }} />
                  <span className="jarvis-mono text-[10px] uppercase tracking-widest" style={{ color: healthColor }}>Health {health}/100 · {healthLabel}</span>
                  <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">·</span>
                  <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">{timeAgo(new Date(briefing.generatedAt))}</span>
                </div>
                <h3 className="text-lg md:text-xl font-semibold leading-relaxed">{briefing.headline}</h3>
                <p className="text-sm text-[var(--j-text-dim)] mt-2 leading-loose">{briefing.summary}</p>
              </div>
            </div>
          </motion.div>

          {/* Metric strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-1">
            <MetricChip icon={Bot} label="Agents" value={`${briefing.metrics.activeAgents}/${briefing.metrics.agents}`} sub="active" accent={JARVIS.colors.cyan} />
            <MetricChip icon={Cpu} label="CPU" value={`${briefing.metrics.cpu}%`} sub={briefing.metrics.cpu > 70 ? 'high' : 'ok'} accent={briefing.metrics.cpu > 70 ? JARVIS.colors.amber : JARVIS.colors.green} />
            <MetricChip icon={Gauge} label="MEM" value={`${briefing.metrics.memPct}%`} sub="usage" accent={JARVIS.colors.violet} />
            <MetricChip icon={Target} label="Tasks" value={`${briefing.metrics.pendingTasks + briefing.metrics.inProgressTasks}`} sub={`${briefing.metrics.blockedTasks} blocked`} accent={JARVIS.colors.amber} />
            <MetricChip icon={Wallet} label="Revenue" value={`₹${briefing.metrics.confirmedRevenue.toLocaleString()}`} sub={`₹${briefing.metrics.pendingRevenue.toLocaleString()} pend`} accent={JARVIS.colors.green} />
            <MetricChip icon={TrendingUp} label="Success" value={`${briefing.metrics.successRate}%`} sub="fleet avg" accent={JARVIS.colors.green} />
          </div>

          {/* Risks + Recommendations grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Top risks */}
            <div className="jarvis-panel p-4 lg:col-span-1 relative overflow-hidden" style={{ background: 'linear-gradient(180deg, rgba(248,113,113,0.06), transparent 60%)' }}>
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${JARVIS.colors.red}55, transparent)` }} />
              <div className="flex items-center gap-2 mb-3">
                <div className="h-7 w-7 rounded-md flex items-center justify-center" style={{ background: 'rgba(248,113,113,0.12)', color: JARVIS.colors.red }}>
                  <AlertTriangle className="h-4 w-4" />
                </div>
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Top Risks</h4>
                <span className="jarvis-mono text-[10px] ml-auto px-1.5 py-0.5 rounded" style={{ color: JARVIS.colors.red, background: 'rgba(248,113,113,0.12)' }}>{briefing.topRisks.length}</span>
              </div>
              <div className="space-y-2">
                {briefing.topRisks.map((risk, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-2 p-2.5 rounded-md bg-[var(--j-panel-soft)]/80 border-l-2"
                    style={{ borderColor: JARVIS.colors.red }}
                  >
                    <span className="jarvis-mono text-[10px] mt-0.5 font-bold" style={{ color: JARVIS.colors.red }}>{String(i + 1).padStart(2, '0')}</span>
                    <span className="text-xs text-[var(--j-text-dim)] leading-relaxed">{risk}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Predictive Analytics — fleet forecasts */}
            {briefing.forecasts && briefing.forecasts.length > 0 && (
              <div className="jarvis-panel p-4 lg:col-span-3 relative overflow-hidden" style={{ background: 'linear-gradient(180deg, rgba(167,139,250,0.05), transparent 60%)' }}>
                <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${JARVIS.colors.violet}55, transparent)` }} />
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-7 w-7 rounded-md flex items-center justify-center" style={{ background: 'rgba(167,139,250,0.12)', color: JARVIS.colors.violet }}>
                    <TrendingUp className="h-4 w-4" />
                  </div>
                  <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Predictive Analytics · Fleet Forecasts</h4>
                  <span className="jarvis-mono text-[10px] ml-auto px-1.5 py-0.5 rounded" style={{ color: JARVIS.colors.violet, background: 'rgba(167,139,250,0.12)' }}>{briefing.forecasts.length} metrics</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                  {briefing.forecasts.map((f, i) => {
                    const riskColor = f.riskLevel === 'critical' ? JARVIS.colors.red : f.riskLevel === 'high' ? JARVIS.colors.amber : f.riskLevel === 'medium' ? JARVIS.colors.cyan : JARVIS.colors.green;
                    const TrendIcon = f.trend === 'up' ? TrendingUp : f.trend === 'down' ? TrendingDown : Activity;
                    const metricLabel = f.metric.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
                    return (
                      <motion.div
                        key={f.metric}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="rounded-md p-3 border bg-[var(--j-panel-soft)]/60"
                        style={{ borderColor: `${riskColor}33` }}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] truncate">{metricLabel}</span>
                          <TrendIcon className="h-3 w-3 shrink-0" style={{ color: riskColor }} />
                        </div>
                        <div className="flex items-baseline gap-1 mb-1">
                          <span className="jarvis-mono text-lg font-bold tabular-nums" style={{ color: 'var(--j-text)' }}>{Math.round(f.forecast)}</span>
                          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">/ {f.horizon}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">now {Math.round(f.current)}</span>
                          <span className="jarvis-mono text-[9px] px-1 py-0.5 rounded font-bold uppercase" style={{ color: riskColor, background: `${riskColor}1a` }}>{f.riskLevel}</span>
                        </div>
                        <div className="mt-1.5 h-1 rounded-full bg-[var(--j-panel-soft)] overflow-hidden">
                          <div className="h-full rounded-full transition-all" style={{ width: `${Math.round(f.confidence * 100)}%`, background: riskColor }} />
                        </div>
                        <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)] mt-0.5 block">conf {Math.round(f.confidence * 100)}%</span>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Recommendations */}
            <div className="lg:col-span-2 space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
                  <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Recommended Actions</h4>
                </div>
                <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">{briefing.recommendations.filter((r) => !convertedRecs.has(r.title)).length} items{convertedRecs.size > 0 && ` · ${convertedRecs.size} converted`}</span>
              </div>
              <AnimatePresence mode="popLayout">
                {briefing.recommendations.filter((r) => !convertedRecs.has(r.title)).map((rec, i) => {
                  const ps = PRIORITY_STYLE[rec.priority];
                  const CatIcon = CATEGORY_ICON[rec.category] ?? Activity;
                  const isCreating = creatingIdx === i;
                  return (
                    <motion.div
                      key={rec.title}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.97 }}
                      transition={{ delay: i * 0.06 }}
                      className="jarvis-panel p-4 group hover:border-[var(--j-cyan)]/40 transition-all relative overflow-hidden"
                    >
                      <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: ps.color }} />
                      <div className="flex items-start gap-3 pl-2">
                        <div className="shrink-0 mt-0.5 h-8 w-8 rounded-md flex items-center justify-center" style={{ background: ps.bg, color: ps.color }}>
                          <CatIcon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold tracking-wider" style={{ color: ps.color, background: ps.bg }}>{ps.label}</span>
                            <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">{rec.category}</span>
                            {rec.suggestedAssignee && (
                              <span className="jarvis-mono text-[9px] text-[var(--j-violet)] flex items-center gap-1">
                                <Bot className="h-2.5 w-2.5" /> {rec.suggestedAssignee}
                              </span>
                            )}
                          </div>
                          <h5 className="text-sm font-medium text-[var(--j-text)] leading-snug">{rec.title}</h5>
                          <p className="text-xs text-[var(--j-text-dim)] mt-1 leading-relaxed">{rec.rationale}</p>
                        </div>
                        <button
                          onClick={() => createTaskFromRec(rec, i)}
                          disabled={isCreating}
                          className="shrink-0 self-center flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)] hover:shadow-[0_0_12px_rgba(125,211,252,0.25)] transition-all text-xs disabled:opacity-50"
                          title="Create a task from this recommendation"
                        >
                          {isCreating ? <Loader2 className="h-3 w-3 animate-spin" /> : <ArrowRight className="h-3 w-3" />}
                          <span className="jarvis-mono text-[10px] uppercase whitespace-nowrap">{isCreating ? 'Creating' : 'Make Task'}</span>
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>

          {/* Daily Standup — ARIA's narrative of the last 24h */}
          <DailyStandup />
        </>
      )}
    </div>
  );
}

/* ---------- Quick Actions bar ---------- */
interface QuickActionDef {
  key: string;
  label: string;
  icon: typeof Bot;
  accent: string;
  method: 'POST' | 'GET';
  url: string;
  body?: unknown;
  doneMsg: string;
  /** Some endpoints return a summary we can surface in the toast. */
  summarize?: (data: any) => string | undefined;
}

const QUICK_ACTIONS: QuickActionDef[] = [
  { key: 'autonomy', label: 'Run Autonomy', icon: Rocket, accent: JARVIS.colors.cyan, method: 'POST', url: '/api/orchestrate/parallel', body: { goal: 'advance highest-priority pending work', maxAgents: 3 }, doneMsg: 'Autonomy cycle dispatched', summarize: (d) => (d?.summary ? `${d.summary}`.slice(0, 90) : undefined) },
  { key: 'insight', label: 'Generate Insight', icon: Wand2, accent: JARVIS.colors.violet, method: 'GET', url: '/api/insights', doneMsg: 'Fresh insight generated' },
  { key: 'sync-models', label: 'Sync Models', icon: Network, accent: JARVIS.colors.green, method: 'POST', url: '/api/models/sync', doneMsg: 'Model catalog synced', summarize: (d) => (typeof d?.count === 'number' ? `${d.count} models` : undefined) },
  { key: 'kd-sync', label: 'Sync Knowledge', icon: Database, accent: JARVIS.colors.amber, method: 'POST', url: '/api/knowledge-daemon/sync', doneMsg: 'Knowledge daemon synced' },
];

function QuickActions({ onRefresh, onDone, onError }: { onRefresh: () => void; onDone: (msg: string) => void; onError: (msg: string) => void }) {
  const [busyKey, setBusyKey] = useState<string | null>(null);

  const run = useCallback(async (a: QuickActionDef) => {
    setBusyKey(a.key);
    try {
      const res = await fetch(a.url, {
        method: a.method,
        headers: a.method === 'POST' ? { 'Content-Type': 'application/json' } : undefined,
        body: a.method === 'POST' ? JSON.stringify(a.body ?? {}) : undefined,
        cache: 'no-store',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      let data: any = null;
      try { data = await res.json(); } catch { /* no body */ }
      const extra = a.summarize?.(data);
      onDone(extra ? `${a.doneMsg} · ${extra}` : a.doneMsg);
      // After any autonomous action, refresh the briefing so the operator sees the new state.
      onRefresh();
    } catch (e) {
      onError(e instanceof Error ? e.message : 'Unknown error');
    } finally {
      setBusyKey(null);
    }
  }, [onDone, onError, onRefresh]);

  return (
    <div className="jarvis-panel p-3">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)] mr-1 hidden sm:inline">Quick Actions</span>
        {QUICK_ACTIONS.map((a) => {
          const Icon = a.icon;
          const busy = busyKey === a.key;
          return (
            <button
              key={a.key}
              onClick={() => run(a)}
              disabled={busy}
              className="group relative flex items-center gap-2 h-9 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-text)] transition-all text-sm disabled:opacity-50 overflow-hidden"
              style={{ borderColor: busy ? a.accent : undefined }}
            >
              <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: `radial-gradient(120px circle at 50% 50%, ${a.accent}14, transparent 70%)` }} />
              {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin relative z-10" style={{ color: a.accent }} /> : <Icon className="h-3.5 w-3.5 relative z-10" style={{ color: a.accent }} />}
              <span className="jarvis-mono text-[10px] uppercase tracking-wider relative z-10 whitespace-nowrap">{busy ? 'Running…' : a.label}</span>
            </button>
          );
        })}
        <div className="ml-auto jarvis-mono text-[9px] text-[var(--j-text-mute)] hidden md:flex items-center gap-1">
          <Zap className="h-3 w-3" style={{ color: JARVIS.colors.amber }} />
          <span>Actions trigger a briefing refresh</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Health ring ---------- */
function HealthRing({ score, color, label }: { score: number; color: string; label: string }) {
  const r = 42;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  return (
    <div className="relative h-28 w-28">
      <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={r} fill="none" stroke="var(--j-border)" strokeWidth="6" />
        <motion.circle
          cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: 'easeOut' }}
          style={{ filter: `drop-shadow(0 0 6px ${color})` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold jarvis-num" style={{ color }}>{score}</span>
        <span className="jarvis-mono text-[9px] uppercase tracking-widest" style={{ color }}>{label}</span>
      </div>
    </div>
  );
}

/* ---------- Metric chip ---------- */
function MetricChip({ icon: Icon, label, value, sub, accent }: { icon: typeof Bot; label: string; value: string; sub: string; accent: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden group hover:scale-[1.02] transition-transform">
      <div className="absolute top-0 right-0 h-12 w-12 rounded-full opacity-10 blur-xl" style={{ background: accent }} />
      <div className="flex items-center gap-2 mb-1">
        <Icon className="h-3.5 w-3.5" style={{ color: accent }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <div className="text-lg font-bold jarvis-num">{value}</div>
      <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-0.5">{sub}</div>
    </div>
  );
}

/* ---------- Skeleton ---------- */
function BriefingSkeleton() {
  return (
    <div className="space-y-5">
      <div className="jarvis-panel p-6 flex items-center gap-5">
        <div className="h-28 w-28 rounded-full bg-[var(--j-panel-soft)] jarvis-skeleton" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-24 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
          <div className="h-5 w-3/4 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
          <div className="h-3 w-full rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
          <div className="h-3 w-2/3 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {Array.from({ length: 6 }).map((_, i) => <div key={i} className="jarvis-panel p-3 h-20 jarvis-skeleton" />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="jarvis-panel p-4 h-48 jarvis-skeleton" />
        <div className="lg:col-span-2 space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="jarvis-panel p-4 h-20 jarvis-skeleton" />)}
        </div>
      </div>
    </div>
  );
}

/* ---------- Daily Standup ---------- */
interface StandupData {
  standup: {
    generatedAt: string;
    windowHours: number;
    headline: string;
    sections: {
      accomplished: string[];
      inProgress: string[];
      blocked: string[];
      nextPriorities: string[];
    };
    stats: {
      tasksCompleted: number;
      tasksCreated: number;
      agentLogs: number;
      paymentsConfirmed: number;
      revenueConfirmed: number;
      autopilotCycles: number;
    };
  };
}

function DailyStandup() {
  const { data, loading, refresh } = useApi<StandupData>('/api/standup', 0);
  const s = data?.standup;

  if (loading && !s) {
    return (
      <div className="jarvis-panel p-5">
        <div className="h-4 w-32 rounded bg-[var(--j-panel-soft)] jarvis-skeleton mb-3" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-28 rounded-md bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
        </div>
      </div>
    );
  }
  if (!s) return null;

  const sections = [
    { key: 'accomplished', label: 'Accomplished', icon: CheckIcon, color: JARVIS.colors.green, items: s.sections.accomplished },
    { key: 'inProgress', label: 'In Progress', icon: CircleDashed, color: JARVIS.colors.cyan, items: s.sections.inProgress },
    { key: 'blocked', label: 'Blocked', icon: AlertTriangle, color: JARVIS.colors.red, items: s.sections.blocked },
    { key: 'nextPriorities', label: 'Next Priorities', icon: ListChecks, color: JARVIS.colors.amber, items: s.sections.nextPriorities },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="jarvis-panel p-5 relative overflow-hidden"
    >
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ background: `radial-gradient(600px circle at 100% 0%, ${JARVIS.colors.amber}18, transparent 50%)` }} />
      <div className="relative z-10">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: 'rgba(251,191,36,0.12)', color: JARVIS.colors.amber }}>
              <Sunrise className="h-4 w-4" />
            </div>
            <div>
              <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Daily Standup</h4>
              <p className="text-[10px] text-[var(--j-text-mute)]">Last {s.windowHours}h · {timeAgo(new Date(s.generatedAt))}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-3 jarvis-mono text-[10px] text-[var(--j-text-mute)]">
              <span><span className="text-[var(--j-green)]">{s.stats.tasksCompleted}</span> done</span>
              <span><span className="text-[var(--j-cyan)]">{s.stats.tasksCreated}</span> created</span>
              <span><span className="text-[var(--j-green)]">₹{s.stats.revenueConfirmed.toLocaleString()}</span> rev</span>
              <span><span className="text-[var(--j-violet)]">{s.stats.autopilotCycles}</span> autopilot</span>
            </div>
            <button onClick={refresh} className="flex items-center gap-1.5 h-7 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-amber)] hover:border-[var(--j-amber)] transition-colors text-xs">
              <RefreshCw className="h-3 w-3" />
              <span className="jarvis-mono text-[9px] uppercase">Refresh</span>
            </button>
          </div>
        </div>
        <p className="text-sm text-[var(--j-text)] mb-4 leading-relaxed font-medium">{s.headline}</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {sections.map((sec, i) => (
            <motion.div
              key={sec.key}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]/50 p-3"
            >
              <div className="flex items-center gap-1.5 mb-2">
                <sec.icon className="h-3 w-3" style={{ color: sec.color }} />
                <span className="jarvis-mono text-[9px] uppercase tracking-wider" style={{ color: sec.color }}>{sec.label}</span>
                <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-auto">{sec.items.length}</span>
              </div>
              <div className="space-y-1.5">
                {sec.items.length === 0 ? (
                  <p className="text-[10px] text-[var(--j-text-mute)] italic">Nothing to report.</p>
                ) : (
                  sec.items.map((item, j) => (
                    <div key={j} className="flex items-start gap-1.5">
                      <span className="h-1 w-1 rounded-full mt-1.5 shrink-0" style={{ background: sec.color }} />
                      <span className="text-[11px] text-[var(--j-text-dim)] leading-snug">{item}</span>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
