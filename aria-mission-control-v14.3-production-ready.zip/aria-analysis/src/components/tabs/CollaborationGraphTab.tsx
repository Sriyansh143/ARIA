'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Network, RefreshCw, Loader2, Bot, Zap, AlertTriangle, Radio,
  ArrowRight, Send, Inbox, Megaphone, Search, Filter, X,
  TrendingUp, Activity, MessageSquare,
} from 'lucide-react';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ─── Types ────────────────────────────────────────────────────────────
interface GraphNode {
  id: string;
  sent: number;
  received: number;
  total: number;
  size: number;
}

interface GraphEdge {
  from: string;
  to: string;
  count: number;
  lastAt: string;
  urgent: number;
  high: number;
  normal: number;
  weight: number;
}

interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: {
    totalMessages: number;
    totalEdges: number;
    totalNodes: number;
    broadcasts: number;
    urgent: number;
    high: number;
    unread: number;
    topTalkers: Array<{ agent: string; total: number }>;
    busiestEdge: GraphEdge | null;
  };
}

const PRIORITY_COLORS = {
  urgent: JARVIS.colors.red,
  high: JARVIS.colors.amber,
  normal: JARVIS.colors.cyan,
};

// Radial layout: position nodes in a circle around the center
function useRadialLayout(nodes: GraphNode[], selectedId: string | null) {
  return useMemo(() => {
    if (nodes.length === 0) return [];
    const cx = 250;
    const cy = 250;
    const radius = 180;
    // Put BROADCAST or selected node in the center
    const centerNode = selectedId ?? (nodes.find((n) => n.id === 'BROADCAST')?.id ?? null);
    const positions = new Map<string, { x: number; y: number }>();

    if (centerNode) {
      positions.set(centerNode, { x: cx, y: cy });
    }

    const ringNodes = nodes.filter((n) => n.id !== centerNode);
    ringNodes.forEach((node, i) => {
      const angle = (i / ringNodes.length) * Math.PI * 2 - Math.PI / 2;
      positions.set(node.id, {
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
      });
    });

    return positions;
  }, [nodes, selectedId]);
}

export default function CollaborationGraphTab() {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [priorityFilter, setPriorityFilter] = useState<'all' | 'urgent' | 'high' | 'normal'>('all');
  const [hoveredEdge, setHoveredEdge] = useState<string | null>(null);

  const { data, loading, refresh } = useApi<GraphData>('/api/comms/graph', 20000);

  const nodes = data?.nodes ?? [];
  const edges = data?.edges ?? [];
  const stats = data?.stats;

  const positions = useRadialLayout(nodes, selectedAgent);

  // Filter edges by priority
  const filteredEdges = useMemo(() => {
    if (priorityFilter === 'all') return edges;
    return edges.filter((e) => e[priorityFilter as 'urgent' | 'high' | 'normal'] > 0);
  }, [edges, priorityFilter]);

  // When an agent is selected, highlight only its edges
  const visibleEdges = useMemo(() => {
    if (!selectedAgent) return filteredEdges;
    return filteredEdges.filter((e) => e.from === selectedAgent || e.to === selectedAgent);
  }, [filteredEdges, selectedAgent]);

  const handleNodeClick = useCallback((id: string) => {
    setSelectedAgent((prev) => (prev === id ? null : id));
  }, []);

  // Agent detail for selected
  const selectedNode = selectedAgent ? nodes.find((n) => n.id === selectedAgent) : null;
  const selectedEdges = selectedAgent ? edges.filter((e) => e.from === selectedAgent || e.to === selectedAgent) : [];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Network className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Inter-Agent Message Flows · Collaboration Network</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Collaboration Graph</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Visualizes every inter-agent message. Node size = activity. Edge thickness = message count. Click a node to focus its flows.
          </p>
        </div>
        <Button onClick={refresh} variant="outline" className="border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-cyan)] hover:border-[var(--j-cyan)]">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''} mr-1.5`} /> Refresh
        </Button>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <SummaryCard icon={MessageSquare} label="Messages" value={stats?.totalMessages ?? 0} color={JARVIS.colors.cyan} />
        <SummaryCard icon={Network} label="Nodes" value={stats?.totalNodes ?? 0} color={JARVIS.colors.violet} />
        <SummaryCard icon={ArrowRight} label="Edges" value={stats?.totalEdges ?? 0} color={JARVIS.colors.green} />
        <SummaryCard icon={Megaphone} label="Broadcasts" value={stats?.broadcasts ?? 0} color={JARVIS.colors.amber} />
        <SummaryCard icon={AlertTriangle} label="Urgent" value={stats?.urgent ?? 0} color={JARVIS.colors.red} />
        <SummaryCard icon={Zap} label="High Pri" value={stats?.high ?? 0} color={JARVIS.colors.amber} />
        <SummaryCard icon={Inbox} label="Unread" value={stats?.unread ?? 0} color={JARVIS.colors.cyan} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Graph visualization (2 cols) */}
        <div className="lg:col-span-2 jarvis-panel p-4 relative">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <Radio className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Network Graph</h4>
            <div className="flex items-center gap-1 ml-auto">
              <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mr-1">Priority:</span>
              {(['all', 'urgent', 'high', 'normal'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPriorityFilter(p)}
                  className="jarvis-mono text-[9px] px-2 py-0.5 rounded-md transition-colors uppercase tracking-wider"
                  style={{
                    background: priorityFilter === p ? `${PRIORITY_COLORS[p === 'all' ? 'normal' : p]}1a` : 'var(--j-panel-soft)',
                    color: priorityFilter === p ? PRIORITY_COLORS[p === 'all' ? 'normal' : p] : 'var(--j-text-mute)',
                    border: `1px solid ${priorityFilter === p ? `${PRIORITY_COLORS[p === 'all' ? 'normal' : p]}44` : 'var(--j-border)'}`,
                  }}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {loading && nodes.length === 0 ? (
            <div className="h-[500px] flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin" style={{ color: JARVIS.colors.cyan }} />
            </div>
          ) : nodes.length === 0 ? (
            <div className="h-[500px] flex flex-col items-center justify-center">
              <Network className="h-12 w-12 mb-3 opacity-30" />
              <p className="text-sm text-[var(--j-text-mute)]">No inter-agent messages yet.</p>
            </div>
          ) : (
            <div className="relative w-full" style={{ height: 500 }}>
              <svg viewBox="0 0 500 500" className="w-full h-full" style={{ maxHeight: 500 }}>
                {/* Edges */}
                {visibleEdges.map((edge, i) => {
                  const fromPos = positions.get(edge.from);
                  const toPos = positions.get(edge.to);
                  if (!fromPos || !toPos) return null;
                  const isHovered = hoveredEdge === `${edge.from}→${edge.to}`;
                  const maxCount = Math.max(...visibleEdges.map((e) => e.count), 1);
                  const strokeWidth = 1 + (edge.count / maxCount) * 5;
                  const color = edge.urgent > 0 ? JARVIS.colors.red : edge.high > 0 ? JARVIS.colors.amber : JARVIS.colors.cyan;
                  const midX = (fromPos.x + toPos.x) / 2;
                  const midY = (fromPos.y + toPos.y) / 2;
                  return (
                    <g key={i}>
                      <line
                        x1={fromPos.x}
                        y1={fromPos.y}
                        x2={toPos.x}
                        y2={toPos.y}
                        stroke={color}
                        strokeWidth={isHovered ? strokeWidth + 1 : strokeWidth}
                        strokeOpacity={isHovered ? 0.8 : 0.25 + (edge.count / maxCount) * 0.3}
                        onMouseEnter={() => setHoveredEdge(`${edge.from}→${edge.to}`)}
                        onMouseLeave={() => setHoveredEdge(null)}
                        style={{ cursor: 'pointer', transition: 'stroke-opacity 0.2s, stroke-width 0.2s' }}
                      />
                      {/* Arrow direction indicator */}
                      <circle
                        cx={midX}
                        cy={midY}
                        r={2}
                        fill={color}
                        opacity={isHovered ? 1 : 0.5}
                      />
                      {/* Hover tooltip */}
                      {isHovered && (
                        <g>
                          <rect x={midX - 45} y={midY - 28} width={90} height={20} rx={4} fill="#0E1218" stroke={color} strokeWidth={1} opacity={0.95} />
                          <text x={midX} y={midY - 15} textAnchor="middle" fill={color} fontSize={9} fontFamily="ui-monospace, monospace" fontWeight="bold">
                            {edge.count} msgs · {edge.urgent}U {edge.high}H
                          </text>
                        </g>
                      )}
                    </g>
                  );
                })}
                {/* Nodes */}
                {nodes.map((node) => {
                  const pos = positions.get(node.id);
                  if (!pos) return null;
                  const isSelected = selectedAgent === node.id;
                  const isCenter = positions.get(node.id)?.x === 250 && positions.get(node.id)?.y === 250;
                  const color = node.id === 'BROADCAST' ? JARVIS.colors.amber : isSelected ? JARVIS.colors.green : JARVIS.colors.cyan;
                  return (
                    <g
                      key={node.id}
                      onClick={() => handleNodeClick(node.id)}
                      style={{ cursor: 'pointer' }}
                    >
                      {/* Outer glow ring for selected */}
                      {isSelected && (
                        <circle cx={pos.x} cy={pos.y} r={node.size + 6} fill="none" stroke={color} strokeWidth={1} strokeOpacity={0.4} strokeDasharray="3 3">
                          <animate attributeName="r" values={`${node.size + 4};${node.size + 8};${node.size + 4}`} dur="2s" repeatCount="indefinite" />
                        </circle>
                      )}
                      {/* Node circle */}
                      <circle
                        cx={pos.x}
                        cy={pos.y}
                        r={node.size}
                        fill={`${color}22`}
                        stroke={color}
                        strokeWidth={isSelected ? 2.5 : 1.5}
                        style={{ transition: 'all 0.2s' }}
                      />
                      {/* Node label */}
                      <text
                        x={pos.x}
                        y={pos.y + node.size + 12}
                        textAnchor="middle"
                        fill={isSelected ? color : '#94A3B8'}
                        fontSize={9}
                        fontFamily="ui-monospace, monospace"
                        fontWeight={isSelected ? 'bold' : 'normal'}
                      >
                        {node.id.length > 10 ? node.id.slice(0, 9) + '…' : node.id}
                      </text>
                      {/* Count badge */}
                      <text
                        x={pos.x}
                        y={pos.y + 3}
                        textAnchor="middle"
                        fill={color}
                        fontSize={node.size > 20 ? 11 : 9}
                        fontFamily="ui-monospace, monospace"
                        fontWeight="bold"
                      >
                        {node.total}
                      </text>
                    </g>
                  );
                })}
              </svg>
              {/* Legend overlay */}
              <div className="absolute bottom-2 left-2 flex items-center gap-3 flex-wrap bg-[var(--j-panel)]/80 backdrop-blur-sm p-2 rounded-md border border-[var(--j-border)]">
                <span className="jarvis-mono text-[8px] uppercase tracking-wider text-[var(--j-text-mute)]">Edges:</span>
                <div className="flex items-center gap-1">
                  <span className="h-1 w-4 rounded-full" style={{ background: JARVIS.colors.red }} />
                  <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">Urgent</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="h-1 w-4 rounded-full" style={{ background: JARVIS.colors.amber }} />
                  <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">High</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="h-1 w-4 rounded-full" style={{ background: JARVIS.colors.cyan }} />
                  <span className="jarvis-mono text-[8px] text-[var(--j-text-mute)]">Normal</span>
                </div>
              </div>
              {selectedAgent && (
                <button
                  onClick={() => setSelectedAgent(null)}
                  className="absolute top-2 right-2 flex items-center gap-1 h-7 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-red)] hover:border-[var(--j-red)] transition-colors text-xs"
                >
                  <X className="h-3 w-3" />
                  <span className="jarvis-mono text-[9px] uppercase">Clear Focus</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right: detail panel (1 col) */}
        <div className="space-y-4">
          {/* Selected agent detail */}
          {selectedNode ? (
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <Bot className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Focused Agent</h4>
              </div>
              <div className="flex items-center gap-3 mb-3">
                <div className="h-12 w-12 rounded-md flex items-center justify-center jarvis-mono text-sm font-bold" style={{ background: `${JARVIS.colors.green}1a`, color: JARVIS.colors.green }}>
                  {selectedNode.id.slice(0, 2)}
                </div>
                <div>
                  <div className="font-bold text-lg">{selectedNode.id}</div>
                  <div className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">{selectedNode.total} total messages</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div className="p-2 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]">
                  <div className="flex items-center gap-1 mb-1">
                    <Send className="h-3 w-3" style={{ color: JARVIS.colors.cyan }} />
                    <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Sent</span>
                  </div>
                  <span className="jarvis-mono text-lg font-bold" style={{ color: JARVIS.colors.cyan }}>{selectedNode.sent}</span>
                </div>
                <div className="p-2 rounded-md bg-[var(--j-panel-soft)]/60 border border-[var(--j-border)]">
                  <div className="flex items-center gap-1 mb-1">
                    <Inbox className="h-3 w-3" style={{ color: JARVIS.colors.violet }} />
                    <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Received</span>
                  </div>
                  <span className="jarvis-mono text-lg font-bold" style={{ color: JARVIS.colors.violet }}>{selectedNode.received}</span>
                </div>
              </div>
              {/* Connections list */}
              <div>
                <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2">Connections ({selectedEdges.length})</p>
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {selectedEdges.slice(0, 12).map((e, i) => {
                    const isSender = e.from === selectedNode.id;
                    const other = isSender ? e.to : e.from;
                    const color = e.urgent > 0 ? JARVIS.colors.red : e.high > 0 ? JARVIS.colors.amber : JARVIS.colors.cyan;
                    return (
                      <div key={i} className="flex items-center gap-2 p-1.5 rounded-md bg-[var(--j-panel-soft)]/40">
                        <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)]">{isSender ? '→' : '←'}</span>
                        <span className="jarvis-mono text-[10px] font-semibold flex-1 truncate" style={{ color }}>{other}</span>
                        <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] tabular-nums">{e.count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="h-4 w-4" style={{ color: JARVIS.colors.amber }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Top Talkers</h4>
              </div>
              <div className="space-y-1.5">
                {(stats?.topTalkers ?? []).map((t, i) => {
                  const color = i === 0 ? JARVIS.colors.green : i === 1 ? JARVIS.colors.cyan : i === 2 ? JARVIS.colors.amber : JARVIS.colors.textMute;
                  return (
                    <button
                      key={t.agent}
                      onClick={() => setSelectedAgent(t.agent)}
                      className="w-full flex items-center gap-2 p-2 rounded-md hover:bg-[var(--j-panel-soft)]/60 transition-colors text-left"
                    >
                      <span className="jarvis-mono text-[10px] font-bold w-5" style={{ color }}>{i + 1}</span>
                      <span className="jarvis-mono text-[11px] font-semibold flex-1 truncate" style={{ color: i < 3 ? color : 'var(--j-text-dim)' }}>{t.agent}</span>
                      <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] tabular-nums">{t.total}</span>
                    </button>
                  );
                })}
              </div>
              <p className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-3 text-center">Click any agent to focus</p>
            </div>
          )}

          {/* Busiest edge */}
          {stats?.busiestEdge && (
            <div className="jarvis-panel p-4">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="h-4 w-4" style={{ color: JARVIS.colors.red }} />
                <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Busiest Channel</h4>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.cyan }}>{stats.busiestEdge.from}</span>
                <ArrowRight className="h-3 w-3 text-[var(--j-text-mute)]" />
                <span className="jarvis-mono text-xs font-bold" style={{ color: JARVIS.colors.violet }}>{stats.busiestEdge.to}</span>
              </div>
              <div className="flex items-center gap-3 text-[10px] jarvis-mono">
                <span style={{ color: JARVIS.colors.cyan }}>{stats.busiestEdge.count} msgs</span>
                {stats.busiestEdge.urgent > 0 && <span style={{ color: JARVIS.colors.red }}>{stats.busiestEdge.urgent} urgent</span>}
                {stats.busiestEdge.high > 0 && <span style={{ color: JARVIS.colors.amber }}>{stats.busiestEdge.high} high</span>}
                <span className="text-[var(--j-text-mute)] ml-auto">{timeAgo(new Date(stats.busiestEdge.lastAt))}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: string | number; color: string }) {
  return (
    <div className="jarvis-panel p-3 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="h-3.5 w-3.5" style={{ color }} />
        <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}
