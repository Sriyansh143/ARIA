'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { GitPullRequest, CheckCircle, XCircle, Rocket, RotateCcw, ChevronDown, ChevronRight, Plus } from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS } from '@/lib/config';
import { SectionTitle, StatCard } from '@/components/jarvis/shared';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface ChangeRow {
  id: string; changeType: string; scope: string; title: string; description: string;
  rationale: string | null; impact: string | null; proposedBy: string; status: string;
  deployedAt: string | null; createdAt: string;
}

export default function ChangeRequestsTab() {
  const { toast } = useToast();
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [showCreate, setShowCreate] = useState(false);
  const [newChange, setNewChange] = useState({ changeType: 'feature-add', title: '', description: '', rationale: '', impact: '' });

  const query = (() => {
    const p = new URLSearchParams();
    if (filterStatus !== 'all') p.set('status', filterStatus);
    if (filterType !== 'all') p.set('changeType', filterType);
    return `/api/changes?${p.toString()}`;
  })();

  const { data: stats } = useApi<{ total: number; pending: number; approved: number; rejected: number; deployed: number }>('/api/changes?stats=1', 30000);
  const { data, refresh } = useApi<{ rows: ChangeRow[] }>(query, 15000);
  const s = stats ?? { total: 0, pending: 0, approved: 0, rejected: 0, deployed: 0 };

  const toggleExpand = (id: string) => setExpanded(prev => { const n = new Set(prev); if (n.has(id)) { n.delete(id); } else { n.add(id); } return n; });

  const actOnChange = async (id: string, action: 'approve' | 'reject' | 'deploy') => {
    try {
      await postJson(`/api/changes/${id}`, { action, decidedBy: 'operator' });
      toast({ title: `Change ${action}d`, description: `Status updated successfully` });
      refresh();
    } catch (e) {
      toast({ title: 'Action failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  const createChange = async () => {
    if (!newChange.title || !newChange.description) return;
    try {
      await postJson('/api/changes', { ...newChange, proposedBy: 'operator' });
      toast({ title: 'Change request created' });
      setNewChange({ changeType: 'feature-add', title: '', description: '', rationale: '', impact: '' });
      setShowCreate(false);
      refresh();
    } catch (e) {
      toast({ title: 'Creation failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    }
  };

  const STATUS_COLORS: Record<string, string> = {
    pending: JARVIS.colors.amber, approved: JARVIS.colors.green, rejected: JARVIS.colors.red,
    deployed: JARVIS.colors.cyan, draft: JARVIS.colors.textMute, 'rolled-back': JARVIS.colors.violet,
  };

  return (
    <div className="space-y-4">
      <SectionTitle title="Change Requests" icon={GitPullRequest} accent={JARVIS.colors.amber} action={<Button size="sm" onClick={() => setShowCreate(!showCreate)} className="jarvis-btn-accent border-0"><Plus className="h-3.5 w-3.5 mr-1" /> New Change</Button>} />
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatCard label="Total" value={s.total} icon={GitPullRequest} accent={JARVIS.colors.cyan} />
        <StatCard label="Pending" value={s.pending} icon={RotateCcw} accent={JARVIS.colors.amber} />
        <StatCard label="Approved" value={s.approved} icon={CheckCircle} accent={JARVIS.colors.green} />
        <StatCard label="Rejected" value={s.rejected} icon={XCircle} accent={JARVIS.colors.red} />
        <StatCard label="Deployed" value={s.deployed} icon={Rocket} accent={JARVIS.colors.cyan} />
      </div>
      {showCreate && (
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] space-y-3">
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Request New Change</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Change Type</Label>
              <Select value={newChange.changeType} onValueChange={(v) => setNewChange({ ...newChange, changeType: v })}>
                <SelectTrigger className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="feature-add">Feature Add</SelectItem><SelectItem value="feature-remove">Feature Remove</SelectItem><SelectItem value="upgrade">Upgrade</SelectItem><SelectItem value="dependency">Dependency</SelectItem><SelectItem value="schema">Schema</SelectItem><SelectItem value="config">Config</SelectItem><SelectItem value="rule">Rule</SelectItem><SelectItem value="hotfix">Hotfix</SelectItem><SelectItem value="refactor">Refactor</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Title</Label>
              <Input value={newChange.title} onChange={(e) => setNewChange({ ...newChange, title: e.target.value })} placeholder="Brief title" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Description</Label>
            <Textarea value={newChange.description} onChange={(e) => setNewChange({ ...newChange, description: e.target.value })} placeholder="What is the change?" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] min-h-[60px] text-xs" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Rationale</Label>
              <Input value={newChange.rationale} onChange={(e) => setNewChange({ ...newChange, rationale: e.target.value })} placeholder="Why?" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9" />
            </div>
            <div className="space-y-1.5">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Impact</Label>
              <Input value={newChange.impact} onChange={(e) => setNewChange({ ...newChange, impact: e.target.value })} placeholder="What could break?" className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9" />
            </div>
          </div>
          <div className="flex gap-2 justify-end"><Button size="sm" variant="ghost" onClick={() => setShowCreate(false)} className="text-[var(--j-text-mute)]">Cancel</Button><Button size="sm" onClick={createChange} disabled={!newChange.title || !newChange.description} className="jarvis-btn-accent border-0">Submit</Button></div>
        </Card>
      )}
      <div className="flex flex-wrap items-center gap-2">
        <Select value={filterStatus} onValueChange={setFilterStatus}><SelectTrigger className="w-[160px] bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">All Statuses</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="approved">Approved</SelectItem><SelectItem value="rejected">Rejected</SelectItem><SelectItem value="deployed">Deployed</SelectItem></SelectContent></Select>
        <Select value={filterType} onValueChange={setFilterType}><SelectTrigger className="w-[160px] bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"><SelectValue placeholder="Type" /></SelectTrigger><SelectContent><SelectItem value="all">All Types</SelectItem><SelectItem value="feature-add">Feature Add</SelectItem><SelectItem value="feature-remove">Feature Remove</SelectItem><SelectItem value="upgrade">Upgrade</SelectItem><SelectItem value="hotfix">Hotfix</SelectItem><SelectItem value="refactor">Refactor</SelectItem></SelectContent></Select>
      </div>
      <div className="space-y-2 max-h-[600px] overflow-y-auto">
        {data?.rows?.map((row, i) => {
          const isExpanded = expanded.has(row.id);
          const statusColor = STATUS_COLORS[row.status] ?? JARVIS.colors.textMute;
          return (
            <motion.div key={row.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.02, 0.4) }}>
              <Card className="p-3 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
                <button onClick={() => toggleExpand(row.id)} className="flex items-center gap-3 w-full text-left">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md" style={{ background: `${statusColor}1a`, border: `1px solid ${statusColor}33`, color: statusColor }}><GitPullRequest className="h-3.5 w-3.5" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm text-[var(--j-text)] font-medium truncate">{row.title}</span>
                      <span className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded" style={{ background: `${statusColor}1a`, color: statusColor }}>{row.status}</span>
                      <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">{row.changeType}</span>
                      <span className="text-[10px] text-[var(--j-text-mute)] ml-auto">{new Date(row.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="text-xs text-[var(--j-text-dim)] mt-0.5 truncate">{row.description}</div>
                  </div>
                  {isExpanded ? <ChevronDown className="h-4 w-4 text-[var(--j-text-mute)]" /> : <ChevronRight className="h-4 w-4 text-[var(--j-text-mute)]" />}
                </button>
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-[var(--j-border-soft)] space-y-2">
                    {row.rationale && <div><div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">Rationale</div><div className="text-[11px] text-[var(--j-text-dim)]">{row.rationale}</div></div>}
                    {row.impact && <div><div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mb-0.5">Impact</div><div className="text-[11px] text-[var(--j-text-dim)]">{row.impact}</div></div>}
                    <div className="flex gap-2 pt-1">
                      {row.status === 'pending' && (
                        <>
                          <Button size="sm" onClick={() => actOnChange(row.id, 'approve')} className="jarvis-btn-accent border-0 h-7 text-[11px]"><CheckCircle className="h-3 w-3 mr-1" /> Approve</Button>
                          <Button size="sm" variant="outline" onClick={() => actOnChange(row.id, 'reject')} className="border-[var(--j-red)] text-[var(--j-red)] hover:bg-[var(--j-red)]/10 h-7 text-[11px]"><XCircle className="h-3 w-3 mr-1" /> Reject</Button>
                        </>
                      )}
                      {row.status === 'approved' && <Button size="sm" onClick={() => actOnChange(row.id, 'deploy')} className="jarvis-btn-accent border-0 h-7 text-[11px]"><Rocket className="h-3 w-3 mr-1" /> Deploy</Button>}
                    </div>
                  </div>
                )}
              </Card>
            </motion.div>
          );
        })}
        {data?.rows?.length === 0 && (
          <Card className="p-8 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] text-center"><GitPullRequest className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)]" /><div className="text-sm text-[var(--j-text-dim)]">No change requests yet.</div></Card>
        )}
      </div>
    </div>
  );
}
