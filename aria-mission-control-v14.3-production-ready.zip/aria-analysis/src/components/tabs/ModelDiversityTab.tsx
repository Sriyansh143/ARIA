'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Cpu, Layers, RefreshCw, Loader2, Search, Filter, Pin, RotateCcw,
  CheckCircle2, XCircle, Zap, Bot, Server, ChevronDown, ChevronRight,
  AlertTriangle, Sparkles, Network,
} from 'lucide-react';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ─── Types ────────────────────────────────────────────────────────────
interface Assignment {
  id: string;
  agentCodename: string;
  modelId: string;
  providerKey: string;
  taskRouting: string;
  priority: number;
  enabled: boolean;
  reason: string | null;
  assignedAt: string;
  updatedAt: string;
}

interface Agent {
  codename: string;
  name: string;
  role: string;
  status: string;
  model: string;
}

interface DiversityData {
  assignments: Assignment[];
  agents: Agent[];
  diversity: {
    uniqueModels: number;
    uniqueProviders: number;
    byModel: Record<string, number>;
    byProvider: Record<string, number>;
  };
}

interface ModelInfo {
  modelId: string;
  providerKey: string;
  tier: string;
  contextWindow: number;
  enabled: boolean;
  status: string;
}

interface ModelsData {
  models: ModelInfo[];
  byProvider: Record<string, ModelInfo[]>;
  providers: string[];
}

const PROVIDER_COLORS: Record<string, string> = {
  zai: JARVIS.colors.cyan,
  openai: JARVIS.colors.green,
  anthropic: JARVIS.colors.amber,
  groq: JARVIS.colors.violet,
  deepseek: JARVIS.colors.red,
  siliconflow: JARVIS.colors.cyan,
  nvidia: JARVIS.colors.green,
  ollama: JARVIS.colors.amber,
  gemini: JARVIS.colors.violet,
  openrouter: JARVIS.colors.cyan,
};

const ROUTING_BADGE: Record<string, { color: string; label: string; icon: typeof Pin }> = {
  pinned: { color: JARVIS.colors.amber, label: 'Pinned', icon: Pin },
  'role-based': { color: JARVIS.colors.cyan, label: 'Role-based', icon: Sparkles },
  auto: { color: JARVIS.colors.violet, label: 'Auto', icon: Zap },
  fallback: { color: JARVIS.colors.textMute, label: 'Fallback', icon: RotateCcw },
};

export default function ModelDiversityTab() {
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [providerFilter, setProviderFilter] = useState('all');
  const [routingFilter, setRoutingFilter] = useState('all');
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);
  const [pinning, setPinning] = useState<string | null>(null);
  const [showPinDialog, setShowPinDialog] = useState<string | null>(null);

  const { data, loading, refresh } = useApi<DiversityData>('/api/agent-models?includeAgents=1', 30000);
  const { data: modelsData } = useApi<ModelsData>('/api/models', 60000);

  const assignments = data?.assignments ?? [];
  const agents = data?.agents ?? [];

  // Merge agent info into assignments
  const merged = useMemo(() => {
    const agentMap = new Map(agents.map((a) => [a.codename, a]));
    return assignments.map((a) => ({
      ...a,
      agent: agentMap.get(a.agentCodename),
    }));
  }, [assignments, agents]);

  // Apply filters
  const filtered = useMemo(() => {
    return merged.filter((a) => {
      if (providerFilter !== 'all' && a.providerKey !== providerFilter) return false;
      if (routingFilter !== 'all' && a.taskRouting !== routingFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        const haystack = `${a.agentCodename} ${a.agent?.name ?? ''} ${a.agent?.role ?? ''} ${a.modelId} ${a.providerKey}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [merged, providerFilter, routingFilter, search]);

  const handleSeed = useCallback(async () => {
    try {
      const res = await postJson<{ ok: boolean; created: number; updated: number }>('/api/agent-models', { action: 'seed' });
      if (res.ok) {
        toast({ title: 'Assignments re-seeded', description: `${res.created} created, ${res.updated} updated` });
        refresh();
      }
    } catch (err) {
      toast({ title: 'Seed failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refresh]);

  const handlePin = useCallback(async (codename: string, modelId: string, providerKey: string) => {
    setPinning(codename);
    try {
      const res = await postJson<{ ok: boolean; assignment: Assignment }>('/api/agent-models', {
        action: 'pin',
        agentCodename: codename,
        modelId,
        providerKey,
        reason: 'Manually pinned via Model Diversity UI',
      });
      if (res.ok) {
        toast({ title: 'Agent pinned', description: `${codename} → ${modelId} (${providerKey})` });
        setShowPinDialog(null);
        refresh();
      }
    } catch (err) {
      toast({ title: 'Pin failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    } finally {
      setPinning(null);
    }
  }, [toast, refresh]);

  const handleUnpin = useCallback(async (codename: string) => {
    setPinning(codename);
    try {
      // Re-seed just this agent by resolving its role-based model
      const res = await postJson<{ ok: boolean; resolved: { modelId: string; providerKey: string } }>('/api/agent-models', {
        action: 'resolve',
        agentCodename: codename,
        role: agents.find((a) => a.codename === codename)?.role,
      });
      if (res.ok && res.resolved) {
        // Update to role-based (unpin)
        const pinRes = await postJson<{ ok: boolean }>('/api/agent-models', {
          action: 'pin',
          agentCodename: codename,
          modelId: res.resolved.modelId,
          providerKey: res.resolved.providerKey,
          reason: 'Role-based (unpinned)',
        });
        if (pinRes.ok) {
          // Now set routing back to role-based
          toast({ title: 'Agent unpinned', description: `${codename} reverted to role-based routing` });
          refresh();
        }
      }
    } catch (err) {
      toast({ title: 'Unpin failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    } finally {
      setPinning(null);
    }
  }, [toast, refresh, agents]);

  const diversity = data?.diversity;
  const providers = Object.keys(diversity?.byProvider ?? {});

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Per-Agent Model Diversity · Provider Spread</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">Model Diversity</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Manage which AI model each agent uses. Pin specialists to optimal models, spread load across providers for rate-limit resilience.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={handleSeed} variant="outline" className="jarvis-btn-accent border-0">
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" /> Re-seed Role-based
          </Button>
        </div>
      </div>

      {/* Diversity summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SummaryCard
          icon={Bot}
          label="Total Agents"
          value={assignments.length}
          color={JARVIS.colors.cyan}
        />
        <SummaryCard
          icon={Cpu}
          label="Unique Models"
          value={diversity?.uniqueModels ?? 0}
          color={JARVIS.colors.violet}
        />
        <SummaryCard
          icon={Server}
          label="Providers"
          value={diversity?.uniqueProviders ?? 0}
          color={JARVIS.colors.green}
        />
        <SummaryCard
          icon={Pin}
          label="Pinned"
          value={assignments.filter((a) => a.taskRouting === 'pinned').length}
          color={JARVIS.colors.amber}
        />
      </div>

      {/* Provider distribution bars */}
      {diversity && Object.keys(diversity.byProvider).length > 0 && (
        <div className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Network className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">Provider Distribution</h4>
          </div>
          <div className="space-y-2.5">
            {Object.entries(diversity.byProvider).map(([provider, count]) => {
              const total = assignments.length || 1;
              const pct = (count / total) * 100;
              const color = PROVIDER_COLORS[provider] ?? JARVIS.colors.cyan;
              return (
                <div key={provider} className="flex items-center gap-3">
                  <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-dim)] w-24 truncate">{provider}</span>
                  <div className="flex-1 h-6 rounded-full bg-[var(--j-bg)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.6, ease: 'easeOut' }}
                      className="h-full rounded-full flex items-center justify-end pr-2"
                      style={{ background: `${color}22`, borderRight: `2px solid ${color}`, boxShadow: `inset 0 0 8px ${color}33` }}
                    >
                      <span className="jarvis-mono text-[10px] font-bold tabular-nums" style={{ color }}>{count}</span>
                    </motion.div>
                  </div>
                  <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] w-12 text-right">{pct.toFixed(0)}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="jarvis-panel p-3 flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--j-text-mute)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search agents, models, providers…"
            className="pl-9 h-8 text-sm"
          />
        </div>
        <Select value={providerFilter} onValueChange={setProviderFilter}>
          <SelectTrigger className="w-[140px] h-8 text-xs">
            <Filter className="h-3 w-3 mr-1" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Providers</SelectItem>
            {providers.map((p) => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={routingFilter} onValueChange={setRoutingFilter}>
          <SelectTrigger className="w-[140px] h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Routing</SelectItem>
            <SelectItem value="pinned">Pinned</SelectItem>
            <SelectItem value="role-based">Role-based</SelectItem>
            <SelectItem value="auto">Auto</SelectItem>
            <SelectItem value="fallback">Fallback</SelectItem>
          </SelectContent>
        </Select>
        <span className="jarvis-mono text-[10px] text-[var(--j-text-mute)] ml-auto">
          {filtered.length} / {assignments.length} agents
        </span>
      </div>

      {/* Agent assignments list */}
      <div className="jarvis-panel p-0 overflow-hidden">
        {loading && assignments.length === 0 ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-12 rounded bg-[var(--j-panel-soft)] jarvis-skeleton" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center">
            <Bot className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm text-[var(--j-text-mute)]">No agents match the current filters.</p>
          </div>
        ) : (
          <div className="max-h-[700px] overflow-y-auto">
            {filtered.map((a, i) => {
              const isOpen = expandedAgent === a.agentCodename;
              const agent = a.agent;
              const providerColor = PROVIDER_COLORS[a.providerKey] ?? JARVIS.colors.cyan;
              const routing = ROUTING_BADGE[a.taskRouting] ?? ROUTING_BADGE.auto;
              const RoutingIcon = routing.icon;
              return (
                <motion.div
                  key={a.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.02, 0.4) }}
                  className="border-b border-[var(--j-border)] last:border-b-0"
                >
                  <div
                    className="flex items-center gap-3 p-3 hover:bg-[var(--j-panel-soft)]/40 cursor-pointer transition-colors"
                    onClick={() => setExpandedAgent(isOpen ? null : a.agentCodename)}
                  >
                    {/* Expand chevron */}
                    {isOpen ? (
                      <ChevronDown className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" />
                    ) : (
                      <ChevronRight className="h-3.5 w-3.5 text-[var(--j-text-mute)] shrink-0" />
                    )}
                    {/* Agent avatar */}
                    <div
                      className="h-8 w-8 rounded-md flex items-center justify-center shrink-0 jarvis-mono text-[10px] font-bold"
                      style={{ background: `${providerColor}1a`, color: providerColor }}
                    >
                      {a.agentCodename.slice(0, 2)}
                    </div>
                    {/* Agent info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-semibold text-sm truncate">{a.agentCodename}</span>
                        {agent && <span className="text-[10px] text-[var(--j-text-mute)] truncate">· {agent.name}</span>}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {agent?.role && <span className="text-[10px] text-[var(--j-text-dim)]">{agent.role}</span>}
                        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider" style={{ color: routing.color, background: `${routing.color}1a` }}>
                          <RoutingIcon className="h-2 w-2 inline mr-0.5" />{routing.label}
                        </span>
                      </div>
                    </div>
                    {/* Model + provider */}
                    <div className="text-right shrink-0 hidden sm:block">
                      <div className="jarvis-mono text-[11px] font-semibold" style={{ color: providerColor }}>{a.modelId}</div>
                      <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] uppercase">{a.providerKey}</div>
                    </div>
                    {/* Status dot */}
                    <div className="shrink-0 flex items-center gap-1.5">
                      {a.enabled ? (
                        <CheckCircle2 className="h-3.5 w-3.5" style={{ color: JARVIS.colors.green }} />
                      ) : (
                        <XCircle className="h-3.5 w-3.5" style={{ color: JARVIS.colors.red }} />
                      )}
                    </div>
                  </div>
                  {/* Expanded detail */}
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-[var(--j-panel-soft)]/30"
                      >
                        <div className="p-3 pl-12 space-y-2">
                          {a.reason && (
                            <div className="flex items-start gap-2">
                              <Sparkles className="h-3 w-3 mt-0.5 shrink-0" style={{ color: JARVIS.colors.violet }} />
                              <span className="text-[11px] text-[var(--j-text-dim)]">{a.reason}</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2 text-[10px] jarvis-mono text-[var(--j-text-mute)]">
                            <span>Priority: {a.priority}</span>
                            <span>·</span>
                            <span>Updated: {timeAgo(new Date(a.updatedAt))}</span>
                            <span>·</span>
                            <span>ID: {a.id.slice(0, 12)}…</span>
                          </div>
                          {/* Pin dialog */}
                          {showPinDialog === a.agentCodename ? (
                            <PinDialog
                              agent={a}
                              models={modelsData?.models ?? []}
                              onPin={(modelId, providerKey) => handlePin(a.agentCodename, modelId, providerKey)}
                              onCancel={() => setShowPinDialog(null)}
                              pinning={pinning === a.agentCodename}
                            />
                          ) : (
                            <div className="flex items-center gap-2 pt-1">
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-[11px] jarvis-btn-accent border-0"
                                onClick={(e) => { e.stopPropagation(); setShowPinDialog(a.agentCodename); }}
                              >
                                <Pin className="h-3 w-3 mr-1" /> Pin to Model
                              </Button>
                              {a.taskRouting === 'pinned' && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 text-[11px] border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-amber)] hover:border-[var(--j-amber)]"
                                  onClick={(e) => { e.stopPropagation(); handleUnpin(a.agentCodename); }}
                                  disabled={pinning === a.agentCodename}
                                >
                                  {pinning === a.agentCodename ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <RotateCcw className="h-3 w-3 mr-1" />}
                                  Unpin (Role-based)
                                </Button>
                              )}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Models available notice */}
      {modelsData && modelsData.models.length === 0 && (
        <div className="jarvis-panel p-3 flex items-center gap-2 border-l-2" style={{ borderColor: JARVIS.colors.amber }}>
          <AlertTriangle className="h-4 w-4 shrink-0" style={{ color: JARVIS.colors.amber }} />
          <div className="text-[11px]">
            <span className="font-semibold" style={{ color: JARVIS.colors.amber }}>No models in the catalog.</span>
            <span className="text-[var(--j-text-dim)]"> All agents default to GLM-4.6 (z-ai). Sync models from the AI Models tab or add provider API keys to enable model diversity.</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────
function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Bot; label: string; value: number; color: string }) {
  return (
    <div className="jarvis-panel p-4 relative overflow-hidden" style={{ background: `linear-gradient(180deg, ${color}08, transparent 60%)` }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${color}55, transparent)` }} />
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4" style={{ color }} />
        <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">{label}</span>
      </div>
      <span className="jarvis-mono text-3xl font-bold tabular-nums" style={{ color }}>{value}</span>
    </div>
  );
}

// ─── Pin Dialog ───────────────────────────────────────────────────────
function PinDialog({
  agent,
  models,
  onPin,
  onCancel,
  pinning,
}: {
  agent: Assignment;
  models: ModelInfo[];
  onPin: (modelId: string, providerKey: string) => void;
  onCancel: () => void;
  pinning: boolean;
}) {
  const [selectedModel, setSelectedModel] = useState(`${agent.modelId}::${agent.providerKey}`);
  const availableModels = models.length > 0
    ? models
    : [
        { modelId: 'glm-4.6', providerKey: 'zai', tier: 'strong', contextWindow: 128000, enabled: true, status: 'active' },
        { modelId: 'claude-3.5-sonnet', providerKey: 'anthropic', tier: 'expert', contextWindow: 200000, enabled: true, status: 'active' },
        { modelId: 'gpt-4o', providerKey: 'openai', tier: 'expert', contextWindow: 128000, enabled: true, status: 'active' },
        { modelId: 'llama-3.3-70b', providerKey: 'groq', tier: 'strong', contextWindow: 128000, enabled: true, status: 'active' },
        { modelId: 'deepseek-r1', providerKey: 'deepseek', tier: 'expert', contextWindow: 128000, enabled: true, status: 'active' },
        { modelId: 'gemini-2.0-flash', providerKey: 'gemini', tier: 'fast', contextWindow: 1000000, enabled: true, status: 'active' },
      ];

  return (
    <div className="mt-2 p-3 rounded-md border border-[var(--j-border)] bg-[var(--j-bg)]" onClick={(e) => e.stopPropagation()}>
      <p className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-mute)] mb-2">
        Pin {agent.agentCodename} to a specific model
      </p>
      <Select value={selectedModel} onValueChange={setSelectedModel}>
        <SelectTrigger className="h-8 text-xs mb-2">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="max-h-60">
          {availableModels.map((m) => (
            <SelectItem key={`${m.modelId}::${m.providerKey}`} value={`${m.modelId}::${m.providerKey}`}>
              <span className="jarvis-mono text-[11px]">{m.modelId}</span>
              <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-2">· {m.providerKey} · {m.tier}</span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          className="h-7 text-[11px] jarvis-btn-accent border-0"
          disabled={pinning}
          onClick={() => {
            const [modelId, providerKey] = selectedModel.split('::');
            onPin(modelId, providerKey);
          }}
        >
          {pinning ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Pin className="h-3 w-3 mr-1" />}
          Confirm Pin
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="h-7 text-[11px] border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)]"
          onClick={onCancel}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
