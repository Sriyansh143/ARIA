'use client';

import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, Activity, Gauge, Wallet, Zap, Target,
  RefreshCw, Loader2, AlertTriangle, CheckCircle2, ChevronDown,
} from 'lucide-react';
import {
  AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid,
  ResponsiveContainer, Tooltip, ReferenceLine,
} from 'recharts';
import { useApi, postJson } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';

// ─── Types ────────────────────────────────────────────────────────────
interface KpiPoint {
  snapshotAt: string;
  value: number;
  target: number;
  status: string;
  autoAdjusted: boolean;
}

interface ForecastPoint {
  generatedAt: string;
  current: number;
  forecast: number;
  confidence: number;
  trend: string;
  riskLevel: string;
  horizon: string;
}

interface KpiHistoryData {
  series: Record<string, KpiPoint[]>;
  count: number;
  kpis: string[];
}

interface ForecastHistoryData {
  series: Record<string, ForecastPoint[]>;
  count: number;
  metrics: string[];
}

interface CurrentKpi {
  kpi: string;
  value: number;
  target: number;
  status: 'nominal' | 'warning' | 'critical' | 'exceeded';
  autoAdjusted: boolean;
  adjustmentNote?: string;
}

const KPI_META: Record<string, { label: string; color: string; icon: typeof Gauge; unit: string; higherIsBetter: boolean }> = {
  health: { label: 'Health Score', color: JARVIS.colors.green, icon: Gauge, unit: '/100', higherIsBetter: true },
  throughput: { label: 'Throughput', color: JARVIS.colors.cyan, icon: Activity, unit: '%', higherIsBetter: true },
  'success-rate': { label: 'Success Rate', color: JARVIS.colors.violet, icon: Target, unit: '%', higherIsBetter: true },
  revenue: { label: 'Revenue', color: JARVIS.colors.green, icon: Wallet, unit: '₹', higherIsBetter: true },
  latency: { label: 'Latency', color: JARVIS.colors.amber, icon: Zap, unit: 'ms', higherIsBetter: false },
};

const FORECAST_META: Record<string, { label: string; color: string; unit: string }> = {
  'fleet-load': { label: 'Fleet Load', color: JARVIS.colors.cyan, unit: '%' },
  'overload-risk': { label: 'Overload Risk', color: JARVIS.colors.red, unit: '' },
  'task-completion': { label: 'Task Completion', color: JARVIS.colors.violet, unit: '%' },
  revenue: { label: 'Revenue Forecast', color: JARVIS.colors.green, unit: '₹' },
  'error-rate': { label: 'Error Rate', color: JARVIS.colors.amber, unit: '%' },
};

const STATUS_COLOR: Record<string, string> = {
  nominal: JARVIS.colors.green,
  warning: JARVIS.colors.amber,
  critical: JARVIS.colors.red,
  exceeded: JARVIS.colors.cyan,
};

function fmtTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
}

export default function KpiTrendsTab() {
  const { toast } = useToast();
  const [selectedKpi, setSelectedKpi] = useState<string>('health');
  const [selectedForecast, setSelectedForecast] = useState<string>('fleet-load');
  const [historyLimit, setHistoryLimit] = useState<number>(48);

  const { data: kpiHistory, loading: kpiLoading, refresh: refreshKpiHistory } = useApi<KpiHistoryData>(`/api/kpis/history?limit=${historyLimit}`, 30000);
  const { data: forecastHistory, loading: forecastLoading, refresh: refreshForecastHistory } = useApi<ForecastHistoryData>(`/api/forecasts/history?limit=${historyLimit}`, 30000);
  const { data: currentKpis } = useApi<{ kpis: CurrentKpi[] }>('/api/kpis', 30000);

  const kpiChart = useMemo(() => {
    const pts = kpiHistory?.series?.[selectedKpi] ?? [];
    return pts.map((p) => ({
      time: fmtTime(p.snapshotAt),
      value: Math.round(p.value),
      target: Math.round(p.target),
      status: p.status,
      autoAdjusted: p.autoAdjusted,
    }));
  }, [kpiHistory, selectedKpi]);

  const forecastChart = useMemo(() => {
    const pts = forecastHistory?.series?.[selectedForecast] ?? [];
    return pts.map((p) => ({
      time: fmtTime(p.generatedAt),
      current: Math.round(p.current),
      forecast: Math.round(p.forecast),
      confidence: Math.round(p.confidence * 100),
      riskLevel: p.riskLevel,
    }));
  }, [forecastHistory, selectedForecast]);

  const handleRegenerate = useCallback(async () => {
    try {
      await postJson('/api/kpis', {});
      toast({ title: 'KPIs re-evaluated', description: 'New snapshot captured' });
      refreshKpiHistory();
    } catch (err) {
      toast({ title: 'Failed', description: err instanceof Error ? err.message : 'error', variant: 'destructive' });
    }
  }, [toast, refreshKpiHistory]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="h-4 w-4" style={{ color: JARVIS.colors.violet }} />
            <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-mute)]">Time-Series Analytics · KPI + Forecast Trends</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            <span className="jarvis-text-gradient">KPI Trends</span>
          </h2>
          <p className="text-xs text-[var(--j-text-dim)] mt-1">
            Historical KPI snapshots + fleet forecast evolution. Spot trends, verify auto-adjustments, track prediction accuracy over time.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* History limit selector */}
          <div className="flex items-center gap-1 h-8 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)]">
            <span className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] mr-1">Points</span>
            {[24, 48, 96, 200].map((n) => (
              <button
                key={n}
                onClick={() => setHistoryLimit(n)}
                className="jarvis-mono text-[10px] px-1.5 py-0.5 rounded transition-colors"
                style={{
                  background: historyLimit === n ? 'rgba(125,211,252,0.15)' : 'transparent',
                  color: historyLimit === n ? JARVIS.colors.cyan : 'var(--j-text-mute)',
                }}
              >
                {n}
              </button>
            ))}
          </div>
          <button
            onClick={handleRegenerate}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-[var(--j-text-dim)] hover:text-[var(--j-violet)] hover:border-[var(--j-violet)] transition-colors text-sm"
          >
            <RefreshCw className={kpiLoading ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'} />
            <span className="jarvis-mono text-[10px] uppercase">New Snapshot</span>
          </button>
        </div>
      </div>

      {/* Current KPI snapshot strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {currentKpis?.kpis?.map((kpi, i) => {
          const meta = KPI_META[kpi.kpi] ?? { label: kpi.kpi, color: JARVIS.colors.cyan, icon: Gauge, unit: '', higherIsBetter: true };
          const color = STATUS_COLOR[kpi.status] ?? JARVIS.colors.cyan;
          const delta = meta.higherIsBetter ? kpi.value - kpi.target : kpi.target - kpi.value;
          const positive = delta >= 0;
          return (
            <motion.button
              key={kpi.kpi}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              onClick={() => setSelectedKpi(kpi.kpi)}
              className="jarvis-panel p-3 text-left relative overflow-hidden transition-all"
              style={{
                background: selectedKpi === kpi.kpi ? `linear-gradient(180deg, ${meta.color}10, transparent 60%)` : undefined,
                borderColor: selectedKpi === kpi.kpi ? `${meta.color}66` : 'var(--j-border)',
                boxShadow: selectedKpi === kpi.kpi ? `0 0 0 1px ${meta.color}33` : undefined,
              }}
            >
              <div className="flex items-center justify-between mb-1.5">
                <meta.icon className="h-3.5 w-3.5" style={{ color: meta.color }} />
                {kpi.autoAdjusted && (
                  <span className="jarvis-mono text-[8px] px-1 py-0.5 rounded font-bold" style={{ color: JARVIS.colors.amber, background: 'rgba(251,191,36,0.12)' }}>AUTO</span>
                )}
              </div>
              <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-0.5">{meta.label}</p>
              <div className="flex items-baseline gap-1 mb-1">
                <span className="jarvis-mono text-lg font-bold tabular-nums" style={{ color }}>
                  {meta.unit === '₹' ? meta.unit : ''}{Math.round(kpi.value).toLocaleString()}{meta.unit !== '₹' && meta.unit !== '/100' ? meta.unit : ''}
                </span>
                <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">/ {meta.unit === '₹' ? '₹' : ''}{Math.round(kpi.target).toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                {positive ? (
                  <TrendingUp className="h-2.5 w-2.5" style={{ color: JARVIS.colors.green }} />
                ) : (
                  <TrendingDown className="h-2.5 w-2.5" style={{ color: JARVIS.colors.red }} />
                )}
                <span className="jarvis-mono text-[9px]" style={{ color: positive ? JARVIS.colors.green : JARVIS.colors.red }}>
                  {positive ? '+' : ''}{Math.round(delta).toLocaleString()}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* KPI History Chart */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Gauge className="h-4 w-4" style={{ color: KPI_META[selectedKpi]?.color ?? JARVIS.colors.cyan }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">
            KPI History · {KPI_META[selectedKpi]?.label ?? selectedKpi}
          </h4>
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-1">
            {kpiChart.length} data points
          </span>
          <div className="flex items-center gap-1 ml-auto flex-wrap">
            {Object.entries(KPI_META).map(([key, meta]) => (
              <button
                key={key}
                onClick={() => setSelectedKpi(key)}
                className="jarvis-mono text-[9px] px-2 py-0.5 rounded-md transition-colors uppercase tracking-wider"
                style={{
                  background: selectedKpi === key ? `${meta.color}1a` : 'var(--j-panel-soft)',
                  color: selectedKpi === key ? meta.color : 'var(--j-text-mute)',
                  border: `1px solid ${selectedKpi === key ? `${meta.color}44` : 'var(--j-border)'}`,
                }}
              >
                {meta.label}
              </button>
            ))}
          </div>
        </div>
        {kpiLoading && kpiChart.length === 0 ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: JARVIS.colors.cyan }} />
          </div>
        ) : kpiChart.length < 2 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center">
            <AlertTriangle className="h-8 w-8 mb-2 opacity-40" style={{ color: JARVIS.colors.amber }} />
            <p className="text-sm text-[var(--j-text-mute)]">Not enough history yet.</p>
            <p className="text-[10px] text-[var(--j-text-mute)] mt-1">Click "New Snapshot" to capture data points. Need at least 2 to chart.</p>
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={kpiChart} margin={{ top: 4, right: 12, left: -8, bottom: 0 }}>
                <defs>
                  <linearGradient id={`kpiGrad-${selectedKpi}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={KPI_META[selectedKpi]?.color ?? JARVIS.colors.cyan} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={KPI_META[selectedKpi]?.color ?? JARVIS.colors.cyan} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} vertical={false} />
                <XAxis dataKey="time" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} minTickGap={32} />
                <YAxis tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(v: number, name: string) => {
                    const meta = KPI_META[selectedKpi];
                    const prefix = meta?.unit === '₹' ? '₹' : '';
                    const suffix = meta?.unit && meta.unit !== '₹' && meta.unit !== '/100' ? meta.unit : '';
                    return [`${prefix}${v}${suffix}`, name === 'value' ? 'Value' : 'Target'];
                  }}
                />
                <ReferenceLine y={kpiChart[kpiChart.length - 1]?.target} stroke={JARVIS.colors.amber} strokeDasharray="4 4" strokeWidth={1} label={{ value: 'Target', fill: JARVIS.colors.amber, fontSize: 10, position: 'right' }} />
                <Area type="monotone" dataKey="value" name="value" stroke={KPI_META[selectedKpi]?.color ?? JARVIS.colors.cyan} strokeWidth={2.5} fill={`url(#kpiGrad-${selectedKpi})`} />
                <Line type="monotone" dataKey="target" name="target" stroke={JARVIS.colors.amber} strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
        {/* Auto-adjustment events */}
        {kpiChart.some((p) => p.autoAdjusted) && (
          <div className="mt-3 pt-3 border-t border-[var(--j-border)]">
            <p className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)] mb-1.5">Auto-Adjustment Events</p>
            <div className="space-y-1">
              {kpiChart.filter((p) => p.autoAdjusted).slice(-5).reverse().map((p, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: JARVIS.colors.amber }} />
                  <span className="jarvis-mono text-[var(--j-text-mute)]">{p.time}</span>
                  <span className="jarvis-mono" style={{ color: JARVIS.colors.amber }}>target → {p.target}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Forecast History Chart */}
      <div className="jarvis-panel p-4">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <TrendingUp className="h-4 w-4" style={{ color: FORECAST_META[selectedForecast]?.color ?? JARVIS.colors.violet }} />
          <h4 className="jarvis-mono text-[11px] uppercase tracking-widest text-[var(--j-text-dim)]">
            Forecast Evolution · {FORECAST_META[selectedForecast]?.label ?? selectedForecast}
          </h4>
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-1">
            {forecastChart.length} data points
          </span>
          <div className="flex items-center gap-1 ml-auto flex-wrap">
            {Object.entries(FORECAST_META).map(([key, meta]) => (
              <button
                key={key}
                onClick={() => setSelectedForecast(key)}
                className="jarvis-mono text-[9px] px-2 py-0.5 rounded-md transition-colors uppercase tracking-wider"
                style={{
                  background: selectedForecast === key ? `${meta.color}1a` : 'var(--j-panel-soft)',
                  color: selectedForecast === key ? meta.color : 'var(--j-text-mute)',
                  border: `1px solid ${selectedForecast === key ? `${meta.color}44` : 'var(--j-border)'}`,
                }}
              >
                {meta.label}
              </button>
            ))}
          </div>
        </div>
        {forecastLoading && forecastChart.length === 0 ? (
          <div className="h-56 flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: JARVIS.colors.violet }} />
          </div>
        ) : forecastChart.length < 2 ? (
          <div className="h-56 flex flex-col items-center justify-center text-center">
            <AlertTriangle className="h-8 w-8 mb-2 opacity-40" style={{ color: JARVIS.colors.amber }} />
            <p className="text-sm text-[var(--j-text-mute)]">Not enough forecast history yet.</p>
            <p className="text-[10px] text-[var(--j-text-mute)] mt-1">Forecasts are generated on each briefing refresh (every 5 min).</p>
          </div>
        ) : (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forecastChart} margin={{ top: 4, right: 12, left: -8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1B2330" strokeOpacity={0.5} vertical={false} />
                <XAxis dataKey="time" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} minTickGap={32} />
                <YAxis tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#0E1218', border: '1px solid #1B2330', borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: '#94A3B8' }}
                />
                <Line type="monotone" dataKey="current" name="Actual" stroke={JARVIS.colors.cyan} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="forecast" name="Forecast" stroke={FORECAST_META[selectedForecast]?.color ?? JARVIS.colors.violet} strokeWidth={2.5} strokeDasharray="5 3" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        {/* Forecast accuracy badge */}
        {forecastChart.length >= 3 && (
          <div className="mt-3 pt-3 border-t border-[var(--j-border)] flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3 w-3" style={{ color: JARVIS.colors.green }} />
              <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">Prediction Accuracy</span>
              {(() => {
                // Compare each forecast to the next actual (current) value.
                const pairs: Array<{ forecast: number; actual: number }> = [];
                for (let i = 0; i < forecastChart.length - 1; i++) {
                  pairs.push({ forecast: forecastChart[i].forecast, actual: forecastChart[i + 1].current });
                }
                const mape = pairs.reduce((s, p) => {
                  const denom = Math.abs(p.actual) || 1;
                  return s + (Math.abs(p.actual - p.forecast) / denom);
                }, 0) / pairs.length;
                const acc = Math.max(0, Math.round((1 - mape) * 100));
                const color = acc >= 80 ? JARVIS.colors.green : acc >= 60 ? JARVIS.colors.amber : JARVIS.colors.red;
                return <span className="jarvis-mono text-sm font-bold tabular-nums" style={{ color }}>{acc}%</span>;
              })()}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-mute)]">Latest Risk</span>
              {(() => {
                const last = forecastChart[forecastChart.length - 1];
                const color = last.riskLevel === 'critical' ? JARVIS.colors.red : last.riskLevel === 'high' ? JARVIS.colors.amber : last.riskLevel === 'medium' ? JARVIS.colors.cyan : JARVIS.colors.green;
                return <span className="jarvis-mono text-[10px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ color, background: `${color}1a` }}>{last.riskLevel}</span>;
              })()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
