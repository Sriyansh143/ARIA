'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Eye, Camera, Upload, Loader2, Send, ImageIcon, Monitor, Radio, Square,
  Play, Pause, Trash2, Activity, Clock, AlertCircle, RefreshCw, ChevronDown,
} from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { SectionTitle, Pill } from '@/components/jarvis/shared';
import { postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';

interface WatchEntry {
  id: string;
  ts: number;
  question: string;
  description: string;
  error?: string;
  latencyMs: number;
}

const WATCH_INTERVALS = [
  { label: '0.5s', value: 500 },
  { label: '1s', value: 1000 },
  { label: '2s', value: 2000 },
  { label: '5s', value: 5000 },
  { label: '10s', value: 10000 },
  { label: '15s', value: 15000 },
  { label: '30s', value: 30000 },
  { label: '60s', value: 60000 },
];

const FOCUS_PRESETS = [
  'Describe what is on screen right now. Identify any UI elements, text, or notable features.',
  'Are there any visible errors, warnings, or broken UI elements on screen? Be specific.',
  'Summarize the current screen activity in one sentence. What is the user doing?',
  'Identify any text on screen that looks like a bug, stack trace, or error message.',
  'What is the main focus of this screen? Suggest one improvement.',
];

export default function ScreenVisionTab() {
  const { toast } = useToast();
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [question, setQuestion] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ── Continuous Watch state ──────────────────────────────────────────────
  const [watching, setWatching] = useState(false);
  const [paused, setPaused] = useState(false);
  const [intervalMs, setIntervalMs] = useState(15000);
  const [focusPrompt, setFocusPrompt] = useState(FOCUS_PRESETS[1]);
  const [watchEntries, setWatchEntries] = useState<WatchEntry[]>([]);
  const [watchCount, setWatchCount] = useState(0);
  const [errorCount, setErrorCount] = useState(0);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const focusPromptRef = useRef(focusPrompt);
  const intervalMsRef = useRef(intervalMs);
  const pausedRef = useRef(paused);

  useEffect(() => { focusPromptRef.current = focusPrompt; }, [focusPrompt]);
  useEffect(() => { intervalMsRef.current = intervalMs; }, [intervalMs]);
  useEffect(() => { pausedRef.current = paused; }, [paused]);

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      setImageBase64(base64);
      setAnalysis(null);
    };
    reader.readAsDataURL(file);
  };

  const captureScreen = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = stream.getVideoTracks()[0];
      await new Promise((resolve) => setTimeout(resolve, 500));
      const canvas = document.createElement('canvas');
      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        setImageBase64(base64);
        setAnalysis(null);
      }
      track.stop();
      stream.getTracks().forEach((t) => t.stop());
    } catch (e) {
      toast({ title: 'Capture failed', description: 'Screen capture permission denied', variant: 'destructive' });
    }
  };

  const analyze = async () => {
    if (!imageBase64) return;
    setAnalyzing(true);
    setAnalysis(null);
    try {
      const res = (await postJson('/api/vision', {
        image: imageBase64,
        question: question || 'Describe what you see in this image. Identify any UI elements, text, layout issues, or notable features.',
      })) as { description?: string; error?: string };
      if (res.error) {
        toast({ title: 'Analysis failed', description: res.error, variant: 'destructive' });
      } else {
        setAnalysis(res.description ?? 'No description returned.');
      }
    } catch (e) {
      toast({ title: 'Analysis failed', description: e instanceof Error ? e.message : '', variant: 'destructive' });
    } finally {
      setAnalyzing(false);
    }
  };

  // ── Continuous Watch: capture a frame from the live stream ──────────────
  const grabFrame = useCallback((): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || !video.videoWidth) return null;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    return dataUrl.split(',')[1];
  }, []);

  const analyzeFrame = useCallback(async (base64: string, q: string) => {
    const start = Date.now();
    try {
      const res = (await postJson('/api/vision', { image: base64, question: q })) as { description?: string; error?: string };
      const entry: WatchEntry = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        ts: Date.now(),
        question: q,
        description: res.error ? '' : (res.description ?? 'No description returned.'),
        error: res.error,
        latencyMs: Date.now() - start,
      };
      setWatchEntries((prev) => [entry, ...prev].slice(0, 30));
      setWatchCount((c) => c + 1);
      if (res.error) setErrorCount((c) => c + 1);
      // Also mirror the latest frame into the one-shot preview + analysis.
      setImageBase64(base64);
      setAnalysis(res.error ? null : entry.description);
    } catch (e) {
      const entry: WatchEntry = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        ts: Date.now(),
        question: q,
        description: '',
        error: e instanceof Error ? e.message : 'Unknown error',
        latencyMs: Date.now() - start,
      };
      setWatchEntries((prev) => [entry, ...prev].slice(0, 30));
      setWatchCount((c) => c + 1);
      setErrorCount((c) => c + 1);
    }
  }, []);

  // The tick: grab a frame + analyze (unless paused).
  const tick = useCallback(async () => {
    if (pausedRef.current) return;
    const frame = grabFrame();
    if (!frame) return;
    await analyzeFrame(frame, focusPromptRef.current || FOCUS_PRESETS[0]);
  }, [grabFrame, analyzeFrame]);

  const startWatching = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 1 } });
      streamRef.current = stream;
      const video = document.createElement('video');
      video.srcObject = stream;
      video.muted = true;
      video.playsInline = true;
      await video.play();
      videoRef.current = video;
      setWatching(true);
      setPaused(false);
      setWatchCount(0);
      setErrorCount(0);
      setWatchEntries([]);
      toast({ title: 'Live screen watch started', description: `Capturing every ${WATCH_INTERVALS.find((i) => i.value === intervalMsRef.current)?.label}. Click the browser’s “Stop sharing” button to end.` });

      // Stop automatically when the user stops sharing via the browser UI.
      stream.getVideoTracks()[0].addEventListener('ended', () => stopWatching());

      // Run an immediate first capture, then start the interval.
      setTimeout(() => { tick(); }, 800);
      intervalRef.current = setInterval(tick, intervalMsRef.current);
    } catch (e) {
      toast({ title: 'Could not start watch', description: 'Screen capture permission denied or unavailable.', variant: 'destructive' });
    }
  };

  const stopWatching = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
      videoRef.current = null;
    }
    setWatching(false);
    setPaused(false);
  }, []);

  // Restart interval when intervalMs changes while watching.
  const changeInterval = (ms: number) => {
    setIntervalMs(ms);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = setInterval(tick, ms);
    }
  };

  useEffect(() => () => stopWatching(), [stopWatching]);

  const successRate = watchCount > 0 ? Math.round(((watchCount - errorCount) / watchCount) * 100) : 100;

  return (
    <div className="space-y-4">
      <SectionTitle
        title="Screen Vision"
        icon={Eye}
        accent={JARVIS.colors.violet}
        action={
          <div className="flex items-center gap-2">
            {watching && <Pill color={paused ? JARVIS.colors.amber : JARVIS.colors.green}><span className="jarvis-blink">●</span> {paused ? 'PAUSED' : 'LIVE'}</Pill>}
            <Pill color={JARVIS.colors.violet}>Gemini-style Watch</Pill>
          </div>
        }
      />

      {/* ── Continuous Watch control bar ──────────────────────────────── */}
      <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)] relative overflow-hidden">
        {watching && (
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, ${paused ? JARVIS.colors.amber : JARVIS.colors.green}, transparent)` }} />
        )}
        <div className="flex items-center gap-2 mb-3">
          <Radio className="h-4 w-4" style={{ color: watching ? (paused ? JARVIS.colors.amber : JARVIS.colors.green) : JARVIS.colors.violet }} />
          <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Continuous Screen Watch</h3>
          <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] ml-1">· like Gemini — ARIA watches your screen and reports what it sees</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mb-3">
          <div>
            <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-1.5 block">Focus Prompt (asked every cycle)</Label>
            <Textarea
              value={focusPrompt}
              onChange={(e) => setFocusPrompt(e.target.value)}
              placeholder="What should ARIA look for on each capture?"
              className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] min-h-[60px] text-xs"
            />
            <div className="flex flex-wrap gap-1 mt-1.5">
              {FOCUS_PRESETS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setFocusPrompt(p)}
                  className="jarvis-mono text-[9px] uppercase px-1.5 py-0.5 rounded border border-[var(--j-border)] text-[var(--j-text-mute)] hover:text-[var(--j-violet)] hover:border-[var(--j-violet)] transition-colors"
                  title={p}
                >
                  {['Describe', 'Errors', 'Summary', 'Bugs', 'Improve'][i]}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)] mb-1.5 block">Capture Interval</Label>
            <div className="flex gap-1 flex-wrap">
              {WATCH_INTERVALS.map((iv) => (
                <button
                  key={iv.value}
                  onClick={() => changeInterval(iv.value)}
                  className={`jarvis-mono text-[10px] uppercase px-2.5 py-1.5 rounded-md border transition-colors ${
                    intervalMs === iv.value
                      ? 'border-[var(--j-violet)] text-[var(--j-violet)] bg-[rgba(167,139,250,0.10)]'
                      : 'border-[var(--j-border)] text-[var(--j-text-mute)] hover:text-[var(--j-text)] hover:border-[var(--j-violet)]/40'
                  }`}
                >
                  {iv.label}
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <div className="rounded-md p-2 bg-[var(--j-panel-soft)] border border-[var(--j-border)]">
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Captures</div>
                <div className="text-base font-bold jarvis-num" style={{ color: JARVIS.colors.cyan }}>{watchCount}</div>
              </div>
              <div className="rounded-md p-2 bg-[var(--j-panel-soft)] border border-[var(--j-border)]">
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">Errors</div>
                <div className="text-base font-bold jarvis-num" style={{ color: JARVIS.colors.red }}>{errorCount}</div>
              </div>
              <div className="rounded-md p-2 bg-[var(--j-panel-soft)] border border-[var(--j-border)]">
                <div className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)]">OK %</div>
                <div className="text-base font-bold jarvis-num" style={{ color: successRate >= 80 ? JARVIS.colors.green : JARVIS.colors.amber }}>{successRate}%</div>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 justify-end">
            {!watching ? (
              <Button onClick={startWatching} className="jarvis-btn-accent border-0 h-10">
                <Radio className="h-4 w-4 mr-1.5" /> Start Live Watch
              </Button>
            ) : (
              <>
                <div className="flex gap-2">
                  <Button
                    onClick={() => setPaused((p) => !p)}
                    variant="outline"
                    className="border-[var(--j-border)] text-[var(--j-text-dim)] flex-1 h-10"
                  >
                    {paused ? <><Play className="h-4 w-4 mr-1.5" /> Resume</> : <><Pause className="h-4 w-4 mr-1.5" /> Pause</>}
                  </Button>
                  <Button onClick={stopWatching} variant="outline" className="border-[var(--j-red)]/40 text-[var(--j-red)] h-10">
                    <Square className="h-4 w-4 mr-1.5" /> Stop
                  </Button>
                </div>
                <Button
                  onClick={() => tick()}
                  variant="ghost"
                  disabled={paused}
                  className="text-[var(--j-text-mute)] hover:text-[var(--j-cyan)] h-8 text-xs"
                >
                  <RefreshCw className="h-3 w-3 mr-1.5" /> Capture Now
                </Button>
              </>
            )}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Image input side */}
        <div className="space-y-3">
          <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
            <div className="flex items-center gap-2 mb-3">
              <Monitor className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
              <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Capture or Upload (one-shot)</h3>
            </div>
            <div className="flex gap-2">
              <Button onClick={captureScreen} className="jarvis-btn-accent border-0 flex-1">
                <Camera className="h-3.5 w-3.5 mr-1.5" /> Capture Screen
              </Button>
              <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="border-[var(--j-border)] text-[var(--j-text-dim)] flex-1">
                <Upload className="h-3.5 w-3.5 mr-1.5" /> Upload Image
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileUpload(file);
                }}
              />
            </div>
          </Card>

          {/* Image preview / live frame */}
          <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]" style={{ minHeight: '300px' }}>
            <div className="flex items-center justify-between mb-2">
              <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">{watching ? 'Live Frame' : 'Preview'}</h3>
              {watching && !paused && <span className="jarvis-mono text-[9px] flex items-center gap-1" style={{ color: JARVIS.colors.green }}><span className="h-1.5 w-1.5 rounded-full jarvis-blink" style={{ background: JARVIS.colors.green }} /> streaming</span>}
            </div>
            {imageBase64 ? (
              <div className="space-y-2">
                <img
                  src={`data:image/jpeg;base64,${imageBase64}`}
                  alt="Captured/Uploaded"
                  className="w-full rounded-lg border border-[var(--j-border)]"
                  style={{ maxHeight: '300px', objectFit: 'contain' }}
                />
                <Button size="sm" variant="ghost" onClick={() => { setImageBase64(null); setAnalysis(null); }} className="text-[var(--j-red)] h-7 text-xs">
                  Remove
                </Button>
              </div>
            ) : (
              <div className="flex items-center justify-center" style={{ minHeight: '250px' }}>
                <div className="text-center">
                  <ImageIcon className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)] opacity-50" />
                  <div className="text-sm text-[var(--j-text-dim)]">No image captured</div>
                  <div className="text-[11px] text-[var(--j-text-mute)] mt-1">Start a live watch, capture your screen, or upload an image</div>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Analysis side */}
        <div className="space-y-3">
          <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
            <div className="flex items-center gap-2 mb-3">
              <Send className="h-4 w-4" style={{ color: JARVIS.colors.green }} />
              <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Ask About the Image</h3>
            </div>
            <div className="space-y-2">
              <Label className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Question (optional · one-shot)</Label>
              <Input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="e.g. What UI elements are visible? Any layout issues?"
                className="bg-[var(--j-panel-soft)] border-[var(--j-border)] text-[var(--j-text)] text-xs h-9"
              />
              <Button
                onClick={analyze}
                disabled={!imageBase64 || analyzing}
                className="jarvis-btn-accent border-0 w-full"
              >
                {analyzing ? (
                  <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Analyzing...</>
                ) : (
                  <><Eye className="h-3.5 w-3.5 mr-1.5" /> Analyze Image</>
                )}
              </Button>
            </div>
          </Card>

          {/* Latest analysis */}
          <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]" style={{ minHeight: watching ? 'auto' : '300px' }}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Latest Vision Analysis</h3>
              {watchEntries[0] && (
                <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] flex items-center gap-1">
                  <Clock className="h-2.5 w-2.5" /> {new Date(watchEntries[0].ts).toLocaleTimeString()}
                </span>
              )}
            </div>
            {analysis ? (
              <motion.div
                key={watchEntries[0]?.id || 'manual'}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-sm text-[var(--j-text-dim)] whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto"
              >
                {analysis}
              </motion.div>
            ) : (
              <div className="flex items-center justify-center" style={{ minHeight: '200px' }}>
                <div className="text-center">
                  <Eye className="h-8 w-8 mx-auto mb-2 text-[var(--j-text-mute)] opacity-50" />
                  <div className="text-sm text-[var(--j-text-dim)]">Analysis will appear here</div>
                  <div className="text-[11px] text-[var(--j-text-mute)] mt-1">Live watch updates this automatically each cycle</div>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>

      {/* ── Watch history (rolling log) ───────────────────────────────── */}
      {watching || watchEntries.length > 0 ? (
        <Card className="p-4 jarvis-panel border-[var(--j-border)] bg-[var(--j-panel)]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
              <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">Watch History</h3>
              <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">· last {watchEntries.length} captures</span>
            </div>
            {watchEntries.length > 0 && (
              <Button size="sm" variant="ghost" onClick={() => { setWatchEntries([]); setWatchCount(0); setErrorCount(0); }} className="text-[var(--j-text-mute)] hover:text-[var(--j-red)] h-7 text-xs">
                <Trash2 className="h-3 w-3 mr-1" /> Clear
              </Button>
            )}
          </div>
          {watchEntries.length === 0 ? (
            <div className="text-center py-8 text-xs text-[var(--j-text-mute)]">
              {watching ? 'Waiting for the first capture…' : 'No captures yet.'}
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              <AnimatePresence initial={false}>
                {watchEntries.map((e) => (
                  <motion.div
                    key={e.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    className="rounded-md border p-3"
                    style={{ borderColor: e.error ? `${JARVIS.colors.red}44` : 'var(--j-border)', background: e.error ? 'rgba(248,113,113,0.04)' : 'var(--j-panel-soft)' }}
                  >
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] flex items-center gap-1">
                        <Clock className="h-2.5 w-2.5" /> {new Date(e.ts).toLocaleTimeString()}
                      </span>
                      {!e.error && <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">· {e.latencyMs}ms</span>}
                      {e.error ? (
                        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded flex items-center gap-1" style={{ color: JARVIS.colors.red, background: 'rgba(248,113,113,0.12)' }}>
                          <AlertCircle className="h-2.5 w-2.5" /> ERROR
                        </span>
                      ) : (
                        <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded" style={{ color: JARVIS.colors.green, background: 'rgba(52,211,153,0.12)' }}>OK</span>
                      )}
                    </div>
                    {e.error ? (
                      <div className="text-xs text-[var(--j-red)]">{e.error}</div>
                    ) : (
                      <div className="text-xs text-[var(--j-text-dim)] leading-relaxed line-clamp-4">{e.description}</div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </Card>
      ) : null}

      {/* hidden canvas used to grab frames from the live stream */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
