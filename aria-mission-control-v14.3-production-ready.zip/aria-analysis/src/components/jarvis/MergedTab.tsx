'use client';

import { useState, type ComponentType } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface SubTabDef {
  key: string;
  label: string;
  icon: LucideIcon;
  Component: ComponentType;
}

interface MergedTabProps {
  subTabs: SubTabDef[];
  defaultKey?: string;
  /** When true, the sub-tab bar collapses into a dropdown (saves vertical space). */
  dropdown?: boolean;
}

/**
 * MergedTab — a container that renders multiple sub-tab components behind a
 * compact switcher. Used to collapse related single-purpose tabs into one
 * sidebar entry (e.g. Chat + App Preview + Screen Vision → "AI Studio").
 *
 * The switcher is a horizontal pill bar on desktop, and collapses into a
 * dropdown on narrow viewports. The active sub-tab persists in component
 * state (resets when the user navigates away — acceptable for this app).
 */
export default function MergedTab({ subTabs, defaultKey, dropdown = false }: MergedTabProps) {
  const [active, setActive] = useState(defaultKey ?? subTabs[0]?.key);
  const [open, setOpen] = useState(false);
  const cur = subTabs.find((s) => s.key === active) ?? subTabs[0];
  if (!cur) return null;
  const Cur = cur.Component;

  if (dropdown) {
    // Dropdown mode — compact, for tabs with many sub-tabs.
    return (
      <div className="space-y-3 h-full flex flex-col">
        <div className="relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="flex items-center gap-2 px-3 py-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] text-sm text-[var(--j-text)] hover:border-[var(--j-cyan)] transition-colors w-full"
          >
            <cur.icon className="h-4 w-4" style={{ color: 'var(--j-cyan)' }} />
            <span className="flex-1 text-left">{cur.label}</span>
            <motion.span animate={{ rotate: open ? 180 : 0 }} className="text-[var(--j-text-mute)]">▾</motion.span>
          </button>
          <AnimatePresence>
            {open && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="absolute top-full left-0 right-0 mt-1 z-40 jarvis-panel p-1 max-h-80 overflow-y-auto jarvis-scroll"
                >
                  {subTabs.map((s) => {
                    const Icon = s.icon;
                    const isActive = s.key === active;
                    return (
                      <button
                        key={s.key}
                        onClick={() => { setActive(s.key); setOpen(false); }}
                        className={cn(
                          'w-full flex items-center gap-2 px-2.5 py-2 rounded text-sm transition-colors text-left',
                          isActive ? 'bg-[var(--j-cyan)]/15 text-[var(--j-cyan)]' : 'text-[var(--j-text-dim)] hover:text-[var(--j-text)] hover:bg-[var(--j-panel-soft)]',
                        )}
                      >
                        <Icon className="h-3.5 w-3.5 shrink-0" />
                        <span className="flex-1">{s.label}</span>
                        {isActive && <span className="h-1.5 w-1.5 rounded-full bg-[var(--j-cyan)]" />}
                      </button>
                    );
                  })}
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
        <div className="flex-1 min-h-0">
          <Cur />
        </div>
      </div>
    );
  }

  // Pill-bar mode (default) — horizontal switcher with scroll overflow.
  // Used for ALL merged tabs now (2-10 sub-tabs). Pills wrap on narrow
  // viewports and scroll horizontally if they overflow.
  return (
    <div className="space-y-3 h-full flex flex-col">
      <div className="flex items-center gap-1.5 flex-wrap border-b border-[var(--j-border)] pb-2 overflow-x-auto jarvis-scroll">
        {subTabs.map((s) => {
          const Icon = s.icon;
          const isActive = s.key === active;
          return (
            <button
              key={s.key}
              onClick={() => setActive(s.key)}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs jarvis-mono uppercase tracking-wider transition-all relative shrink-0',
                isActive
                  ? 'bg-[var(--j-cyan)]/15 text-[var(--j-cyan)] border border-[var(--j-cyan)]/40'
                  : 'text-[var(--j-text-mute)] hover:text-[var(--j-text)] border border-transparent hover:bg-[var(--j-panel-soft)]',
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {s.label}
              {isActive && (
                <motion.div
                  layoutId="merged-tab-active"
                  className="absolute -bottom-[9px] left-1/2 -translate-x-1/2 h-[2px] w-8 rounded-full bg-[var(--j-cyan)]"
                  style={{ boxShadow: '0 0 6px var(--j-cyan)' }}
                />
              )}
            </button>
          );
        })}
      </div>
      <div className="flex-1 min-h-0">
        <Cur />
      </div>
    </div>
  );
}
