'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, Cpu, MemoryStick, Zap, AlertTriangle, Clock, TrendingUp, TrendingDown,
} from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceLine, Area, AreaChart,
} from 'recharts';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, fmtTime } from '@/lib/config';

interface HistoryPoint {
  time: string;
  cpu: number;
  memPct: number;
  disk: number;
  latency: number;
}

interface Summary {
  avgCpu: number;
  maxCpu: number;
  avgMem: number;
  maxMem: number;
  avgLatency: number;
  maxLatency: number;
  alertMinutes: number;
}

interface Thresholds {
  cpuWarn: number;
  cpuCrit: number;
  memWarn: number;
  memCrit: number;
  latWarn: number;
  latCrit: number;
  diskWarn: number;
  diskCrit: number;
}

interface HistoryData {
  points: HistoryPoint[];
  summary: Summary;
  thresholds: Thresholds;
}

const HOUR_OPTIONS = [
  { value: 1, label: '1H' },
  { value: 6, label: '6H' },
  { value: 12, label: '12H' },
  { value: 24, label: '24H' },
];

function fmtAxisTime(iso: string): string {
  const d = new Date(iso);
  return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
}

export default function SystemStatusHistoryChart() {
  const [hours, setHours] = useState(1);
  const { data, loading } = useApi<HistoryData>(`/api/system-history?hours=${hours}&limit=80`, 30000);
  const [metric, setMetric] = useState<'cpu' | 'mem' | 'lat'>('cpu');

  const points = data?.points;
  const chartData = useMemo(() => {
    if (!points) return [];
    return points.map((p) => ({
      time: fmtAxisTime(p.time),
      cpu: p.cpu,
      mem: p.memPct,
      lat: p.latency,
    }));
  }, [points]);

  const s = data?.summary;
  const t = data?.thresholds;

  const metricConfig = {
    cpu: {
      label: 'CPU',
      icon: Cpu,
      color: JARVIS.colors.cyan,
      unit: '%',
      domain: [0, 100] as [number, number],
      warn: t?.cpuWarn ?? 70,
      crit: t?.cpuCrit ?? 85,
      avg: s?.avgCpu ?? 0,
      max: s?.maxCpu ?? 0,
    },
    mem: {
      label: 'Memory',
      icon: MemoryStick,
      color: JARVIS.colors.violet,
      unit: '%',
      domain: [0, 100] as [number, number],
      warn: t?.memWarn ?? 75,
      crit: t?.memCrit ?? 90,
      avg: s?.avgMem ?? 0,
      max: s?.maxMem ?? 0,
    },
    lat: {
      label: 'Latency',
      icon: Zap,
      color: JARVIS.colors.amber,
      unit: 'ms',
      domain: [0, 'auto'] as [number, string],
      warn: t?.latWarn ?? 800,
      crit: t?.latCrit ?? 1500,
      avg: s?.avgLatency ?? 0,
      max: s?.maxLatency ?? 0,
    },
  } as const;

  const cfg = metricConfig[metric];
  const MCIcon = cfg.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="jarvis-panel p-4 relative overflow-hidden"
    >
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ background: `radial-gradient(500px circle at 100% 0%, ${cfg.color}, transparent 60%)` }} />
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4" style={{ color: JARVIS.colors.cyan }} />
            <h3 className="jarvis-mono text-xs uppercase tracking-widest text-[var(--j-text)]">System Status History</h3>
            <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]">· alert frequency over time</span>
          </div>
          {/* Hour selector */}
          <div className="flex items-center gap-1">
            {HOUR_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setHours(opt.value)}
                className={`jarvis-mono text-[9px] uppercase px-2 py-1 rounded-md border transition-colors ${
                  hours === opt.value
                    ? 'border-[var(--j-cyan)] text-[var(--j-cyan)] bg-[rgba(125,211,252,0.10)]'
                    : 'border-[var(--j-border)] text-[var(--j-text-mute)] hover:text-[var(--j-text)]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Metric selector + summary chips */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          {(Object.keys(metricConfig) as Array<keyof typeof metricConfig>).map((key) => {
            const c = metricConfig[key];
            const Icon = c.icon;
            const active = metric === key;
            return (
              <button
                key={key}
                onClick={() => setMetric(key)}
                className={`group flex items-center gap-1.5 h-7 px-2.5 rounded-md border transition-all ${
                  active ? 'border-transparent' : 'border-[var(--j-border)] hover:border-[var(--j-cyan)]/40'
                }`}
                style={active ? { background: `${c.color}1a`, color: c.color, borderColor: `${c.color}44` } : undefined}
              >
                <Icon className="h-3 w-3" />
                <span className="jarvis-mono text-[10px] uppercase tracking-wider font-bold">{c.label}</span>
                <span className="jarvis-mono text-[10px] tabular-nums opacity-80">{c.avg}{c.unit}</span>
              </button>
            );
          })}
          {/* Alert minutes badge */}
          <div className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] ml-auto">
            <AlertTriangle className="h-3 w-3" style={{ color: (s?.alertMinutes ?? 0) > 0 ? JARVIS.colors.amber : JARVIS.colors.green }} />
            <span className="jarvis-mono text-[10px] uppercase text-[var(--j-text-mute)]">Alert min</span>
            <span className="jarvis-mono text-[10px] font-bold tabular-nums" style={{ color: (s?.alertMinutes ?? 0) > 0 ? JARVIS.colors.amber : JARVIS.colors.green }}>
              {s?.alertMinutes ?? 0}
            </span>
          </div>
        </div>

        {/* Chart */}
        {loading && chartData.length === 0 ? (
          <div className="h-56 flex items-center justify-center">
            <div className="text-xs text-[var(--j-text-mute)] jarvis-mono uppercase">Loading telemetry…</div>
          </div>
        ) : chartData.length === 0 ? (
          <div className="h-56 flex flex-col items-center justify-center text-center">
            <Clock className="h-7 w-7 mb-2 text-[var(--j-text-mute)] opacity-40" />
            <div className="text-xs text-[var(--j-text-dim)]">No telemetry data for the last {hours}h</div>
            <div className="jarvis-mono text-[9px] text-[var(--j-text-mute)] mt-1">Telemetry is recorded every 5s — check back shortly</div>
          </div>
        ) : (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id={`grad-${metric}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={cfg.color} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={cfg.color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--j-border-soft)" vertical={false} />
                <XAxis
                  dataKey="time"
                  tick={{ fill: 'var(--j-text-mute)', fontSize: 9 }}
                  axisLine={{ stroke: 'var(--j-border)' }}
                  tickLine={false}
                  minTickGap={32}
                />
                <YAxis
                  domain={cfg.domain}
                  tick={{ fill: 'var(--j-text-mute)', fontSize: 9 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  cursor={{ stroke: cfg.color, strokeWidth: 1, strokeDasharray: '3 3' }}
                  contentStyle={{
                    background: 'var(--j-panel)',
                    border: `1px solid ${cfg.color}44`,
                    borderRadius: 8,
                    fontSize: 11,
                    color: 'var(--j-text)',
                  }}
                  labelStyle={{ color: 'var(--j-text-mute)', fontSize: 10 }}
                  formatter={(value: number) => [`${Math.round(value * 10) / 10}${cfg.unit}`, cfg.label]}
                />
                {/* Warn threshold reference line */}
                <ReferenceLine
                  y={cfg.warn}
                  stroke={JARVIS.colors.amber}
                  strokeDasharray="4 4"
                  strokeOpacity={0.4}
                  label={{ value: `warn ${cfg.warn}`, position: 'right', fill: JARVIS.colors.amber, fontSize: 8 }}
                />
                {/* Crit threshold reference line */}
                <ReferenceLine
                  y={cfg.crit}
                  stroke={JARVIS.colors.red}
                  strokeDasharray="4 4"
                  strokeOpacity={0.4}
                  label={{ value: `crit ${cfg.crit}`, position: 'right', fill: JARVIS.colors.red, fontSize: 8 }}
                />
                <Area
                  type="monotone"
                  dataKey={metric}
                  stroke={cfg.color}
                  strokeWidth={2}
                  fill={`url(#grad-${metric})`}
                  dot={false}
                  activeDot={{ r: 4, fill: cfg.color, stroke: 'var(--j-panel)', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Summary row */}
        {s && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 pt-3 border-t border-[var(--j-border-soft)]">
            <SummaryChip icon={TrendingUp} label={`Avg ${cfg.label}`} value={`${cfg.avg}${cfg.unit}`} color={cfg.color} />
            <SummaryChip icon={TrendingUp} label={`Peak ${cfg.label}`} value={`${cfg.max}${cfg.unit}`} color={cfg.max > cfg.warn ? JARVIS.colors.amber : cfg.color} />
            <SummaryChip icon={AlertTriangle} label="Alert min" value={`${s.alertMinutes}`} color={s.alertMinutes > 0 ? JARVIS.colors.amber : JARVIS.colors.green} />
            <SummaryChip icon={Clock} label="Window" value={`${hours}h`} color={JARVIS.colors.cyan} />
          </div>
        )}
      </div>
    </motion.div>
  );
}

function SummaryChip({ icon: Icon, label, value, color }: { icon: typeof Cpu; label: string; value: string; color: string }) {
  return (
    <div className="flex items-center gap-2 px-2 py-1.5 rounded-md bg-[var(--j-panel-soft)] border border-[var(--j-border-soft)]">
      <Icon className="h-3 w-3 shrink-0" style={{ color }} />
      <div className="min-w-0">
        <div className="jarvis-mono text-[8px] uppercase tracking-wider text-[var(--j-text-mute)] truncate">{label}</div>
        <div className="jarvis-mono text-xs font-bold tabular-nums" style={{ color }}>{value}</div>
      </div>
    </div>
  );
}
