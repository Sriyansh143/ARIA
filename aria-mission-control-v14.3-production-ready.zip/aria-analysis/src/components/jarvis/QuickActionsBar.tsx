'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap, Rocket, Wand2, Network, Database, RefreshCw, Loader2, ChevronUp,
  ChevronDown, X, Activity, GitBranch, Sparkles, Brain,
} from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { postJson } from '@/lib/hooks/use-api';
import { useToast } from '@/hooks/use-toast';

/**
 * Quick Actions floating bar — a globally-accessible one-click command bar
 * pinned to the bottom-center of the viewport (above the footer). Collapsible
 * to a single "ZAP" pill. Each action fires a POST/GET to the relevant API
 * and toasts the result. Stays mounted across tab switches so the operator
 * can run common operations (autonomy cycle, insight, model sync, knowledge
 * sync, telemetry refresh) from anywhere.
 *
 * State (collapsed/expanded + last action timestamp) is persisted to
 * localStorage so it survives remounts.
 */

interface QuickActionDef {
  key: string;
  label: string;
  shortLabel: string;
  icon: typeof Zap;
  accent: string;
  method: 'POST' | 'GET';
  url: string;
  body?: unknown;
  doneMsg: string;
  summarize?: (d: any) => string | undefined;
}

const QUICK_ACTIONS: QuickActionDef[] = [
  {
    key: 'autonomy',
    label: 'Run Autonomy Cycle',
    shortLabel: 'Autonomy',
    icon: Rocket,
    accent: JARVIS.colors.cyan,
    method: 'POST',
    url: '/api/orchestrate/parallel',
    body: { goal: 'advance highest-priority pending work', maxAgents: 3 },
    doneMsg: 'Autonomy cycle dispatched',
    summarize: (d) => (d?.summary ? `${d.summary}`.slice(0, 70) : undefined),
  },
  {
    key: 'insight',
    label: 'Generate AI Insight',
    shortLabel: 'Insight',
    icon: Wand2,
    accent: JARVIS.colors.violet,
    method: 'GET',
    url: '/api/insights',
    doneMsg: 'Fresh insight generated',
  },
  {
    key: 'sync-models',
    label: 'Sync Model Catalog',
    shortLabel: 'Models',
    icon: Network,
    accent: JARVIS.colors.green,
    method: 'POST',
    url: '/api/models/sync',
    doneMsg: 'Model catalog synced',
    summarize: (d) => (typeof d?.summary?.total === 'number' ? `${d.summary.total} models` : undefined),
  },
  {
    key: 'kd-sync',
    label: 'Sync Knowledge Daemon',
    shortLabel: 'Knowledge',
    icon: Database,
    accent: JARVIS.colors.amber,
    method: 'POST',
    url: '/api/knowledge-daemon/sync',
    doneMsg: 'Knowledge daemon synced',
  },
  {
    key: 'briefing',
    label: 'Regenerate Briefing',
    shortLabel: 'Briefing',
    icon: Sparkles,
    accent: JARVIS.colors.green,
    method: 'GET',
    url: '/api/briefing',
    doneMsg: 'Briefing regenerated',
  },
  {
    key: 'health',
    label: 'Run Health Check',
    shortLabel: 'Health',
    icon: Activity,
    accent: JARVIS.colors.cyan,
    method: 'GET',
    url: '/api/health',
    doneMsg: 'Health snapshot refreshed',
  },
];

const COLLAPSED_KEY = 'aria.quickbar.collapsed.v1';
const HISTORY_KEY = 'aria.quickbar.history.v1';

interface HistoryEntry {
  key: string;
  ts: number;
  ok: boolean;
}

function loadHistory(): HistoryEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.slice(0, 8) : [];
  } catch {
    return [];
  }
}

function saveHistory(entries: HistoryEntry[]) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(HISTORY_KEY, JSON.stringify(entries.slice(0, 8)));
  } catch { /* ignore */ }
}

function timeAgoShort(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

export default function QuickActionsBar() {
  const { toast } = useToast();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    try { return window.localStorage.getItem(COLLAPSED_KEY) === '1'; } catch { return false; }
  });
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>(() => loadHistory());
  const [showHistory, setShowHistory] = useState(false);
  const barRef = useRef<HTMLDivElement | null>(null);

  // Persist collapsed state.
  useEffect(() => {
    try { window.localStorage.setItem(COLLAPSED_KEY, collapsed ? '1' : '0'); } catch { /* ignore */ }
  }, [collapsed]);

  const run = useCallback(async (a: QuickActionDef) => {
    setBusyKey(a.key);
    const entry: HistoryEntry = { key: a.key, ts: Date.now(), ok: false };
    try {
      const res = await fetch(a.url, {
        method: a.method,
        headers: a.method === 'POST' ? { 'Content-Type': 'application/json' } : undefined,
        body: a.method === 'POST' ? JSON.stringify(a.body ?? {}) : undefined,
        cache: 'no-store',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      let data: any = null;
      try { data = await res.json(); } catch { /* no body */ }
      const extra = a.summarize?.(data);
      toast({ title: a.doneMsg, description: extra });
      entry.ok = true;
    } catch (e) {
      toast({ title: `${a.shortLabel} failed`, description: e instanceof Error ? e.message : 'Unknown error', variant: 'destructive' });
    } finally {
      setBusyKey(null);
      setHistory((prev) => {
        const next = [entry, ...prev].slice(0, 8);
        saveHistory(next);
        return next;
      });
    }
  }, [toast]);

  // Keyboard shortcut: Alt+Q toggles the bar.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'q' || e.key === 'Q')) {
        e.preventDefault();
        setCollapsed((c) => !c);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div
      ref={barRef}
      className="fixed bottom-12 left-1/2 -translate-x-1/2 z-40 select-none"
      style={{ pointerEvents: 'none' }}
    >
      <motion.div
        initial={false}
        animate={{ y: collapsed ? 0 : 0 }}
        className="jarvis-glass rounded-full border border-[var(--j-border)] shadow-2xl"
        style={{ pointerEvents: 'auto' }}
      >
        <AnimatePresence mode="wait" initial={false}>
          {collapsed ? (
            /* Collapsed pill — pulses subtly to hint at its presence */
            <motion.button
              key="collapsed"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.15 }}
              onClick={() => setCollapsed(false)}
              className="group flex items-center gap-2 h-10 px-4 rounded-full relative"
              title="Expand Quick Actions (Alt+Q)"
            >
              {/* Subtle pulsing glow ring to hint at the bar */}
              <span
                className="absolute inset-0 rounded-full pointer-events-none opacity-40 group-hover:opacity-70 transition-opacity"
                style={{ boxShadow: `0 0 12px ${JARVIS.colors.cyan}30, inset 0 0 8px ${JARVIS.colors.cyan}10` }}
              />
              <Zap className="h-4 w-4 relative z-10 transition-transform group-hover:scale-110" style={{ color: JARVIS.colors.cyan }} />
              <span className="jarvis-mono text-[10px] uppercase tracking-widest text-[var(--j-text-dim)] relative z-10 group-hover:text-[var(--j-text)] transition-colors">Quick</span>
              <span className="jarvis-mono text-[9px] px-1.5 py-0.5 rounded-full relative z-10 transition-transform group-hover:scale-105" style={{ color: JARVIS.colors.cyan, background: 'rgba(125,211,252,0.12)', border: `1px solid ${JARVIS.colors.cyan}30` }}>Alt+Q</span>
            </motion.button>
          ) : (
            /* Expanded bar */
            <motion.div
              key="expanded"
              initial={{ opacity: 0, scale: 0.95, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 8 }}
              transition={{ duration: 0.18 }}
              className="flex items-center gap-1 p-1.5 rounded-full"
            >
              {/* Collapse button */}
              <button
                onClick={() => setCollapsed(true)}
                className="flex items-center justify-center h-8 w-8 rounded-full hover:bg-[var(--j-panel-soft)] transition-colors shrink-0"
                title="Collapse (Alt+Q)"
              >
                <ChevronDown className="h-3.5 w-3.5 text-[var(--j-text-mute)]" />
              </button>

              {/* Action buttons */}
              <div className="flex items-center gap-0.5">
                {QUICK_ACTIONS.map((a, idx) => {
                  const Icon = a.icon;
                  const busy = busyKey === a.key;
                  const lastEntry = history.find((h) => h.key === a.key);
                  const lastFailed = lastEntry && !lastEntry.ok;
                  return (
                    <motion.button
                      key={a.key}
                      onClick={() => run(a)}
                      disabled={busy}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.03 }}
                      className="group relative flex items-center gap-1.5 h-8 px-2.5 rounded-full transition-all disabled:cursor-wait"
                      style={{
                        background: busy ? `${a.accent}15` : undefined,
                        boxShadow: busy ? `0 0 12px ${a.accent}40, inset 0 0 8px ${a.accent}10` : undefined,
                      }}
                      onMouseEnter={(e) => { if (!busy) e.currentTarget.style.background = `${a.accent}12`; }}
                      onMouseLeave={(e) => { if (!busy) e.currentTarget.style.background = ''; }}
                      title={a.label + (lastEntry ? ` · last: ${timeAgoShort(lastEntry.ts)} ${lastEntry.ok ? '✓' : '✗'}` : '')}
                    >
                      {busy ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" style={{ color: a.accent }} />
                      ) : (
                        <Icon className="h-3.5 w-3.5 transition-transform group-hover:scale-125 group-active:scale-95" style={{ color: a.accent, filter: `drop-shadow(0 0 3px ${a.accent}40)` }} />
                      )}
                      <span className="jarvis-mono text-[10px] uppercase tracking-wider text-[var(--j-text-dim)] hidden sm:inline group-hover:text-[var(--j-text)] transition-colors">
                        {a.shortLabel}
                      </span>
                      {/* Status indicator dot — green/amber/red based on last run */}
                      {!busy && lastEntry && (
                        <span
                          className="absolute -top-0.5 -right-0.5 h-1.5 w-1.5 rounded-full"
                          style={{
                            background: lastFailed ? JARVIS.colors.red : JARVIS.colors.green,
                            boxShadow: `0 0 4px ${lastFailed ? JARVIS.colors.red : JARVIS.colors.green}66`,
                          }}
                        />
                      )}
                      {/* Accent dot for actions never run yet */}
                      {!busy && !lastEntry && (
                        <span className="absolute -top-0.5 -right-0.5 h-1 w-1 rounded-full opacity-40" style={{ background: a.accent }} />
                      )}
                      {/* Busy pulse ring */}
                      {busy && (
                        <span
                          className="absolute inset-0 rounded-full pointer-events-none"
                          style={{
                            border: `1px solid ${a.accent}`,
                            animation: 'jarvis-pulse-ring 1.2s ease-out infinite',
                          }}
                        />
                      )}
                      {/* Last-run timestamp tooltip on hover (below button) */}
                      {lastEntry && (
                        <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 jarvis-mono text-[8px] text-[var(--j-text-mute)] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                          {timeAgoShort(lastEntry.ts)} {lastEntry.ok ? '✓' : '✗'}
                        </span>
                      )}
                    </motion.button>
                  );
                })}
              </div>

              {/* Divider */}
              <div className="h-5 w-px bg-[var(--j-border)] mx-0.5 shrink-0" />

              {/* History toggle */}
              <button
                onClick={() => setShowHistory((s) => !s)}
                className="flex items-center justify-center h-8 w-8 rounded-full hover:bg-[var(--j-panel-soft)] transition-colors shrink-0"
                title="Recent actions history"
              >
                <GitBranch className={`h-3.5 w-3.5 ${showHistory ? 'text-[var(--j-cyan)]' : 'text-[var(--j-text-mute)]'}`} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* History popover */}
        <AnimatePresence>
          {showHistory && !collapsed && history.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.96 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 jarvis-glass rounded-lg border border-[var(--j-border)] shadow-2xl p-2"
            >
              <div className="flex items-center gap-1.5 mb-2 px-1">
                <Brain className="h-3 w-3" style={{ color: JARVIS.colors.violet }} />
                <span className="jarvis-mono text-[9px] uppercase tracking-widest text-[var(--j-text-mute)]">Recent Actions</span>
                <button onClick={() => setShowHistory(false)} className="ml-auto text-[var(--j-text-mute)] hover:text-[var(--j-text)]">
                  <X className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {history.map((h, i) => {
                  const a = QUICK_ACTIONS.find((q) => q.key === h.key);
                  if (!a) return null;
                  const Icon = a.icon;
                  return (
                    <div key={i} className="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-[var(--j-panel-soft)] transition-colors">
                      <Icon className="h-3 w-3 shrink-0" style={{ color: a.accent }} />
                      <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] flex-1 truncate">{a.shortLabel}</span>
                      <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)] tabular-nums">{timeAgoShort(h.ts)}</span>
                      <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ background: h.ok ? JARVIS.colors.green : JARVIS.colors.red }} />
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
