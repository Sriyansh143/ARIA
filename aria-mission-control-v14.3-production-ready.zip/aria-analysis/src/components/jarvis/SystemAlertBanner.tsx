'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle, AlertOctagon, X, Cpu, MemoryStick, Zap, Activity, ArrowRight,
} from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { useNavStore } from '@/lib/nav-store';

/**
 * SystemAlertBanner — a dismissible banner that appears at the top of the main
 * content area when any system metric crosses a critical or warning threshold.
 *
 * Metrics monitored (from /api/metrics):
 *   - CPU %: warn ≥ 70, crit ≥ 85
 *   - MEM %: warn ≥ 75, crit ≥ 90
 *   - LAT ms: warn ≥ 800, crit ≥ 1500
 *   - Disk %: warn ≥ 80, crit ≥ 92
 *   - Load avg (1m): warn ≥ 2.0, crit ≥ 3.5
 *
 * The banner shows the highest-severity alert(s). It's dismissible per-session
 * (state in localStorage) and auto-reappears if a NEW critical alert fires.
 * Clicking an alert navigates to the relevant tab (telemetry/health).
 */

export interface MetricsSnapshot {
  cpu: number;
  mem: number;
  memTotal?: number;
  disk?: number;
  diskTotal?: number;
  latency: number;
  loadAvg?: number[];
}

interface AlertDef {
  id: string;
  metric: string;
  label: string;
  value: string;
  severity: 'warn' | 'crit';
  icon: typeof Cpu;
  navigateTab: string;
}

const DISMISS_KEY = 'aria.alertbanner.dismissed.v1';

function buildAlerts(m: MetricsSnapshot | null): AlertDef[] {
  if (!m) return [];
  const alerts: AlertDef[] = [];

  // CPU
  if (m.cpu >= 85) alerts.push({ id: 'cpu', metric: 'CPU', label: 'CPU at critical load', value: `${Math.round(m.cpu)}%`, severity: 'crit', icon: Cpu, navigateTab: 'telemetry' });
  else if (m.cpu >= 70) alerts.push({ id: 'cpu', metric: 'CPU', label: 'CPU under high load', value: `${Math.round(m.cpu)}%`, severity: 'warn', icon: Cpu, navigateTab: 'telemetry' });

  // MEM
  const memPct = m.memTotal ? (m.mem / m.memTotal) * 100 : 0;
  if (memPct >= 90) alerts.push({ id: 'mem', metric: 'MEM', label: 'Memory near saturation', value: `${Math.round(memPct)}%`, severity: 'crit', icon: MemoryStick, navigateTab: 'telemetry' });
  else if (memPct >= 75) alerts.push({ id: 'mem', metric: 'MEM', label: 'Memory usage high', value: `${Math.round(memPct)}%`, severity: 'warn', icon: MemoryStick, navigateTab: 'telemetry' });

  // Latency
  if (m.latency >= 1500) alerts.push({ id: 'lat', metric: 'LAT', label: 'Provider latency critical', value: `${m.latency}ms`, severity: 'crit', icon: Zap, navigateTab: 'providers' });
  else if (m.latency >= 800) alerts.push({ id: 'lat', metric: 'LAT', label: 'Provider latency elevated', value: `${m.latency}ms`, severity: 'warn', icon: Zap, navigateTab: 'providers' });

  // Disk
  if (m.disk != null) {
    if (m.disk >= 92) alerts.push({ id: 'disk', metric: 'DISK', label: 'Disk space critical', value: `${Math.round(m.disk)}%`, severity: 'crit', icon: Activity, navigateTab: 'telemetry' });
    else if (m.disk >= 80) alerts.push({ id: 'disk', metric: 'DISK', label: 'Disk space low', value: `${Math.round(m.disk)}%`, severity: 'warn', icon: Activity, navigateTab: 'telemetry' });
  }

  // Load average (1m)
  const load1 = m.loadAvg?.[0];
  if (load1 != null) {
    if (load1 >= 3.5) alerts.push({ id: 'load', metric: 'LOAD', label: 'System load critical', value: load1.toFixed(2), severity: 'crit', icon: Activity, navigateTab: 'telemetry' });
    else if (load1 >= 2.0) alerts.push({ id: 'load', metric: 'LOAD', label: 'System load elevated', value: load1.toFixed(2), severity: 'warn', icon: Activity, navigateTab: 'telemetry' });
  }

  // Sort: crit first, then warn
  alerts.sort((a, b) => (a.severity === 'crit' ? -1 : 1) - (b.severity === 'crit' ? -1 : 1));
  return alerts;
}

export default function SystemAlertBanner({ metrics }: { metrics: MetricsSnapshot | null }) {
  const navigate = useNavStore((s) => s.navigate);
  const alerts = useMemo(() => buildAlerts(metrics), [metrics]);
  const hasCrit = alerts.some((a) => a.severity === 'crit');
  const [dismissed, setDismissed] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') return new Set();
    try {
      const raw = window.localStorage.getItem(DISMISS_KEY);
      if (!raw) return new Set();
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? new Set(arr) : new Set();
    } catch {
      return new Set();
    }
  });

  // Compute visible alerts from the current alert list + dismissed set.
  // Derived (no setState-in-effect): when an alert is no longer present, its
  // dismissed entry is naturally irrelevant — we prune the dismissed set
  // lazily here so a re-trigger later is possible.
  const activeIds = useMemo(() => new Set(alerts.map((a) => a.id)), [alerts]);
  const effectiveDismissed = useMemo(() => {
    const pruned = new Set<string>();
    for (const id of dismissed) {
      if (activeIds.has(id)) pruned.add(id);
    }
    return pruned;
  }, [dismissed, activeIds]);

  const visibleAlerts = alerts.filter((a) => !effectiveDismissed.has(a.id));

  const dismiss = (id: string) => {
    setDismissed((prev) => {
      const next = new Set(prev).add(id);
      try { window.localStorage.setItem(DISMISS_KEY, JSON.stringify(Array.from(next))); } catch { /* ignore */ }
      return next;
    });
  };

  const dismissAll = () => {
    const ids = alerts.map((a) => a.id);
    setDismissed(new Set(ids));
    try { window.localStorage.setItem(DISMISS_KEY, JSON.stringify(ids)); } catch { /* ignore */ }
  };

  if (visibleAlerts.length === 0) return null;

  const accent = hasCrit ? JARVIS.colors.red : JARVIS.colors.amber;
  const bgGradient = hasCrit
    ? 'linear-gradient(90deg, rgba(248,113,113,0.12), rgba(248,113,113,0.04))'
    : 'linear-gradient(90deg, rgba(251,191,36,0.12), rgba(251,191,36,0.04))';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.2 }}
        className="border-b overflow-hidden"
        style={{ borderColor: `${accent}33`, background: bgGradient }}
      >
        <div className="px-4 lg:px-6 py-2 flex items-center gap-3 flex-wrap">
          {/* Severity icon */}
          <div className="flex items-center gap-2 shrink-0">
            <motion.div
              animate={{ scale: hasCrit ? [1, 1.15, 1] : 1 }}
              transition={{ duration: 1.2, repeat: hasCrit ? Infinity : 0 }}
              className="h-6 w-6 rounded-md flex items-center justify-center"
              style={{ background: `${accent}1a`, color: accent }}
            >
              {hasCrit ? <AlertOctagon className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
            </motion.div>
            <span className="jarvis-mono text-[10px] uppercase tracking-widest font-bold" style={{ color: accent }}>
              {hasCrit ? 'Critical' : 'Warning'}
            </span>
          </div>

          {/* Alert chips */}
          <div className="flex items-center gap-1.5 flex-wrap flex-1 min-w-0">
            {visibleAlerts.map((a) => {
              const Icon = a.icon;
              const aColor = a.severity === 'crit' ? JARVIS.colors.red : JARVIS.colors.amber;
              return (
                <motion.button
                  key={a.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  onClick={() => navigate(a.navigateTab)}
                  className="group flex items-center gap-1.5 h-7 px-2.5 rounded-md border transition-all hover:scale-105"
                  style={{ borderColor: `${aColor}44`, background: `${aColor}10`, color: aColor }}
                  title={`Navigate to ${a.navigateTab}`}
                >
                  <Icon className="h-3 w-3" />
                  <span className="jarvis-mono text-[10px] uppercase tracking-wider font-bold">{a.metric}</span>
                  <span className="jarvis-mono text-[10px] tabular-nums">{a.value}</span>
                  <span className="text-[10px] text-[var(--j-text-dim)] hidden sm:inline group-hover:text-[var(--j-text)] transition-colors">{a.label}</span>
                  <ArrowRight className="h-2.5 w-2.5 opacity-0 group-hover:opacity-60 transition-opacity" />
                </motion.button>
              );
            })}
          </div>

          {/* Dismiss buttons */}
          <div className="flex items-center gap-1 shrink-0">
            {visibleAlerts.length > 1 && (
              <button
                onClick={dismissAll}
                className="jarvis-mono text-[9px] uppercase text-[var(--j-text-mute)] hover:text-[var(--j-text)] px-2 py-1 rounded transition-colors"
                title="Dismiss all alerts"
              >
                Dismiss all
              </button>
            )}
            <button
              onClick={() => visibleAlerts.forEach((a) => dismiss(a.id))}
              className="h-6 w-6 flex items-center justify-center rounded text-[var(--j-text-mute)] hover:text-[var(--j-text)] hover:bg-[var(--j-panel-soft)] transition-colors"
              title="Dismiss"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
