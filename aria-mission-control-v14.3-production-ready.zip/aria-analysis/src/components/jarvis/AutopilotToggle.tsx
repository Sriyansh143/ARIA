'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Rocket, Loader2, Square, Sparkles } from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';

interface TickResult {
  cycle: number;
  decidedGoal: string;
  rationale: string;
  dispatched: boolean;
  runId?: string;
  taskCreated?: string;
  agentsDispatched?: number;
  durationMs: number;
  error?: string;
}

interface AutopilotState {
  active: boolean;
  lastTickAt: number | null;
  lastTickResult: TickResult | null;
  nextTickIn: number; // ms remaining
  currentInterval: number;
  cycleCount: number;
  errorCount: number;
  lastError: string | null;
  startedAt: number;
  schedulerHealthy: boolean;
  inFlight: boolean;
}

interface AutopilotToggleProps {
  /** Called after each successful tick so listeners (e.g. the briefing tab) can refresh. */
  onTick?: () => void;
}

const STATE_POLL_MS = 5000; // poll /api/autopilot/state every 5s — much cheaper than triggering ticks

/**
 * Autopilot — a self-running mode for the autonomous AI company. When ON,
 * ARIA runs a full decide→dispatch cycle every 60s: GLM-4.6 picks the single
 * highest-leverage next action from the live fleet state, then dispatches it to
 * idle agents (or queues it as a task).
 *
 * ── STATE SOURCE-OF-TRUTH ─────────────────────────────────────────────
 * The ON/OFF flag lives on the SERVER (via /api/autopilot/state), NOT in
 * localStorage. This eliminates the per-browser autopilot race that caused
 * the localhost ↔ network-IP briefing desync: every browser now reads the
 * same server-side state, and exactly ONE scheduler loop runs in the server
 * process regardless of how many browsers are open.
 *
 * ── OPTIMISTIC UI ─────────────────────────────────────────────────────
 * The toggle flips instantly on click for snappy UX. If the server POST
 * fails, the toggle rolls back to the previous state and shows a toast.
 */
export default function AutopilotToggle({ onTick }: AutopilotToggleProps) {
  const [state, setState] = useState<AutopilotState | null>(null);
  const [toggling, setToggling] = useState(false);
  const [running, setRunning] = useState(false); // true while a tick is in-flight (from state.inFlight)
  const onTickRef = useRef(onTick);
  onTickRef.current = onTick;
  const { toast } = useToast();

  // Poll the server-side scheduler state. Cheap endpoint — no LLM cost.
  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const poll = async () => {
      if (cancelled) return;
      try {
        const res = await fetch('/api/autopilot/state', { cache: 'no-store' });
        if (res.ok) {
          const data: AutopilotState = await res.json();
          if (cancelled) return;
          // Detect a fresh tick completion → fire onTick callback + toast.
          const prev = stateRef.current;
          if (prev && data.lastTickAt && prev.lastTickAt !== data.lastTickAt) {
            setRunning(false);
            if (data.lastTickResult) {
              onTickRef.current?.();
              toast({
                title: `Autopilot ${data.lastTickResult.dispatched ? 'dispatched' : 'queued'}`,
                description: data.lastTickResult.decidedGoal.slice(0, 90) + (data.lastTickResult.decidedGoal.length > 90 ? '…' : ''),
              });
            }
          }
          setRunning(data.inFlight);
          stateRef.current = data;
          setState(data);
        }
      } catch {
        // Network blip — silently retry on next interval.
      } finally {
        if (!cancelled) {
          timer = setTimeout(poll, STATE_POLL_MS);
        }
      }
    };

    const stateRef: { current: AutopilotState | null } = { current: null };
    poll();

    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [toast]);

  const toggle = useCallback(async () => {
    if (!state || toggling) return;
    const next = !state.active;
    setToggling(true);
    // Optimistic UI — flip immediately for snappy response.
    setState((s) => (s ? { ...s, active: next } : s));
    try {
      const res = await fetch('/api/autopilot/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: next }),
        cache: 'no-store',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: AutopilotState = await res.json();
      setState(data);
      if (next) {
        toast({ title: 'Autopilot engaged', description: 'ARIA will self-run a cycle every 60s.' });
      } else {
        toast({ title: 'Autopilot disengaged' });
      }
    } catch (e) {
      // Rollback the optimistic flip.
      setState((s) => (s ? { ...s, active: !next } : s));
      toast({
        title: 'Failed to toggle autopilot',
        description: e instanceof Error ? e.message : 'unknown error',
        variant: 'destructive',
      });
    } finally {
      setToggling(false);
    }
  }, [state, toggling, toast]);

  const active = state?.active ?? false;
  const schedulerHealthy = state?.schedulerHealthy ?? false;
  const lastTick = state?.lastTickResult ?? null;
  const lastRunAt = state?.lastTickAt ?? null;
  const nextRunIn = state?.nextTickIn ?? 0;
  const currentInterval = state?.currentInterval ?? 60_000;
  const cycleCount = state?.cycleCount ?? 0;
  const errorCount = state?.errorCount ?? 0;

  const accent = active ? JARVIS.colors.green : JARVIS.colors.textMute;
  const secs = Math.ceil(nextRunIn / 1000);

  return (
    <div className="flex items-center gap-2">
      {/* Status popover */}
      <AnimatePresence>
        {active && lastTick && (
          <motion.div
            initial={{ opacity: 0, x: 8, width: 0 }}
            animate={{ opacity: 1, x: 0, width: 'auto' }}
            exit={{ opacity: 0, x: 8, width: 0 }}
            className="hidden lg:flex items-center gap-2 overflow-hidden"
          >
            <div className="flex flex-col items-end leading-none max-w-[260px]">
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-2.5 w-2.5 shrink-0" style={{ color: JARVIS.colors.cyan }} />
                <span className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate" title={lastTick.decidedGoal}>
                  {lastTick.decidedGoal.slice(0, 48)}{lastTick.decidedGoal.length > 48 ? '…' : ''}
                </span>
              </div>
              <span className="jarvis-mono text-[9px] text-[var(--j-text-mute)]" title={`cycles: ${cycleCount}, errors: ${errorCount}${state?.lastError ? `, lastErr: ${state.lastError}` : ''}`}>
                {running ? 'running…' : secs > 0 ? `next in ${secs}s` : 'due'} · {lastTick.dispatched ? `${lastTick.agentsDispatched ?? 0} dispatched` : 'queued'} · {Math.round(currentInterval / 1000)}s cadence
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={toggle}
        disabled={toggling || !schedulerHealthy}
        className="group relative flex items-center gap-1.5 h-8 px-2.5 rounded-md border transition-all overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
        style={{
          borderColor: active ? JARVIS.colors.green : 'var(--j-border)',
          background: active ? 'rgba(52,211,153,0.10)' : 'var(--j-panel-soft)',
          color: active ? JARVIS.colors.green : 'var(--j-text-dim)',
          boxShadow: active ? `0 0 12px ${JARVIS.colors.green}33` : undefined,
        }}
        aria-label={active ? 'Disengage autopilot' : 'Engage autopilot'}
        title={
          !schedulerHealthy
            ? 'Autopilot scheduler not started (server boot incomplete)'
            : active
              ? `Autopilot ON — click to disengage · ${cycleCount} cycles · ${errorCount} errors`
              : 'Engage Autopilot — ARIA self-runs a cycle every 60s'
        }
      >
        {active && (
          <motion.span
            className="absolute inset-0 opacity-40 pointer-events-none"
            style={{ background: `linear-gradient(90deg, transparent, ${JARVIS.colors.green}22, transparent)` }}
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          />
        )}
        {toggling ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin relative z-10" />
        ) : running ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin relative z-10" />
        ) : active ? (
          <Rocket className="h-3.5 w-3.5 relative z-10" />
        ) : (
          <Square className="h-3 w-3 relative z-10" style={{ color: accent }} />
        )}
        <span className="jarvis-mono text-[10px] uppercase tracking-wider relative z-10 whitespace-nowrap">
          {active ? (running ? 'Running' : 'Autopilot') : 'Autopilot'}
        </span>
        {active && (
          <span className="relative z-10 h-1.5 w-1.5 rounded-full jarvis-blink" style={{ background: JARVIS.colors.green, boxShadow: `0 0 6px ${JARVIS.colors.green}` }} />
        )}
      </button>
    </div>
  );
}
