'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, History, X } from 'lucide-react';
import { JARVIS } from '@/lib/config';
import { useNavStore } from '@/lib/nav-store';

/**
 * RecentlyViewedBreadcrumb — a compact breadcrumb trail of recently-visited
 * tabs, shown in the tab header strip. Each chip is clickable to jump back.
 *
 * Tracks the last 5 unique tab navigations in localStorage
 * (`aria.breadcrumb.history.v1`). The current tab is NOT shown (it's the
 * page title already); only previously-visited tabs appear as breadcrumbs.
 *
 * Hidden on small screens (md:flex) to avoid crowding the header.
 */

const HISTORY_KEY = 'aria.breadcrumb.history.v1';
const MAX_ENTRIES = 5;

export interface BreadcrumbEntry {
  key: string;
  label: string;
  accent: string;
  ts: number;
}

// Tab metadata is injected by the parent (avoids circular import of TABS).
export default function RecentlyViewedBreadcrumb({
  currentTab,
  tabMeta,
}: {
  currentTab: string;
  tabMeta: Record<string, { label: string; accent: string }>;
}) {
  const navigate = useNavStore((s) => s.navigate);
  // Lazy-load history from localStorage so there's no set-state-in-effect.
  const [history, setHistory] = useState<BreadcrumbEntry[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) return arr.slice(0, MAX_ENTRIES);
      }
    } catch { /* ignore */ }
    return [];
  });
  // Keep the latest tabMeta in a ref so the tracking effect only depends on
  // currentTab (not the tabMeta object identity, which would re-run + cause
  // an immutability lint warning).
  const tabMetaRef = useRef(tabMeta);
  // Track whether this is the first run (skip the initial mount).
  const firstRunRef = useRef(true);

  // Sync the ref to the latest tabMeta after each render (not during render).
  useEffect(() => {
    tabMetaRef.current = tabMeta;
  }, [tabMeta]);

  // Track navigation: when currentTab changes, prepend it to the history
  // (deduped, max 5). Skip the initial mount (only track actual navigations).
  useEffect(() => {
    if (firstRunRef.current) {
      firstRunRef.current = false;
      return;
    }
    const meta = tabMetaRef.current[currentTab];
    if (!meta) return;
    setHistory((prev) => {
      const filtered = prev.filter((h) => h.key !== currentTab);
      const entry: BreadcrumbEntry = { key: currentTab, label: meta.label, accent: meta.accent, ts: Date.now() };
      const next = [entry, ...filtered].slice(0, MAX_ENTRIES);
      try { localStorage.setItem(HISTORY_KEY, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, [currentTab]);

  // The breadcrumb shows tabs visited BEFORE the current one — i.e. history
  // entries that aren't the current tab. Since we just prepended the current
  // tab, we skip the first entry.
  const crumbs = history.slice(1);

  const clearHistory = () => {
    setHistory([]);
    try { localStorage.removeItem(HISTORY_KEY); } catch { /* ignore */ }
  };

  if (crumbs.length === 0) return null;

  return (
    <div className="hidden md:flex items-center gap-1 min-w-0 flex-1 mx-3 overflow-hidden">
      <History className="h-3 w-3 shrink-0 text-[var(--j-text-mute)]" />
      <AnimatePresence initial={false} mode="popLayout">
        {crumbs.map((c, i) => (
          <motion.div
            key={c.key}
            initial={{ opacity: 0, x: -8, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 8, scale: 0.9 }}
            transition={{ duration: 0.2, delay: i * 0.03 }}
            className="flex items-center gap-1 min-w-0 shrink-0"
          >
            {i > 0 && <ChevronRight className="h-2.5 w-2.5 text-[var(--j-text-mute)] opacity-50 shrink-0" />}
            <button
              onClick={() => navigate(c.key)}
              className="group flex items-center gap-1 h-6 px-2 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] hover:bg-[var(--j-panel)] transition-all shrink-0 max-w-[120px]"
              title={`Back to ${c.label}`}
            >
              <span
                className="h-1.5 w-1.5 rounded-full shrink-0 transition-transform group-hover:scale-125"
                style={{ background: c.accent, boxShadow: `0 0 4px ${c.accent}66` }}
              />
              <span className="jarvis-mono text-[9px] uppercase tracking-wider text-[var(--j-text-dim)] group-hover:text-[var(--j-text)] transition-colors truncate">
                {c.label}
              </span>
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
      {/* Clear button — only shows on hover of the breadcrumb area */}
      <button
        onClick={clearHistory}
        className="shrink-0 h-5 w-5 flex items-center justify-center rounded text-[var(--j-text-mute)] hover:text-[var(--j-red)] opacity-0 hover:opacity-100 transition-opacity"
        title="Clear history"
      >
        <X className="h-2.5 w-2.5" />
      </button>
    </div>
  );
}
