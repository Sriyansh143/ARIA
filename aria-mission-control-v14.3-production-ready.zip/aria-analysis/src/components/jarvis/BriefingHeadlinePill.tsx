'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Satellite } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useApi } from '@/lib/hooks/use-api';
import { JARVIS, timeAgo } from '@/lib/config';
import { useTabNav } from '@/lib/nav-store';

interface BriefingHeadline {
  briefing: {
    headline: string;
    healthScore: number;
    generatedAt: string;
  };
  __meta?: {
    generatedAt: string;
    stateHash: string;
    cacheHit: boolean;
    llmCalled: boolean;
    durationMs: number;
  };
}

/**
 * Compact briefing headline pill for the header. Polls the briefing every 60s
 * AND subscribes to /api/briefing/stream (SSE) for sub-second push updates.
 *
 * The SSE subscription is the primary update channel — whenever the server
 * recomputes the briefing (whether due to a state change, a force=1 request
 * from another client, or the autopilot triggering a refresh), this pill
 * refreshes within milliseconds. The 60s poll is a fallback in case SSE
 * is blocked by a corporate proxy.
 *
 * Because the server caches the briefing for 30s with state-hash + single-
 * flight deduplication, EVERY browser seeing this pill — whether on
 * localhost:3000 or 192.168.0.10:3000 — sees the SAME headline + health
 * score at any given moment.
 */
export default function BriefingHeadlinePill() {
  // 60s poll — SSE is the primary update channel, this is just a safety net.
  const { data, refresh } = useApi<BriefingHeadline>('/api/briefing', 60000);
  const navigate = useTabNav();
  const refreshRef = useRef(refresh);
  refreshRef.current = refresh;
  const [sseConnected, setSseConnected] = useState(false);

  // SSE subscription — push updates whenever the server recomputes the briefing.
  useEffect(() => {
    let es: EventSource | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let closed = false;

    const connect = () => {
      if (closed) return;
      try {
        es = new EventSource('/api/briefing/stream');
        es.addEventListener('open', () => setSseConnected(true));
        es.addEventListener('error', () => {
          setSseConnected(false);
          // SSE connections drop occasionally — auto-reconnect after 5s.
          try { es?.close(); } catch { /* ignore */ }
          es = null;
          if (!closed) {
            reconnectTimer = setTimeout(connect, 5000);
          }
        });
        // Server pushed a briefing:updated event — fetch the fresh payload.
        // (Will be a cache hit, so zero LLM cost.)
        es.addEventListener('briefing:updated', () => {
          refreshRef.current();
        });
        // Operator hit "Regenerate" on another client — refetch.
        es.addEventListener('briefing:invalidated', () => {
          refreshRef.current();
        });
        // Ping — just keep the connection warm.
        es.addEventListener('ping', () => { /* no-op */ });
      } catch {
        // EventSource not supported (very old browser) — fall back to polling only.
      }
    };
    connect();

    return () => {
      closed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      try { es?.close(); } catch { /* ignore */ }
    };
  }, []);

  const b = data?.briefing;
  const health = b?.healthScore ?? 0;
  const color = health >= 85 ? JARVIS.colors.green : health >= 60 ? JARVIS.colors.amber : JARVIS.colors.red;

  return (
    <button
      onClick={() => navigate('briefing', {})}
      className="hidden md:flex items-center gap-2 h-8 px-2.5 rounded-md border border-[var(--j-border)] bg-[var(--j-panel-soft)] hover:border-[var(--j-cyan)]/50 transition-colors max-w-[280px] group"
      title={b ? `ARIA briefing · ${timeAgo(new Date(b.generatedAt))}${sseConnected ? ' · live' : ' · polling'}` : 'Mission Briefing'}
    >
      <Satellite className="h-3.5 w-3.5 shrink-0" style={{ color: sseConnected ? JARVIS.colors.green : JARVIS.colors.textMute }} />
      <AnimatePresence mode="wait">
        <motion.span
          key={b?.headline ?? 'empty'}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.3 }}
          className="jarvis-mono text-[10px] text-[var(--j-text-dim)] truncate group-hover:text-[var(--j-text)]"
        >
          {b?.headline ?? 'Synthesizing briefing…'}
        </motion.span>
      </AnimatePresence>
      {b && (
        <span
          className="shrink-0 jarvis-mono text-[9px] font-bold tabular-nums px-1.5 py-0.5 rounded"
          style={{ color, background: `${color}1a`, border: `1px solid ${color}33` }}
        >
          {health}
        </span>
      )}
      {sseConnected && (
        <span
          className="shrink-0 h-1.5 w-1.5 rounded-full jarvis-blink"
          style={{ background: JARVIS.colors.green, boxShadow: `0 0 6px ${JARVIS.colors.green}` }}
          title="Real-time connection active"
        />
      )}
    </button>
  );
}
