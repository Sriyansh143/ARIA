# CAPABILITIES_INVENTORY.md — ARIA Mission Control

**Version:** v14.1
**Last Updated:** 2026-07-24

> Exhaustive inventory of everything ARIA can actively monitor, automate,
> and execute. Organized by capability category. Every item is verified
> against the source code — no aspirational features.

---

## 1. MONITORING (what ARIA watches)

### 1.1 System Telemetry
- **CPU usage** — real-time via `systeminformation` (`/api/metrics` polls every 8s)
- **Memory usage** — RSS + heap + total (`/api/metrics`)
- **Disk usage** — per-mount + total (`/api/metrics`)
- **Network I/O** — rx + tx bytes/sec (`/api/metrics`)
- **System uptime** — seconds since boot (`/api/metrics`)
- **Load average** — 1/5/15-min averages (`/api/metrics`)
- **Historical series** — last 30 samples in `Telemetry` table (written by health-check cron)

### 1.2 Agent Fleet Monitoring
- **Agent status** — idle|thinking|working|error|offline (per-agent, polled via `/api/agents`)
- **Agent load** — 0-100 per agent (`Agent.load`)
- **Agent success rate** — 0-100 per agent (`Agent.successRate`)
- **Agent task count** — lifetime tasks per agent (`Agent.taskCount`)
- **Agent last-active** — timestamp of last activity (`Agent.lastActive`)
- **Agent heartbeats** — CPU/mem/latency per heartbeat (`AgentHeartbeat` table)
- **Stuck agents** — agents in `working` status for >10min (auto-reset by autonomous-loop)
- **Overloaded agents** — load >70% (flagged in briefing)
- **Error agents** — status=error (flagged in briefing + restart recommendation)

### 1.3 Task Queue Monitoring
- **Pending tasks** — count + list (`Task.status=pending`)
- **In-progress tasks** — count + list (`Task.status=in_progress`)
- **Blocked tasks** — count + list (`Task.status=blocked`)
- **Stale tasks** — in_progress for >10min (auto-reset by autonomous-loop)
- **Task throughput** — tasks completed per hour (computed in analytics)
- **Task backlog** — pending + blocked (flagged in briefing)

### 1.4 Revenue Monitoring
- **Confirmed revenue** — sum of confirmed payments (`Payment.status=confirmed`)
- **Pending revenue** — sum of pending payments (`Payment.status=pending`)
- **Revenue trend** — 30-day time series (`/api/payments/trend`)
- **Revenue forecast** — 7-day forecast (`/api/revenue/dashboard`)
- **Payment gateway status** — Razorpay/Stripe/UPI online indicators (`/api/payments/gateway-status`)

### 1.5 Communication Monitoring
- **Unread inter-agent messages** — count (`AgentMessage.read=false`)
- **Unread notifications** — count (`Notification.read=false`)
- **Critical findings** — count (`AgentMonitorFinding.severity=critical, status=open`)
- **Open approvals** — count (`ApprovalRequest.status=pending`)
- **Approval escalation level** — 1/2/3 (Telegram → Email → Voice)

### 1.6 LLM Provider Monitoring
- **Provider latency** — per-provider, stored in `Provider.latency`
- **Provider token usage** — per-provider, stored in `Provider.tokens`
- **Provider health** — online/offline status (`/api/service-health`)
- **Model catalog** — 464 models across 9 providers (auto-synced by env-watcher)
- **Rate-limit detection** — HTTP 429 triggers 3-retry exponential backoff (3s, 6s, 12s)
- **Fallback chain** — 11 providers tried in order on failure

### 1.7 Predictive Analytics
- **Fleet load forecast** — 1-hour prediction (`FleetForecast` table, 5-min cache)
- **Error rate forecast** — 1-hour prediction with trend direction
- **Revenue forecast** — 7-day prediction with trend direction
- **Confidence scores** — 0-1 per forecast
- **Risk levels** — low/medium/high/critical per forecast

### 1.8 Background Service Monitoring
- **Cron scheduler** — running + last-tick + next-tick (`/api/cron` implicit)
- **Autonomous loop** — running + last-tick (logged to console)
- **Idle-agent dispatcher** — running + dispatching flag (`getDispatcherStatus()`)
- **Autopilot scheduler** — active + lastTickAt + nextTickIn + cycleCount + errorCount + schedulerHealthy + inFlight (`/api/autopilot/state`)
- **Monitoring agents** — 8 monitors with last-run + findings count
- **Env watcher** — running + last change detected
- **DB sync ticker** — DISABLED (Rule 9.1)

### 1.9 Real-time Event Monitoring
- **Agent heartbeats** — `agent:heartbeat` channel
- **Agent status changes** — `agent:status` channel
- **Task updates** — `task:update` channel
- **New decisions** — `decision:new` channel
- **Critical alerts** — `alert:critical` channel
- **Telemetry ticks** — `telemetry:tick` channel
- **Payment updates** — `payment:update` channel
- **Sync status** — `sync:status` channel
- **Briefing updates** — `briefing:updated` event (SSE)
- **Briefing invalidations** — `briefing:invalidated` event (SSE)
- **Autopilot state changes** — `autopilot:state` event

### 1.10 External Service Monitoring
- **Telegram bot** — online/offline (`/api/service-health`)
- **Email SMTP** — connection status
- **FreeSWITCH ESL** — connection status
- **Chatwoot** — connection status
- **Twenty CRM** — connection status
- **Razorpay** — API reachable
- **Stripe** — API reachable
- **Bank portal** — connection status

---

## 2. AUTOMATION (what ARIA does without human intervention)

### 2.1 Autonomous Decision Loop (5-min cycle)
- **Pick pending task** → mark in_progress → run `runAgentLoop` → mark complete
- **Recover stale tasks** — in_progress >10min → reset to pending
- **Reset stuck agents** — working >10min → reset to idle
- **Auto-discover models** — scan agent logs + memory for model mentions → add to catalog
- **Pre-action research** — LLM researches context before executing (with abort capability)
- **Budget guard** — `LLM_DAILY_BUDGET_USD=10.00` gates LLM-consuming tasks
- **Kill-switch** — `autonomous-watchdog.isArmed` blocks ALL autonomy

### 2.2 Autopilot Scheduler (30-300s adaptive cycle)
- **Read fleet state** — agents, tasks, logs
- **GLM-4.6 decides** — picks single highest-leverage next goal
- **Dispatch to orchestrator** — POST `/api/orchestrate/parallel` with 60s timeout
- **Fallback to task queue** — if no idle agents, create a task for later
- **Adaptive cadence** — 30s if dispatched (keep pipeline full), 120s if queued (avoid spam), 120s on error
- **Server singleton** — exactly ONE loop per process (globalThis-mirrored)
- **Persists across restarts** — `MemoryItem` key=`autopilot:state`

### 2.3 Idle-Agent Dispatcher (2-min cycle)
- **Find idle agents** — status=idle AND load<20
- **Find pending tasks** — status=pending, assigneeId=null
- **Create tasks from earning methods** — if idle agents but no pending tasks, auto-create from approved `EarningMethod` rows (24h dedup)
- **Dispatch** — priority-sorted (critical>high>medium>low), assign to idle agents, mark task in_progress, increment agent load
- **Trigger earning research** — if no earning methods exist, POST `/api/earning-methods/research` (throttled to 1/hour)

### 2.4 Cron Scheduler (60s cycle)
- **Run enabled CronJob rows** — checks schedule (cron syntax) + last-run (60s dedup)
- **9 cron jobs seeded:**
  - Monitoring agents (every 10min)
  - Daily research (daily 9am)
  - Session cleanup (hourly)
  - Task reaper (every 30min)
  - Auto-improve (every 2 hours)
  - Auto-audit (every 20min)
  - Health check (every 5min — writes Telemetry row)
  - Knowledge daemon sync (every 30min)
  - CSAT survey scheduler (daily)

### 2.5 Monitoring Agents (10-min cron + startup)
8 monitors run automatically:
- **fleet-watchdog** — watches agent fleet for anomalies
- **api-sentinel** — watches API endpoints for errors/latency
- **health-monitor** — watches system health (CPU/mem/disk)
- **task-watcher** — watches task queue for stuck/blocked tasks
- **comm-watcher** — watches inter-agent comms for unread escalations
- **cron-monitor** — watches cron scheduler for failed jobs
- **payment-monitor** — watches payment gateway for failed payments
- **model-watchdog** — watches model catalog for stale/broken models

Each monitor creates `AgentMonitorFinding` rows for issues detected.

### 2.6 Env Watcher (5-min cycle)
- **Watches `.env`** for provider key changes (file mtime + content hash)
- **Auto-syncs models** — when a new provider key is added, fetches its model list and adds to catalog
- **Resets LLM client** — `resetZaiClient()` when ZAI_API_KEY changes
- **Startup sync** — on server boot, syncs if catalog is empty AND providers are configured

### 2.7 Approval Escalation (30-min cycle)
- **Level 1 (30min)** — Telegram message to owner
- **Level 2 (60min)** — Telegram + Email
- **Level 3 (90min)** — Telegram + Email + Voice call (FreeSWITCH)
- **Auto-expire (24h)** — approval auto-expires if not resolved

### 2.8 Knowledge Daemon (continuous)
- **Ingests knowledge** — from agent logs, comms, completed tasks
- **Deduplicates** — semantic similarity check via vector store
- **Consolidates** — promotes working memory → episodic → semantic
- **Contributes** — operator can manually contribute via `/api/knowledge-daemon/contribute`

### 2.9 Self-Healing Layers
- **Global error handlers** — `unhandledRejection` + `uncaughtException` → log + keep alive
- **Circuit breakers** — per-service (open/half-open/closed states)
- **Error recovery** — retry policies with exponential backoff
- **Rollback system** — reverse destructive actions
- **Git checkpoint** — auto-commit before risky operations
- **Output verification** — verify agent output before commit
- **Pre-action research** — LLM researches before acting (can abort)

### 2.10 Briefing Generation (on-demand + cached)
- **State-hash cache** — skip LLM if state hasn't changed
- **TTL cache (30s)** — all clients within 30s get identical JSON
- **Single-flight** — N concurrent requests share 1 LLM call
- **LLM synthesis** — GLM-4.6 generates headline + summary + recommendations
- **Heuristic fallback** — if LLM fails, deterministic recommendations from metrics
- **Predictive recommendations** — from FleetForecast table
- **SSE push** — `briefing:updated` event to all subscribed clients

### 2.11 Real-time Push
- **SSE endpoint** — `/api/briefing/stream` pushes briefing updates
- **Socket.IO (optional)** — port 3003 for full real-time channel
- **Event bus** — in-process EventEmitter for cross-route signaling
- **State bus** — in-process Map for cross-route state sharing

---

## 3. EXECUTION (what ARIA can do on command or autonomously)

### 3.1 LLM Operations
- **Chat** — multi-turn conversation with GLM-4.6 (`/api/chat`)
- **Quick chat** — one-shot LLM call (`quickChat()` helper)
- **Reasoning** — extended thinking mode (`/api/reasoning`)
- **Prompt enhance** — LLM improves a prompt (`/api/prompt-enhance`)
- **Thinking mode toggle** — global on/off (`/api/thinking-mode`)
- **Multi-agent discussion** — multiple agents discuss a topic (`src/lib/multi-agent-discuss.ts`)
- **Model comparison** — run same prompt across 2-3 models (`/api/compare`)
- **Smart routing** — pick optimal model per task (`/api/smart-router`)

### 3.2 Code Execution
- **Code sandbox** — sandboxed Python/JS execution (`src/lib/code-sandbox.ts`)
- **Code exec API** — `/api/code-exec`
- **Terminal exec** — shell command execution (`/api/terminal/exec`) ⚠️ dev bypass
- **IDE** — in-browser code editor (`IdeTab`)
- **File operations** — read/write/mkdir/delete (`/api/file/*`)

### 3.3 Web Automation
- **Web scraper** — fetch + parse web pages (`src/lib/web-scraper.ts`)
- **Browser agent** — Playwright-based browser automation (`src/lib/browser-agent.ts`)
- **Browser models** — access models via browser login sessions (`/api/models/browser`)
- **Website 3D builder** — generate 3D website layouts (`/api/website-3d/generate`)

### 3.4 Media Generation
- **Image generation** — via Z-AI SDK (`src/lib/image-generator.ts`)
- **Image editing** — modify existing images (`src/lib/image-edit.ts`)
- **Audio generation** — TTS via Sarvam/Z-AI (`src/lib/audio-generator.ts`)
- **Video generation** — via Higgsfield (`src/lib/video-generator.ts`)
- **Vision analysis** — analyze images/screenshots (`/api/vision`)

### 3.5 Orchestration
- **Parallel orchestration** — DAG-based parallel execution (`/api/orchestrate/parallel`)
- **Task decomposition** — LLM decomposes goal into subtasks (`src/lib/task-decomposer.ts`)
- **DAG planning** — LLM generates DAG with dependencies (`src/lib/dag-planner.ts`)
- **Hierarchical orchestration** — manager/worker pattern (`src/lib/hierarchical-orchestrator-v2.ts`)
- **MCTS planning** — Monte Carlo Tree Search for complex decisions (env-configured)

### 3.6 Agent Operations
- **Spawn agent** — clone from template (`/api/agents/spawn`)
- **Assign task** — assign task to agent (`/api/agents/${id}/assign`)
- **Send message** — agent-to-agent comms (`/api/comms`)
- **Backup agents** — export agent config (`/api/agents/backup`)
- **Export agents** — CSV/JSON export (`/api/agents/export`)
- **Terminate spawned** — kill ephemeral agent (`/api/agents/spawn/${id}`)
- **Cleanup expired** — remove expired spawned agents (`/api/agents/spawn/cleanup`)

### 3.7 Task Operations
- **Create task** — manual or from recommendation (`/api/tasks`)
- **Update task** — status, priority, assignee, progress (`/api/tasks/${id}`)
- **Bulk update** — multiple tasks at once (`/api/tasks/bulk`)
- **Reorder tasks** — drag-and-drop in Kanban (`/api/tasks/reorder`)
- **Link tasks** — create dependencies (`/api/tasks/links`)
- **Task graph** — DAG visualization (`/api/tasks/graph`)

### 3.8 Revenue Operations
- **Create payment** — manual entry (`/api/payments`)
- **Create order** — Razorpay/Stripe/UPI checkout (`/api/payments/create-order`)
- **Refund** — process refunds (`/api/refunds`)
- **Payment methods** — add/verify/delete payout methods (`/api/payment-methods`)
- **Webhooks** — Razorpay + Stripe webhook handlers (`/api/payments/webhook/*`)

### 3.9 CRM Operations
- **Clients** — CRUD (`/api/clients`)
- **Leads** — CRUD + convert to client (`/api/leads`)
- **Tickets** — CRUD (`/api/tickets`)
- **CSAT surveys** — schedule + submit (`/api/csat`)

### 3.10 Communication Operations
- **Telegram send** — broadcast to owner (`/api/telegram/send`)
- **Telegram webhook** — receive messages (`/api/telegram/webhook`)
- **Email send** — SMTP (`/api/email/send`)
- **Chatwoot reply** — customer messaging (`/api/comms/reply`)

### 3.11 Memory Operations
- **Memory CRUD** — key-value store (`/api/memory`)
- **Memory graph** — relationship graph (`/api/memory/graph`)
- **Vector search** — embedding similarity (`/api/vector`)
- **Teach from source** — ingest knowledge (`/api/learning/teach`)
- **Auto-categorize** — LLM categorizes learning resources (`/api/learning/auto-categorize`)
- **Auto-move** — progress tracking (`/api/learning/auto-move`)

### 3.12 Skill Operations
- **Skill catalog** — browse 65 skills (`/api/skills`)
- **Skill runner** — execute a skill (`/api/skills` + `/api/agent-exec`)
- **Skill chain** — pipeline of skills (`/api/pipelines`)
- **Skills matrix** — agent×skill coverage (`/api/learning`)
- **Gap analysis** — identify skill gaps (`/api/skills/gap-analysis`)
- **Training schedule** — schedule training (`/api/scheduled-autonomy`)

### 3.13 Model Operations
- **Model catalog** — browse 464 models (`/api/models`)
- **Provider config** — CRUD providers (`/api/providers`)
- **Model sync** — fetch from provider APIs (`/api/models/sync`)
- **Model health check** — ping a model (`/api/models/health-check`)
- **Model purge** — remove stale models (`/api/models/purge`)
- **Browser models** — list browser-accessible models (`/api/models/browser`)
- **Agent-model assignments** — which agent uses which model (`/api/agent-models`)

### 3.14 Governance Operations
- **Approvals** — create/approve/reject (`/api/approvals`)
- **Verifications** — verify output (`/api/verifications`)
- **Change requests** — gated changes (`/api/changes`)
- **Action log** — audit trail (`/api/action-log`)
- **Decision log** — decision history (`/api/decisions`)
- **Rules** — operator-defined constraints (`/api/rules`)

### 3.15 Reporting Operations
- **Daily report** — generated daily (`/api/reports/daily`)
- **Report diffs** — compare two reports (`/api/reports/diff`)
- **Report diffs list** — list of all diffs (`/api/reports/diffs`)
- **Schedule reports** — cron-scheduled (`/api/reports/schedule`)
- **PDF export** — generate PDF (`/api/reports/pdf`)

### 3.16 System Operations
- **Data export** — per-table (`/api/export/${type}`)
- **Data counts** — per-table (`/api/admin/data/counts`)
- **Reset data** — ⚠️ destructive (`/api/admin/reset-data`)
- **DB sync** — manual trigger (`/api/db-sync`)
- **Branding** — white-label config (`/api/branding`)

### 3.17 Planning Operations
- **Goals** — CRUD + hierarchical (`/api/goals`)
- **Strategy** — AI-generated (`/api/strategy`)
- **Strategy proposals** — pending proposals (`/api/strategy/proposals`)
- **Forecasts** — predictive analytics (`/api/forecasts`)
- **Forecast history** — historical accuracy (`/api/forecasts/history`)
- **KPIs** — define + track (`/api/kpis`)
- **KPI history** — historical values (`/api/kpis/history`)
- **Standup** — daily standup summary (`/api/standup`)

### 3.18 File Operations
- **File read** — `/api/file/read`
- **File write** — `/api/file/write`
- **File mkdir** — `/api/file/mkdir`
- **File list** — `/api/file`
- **File upload** — `/api/upload`
- **App tree** — self-introspection (`/api/apptree`)
- **Workspace list** — `/api/workspace/list`

### 3.19 Plugin Operations
- **Plugins** — CRUD (`/api/plugins`)
- **Plugin install** — install external plugin
- **Plugin configure** — update config

### 3.20 Credential Operations
- **Credentials vault** — encrypted storage (`/api/credentials`)
- **Reveal credential** — decrypt + reveal (`/api/credentials/${id}?reveal=1`)
- **Verify credential** — test API key validity

---

## 4. INTELLIGENCE LAYER (Claude-level capabilities)

### 4.1 Reasoning Patterns (10 Claude skills)
1. **Chain-of-Thought** — step-by-step reasoning before answering
2. **Constitutional AI** — self-critique + revision against principles
3. **ReAct pattern** — Reason + Act loop (core agent loop)
4. **Tree-of-Thoughts** — explore multiple reasoning paths
5. **Few-shot learning** — example-based prompting
6. **Step-back prompting** — abstract before solving
7. **Guardrails** — content + action safety checks
8. **Tool use** — function calling (95+ tools available)
9. **Long context** — handles long-context windows
10. **Self-reflection** — post-action reflection + learning

### 4.2 Memory Tiers
- **Working memory** — per-session context
- **Context memory** — per-task context
- **Episodic memory** — event-based long-term
- **Semantic memory** — knowledge graph
- **Agent memory** — per-agent store
- **Memory consolidation** — promotes working → episodic → semantic

### 4.3 Predictive Analytics
- **Fleet load forecast** — 1-hour prediction
- **Error rate forecast** — 1-hour with trend
- **Revenue forecast** — 7-day with trend
- **Confidence scores** — 0-1 per forecast
- **Risk levels** — low/medium/high/critical

### 4.4 Smart Routing
- **Task-type detection** — coding, vision, reasoning, fast chat
- **Cost optimization** — $0 preference
- **Latency optimization** — fastest available
- **Automatic failover** — 11-provider chain
- **Model diversity** — avoid over-reliance on one provider

---

## 5. INTEGRATIONS (external services ARIA connects to)

### 5.1 LLM Providers (11)
Z-AI, Groq, SiliconFlow/Qwen, NVIDIA NIM, Ollama (local), Omniroute, Bytez, HuggingFace, OpenAI, Anthropic, Google Gemini

### 5.2 Payment Gateways
Razorpay (UPI + cards), Stripe (cards), UPI collect (direct)

### 5.3 Communication
Telegram Bot, Email (SMTP + IMAP), FreeSWITCH (voice), Chatwoot (customer messaging)

### 5.4 CRM & Documents
Twenty CRM, DocuSeal (document signing)

### 5.5 Media
Higgsfield (video), ComfyUI (image gen), Sarvam (TTS)

### 5.6 External APIs
Weatherstack (weather), Currencylayer (currency), IPStack (IP geolocation)

### 5.7 SSO / Identity
Azure AD, Okta, Google (all env-configured, currently empty)

### 5.8 Developer Tools
GitHub (native), Git (checkpoint system)

### 5.9 Browser Automation
Playwright (headless browser), Browser models (free-tier harvesting via login sessions)

### 5.10 Voice
FreeSWITCH ESL (voice calls), Dograh (telephony), Sarvam (TTS), Whisper (ASR via z-ai SDK)
