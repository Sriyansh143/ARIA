// Seed the Model catalog with real models from each configured provider.
// The model-sync API tries to call provider APIs (which may be unreachable in
// the sandbox), so this script seeds the catalog directly from a curated list.
import { db } from '../src/lib/db';

interface ModelSeed {
  providerKey: string;
  modelId: string;
  contextWindow: number;
  capabilities: string[];
  tier: string;
  source: string;
  status: string;
  pricingPer1k?: number;
}

const MODELS: ModelSeed[] = [
  // ── z-ai (GLM family — always available) ──
  { providerKey: 'zai', modelId: 'glm-4.6', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'code', 'thinking'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.01 },
  { providerKey: 'zai', modelId: 'glm-4.5-flash', contextWindow: 128000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.005 },
  { providerKey: 'zai', modelId: 'glm-4.5-air', contextWindow: 128000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.002 },
  { providerKey: 'zai', modelId: 'glm-4v', contextWindow: 32000, capabilities: ['chat', 'vision'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0.01 },

  // ── Groq (ultra-fast inference) ──
  { providerKey: 'groq', modelId: 'llama-3.3-70b-versatile', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0006 },
  { providerKey: 'groq', modelId: 'llama-3.1-8b-instant', contextWindow: 128000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0001 },
  { providerKey: 'groq', modelId: 'mixtral-8x7b-32768', contextWindow: 32768, capabilities: ['chat', 'code'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0.0002 },
  { providerKey: 'groq', modelId: 'gemma2-9b-it', contextWindow: 8192, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0001 },

  // ── SiliconFlow / Qwen ──
  { providerKey: 'siliconflow', modelId: 'Qwen/Qwen2.5-7B-Instruct', contextWindow: 32768, capabilities: ['chat', 'code', 'multilingual'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0.0003 },
  { providerKey: 'siliconflow', modelId: 'Qwen/Qwen2.5-72B-Instruct', contextWindow: 32768, capabilities: ['chat', 'reasoning', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.004 },
  { providerKey: 'siliconflow', modelId: 'Qwen/Qwen2.5-Coder-32B-Instruct', contextWindow: 32768, capabilities: ['code', 'chat'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.002 },
  { providerKey: 'siliconflow', modelId: 'deepseek-ai/DeepSeek-V3', contextWindow: 64000, capabilities: ['chat', 'reasoning', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.002 },
  { providerKey: 'siliconflow', modelId: 'deepseek-ai/DeepSeek-R1', contextWindow: 64000, capabilities: ['reasoning', 'research'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.004 },

  // ── NVIDIA NIM ──
  { providerKey: 'nvidia', modelId: 'meta/llama-3.1-70b-instruct', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0008 },
  { providerKey: 'nvidia', modelId: 'meta/llama-3.1-405b-instruct', contextWindow: 128000, capabilities: ['chat', 'reasoning'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.005 },
  { providerKey: 'nvidia', modelId: 'mistralai/mixtral-8x22b-instruct-v0.1', contextWindow: 64000, capabilities: ['chat', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.001 },

  // ── OpenAI (if configured) ──
  { providerKey: 'openai', modelId: 'gpt-4o', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'vision', 'code'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.005 },
  { providerKey: 'openai', modelId: 'gpt-4o-mini', contextWindow: 128000, capabilities: ['chat', 'fast', 'vision'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0.0002 },
  { providerKey: 'openai', modelId: 'o1', contextWindow: 200000, capabilities: ['reasoning', 'math'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.06 },
  { providerKey: 'openai', modelId: 'o3-mini', contextWindow: 200000, capabilities: ['reasoning'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.003 },

  // ── Anthropic (Claude) ──
  { providerKey: 'anthropic', modelId: 'claude-3.5-sonnet', contextWindow: 200000, capabilities: ['chat', 'reasoning', 'code', 'creative', 'vision'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.003 },
  { providerKey: 'anthropic', modelId: 'claude-3-opus', contextWindow: 200000, capabilities: ['chat', 'reasoning', 'creative'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.015 },
  { providerKey: 'anthropic', modelId: 'claude-3-haiku', contextWindow: 200000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.00025 },

  // ── Google Gemini ──
  { providerKey: 'gemini', modelId: 'gemini-2.0-flash-exp', contextWindow: 1000000, capabilities: ['chat', 'fast', 'vision', 'long-context'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0001 },
  { providerKey: 'gemini', modelId: 'gemini-1.5-pro', contextWindow: 2000000, capabilities: ['chat', 'reasoning', 'vision', 'long-context'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.003 },
  { providerKey: 'gemini', modelId: 'gemini-1.5-flash', contextWindow: 1000000, capabilities: ['chat', 'fast', 'vision'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0001 },

  // ── OpenRouter (multi-model gateway) ──
  { providerKey: 'openrouter', modelId: 'openai/gpt-4o-mini', contextWindow: 128000, capabilities: ['chat', 'fast'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0.0002 },
  { providerKey: 'openrouter', modelId: 'anthropic/claude-3.5-sonnet', contextWindow: 200000, capabilities: ['chat', 'reasoning', 'code'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.003 },
  { providerKey: 'openrouter', modelId: 'google/gemini-2.0-flash-exp:free', contextWindow: 1000000, capabilities: ['chat', 'fast', 'long-context'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'openrouter', modelId: 'meta-llama/llama-3.3-70b-instruct', contextWindow: 128000, capabilities: ['chat', 'reasoning'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0008 },

  // ── DeepSeek ──
  { providerKey: 'deepseek', modelId: 'deepseek-chat', contextWindow: 64000, capabilities: ['chat', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.001 },
  { providerKey: 'deepseek', modelId: 'deepseek-coder', contextWindow: 64000, capabilities: ['code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.001 },
  { providerKey: 'deepseek', modelId: 'deepseek-reasoner', contextWindow: 64000, capabilities: ['reasoning', 'research'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.002 },

  // ── Cohere ──
  { providerKey: 'cohere', modelId: 'command-r-plus', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'rag'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.003 },
  { providerKey: 'cohere', modelId: 'command-r', contextWindow: 128000, capabilities: ['chat', 'rag'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0005 },
  { providerKey: 'cohere', modelId: 'command-light', contextWindow: 4096, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0001 },

  // ── Mistral ──
  { providerKey: 'mistral', modelId: 'mistral-large-latest', contextWindow: 128000, capabilities: ['chat', 'reasoning', 'code', 'creative'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0.006 },
  { providerKey: 'mistral', modelId: 'mistral-small-latest', contextWindow: 32000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0.0002 },
  { providerKey: 'mistral', modelId: 'codestral-latest', contextWindow: 32000, capabilities: ['code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.001 },
  { providerKey: 'mistral', modelId: 'mixtral-8x22b', contextWindow: 64000, capabilities: ['chat', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.001 },

  // ── Together AI ──
  { providerKey: 'together', modelId: 'meta-llama/Llama-3.3-70B-Instruct-Turbo', contextWindow: 128000, capabilities: ['chat', 'reasoning'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0009 },
  { providerKey: 'together', modelId: 'Qwen/Qwen2.5-72B-Instruct-Turbo', contextWindow: 32768, capabilities: ['chat', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0.0009 },

  // ── Ollama (local — if running) ──
  { providerKey: 'ollama', modelId: 'qwen2.5:7b', contextWindow: 32768, capabilities: ['chat', 'code'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'ollama', modelId: 'qwen2.5:14b', contextWindow: 32768, capabilities: ['chat', 'reasoning', 'code'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'ollama', modelId: 'qwen2.5:3b', contextWindow: 32768, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'ollama', modelId: 'llama3.2:3b', contextWindow: 128000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
];

async function main() {
  let created = 0;
  let updated = 0;
  for (const m of MODELS) {
    // Check if this model+provider combo already exists
    const existing = await db.model.findFirst({
      where: { modelId: m.modelId, providerKey: m.providerKey },
    });
    if (existing) {
      await db.model.update({
        where: { id: existing.id },
        data: {
          contextWindow: m.contextWindow,
          capabilities: JSON.stringify(m.capabilities),
          tier: m.tier,
          source: m.source,
          status: m.status,
          pricingPer1k: m.pricingPer1k,
        },
      });
      updated++;
    } else {
      await db.model.create({
        data: {
          providerKey: m.providerKey,
          modelId: m.modelId,
          contextWindow: m.contextWindow,
          capabilities: JSON.stringify(m.capabilities),
          tier: m.tier,
          source: m.source,
          status: m.status,
          pricingPer1k: m.pricingPer1k,
        },
      });
      created++;
    }
  }

  // Count by provider
  const byProvider = await db.model.groupBy({ by: ['providerKey'], _count: true });
  console.log(`Models seeded: ${created} created, ${updated} updated, ${MODELS.length} total`);
  console.log('By provider:');
  for (const p of byProvider) {
    console.log(`  ${p.providerKey}: ${p._count}`);
  }
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });

// ── Browser-playground providers as API-accessible models ──
// These are cloud-hosted models accessible via browser playgrounds that
// also have API access (with rate limits). Added so the smart-router
// can route to them for faster responses.
const BROWSER_API_MODELS: ModelSeed[] = [
  // Hugging Face Inference API (free tier, rate-limited)
  { providerKey: 'huggingface', modelId: 'meta-llama/Meta-Llama-3-8B-Instruct', contextWindow: 8192, capabilities: ['chat', 'fast'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'huggingface', modelId: 'mistralai/Mistral-7B-Instruct-v0.3', contextWindow: 32768, capabilities: ['chat', 'code'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'huggingface', modelId: 'google/gemma-2-9b-it', contextWindow: 8192, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'huggingface', modelId: 'microsoft/Phi-3-mini-4k-instruct', contextWindow: 4096, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'huggingface', modelId: 'Qwen/Qwen2.5-VL-7B-Instruct', contextWindow: 32768, capabilities: ['vision', 'chat'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0 },

  // Google AI Studio (free tier — Gemini models)
  { providerKey: 'gemini', modelId: 'gemini-1.5-pro', contextWindow: 2000000, capabilities: ['chat', 'reasoning', 'vision', 'long-context'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'gemini', modelId: 'gemini-1.5-flash', contextWindow: 1000000, capabilities: ['chat', 'fast', 'vision'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'gemini', modelId: 'gemini-2.0-flash-exp', contextWindow: 1000000, capabilities: ['chat', 'fast', 'vision'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },

  // DuckDuckGo AI Chat (free, anonymous, rate-limited)
  { providerKey: 'duckduckgo', modelId: 'llama-3.1-70b-instant', contextWindow: 32000, capabilities: ['chat', 'fast', 'anonymous'], tier: 'strong', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'duckduckgo', modelId: 'gpt-4o-mini', contextWindow: 32000, capabilities: ['chat', 'fast'], tier: 'medium', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'duckduckgo', modelId: 'claude-3-haiku', contextWindow: 32000, capabilities: ['chat', 'fast'], tier: 'fast', source: 'seed', status: 'active', pricingPer1k: 0 },

  // LMSYS (free, rate-limited, best for model comparison)
  { providerKey: 'lmsys', modelId: 'arena-gpt-4o', contextWindow: 128000, capabilities: ['chat', 'reasoning'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'lmsys', modelId: 'arena-claude-3.5-sonnet', contextWindow: 200000, capabilities: ['chat', 'reasoning', 'code'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0 },
  { providerKey: 'lmsys', modelId: 'arena-gemini-1.5-pro', contextWindow: 2000000, capabilities: ['chat', 'reasoning', 'long-context'], tier: 'expert', source: 'seed', status: 'active', pricingPer1k: 0 },
];

// Merge browser API models into the main list
MODELS.push(...BROWSER_API_MODELS);
