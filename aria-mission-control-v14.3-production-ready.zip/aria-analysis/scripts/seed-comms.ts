// Seed sample AgentMessage rows for the collaboration graph.
import { db } from '../src/lib/db';

const AGENTS = [
  'ORION', 'VEGA', 'ATLAS', 'NOVA', 'ECHO', 'SAGE', 'PULSE', 'FORGE',
  'LYRA', 'CASTOR', 'POLLUX', 'SIRIUS', 'RIGEL', 'ALTAIR', 'DENEB',
];
const SUBJECTS = [
  'Task handoff: research complete',
  'Status update: deployment ready',
  'Escalation: error detected',
  'Request: code review needed',
  'Briefing: weekly sync',
  'Alert: load threshold exceeded',
  'Handoff: client follow-up',
  'Collaboration: skill sharing',
  'Question: API integration',
  'Report: telemetry summary',
];
const BODIES = [
  'Sending the latest findings for your review.',
  'Ready for the next phase whenever you are.',
  'Need your eyes on this before we proceed.',
  'Heads up — this needs immediate attention.',
  'FYI: summarizing the current state for the team.',
];
const THREADS = ['ops', 'engineering', 'research', 'comms', 'billing'];
const PRIORITIES = ['normal', 'normal', 'normal', 'high', 'urgent'];

async function main() {
  let count = 0;
  const now = Date.now();
  for (let i = 0; i < 80; i++) {
    const from = AGENTS[Math.floor(Math.random() * AGENTS.length)];
    let to: string;
    if (Math.random() < 0.15) {
      to = 'BROADCAST';
    } else {
      do {
        to = AGENTS[Math.floor(Math.random() * AGENTS.length)];
      } while (to === from);
    }
    const subject = SUBJECTS[Math.floor(Math.random() * SUBJECTS.length)];
    const body = BODIES[Math.floor(Math.random() * BODIES.length)];
    const priority = PRIORITIES[Math.floor(Math.random() * PRIORITIES.length)];
    const thread = THREADS[Math.floor(Math.random() * THREADS.length)];
    const ago = Math.floor(Math.random() * 3600); // up to 1h ago
    await db.agentMessage.create({
      data: {
        fromAgent: from,
        toAgent: to,
        subject,
        body,
        priority,
        thread,
        read: Math.random() > 0.3,
        createdAt: new Date(now - ago * 1000),
      },
    });
    count++;
  }
  console.log(`Seeded ${count} inter-agent messages`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
