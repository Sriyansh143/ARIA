// Seed all 73 rules into the Rule table so they're surfaced in the app.
import { db } from '../src/lib/db';

interface RuleDef {
  key: string;
  title: string;
  description: string;
  category: string;
  priority: string;
}

const RULES: RuleDef[] = [
  // Section 1: Worklog Rules
  { key: 'worklog-never-remove', title: '1.1 NEVER Remove Worklog Lines', description: 'The worklog at /home/z/my-project/worklog.md is APPEND-ONLY. Never delete, overwrite, or truncate existing lines. Only append new entries using the --- separator + Task ID format.', category: 'worklog', priority: 'critical' },
  { key: 'worklog-always-update', title: '1.2 Always Update Worklog Every Run', description: 'Every run (manual or cron) MUST append a worklog entry. Every user prompt MUST result in a worklog update.', category: 'worklog', priority: 'critical' },
  { key: 'worklog-show-pending', title: '1.3 Show Pending Works Every Run', description: 'At the start of every run, read the worklog and identify pending/unfinished work from previous runs. Continue or complete them before starting new work.', category: 'worklog', priority: 'high' },
  // Section 2: File Safety
  { key: 'file-never-reset', title: '2.1 NEVER Reset or Delete Important Files', description: 'Never reset, delete, or truncate: worklog.md, RULES.md, .env, prisma/schema.prisma, db/custom.db, package.json, bun.lock. These are permanent.', category: 'file-safety', priority: 'critical' },
  { key: 'file-code-once-fixed', title: '2.2 Code Once Fixed Should Not Be Disturbed', description: 'If a bug was fixed and the fix is working, do NOT refactor or rewrite that code in a later run unless it breaks. Leave working code alone.', category: 'file-safety', priority: 'high' },
  { key: 'file-use-available', title: '2.3 Use Available Codes from Repos and Zip', description: 'Before writing new code, check if the functionality already exists in the codebase, the uploaded zip files, or open-source repos. Reuse first.', category: 'file-safety', priority: 'medium' },
  // Section 3: Agent Coordination
  { key: 'coord-plan-first', title: '3.1 Multiple Agents Must Plan Before Working', description: 'When multiple subagents work in parallel, they MUST read the worklog first, agree on file boundaries, and never touch the same file.', category: 'coordination', priority: 'high' },
  { key: 'coord-no-conflict', title: '3.2 Never Conflict with Other Agents Work', description: 'Each agent owns its files. If agent A is editing foo.ts, agent B must not edit foo.ts. Coordinate via the worklog.', category: 'coordination', priority: 'high' },
  { key: 'coord-never-break', title: '3.3 Never Break the App', description: 'Every change must keep the app compiling + serving HTTP 200. If a change breaks /, revert it immediately.', category: 'coordination', priority: 'critical' },
  // Section 4: UI/UX
  { key: 'ui-no-tabs-for-everything', title: '4.1 Don\'t Add Tabs for Everything', description: 'Don\'t create a new sidebar tab for every minor feature. Merge related features into existing tabs via sub-tabs or panels.', category: 'ui', priority: 'medium' },
  { key: 'ui-visualize', title: '4.2 Always Visualise with Graphs + Text', description: 'Prefer charts (recharts) over raw text tables. Every data-heavy panel should have at least one visualisation.', category: 'ui', priority: 'medium' },
  { key: 'ui-remove-static-labels', title: '4.3 Remove Static Model Text Labels', description: 'Don\'t hardcode model names like "GLM-4.6" as static text. Fetch from the DB/API so the UI stays accurate when models change.', category: 'ui', priority: 'low' },
  { key: 'ui-responsive', title: '4.4 Responsive Design', description: 'All layouts must be responsive: mobile-first, with sm:/md:/lg:/xl: breakpoints. Touch targets ≥44px.', category: 'ui', priority: 'high' },
  { key: 'ui-sticky-footer', title: '4.5 Sticky Footer', description: 'Footer must stick to the bottom when content is short, and push down naturally when content overflows. Use min-h-screen flex flex-col + mt-auto.', category: 'ui', priority: 'medium' },
  // Section 5: Learning
  { key: 'learn-any-section', title: '5.1 Learning Can Be Saved in Any Section', description: 'Agents can save learnings to Memory, Skills, Knowledge Daemon, or Rules — whichever fits. Don\'t force a single store.', category: 'learning', priority: 'low' },
  { key: 'learn-auto-move', title: '5.2 Auto-Move if Wrong Section', description: 'If a learning is saved in the wrong section, the knowledge daemon auto-moves it to the correct one.', category: 'learning', priority: 'low' },
  { key: 'learn-check-repos', title: '5.3 Always Check Open-Source Repos', description: 'Before building a feature, check if an open-source library or existing skill already does it. Reuse over reinvent.', category: 'learning', priority: 'medium' },
  // Section 6: Operational
  { key: 'ops-complete-pending', title: '6.1 Complete Pending Works Every Run', description: 'Every run must check for pending tasks/works from previous runs and complete or advance them before starting new work.', category: 'operational', priority: 'high' },
  { key: 'ops-daily-research', title: '6.2 Daily Research for New Earning Methods', description: 'The earning-research engine runs daily to discover new monetization methods. Results are saved to EarningMethod table.', category: 'operational', priority: 'high' },
  { key: 'ops-env-api-keys', title: '6.3 All Models Work via Env API Keys', description: 'All LLM providers are configured via .env API keys. No hardcoded keys. The multi-provider fallback chain tries each in order.', category: 'operational', priority: 'high' },
  { key: 'ops-no-investment', title: '6.4 Non-Investment Only', description: 'ARIA only pursues earning methods that require zero upfront investment. No paid tools, no capital expenditure.', category: 'operational', priority: 'medium' },
  // Section 7: Branding
  { key: 'branding-configurable', title: '7.1 Branding Configurable from UI', description: 'App name, version, powered-by, footer note are configurable from the Branding tab (stored in Memory, not hardcoded).', category: 'branding', priority: 'low' },
  { key: 'branding-default', title: '7.2 Default Branding', description: 'Default: appName=JARVIS, company=Liafon Software Private Limited. The branding API returns these if no config is set.', category: 'branding', priority: 'low' },
  // Section 8: Agent Spawning
  { key: 'spawn-heavy-load', title: '8.1 Heavy-Load Agents Can Spawn Sub-Agents', description: 'Agents above 70% load can spawn temporary sub-agents (30-day retention) to distribute work. Spawned agents inherit skills + model.', category: 'spawning', priority: 'medium' },
  { key: 'spawn-64-roster', title: '8.2 64-Agent Roster', description: 'The base fleet is 64 agents across 8 departments. Each has a codename, role, skills, and a model assignment.', category: 'spawning', priority: 'medium' },
  // Section 9: Cron
  { key: 'cron-29-jobs', title: '9.1 29 Cron Jobs', description: '29 cron jobs are seeded: autopilot, briefings, standups, telemetry, earning-research, knowledge-sync, model-sync, etc. Managed via the Scheduler tab.', category: 'cron', priority: 'medium' },
  { key: 'cron-webdevreview', title: '9.2 WebDevReview Cron', description: 'A 15-minute webDevReview cron job runs agent-browser QA, fixes bugs, and adds features autonomously. Logs to worklog.md.', category: 'cron', priority: 'high' },
  // Section 10: Zip
  { key: 'zip-package-parts', title: '10.1 Package in Parts', description: 'When packaging the app for download, split into parts if >100MB. The download/ folder holds the consolidated zip.', category: 'packaging', priority: 'low' },
  // Rules 33-73 (Autonomous AI Company v10+)
  { key: 'r33-persistence', title: 'Rule 33: PERSISTENCE — Never Lose Files to Session End', description: 'The Kata container kills background processes when the bash session ends. Use a double-fork daemon (setsid) to keep the dev server alive across calls.', category: 'persistence', priority: 'critical' },
  { key: 'r34-real-execution', title: 'Rule 34: REAL EXECUTION — No Simulated Actions', description: 'Never simulate API calls, code execution, or deployments. Every action must hit a real endpoint and return a real result.', category: 'execution', priority: 'critical' },
  { key: 'r35-smart-model', title: 'Rule 35: SMART MODEL SELECTION — Best Model Per Task', description: 'The smart-model-router selects the optimal model per task type (code, vision, reasoning, etc.) from the 455-model catalog.', category: 'intelligence', priority: 'high' },
  { key: 'r36-no-assumption', title: 'Rule 36: NO-ASSUMPTION — Verify Before Trusting', description: 'Never assume a feature works. Verify via agent-browser or API call. The Verification system records evidence for every claim.', category: 'verification', priority: 'high' },
  { key: 'r37-app-change-gate', title: 'Rule 37: APP-CHANGE APPROVAL GATE', description: 'Major app changes require a ChangeRequest + ApprovalRequest before deployment. The change-gate system enforces this.', category: 'governance', priority: 'high' },
  { key: 'r38-reversible', title: 'Rule 38: REVERSIBLE ACTIONS', description: 'Every mutating action is logged with before/after state in ActionLog so it can be reversed. The reverseAction() function restores the prior state.', category: 'governance', priority: 'high' },
  { key: 'r39-escalation', title: 'Rule 39: APPROVAL ESCALATION', description: 'Pending approvals escalate over time (level 0→1→2→3) if not decided. The escalation engine auto-raises the level + notifies.', category: 'governance', priority: 'medium' },
  { key: 'r40-pre-action', title: 'Rule 40: AGENT PRE-ACTION RESEARCH', description: 'Before executing a risky action, agents run a pre-action research step (proceed/caution/abort) via the LLM. Logged for audit.', category: 'intelligence', priority: 'medium' },
  { key: 'r41-monitoring-feed', title: 'Rule 41: MONITORING AGENT DATA FEED', description: 'Monitoring agents (fleet-watchdog, api-sentinel, etc.) continuously feed findings to the AgentMonitorFinding table for the UI.', category: 'monitoring', priority: 'high' },
  { key: 'r42-pro-scaffold', title: 'Rule 42: PRO-LEVEL PROMPT ENHANCEMENT', description: 'Every chat call is wrapped with a pro-scaffold (task-type-specific guidance) that elevates the response quality. Mandatory.', category: 'intelligence', priority: 'medium' },
  { key: 'r43-code-sandbox', title: 'Rule 43: CODE EXECUTION SANDBOX', description: 'Python/JS/TS code blocks in chat responses are executed in a sandboxed subprocess (10s timeout, no network). Results appended to the response.', category: 'execution', priority: 'high' },
  { key: 'r44-ui-intelligence', title: 'Rule 44: UI/UX INTELLIGENCE', description: 'The UI must be intelligent: adaptive polling (slower when CPU high), skeleton loaders, toast feedback, keyboard shortcuts, command palette.', category: 'ui', priority: 'medium' },
  { key: 'r45-the-goal', title: 'Rule 45: THE GOAL — Beat Claude, Gemini, z.ai as Autonomous AI Company', description: 'ARIA\'s goal is to be a fully autonomous AI company that outperforms Claude/Gemini/z.ai at multi-agent orchestration + revenue generation.', category: 'strategy', priority: 'critical' },
  { key: 'r46-ponytail', title: 'Rule 46: PONYTAIL PRINCIPLE — The Best Code Is the Code You Never Wrote', description: 'Before writing new code, exhaustively search for existing implementations. Reuse > refactor > rewrite. Less code = fewer bugs.', category: 'strategy', priority: 'medium' },
  { key: 'r47-no-duplicate-tabs', title: 'Rule 47: UI/UX INTELLIGENCE — No Duplicate Tabs', description: 'Never create two tabs that do the same thing. Merge duplicates into a single tab with sub-tabs or a pill bar.', category: 'ui', priority: 'high' },
  { key: 'r48-earning-first', title: 'Rule 48: EARNING IS #1 — Revenue First, Always', description: 'Revenue generation is the top priority. Every feature should ultimately serve earning. The earning engine runs daily research.', category: 'strategy', priority: 'critical' },
  { key: 'r49-tool-finding', title: 'Rule 49: TOOL-FINDING FLOW — Use What We Have First', description: 'Before adding a new dependency, check if an existing skill/tool/lib already does it. The skill-finder helps locate existing capabilities.', category: 'strategy', priority: 'medium' },
  { key: 'r50-continuous-workflow', title: 'Rule 50: CONTINUOUS WORKFLOW — Never Stop at Half-Done', description: 'If a task is started, complete it in the same run. Don\'t leave half-implemented features. The autonomous loop advances pending work.', category: 'operational', priority: 'high' },
  { key: 'r51-competitive-parity', title: 'Rule 51: COMPETITIVE PARITY — Match Claude/Gemini/z.ai Features', description: 'Track competitor features and match them. If Claude has computer-use, ARIA should have browser-agent. If Gemini has 1M context, ARIA should wire long-context.', category: 'strategy', priority: 'medium' },
  { key: 'r52-rules-file', title: 'Rule 52: RULES FILE — Always Read Before Every Run', description: 'Every agent + cron job MUST read RULES.md before working. Violating a rule is a critical error.', category: 'worklog', priority: 'critical' },
  { key: 'r53-monitoring-all-models', title: 'Rule 53: MONITORING AGENTS — Use All 455 Models + All App Features', description: 'Monitoring agents have full access to the model catalog + all app features. They should use the best tool for each finding.', category: 'monitoring', priority: 'high' },
  { key: 'r54-best-improvements', title: 'Rule 54: BEST IMPROVEMENTS — Multi-Agent AI Company', description: 'ARIA is a multi-agent AI company. Each improvement should make the fleet more capable, not just the UI prettier.', category: 'strategy', priority: 'medium' },
  { key: 'r55-real-metrics', title: 'Rule 55: REAL METRICS ONLY — No Math.random', description: 'All dashboard metrics must come from real sources (systeminformation, DB, APIs). Never use Math.random for displayed values.', category: 'data', priority: 'critical' },
  { key: 'r56-merged-tabs', title: 'Rule 56: MERGED TABS — No Duplicate Functionality', description: 'Related tabs are merged into a single tab with sub-tabs. Example: Fleet + Topology + Network → one Fleet tab with sub-tabs.', category: 'ui', priority: 'high' },
  { key: 'r57-thinking-always', title: 'Rule 57: THINKING MODE ALWAYS-ON', description: 'GLM-4.6 thinking mode is ON by default for all chat calls. Complex tasks always get reasoning. Toggled via /api/thinking-mode.', category: 'intelligence', priority: 'medium' },
  { key: 'r58-knowledge-sharing', title: 'Rule 58: KNOWLEDGE SHARING — Conceptual, Never Invents Network Calls', description: 'The knowledge daemon shares learnings conceptually (within the DB). It never fabricates cross-machine network calls.', category: 'knowledge', priority: 'medium' },
  { key: 'r59-apply-all-files', title: 'Rule 59: APPLY TO ALL FILES — Existing + Future', description: 'All rules apply to both existing code and any future code added by agents, crons, or the user.', category: 'worklog', priority: 'high' },
  { key: 'r60-mandatory-doc-updates', title: 'Rule 60: MANDATORY DOC UPDATES — Every Run', description: 'Every run that adds/changes a feature MUST update the documentation (APP_DOCUMENTATION.md, COMPLETE_OVERVIEW.md, RULES.md).', category: 'worklog', priority: 'high' },
  { key: 'r61-no-missing-features', title: 'Rule 61: NO MISSING FEATURES — Never Lose a Previous Version\'s Feature', description: 'When migrating/merging, ensure no feature from a previous version is lost. The merge checklist verifies each feature survives.', category: 'file-safety', priority: 'critical' },
  { key: 'r62-request-goal-logging', title: 'Rule 62: REQUEST → GOAL LOGGING — Audit Trail of What Was Requested', description: 'Every user request is logged as a Goal entity for audit. The request-logger creates a Goal row on every chat message.', category: 'governance', priority: 'medium' },
  { key: 'r63-multi-agent-conflict', title: 'Rule 63: MULTI-AGENT CONFLICT PREVENTION — Parallel Agent Coordination', description: 'Parallel agents must not edit the same file. The worklog + Task IDs coordinate boundaries. Each agent owns its files.', category: 'coordination', priority: 'high' },
  { key: 'r64-sidebar-collapse', title: 'Rule 64: SIDEBAR COLLAPSE DEFAULT — Groups Collapsed on First Load', description: 'All sidebar groups are collapsed by default on page load. The user manually expands the groups they want to see.', category: 'ui', priority: 'low' },
  { key: 'r65-knowledge-bidirectional', title: 'Rule 65: KNOWLEDGE SHARING BIDIRECTIONAL — Both Directions, Honest', description: 'Knowledge sharing flows both ways: contribute local learnings + consume community learnings. Always honest about what was shared/received.', category: 'knowledge', priority: 'medium' },
  { key: 'r66-no-broken-navigate', title: 'Rule 66: NO BROKEN NAVIGATE CALLS — Every navigate() Must Resolve', description: 'Every navigate(\'tab-key\') call must map to a registered tab. The LEGACY_TAB_MAP redirects old keys to merged parents.', category: 'ui', priority: 'high' },
  { key: 'r67-merged-completeness', title: 'Rule 67: MERGED-TAB COMPLETENESS — No Feature Lost in a Merge', description: 'When merging tabs, every feature from the original tabs must be accessible via a sub-tab or panel in the merged parent.', category: 'ui', priority: 'high' },
  { key: 'r68-real-data-first', title: 'Rule 68: REAL DATA FIRST — No Hardcoded Values, No Math.random', description: 'All displayed data must come from real DB/API sources. Never hardcode sample values or use Math.random for displayed metrics.', category: 'data', priority: 'critical' },
  { key: 'r69-no-dropdowns-subtabs', title: 'Rule 69: NO DROPDOWNS FOR ≤5 SUB-TABS — Use Pill Bar', description: 'When a tab has ≤5 sub-tabs, use a pill bar (horizontal buttons) instead of a dropdown. Faster + more discoverable.', category: 'ui', priority: 'low' },
  { key: 'r70-chat-tab-bounded', title: 'Rule 70: CHAT TAB — Bounded Height + Scrollbar + Auto-Scroll + First/Last Nav', description: 'The chat tab has bounded height with a custom scrollbar, auto-scrolls to the latest message, and has first/last navigation buttons.', category: 'ui', priority: 'low' },
  { key: 'r71-goals-first-class', title: 'Rule 71: GOALS ARE FIRST-CLASS ENTITIES — Not MemoryItems, With Time Horizons', description: 'Goals have their own Prisma model with time horizons (daily/weekly/monthly/quarterly/yearly), categories, progress, and parent-child milestones.', category: 'data', priority: 'high' },
  { key: 'r72-orion-default', title: 'Rule 72: ORION SCREEN IS THE DEFAULT LANDING EXPERIENCE', description: 'The Orion voice-shell overlay is the default landing experience (full-screen, hands-free, Jarvis-like). Toggle off with Cmd+Shift+O.', category: 'ui', priority: 'medium' },
  { key: 'r73-knowledge-db-persistence', title: 'Rule 73: KNOWLEDGE SHARING USES DB PERSISTENCE — Real Bidirectional Flow', description: 'The knowledge daemon persists shared/contributed learnings to the DB (MemoryItem + Skill tables). Real bidirectional flow, not conceptual.', category: 'knowledge', priority: 'high' },
];

async function main() {
  let created = 0;
  let updated = 0;
  for (const r of RULES) {
    const existing = await db.rule.findUnique({ where: { key: r.key } });
    if (existing) {
      await db.rule.update({
        where: { key: r.key },
        data: { title: r.title, description: r.description, category: r.category, priority: r.priority },
      });
      updated++;
    } else {
      await db.rule.create({
        data: { key: r.key, title: r.title, description: r.description, category: r.category, priority: r.priority, enabled: true },
      });
      created++;
    }
  }
  console.log(`Rules seeded: ${created} created, ${updated} updated, ${RULES.length} total`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
