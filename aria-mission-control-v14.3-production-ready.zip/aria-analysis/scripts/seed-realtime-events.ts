// Seed sample RealtimeEvent rows so the Realtime Event Log tab has data.
import { db } from '../src/lib/db';

const channels = ['agent:heartbeat', 'agent:status', 'task:update', 'decision:new', 'alert:critical', 'telemetry:tick', 'payment:update', 'sync:status'];
const codenames = ['ORION', 'VEGA', 'ATLAS', 'NOVA', 'ECHO', 'SAGE', 'PULSE', 'FORGE'];
const now = Date.now();
let count = 0;

async function main() {
  for (let i = 0; i < 40; i++) {
    const ch = channels[i % channels.length];
    const ago = Math.floor(Math.random() * 600);
    const event = ch.split(':')[1];
    let payload: Record<string, unknown> = {};
    let broadcastTo = 'all';
    if (ch === 'agent:heartbeat') {
      payload = { codename: codenames[Math.floor(Math.random() * codenames.length)], cpu: Math.round(Math.random() * 80 + 10), mem: Math.round(Math.random() * 70 + 20), load: Math.round(Math.random() * 100), status: Math.random() > 0.9 ? 'error' : 'working' };
      broadcastTo = 'operators';
    } else if (ch === 'telemetry:tick') {
      payload = { cpu: Math.round(Math.random() * 60 + 20), mem: Math.round(Math.random() * 50 + 30), latencyMs: Math.round(Math.random() * 100 + 10), activeAgents: Math.floor(Math.random() * 10 + 50) };
    } else if (ch === 'alert:critical') {
      payload = { metric: 'fleet-load', value: Math.round(Math.random() * 20 + 80), threshold: 85 };
      broadcastTo = 'operators';
    } else if (ch === 'task:update') {
      payload = { taskId: 'task_' + Math.floor(Math.random() * 1000), status: ['created', 'in_progress', 'completed'][Math.floor(Math.random() * 3)] };
    } else if (ch === 'decision:new') {
      payload = { action: ['autopilot.dispatch', 'briefing.generated'][Math.floor(Math.random() * 2)], health: Math.floor(Math.random() * 40 + 60) };
    } else if (ch === 'payment:update') {
      payload = { paymentId: 'pay_' + Math.floor(Math.random() * 1000), status: ['pending', 'confirmed'][Math.floor(Math.random() * 2)], amount: Math.round(Math.random() * 5000 + 100) };
    } else if (ch === 'sync:status') {
      payload = { direction: 'sqlite-to-postgres', tables: Math.floor(Math.random() * 10), rows: Math.floor(Math.random() * 1000), ok: Math.random() > 0.1 };
    } else if (ch === 'agent:status') {
      payload = { codename: codenames[Math.floor(Math.random() * codenames.length)], from: 'idle', to: 'working' };
    }
    await db.realtimeEvent.create({
      data: {
        channel: ch,
        event,
        payload: JSON.stringify(payload),
        broadcastTo,
        createdAt: new Date(now - ago * 1000),
      },
    });
    count++;
  }
  console.log(`Seeded ${count} realtime events`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
