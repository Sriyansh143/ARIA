// Seed the WorkforceAgent + Department tables from the AGENT_ROSTER + DEPARTMENTS config.
// The Agent table (64 agents) is already seeded by scripts/seed.ts — this script
// populates the WorkforceAgent table (the org-chart view) + Department table.
import { db } from '../src/lib/db';
import { AGENT_ROSTER, DEPARTMENTS } from '../src/lib/config';

async function main() {
  let deptCreated = 0;
  let deptUpdated = 0;
  let wfCreated = 0;
  let wfUpdated = 0;

  // 1. Seed departments
  for (const d of DEPARTMENTS) {
    const existing = await db.department.findUnique({ where: { key: d.key } });
    const headAgent = AGENT_ROSTER.find((a) => a.department === d.key && (a.seniority === 'c-suite' || a.seniority === 'lead' || a.seniority === 'director'))?.codename;
    if (existing) {
      await db.department.update({
        where: { key: d.key },
        data: { name: d.name, accent: d.color, headAgent: headAgent ?? null },
      });
      deptUpdated++;
    } else {
      await db.department.create({
        data: {
          key: d.key,
          name: d.name,
          accent: d.color,
          headAgent: headAgent ?? null,
          mission: `${d.name} department — 4 specialists`,
        },
      });
      deptCreated++;
    }
  }

  // 2. Seed workforce agents (one per AGENT_ROSTER entry)
  for (const a of AGENT_ROSTER) {
    const existing = await db.workforceAgent.findUnique({ where: { codename: a.codename } });
    const data = {
      name: a.name,
      title: a.title,
      departmentKey: a.department,
      seniority: a.seniority,
      modelTier: a.seniority === 'c-suite' || a.seniority === 'director' ? 'strong' : a.seniority === 'senior' || a.seniority === 'lead' ? 'strong' : 'medium',
      skills: JSON.stringify(a.skills),
      personality: JSON.stringify({ communication: 'professional', pace: 'steady' }),
      status: 'active',
    };
    if (existing) {
      await db.workforceAgent.update({ where: { codename: a.codename }, data });
      wfUpdated++;
    } else {
      await db.workforceAgent.create({ data: { codename: a.codename, ...data } });
      wfCreated++;
    }
  }

  // 3. Set reportsTo (org hierarchy): everyone reports to ORION (CTO) except department heads who report to ORION
  const orion = AGENT_ROSTER.find((a) => a.codename === 'ORION');
  if (orion) {
    for (const a of AGENT_ROSTER) {
      if (a.codename === 'ORION') continue;
      const isHead = ['c-suite', 'lead', 'director'].includes(a.seniority);
      const reportsTo = isHead ? 'ORION' : AGENT_ROSTER.find((x) => x.department === a.department && ['c-suite', 'lead', 'senior'].includes(x.seniority))?.codename ?? 'ORION';
      await db.workforceAgent.update({
        where: { codename: a.codename },
        data: { reportsTo },
      });
    }
  }

  console.log(`Departments: ${deptCreated} created, ${deptUpdated} updated`);
  console.log(`WorkforceAgents: ${wfCreated} created, ${wfUpdated} updated`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
