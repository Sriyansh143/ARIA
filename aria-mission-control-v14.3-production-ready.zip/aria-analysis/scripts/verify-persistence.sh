#!/bin/bash
# =====================================================================
# verify-persistence.sh — ARIA Mission Control absolute file persistence
# =====================================================================
# Run at the START and END of every session to verify that all critical
# files are persisted on disk with non-zero sizes and correct line counts.
#
# Usage:
#   bash scripts/verify-persistence.sh           # verify all critical files
#   bash scripts/verify-persistence.sh --verbose  # show every file's details
#
# Exits 0 if ALL files are present and non-empty, 1 otherwise.
# =====================================================================
set -e

# Resolve the project root (this script lives in <root>/scripts/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

VERBOSE=false
if [ "$1" = "--verbose" ]; then VERBOSE=true; fi

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Counters
PASS=0
FAIL=0
WARN=0

print_banner() {
  echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
  echo -e "${CYAN}  ARIA Mission Control — File Persistence Verification${NC}"
  echo -e "${CYAN}  Project root: $ROOT${NC}"
  echo -e "${CYAN}  Time: $(date -u '+%Y-%m-%d %H:%M:%S UTC')${NC}"
  echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
  echo ""
}

# Verify a single file: exists, non-empty, report size + line count
verify_file() {
  local relpath="$1"
  local description="$2"
  local min_lines="${3:-1}"  # minimum expected line count
  local abspath="$ROOT/$relpath"

  if [ ! -f "$abspath" ]; then
    echo -e "  ${RED}✗ MISSING${NC}  $relpath"
    echo -e "             $description"
    FAIL=$((FAIL + 1))
    return 1
  fi

  local size=$(stat -c%s "$abspath" 2>/dev/null || stat -f%z "$abspath" 2>/dev/null || echo 0)
  local lines=$(wc -l < "$abspath" 2>/dev/null || echo 0)
  lines=$(echo "$lines" | tr -d ' ')

  if [ "$size" -eq 0 ]; then
    echo -e "  ${RED}✗ EMPTY${NC}    $relpath (0 bytes)"
    echo -e "             $description"
    FAIL=$((FAIL + 1))
    return 1
  fi

  if [ "$lines" -lt "$min_lines" ]; then
    echo -e "  ${YELLOW}⚠ SHORT${NC}    $relpath ($lines lines, expected ≥ $min_lines)"
    echo -e "             $description"
    WARN=$((WARN + 1))
    return 0
  fi

  if [ "$VERBOSE" = true ]; then
    echo -e "  ${GREEN}✓ OK${NC}       $relpath (${size}B, ${lines} lines)"
    echo -e "             $description"
  else
    echo -e "  ${GREEN}✓${NC} $relpath (${size}B, ${lines}L) — $description"
  fi
  PASS=$((PASS + 1))
  return 0
}

# Verify a directory: exists, non-empty
verify_dir() {
  local relpath="$1"
  local description="$2"
  local abspath="$ROOT/$relpath"

  if [ ! -d "$abspath" ]; then
    echo -e "  ${RED}✗ MISSING DIR${NC} $relpath"
    echo -e "                  $description"
    FAIL=$((FAIL + 1))
    return 1
  fi

  local count=$(find "$abspath" -type f 2>/dev/null | wc -l | tr -d ' ')
  if [ "$count" -eq 0 ]; then
    echo -e "  ${YELLOW}⚠ EMPTY DIR${NC}  $relpath (no files)"
    echo -e "                  $description"
    WARN=$((WARN + 1))
    return 0
  fi

  if [ "$VERBOSE" = true ]; then
    echo -e "  ${GREEN}✓ OK DIR${NC}    $relpath ($count files)"
    echo -e "                  $description"
  else
    echo -e "  ${GREEN}✓${NC} $relpath/ ($count files) — $description"
  fi
  PASS=$((PASS + 1))
  return 0
}

print_banner

# ─── 1. Critical source files (the briefing desync fix) ──────────────
echo -e "${CYAN}── Section 1: Briefing Desync Fix — Critical Source Files ──${NC}"
echo ""
verify_file "src/lib/briefing-cache.ts" \
  "Three-layer briefing cache (TTL + state-hash + single-flight)" 100
verify_file "src/lib/autopilot-scheduler.ts" \
  "Server-side singleton autopilot scheduler" 100
verify_file "src/app/api/autopilot/state/route.ts" \
  "GET/POST endpoint for autopilot scheduler state" 20
verify_file "src/app/api/briefing/stream/route.ts" \
  "SSE endpoint for real-time briefing push" 50
verify_file "src/app/api/briefing/route.ts" \
  "Briefing API with cache + state-hash + single-flight" 200
verify_file "src/app/api/autopilot/tick/route.ts" \
  "Autopilot tick route (DASHBOARD_BASE fix)" 100
verify_file "src/components/jarvis/AutopilotToggle.tsx" \
  "Client toggle — polls /api/autopilot/state, optimistic UI" 100
verify_file "src/components/jarvis/BriefingHeadlinePill.tsx" \
  "Header pill — SSE subscription + 60s polling fallback" 50
verify_file "src/components/tabs/BriefingTab.tsx" \
  "Briefing tab — SSE subscription + ?force=1 regenerate" 400
verify_file "src/lib/idle-agent-dispatcher.ts" \
  "Idle-agent dispatcher (DASHBOARD_BASE fix)" 200
verify_file "src/lib/approval-escalation.ts" \
  "Approval escalation (DASHBOARD_BASE fix)" 100
verify_file "instrumentation.ts" \
  "Server boot — starts autopilot scheduler" 50
echo ""

# ─── 2. Configuration & environment ──────────────────────────────────
echo -e "${CYAN}── Section 2: Configuration & Environment ──${NC}"
echo ""
verify_file ".env" "Environment variables (CORS, DB, secrets)" 50
verify_file "package.json" "NPM package manifest" 50
verify_file "next.config.ts" "Next.js config (allowedDevOrigins)" 5
verify_file "tsconfig.json" "TypeScript config" 5
verify_file "prisma/schema.prisma" "Prisma schema (SQLite)" 100
verify_file "prisma/schema-postgres.prisma" "Prisma schema (Postgres mirror)" 100
echo ""

# ─── 3. Documentation (mandatory audit trail) ────────────────────────
echo -e "${CYAN}── Section 3: Documentation & Audit Trail ──${NC}"
echo ""
verify_file "worklog.md" "Shared work log (mandatory, append-only)" 5
verify_file "RULES.md" "Permanent rules (never delete, only append)" 5
verify_file "APP_DOCUMENTATION.md" "App endpoints + architecture docs" 5
verify_file "ROADMAP.md" "Roadmap with completed items checked off" 5
verify_file "INSTALL.md" "Installation instructions" 5
echo ""

# ─── 4. Database ─────────────────────────────────────────────────────
echo -e "${CYAN}── Section 4: Database ──${NC}"
echo ""
verify_file "db/custom.db" "SQLite database (64 agents, tasks, telemetry)" 1
echo ""

# ─── 5. Scripts (this script + test scripts) ─────────────────────────
echo -e "${CYAN}── Section 5: Scripts ──${NC}"
echo ""
verify_file "scripts/verify-persistence.sh" "This persistence verification script" 50
echo ""

# ─── 6. Source directories ───────────────────────────────────────────
echo -e "${CYAN}── Section 6: Source Directories ──${NC}"
echo ""
verify_dir "src/lib" "Core library modules (~130 files)"
verify_dir "src/app/api" "API route handlers (~140 endpoints)"
verify_dir "src/components/tabs" "UI tab components (~60 tabs)"
verify_dir "src/components/jarvis" "Jarvis shell components"
verify_dir "src/components/ui" "shadcn/ui primitives"
verify_dir "skills" "Skill definitions (~65 skills)"
echo ""

# ─── 7. Download directory (deliverables) ────────────────────────────
echo -e "${CYAN}── Section 7: Deliverables (download/) ──${NC}"
echo ""
DOWNLOAD_DIR="/home/z/my-project/download"
if [ -d "$DOWNLOAD_DIR" ]; then
  echo -e "  ${GREEN}✓${NC} /home/z/my-project/download/ exists"
  ls -la "$DOWNLOAD_DIR" | tail -n +2 | head -10
else
  echo -e "  ${YELLOW}⚠${NC} /home/z/my-project/download/ does not exist (no deliverables yet)"
  WARN=$((WARN + 1))
fi
echo ""

# ─── 8. Server health check (optional, if running) ───────────────────
echo -e "${CYAN}── Section 8: Server Health (optional) ──${NC}"
echo ""
if curl -s -o /dev/null -m 3 http://localhost:3000/ 2>/dev/null; then
  echo -e "  ${GREEN}✓${NC} Dev server responding on http://localhost:3000/"

  # Verify critical endpoints
  for endpoint in "/api/briefing" "/api/autopilot/state" "/api/metrics" "/api/tasks" "/api/agents"; do
    code=$(curl -s -o /dev/null -m 10 -w "%{http_code}" "http://localhost:3000${endpoint}" 2>/dev/null)
    if [ "$code" = "200" ]; then
      echo -e "  ${GREEN}✓${NC} $endpoint → 200 OK"
    else
      echo -e "  ${RED}✗${NC} $endpoint → $code"
      FAIL=$((FAIL + 1))
    fi
  done

  # SSE endpoint test
  sse_ok=$(timeout 3 curl -s -N -m 3 http://localhost:3000/api/briefing/stream 2>/dev/null | grep -c "event: ping" || echo 0)
  if [ "$sse_ok" -gt 0 ]; then
    echo -e "  ${GREEN}✓${NC} /api/briefing/stream → SSE ping received"
  else
    echo -e "  ${YELLOW}⚠${NC} /api/briefing/stream → no ping in 3s (may need longer window)"
    WARN=$((WARN + 1))
  fi
else
  echo -e "  ${YELLOW}⚠${NC} Dev server not running — skipping endpoint health checks"
  WARN=$((WARN + 1))
fi
echo ""

# ─── Summary ─────────────────────────────────────────────────────────
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "  PASSED:  ${GREEN}$PASS${NC}"
echo -e "  WARNED:  ${YELLOW}$WARN${NC}"
echo -e "  FAILED:  ${RED}$FAIL${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""

if [ $FAIL -eq 0 ]; then
  echo -e "  ${GREEN}✅ ALL CRITICAL FILES PERSISTED — file integrity verified${NC}"
  echo ""
  exit 0
else
  echo -e "  ${RED}❌ $FAIL critical file(s) missing or empty${NC}"
  echo -e "  ${RED}   Fix the issues above before proceeding.${NC}"
  echo ""
  exit 1
fi
