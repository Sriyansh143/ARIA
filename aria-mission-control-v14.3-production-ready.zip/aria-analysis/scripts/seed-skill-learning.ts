// Seed sample SkillLearning rows for the proficiency matrix.
// Covers ALL 64 agents (was only 16 — fixed in CRON-V11-12).
import { db } from '../src/lib/db';

const SKILL_KEYS = [
  'code-gen', 'code-review', 'refactor', 'design', 'fullstack-dev',
  'ui-ux-pro-max', 'web-search', 'web-reader', 'pdf', 'xlsx',
  'charts', 'image-generation', 'llm', 'vlm', 'tts',
];

async function main() {
  // Fetch ALL agent codenames from the DB (not a hardcoded subset).
  const agents = await db.agent.findMany({ select: { codename: true, role: true } });
  const AGENT_CODES = agents.map((a) => a.codename);
  console.log(`Seeding skill-learning for ${AGENT_CODES.length} agents…`);
  let count = 0;
  // Each agent learns 5-8 random skills with varying proficiency.
  for (const agent of AGENT_CODES) {
    const numSkills = 5 + Math.floor(Math.random() * 4);
    const shuffled = [...SKILL_KEYS].sort(() => Math.random() - 0.5).slice(0, numSkills);
    for (const skill of shuffled) {
      const proficiency = Math.floor(Math.random() * 70 + 20); // 20-90
      const earnings = Math.round(Math.random() * 5000 * (proficiency / 100));
      const daysAgo = Math.floor(Math.random() * 30);
      await db.skillLearning.upsert({
        where: { agentCodename_skillKey: { agentCodename: agent, skillKey: skill } },
        update: { proficiency, earnings, lastUsed: new Date(Date.now() - daysAgo * 86400000) },
        create: {
          agentCodename: agent,
          skillKey: skill,
          proficiency,
          learnedFrom: Math.random() > 0.5 ? 'autonomy-loop' : 'manual',
          earnings,
          lastUsed: new Date(Date.now() - daysAgo * 86400000),
        },
      });
      count++;
    }
  }
  console.log(`Seeded ${count} skill-learning records across ${AGENT_CODES.length} agents`);
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
