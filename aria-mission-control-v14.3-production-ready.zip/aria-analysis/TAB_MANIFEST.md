# TAB_MANIFEST.md — ARIA Mission Control Tab-by-Tab Architectural Breakdown

**Version:** v14.1
**Last Updated:** 2026-07-24
**Total tabs:** 76 tab components → 31 sidebar entries → 8 groups

> This file lists EVERY tab in the app with its purpose, API endpoints,
> UI elements, write operations, and functional status. Tabs are grouped
> by their sidebar group, then by sidebar entry. Merged tabs show their
> sub-tabs indented.

---

## Group 1: Command Center (7 sidebar entries, 11 tabs)

### 1.1 `briefing` — Mission Briefing (standalone)
- **File:** `src/components/tabs/BriefingTab.tsx` (717 lines)
- **Purpose:** ARIA's live situational assessment — synthesizes fleet state, telemetry, tasks, comms & revenue into a prioritized briefing with actionable recommendations.
- **APIs:** `GET /api/briefing` (one-shot on mount, SSE-driven refresh), `GET /api/standup`
- **Writes:** `POST /api/tasks` (one-click promote recommendation → task)
- **Fetches:** `GET /api/briefing?force=1` (Regenerate button)
- **SSE:** Subscribes to `/api/briefing/stream` for sub-second push updates
- **UI elements:**
  - Hero panel: health ring gauge (0-100), headline, summary, generated-at timestamp
  - 6-metric strip: Agents (active/total), CPU%, MEM%, Tasks (pending+in_progress + blocked), Revenue (confirmed + pending), Success%
  - Top Risks panel (left, 1/3 width) — numbered list with red accent
  - Predictive Analytics panel (full width) — 5 forecast chips (fleet-load, error-rate, revenue, etc.) with trend arrows + risk colors
  - Recommendations grid (2/3 width) — priority-sorted cards (critical/high/medium/low) with category icons, one-click "Create Task" button
  - Quick Actions bar — one-click autonomous operations (refresh, etc.)
  - Regenerate button (with SSE-connected green dot)
  - localStorage: `aria.briefing.convertedRecs.v1` (tracks already-converted recommendations)
- **Status:** ✅ Fully functional. Fixed in v14.0 (SSE + cache + state-hash).

### 1.2 `decisions` — Decision Log (standalone)
- **File:** `src/components/tabs/DecisionLogTab.tsx` (340 lines)
- **Purpose:** Audit trail of every autonomous decision made by ARIA (briefings, autopilot ticks, approval escalations, etc.)
- **APIs:** `GET /api/decisions${query}` (with filters: category, actor, limit), `GET /api/decisions?limit=1` (header badge count)
- **Writes:** None (read-only)
- **UI elements:**
  - Filter bar (category, actor, date range)
  - Decision cards: actor, action, category, timestamp, before/after state, meta
  - Reversal support (some decisions have a "Reverse" button)
- **Status:** ✅ Fully functional

### 1.3 `strategy` — AI Strategy (standalone)
- **File:** `src/components/tabs/StrategyTab.tsx` (385 lines)
- **Purpose:** High-level strategic goals + AI-generated strategy proposals
- **APIs:** `GET /api/strategy`
- **Writes:** None (read-only — proposals are surfaced but approval happens in Governance tab)
- **UI elements:**
  - Strategic goals list (long-term, mid-term, short-term)
  - AI-generated strategy proposals (with confidence scores)
  - Strategy history timeline
- **Status:** ✅ Fully functional

### 1.4 `overview` — Overview (standalone)
- **File:** `src/components/tabs/OverviewTab.tsx` (377 lines)
- **Purpose:** Bird's-eye dashboard — the "home" view with key metrics from all systems
- **APIs:** `GET /api/dashboard` (aggregated metrics)
- **Writes:** None
- **UI elements:**
  - KPI cards (agents, tasks, revenue, health)
  - Mini charts (CPU trend, task throughput, revenue trend)
  - Quick links to other tabs
- **Status:** ✅ Fully functional

### 1.5 `ai-studio` — AI Studio (merged, 5 sub-tabs)

#### 1.5.1 `chat` — ARIA Chat
- **File:** `src/components/tabs/ChatTab.tsx` (554 lines)
- **Purpose:** Conversational AI chat with ARIA (the main LLM interface)
- **APIs:** `GET /api/chat?limit=30` (history), `POST /api/chat` (send message)
- **Writes:** `POST /api/chat`, `POST /api/thinking-mode` (toggle), `POST /api/chat/attach` (file upload)
- **UI elements:**
  - Message list (user + assistant, with markdown rendering)
  - Thinking-mode toggle (shows reasoning trace)
  - File attachment button
  - Input box with send button
- **Status:** ✅ Fully functional

#### 1.5.2 `preview` — App Preview
- **File:** `src/components/tabs/PreviewTab.tsx` (213 lines)
- **Purpose:** Live preview of generated apps (similar to z.ai's instant preview)
- **APIs:** None (uses postJson)
- **Writes:** `POST /api/agent-exec` (execute agent), `POST /api/chat` (generate code)
- **UI elements:**
  - URL bar (enter preview URL)
  - iframe preview pane
  - "Generate app" button
- **Status:** ✅ Functional but basic

#### 1.5.3 `screen-vision` — Screen Vision
- **File:** `src/components/tabs/ScreenVisionTab.tsx` (533 lines)
- **Purpose:** Capture + analyze screenshots with the vision model
- **APIs:** None directly
- **Writes:** `POST /api/vision` (upload screenshot for analysis)
- **UI elements:**
  - Screenshot capture button
  - Image preview
  - Vision analysis output (text description of what's on screen)
- **Status:** ✅ Fully functional

#### 1.5.4 `website-3d` — 3D Websites
- **File:** `src/components/tabs/Website3DBuilderTab.tsx` (572 lines)
- **Purpose:** Generate 3D website layouts via LLM
- **APIs:** None directly
- **Writes:** `POST /api/website-3d/generate`
- **UI elements:**
  - Prompt input ("describe the website you want")
  - 3D preview canvas
  - Generate button
  - Saved 3D sites list
- **Status:** ✅ Fully functional

#### 1.5.5 `pitch-templates` — Pitch Templates
- **File:** `src/components/tabs/PitchTemplatesTab.tsx` (565 lines)
- **Purpose:** LLM-generated sales pitch templates
- **APIs:** None directly (fetches on mount via postJson)
- **Writes:** `POST /api/pitch-templates/generate`
- **UI elements:**
  - Template category selector (sales, investor, partnership, etc.)
  - Generate button
  - Template editor (markdown)
  - Saved templates list
- **Status:** ✅ Fully functional

### 1.6 `activity` — Activity Feed (standalone)
- **File:** `src/components/tabs/ActivityTab.tsx` (76 lines)
- **Purpose:** Live feed of all activity across the fleet (agent status changes, task completions, etc.)
- **APIs:** `GET /api/activity` (polls every 8s)
- **Writes:** None
- **UI elements:** Scrollable activity list with timestamps + actor icons
- **Status:** ✅ Fully functional

### 1.7 `insights` — AI Insights (standalone)
- **File:** `src/components/tabs/InsightsTab.tsx` (124 lines)
- **Purpose:** AI-generated insights about fleet performance, anomalies, opportunities
- **APIs:** `GET /api/insights`
- **Writes:** None
- **UI elements:** Insight cards with category, confidence, recommendation
- **Status:** ✅ Fully functional

---

## Group 2: Agent Fleet (1 merged sidebar entry, 8 sub-tabs)

### 2.1 `fleet` — Agent Fleet (merged, 8 sub-tabs)

#### 2.1.1 `fleet-list` — Fleet List
- **File:** `src/components/tabs/FleetTab.tsx` (1634 lines — the biggest tab)
- **Purpose:** The main 64-agent roster with status, load, success rate, skills, model
- **APIs:** `GET /api/agents`
- **Writes:** `POST /api/agents` (create), `PATCH /api/agents/${id}` (update), `POST /api/agents/backup` (export), `POST /api/agents/spawn` (spawn from template), `POST /api/agents/templates`, `POST /api/comms` (send message to agent), `POST /api/tasks` (assign task)
- **Fetches:** `GET /api/agents/${id}` (detail)
- **UI elements:**
  - Agent grid (64 cards) — codename, avatar, status pill, load bar, success rate, model
  - Filter bar (status, role, skill)
  - Agent detail drawer (click a card) — full profile, logs, tasks, heartbeats
  - Action buttons: Create, Spawn, Backup, Export, Send Message, Assign Task
- **Status:** ✅ Fully functional — the primary fleet management UI

#### 2.1.2 `network` — Network
- **File:** `src/components/tabs/AgentNetworkTab.tsx` (1062 lines)
- **Purpose:** Force-directed graph of agent communication patterns
- **APIs:** `GET /api/agents`, `GET /api/agents/${agentId}` (detail on click)
- **Writes:** None
- **UI elements:**
  - Force-directed graph (agents as nodes, comms as edges)
  - Click node → agent detail panel
  - Time range selector
- **Status:** ✅ Fully functional

#### 2.1.3 `workforce` — Workforce
- **File:** `src/components/tabs/WorkforceTab.tsx` (363 lines)
- **Purpose:** Department/tier view of the 64-agent workforce (16 departments × 4 tiers: strong/balanced/fast/cheap)
- **APIs:** `GET /api/workforce`
- **Writes:** `PATCH /api/workforce/${id}` (reassign tier)
- **UI elements:**
  - Department grid (16 cards)
  - Tier breakdown per department
  - Reassign agent to tier
- **Status:** ✅ Fully functional

#### 2.1.4 `spawned` — Spawned
- **File:** `src/components/tabs/SpawnedAgentsTab.tsx` (523 lines)
- **Purpose:** Ephemeral spawned agents (clones created for parallel work, auto-cleaned up)
- **APIs:** `GET /api/agents/spawn` (list spawned)
- **Writes:** `POST /api/agents/spawn/${id}` (terminate a spawned agent)
- **UI elements:**
  - Spawned agent list (with TTL countdown)
  - Terminate button per agent
  - "Cleanup all expired" button
- **Status:** ✅ Fully functional

#### 2.1.5 `compare` — Compare
- **File:** `src/components/tabs/AgentComparisonTab.tsx` (520 lines)
- **Purpose:** Side-by-side comparison of 2-3 agents (performance, skills, model, logs)
- **APIs:** `GET /api/agents`
- **Writes:** None
- **UI elements:**
  - Agent selector (2-3 dropdowns)
  - Comparison table (metric rows: success rate, task count, avg duration, model, skills)
  - Comparison timeline chart
- **Status:** ✅ Fully functional

#### 2.1.6 `collab` — Collaboration
- **File:** `src/components/tabs/CollaborationGraphTab.tsx` (438 lines)
- **Purpose:** Graph of agent collaboration patterns (which agents work together on tasks)
- **APIs:** `GET /api/comms/graph`
- **Writes:** None
- **UI elements:**
  - Force-directed collaboration graph
  - Edge weight = number of shared tasks
  - Time range selector
- **Status:** ✅ Fully functional

#### 2.1.7 `capacity` — Capacity
- **File:** `src/components/tabs/CapacityPlannerTab.tsx` (447 lines)
- **Purpose:** Capacity planning — predicts when fleet will hit saturation based on task throughput
- **APIs:** `GET /api/fleet/capacity`
- **Writes:** None
- **UI elements:**
  - Current capacity gauge (utilization %)
  - 7-day forecast chart
  - Recommendations ("scale out by N agents", "shed non-critical work")
- **Status:** ✅ Fully functional

#### 2.1.8 `comms` — Comms
- **File:** `src/components/tabs/CommsTab.tsx` (319 lines)
- **Purpose:** Inter-agent messaging (read/reply/send between agents)
- **APIs:** `GET /api/agents`, `GET /api/comms`
- **Writes:** `POST /api/comms` (send), `PATCH /api/comms/${id}` (mark read), `POST /api/comms/reply`
- **UI elements:**
  - Message list (from/to/subject/body/timestamp)
  - Filter by agent
  - Reply box
  - Compose new message
- **Status:** ✅ Fully functional

---

## Group 3: Work & Tasks (2 sidebar entries, 4 tabs)

### 3.1 `tasks` — Tasks (merged, 3 sub-tabs)

#### 3.1.1 `tasks-list` — Tasks
- **File:** `src/components/tabs/TasksTab.tsx` (410 lines)
- **Purpose:** The main task queue — list of all tasks with status, priority, assignee, progress
- **APIs:** `GET /api/agents` (for assignee dropdown), `GET /api/tasks?status=${filter}&project=${projectFilter}`
- **Writes:** `POST /api/tasks` (create), `PATCH /api/tasks/${id}` (update), `POST /api/tasks/bulk` (bulk update)
- **UI elements:**
  - Filter bar (status, project, priority, assignee)
  - Task table (title, status, priority, assignee, progress, created, updated)
  - Create task dialog
  - Edit task dialog
  - Bulk select + bulk update
- **Status:** ✅ Fully functional

#### 3.1.2 `kanban` — Kanban
- **File:** `src/components/tabs/KanbanTab.tsx` (579 lines)
- **Purpose:** Kanban board view of tasks (pending → in_progress → review → done columns)
- **APIs:** `GET /api/agents`, `GET /api/tasks`
- **Writes:** `POST /api/tasks`, `PATCH /api/tasks/${id}` (drag to change status), `PATCH /api/tasks/${activeTask.id}`, `POST /api/tasks/reorder` (drag to reorder within column)
- **UI elements:**
  - 4-column Kanban board (drag-and-drop via @dnd-kit)
  - Task cards (title, priority, assignee avatar, progress bar)
  - Drag handles for reordering
- **Status:** ✅ Fully functional

#### 3.1.3 `task-dag` — Task DAG
- **File:** `src/components/tabs/TaskDagTab.tsx` (259 lines)
- **Purpose:** DAG (directed acyclic graph) view of task dependencies
- **APIs:** `GET /api/tasks`, `GET /api/tasks/graph`
- **Writes:** `POST /api/tasks/links` (create dependency edge)
- **UI elements:**
  - DAG visualization (tasks as nodes, dependencies as edges)
  - Click node → task detail
  - Drag to create dependency edge
- **Status:** ✅ Fully functional

### 3.2 `goals` — Goals (standalone)
- **File:** `src/components/tabs/GoalsTab.tsx` (427 lines)
- **Purpose:** Strategic goals (long-term, mid-term, short-term) with hierarchical parent/child relationships
- **APIs:** `GET /api/goals?status=${status}&horizon=${horizon}&category=${category}&parent=${parentParam}`
- **Writes:** `POST /api/goals` (create), `PATCH /api/goals/${id}` (update), `DELETE /api/goals/${id}`
- **UI elements:**
  - Goal tree (parent → children hierarchy)
  - Filter by horizon (long/mid/short), status, category
  - Create/edit goal dialog
  - Progress tracking
- **Status:** ✅ Fully functional

---

## Group 4: Intelligence (3 sidebar entries, 13 tabs)

### 4.1 `skills` — Skills (merged, 7 sub-tabs)

#### 4.1.1 `catalog` — Catalog
- **File:** `src/components/tabs/SkillsTab.tsx` (223 lines)
- **Purpose:** The 65-skill catalog (browse, enable/disable, configure)
- **APIs:** `GET /api/skills`, `GET /api/reasoning` (skill categories)
- **Writes:** `PATCH /api/skills/${key}` (toggle enable, update config)
- **UI elements:**
  - Skill grid (65 cards) — icon, name, description, category, enabled toggle, run count
  - Filter by category
  - Configure skill dialog
- **Status:** ✅ Fully functional

#### 4.1.2 `runner` — Runner
- **File:** `src/components/tabs/SkillRunnerTab.tsx` (247 lines)
- **Purpose:** Execute a skill with custom input + see output
- **APIs:** `GET /api/skills/history?limit=8` (recent runs)
- **Writes:** None (skill execution happens via `/api/skills` or `/api/agent-exec`)
- **UI elements:**
  - Skill selector dropdown
  - Input box (JSON or text)
  - Run button
  - Output panel (with markdown rendering)
  - Recent runs list
- **Status:** ✅ Fully functional

#### 4.1.3 `chain` — Pipeline
- **File:** `src/components/tabs/SkillChainTab.tsx` (469 lines)
- **Purpose:** Chain multiple skills into a pipeline (output of one → input of next)
- **APIs:** `GET /api/pipelines`, `GET /api/pipelines?community=true` (community-shared pipelines)
- **Writes:** `POST /api/pipelines` (create), `PATCH /api/pipelines/${id}` (update)
- **UI elements:**
  - Pipeline builder (drag skills to add to chain)
  - Pipeline list (yours + community)
  - Execute pipeline button
  - Execution trace (per-step output)
- **Status:** ✅ Fully functional

#### 4.1.4 `matrix` — Matrix
- **File:** `src/components/tabs/SkillsMatrixTab.tsx` (382 lines)
- **Purpose:** Matrix view of which agents have which skills (gaps + coverage)
- **APIs:** `GET /api/learning` (agent-skill assignments)
- **Writes:** None
- **UI elements:**
  - Agent × Skill matrix (green = mastered, yellow = learning, red = gap)
  - Filter by skill category
  - Click cell → training history
- **Status:** ✅ Fully functional

#### 4.1.5 `training-dashboard` — Dashboard
- **File:** `src/components/tabs/TrainingDashboardTab.tsx` (407 lines)
- **Purpose:** Training progress dashboard (which agents are learning what, success rates)
- **APIs:** `GET /api/training-dashboard`
- **Writes:** None
- **UI elements:**
  - Training completion gauge
  - Per-agent training progress
  - Success rate trends
- **Status:** ✅ Fully functional

#### 4.1.6 `gap` — Gap Analysis
- **File:** `src/components/tabs/SkillGapAnalyzerTab.tsx` (400 lines)
- **Purpose:** Identify skill gaps in the fleet + recommend training
- **APIs:** `GET /api/skills/gap-analysis`
- **Writes:** None
- **UI elements:**
  - Gap heatmap (skill × department)
  - Recommended training list
  - Auto-generate training schedule button
- **Status:** ✅ Fully functional

#### 4.1.7 `training` — Training
- **File:** `src/components/tabs/TrainingSchedulerTab.tsx` (432 lines)
- **Purpose:** Schedule + manage training sessions for agents
- **APIs:** `GET /api/scheduled-autonomy`, `GET /api/skills/gap-analysis`
- **Writes:** `POST /api/scheduled-autonomy/${id}` (schedule), `PATCH /api/scheduled-autonomy/${schedule.id}` (update)
- **UI elements:**
  - Training schedule calendar
  - Create training session dialog
  - Upcoming sessions list
- **Status:** ✅ Fully functional

### 4.2 `autonomy` — Autonomy Loop (standalone)
- **File:** `src/components/tabs/AutonomyTab.tsx` (1044 lines)
- **Purpose:** Configure + monitor the autonomous decision loop
- **APIs:** `GET /api/agents`, `GET /api/agent/compare?a=${aId}&b=${bId}`, `GET /api/agent/history?limit=15`, `GET /api/autonomy-templates`, `GET /api/scheduled-autonomy`
- **Writes:** `POST /api/agent/autonomy`, `POST /api/autonomy-templates`, `PATCH /api/autonomy-templates/${id}`, `POST /api/scheduled-autonomy`, `PATCH /api/scheduled-autonomy/${id}`
- **Fetches:** `GET /api/agent/history`
- **UI elements:**
  - Autonomy templates (create/edit/delete)
  - Scheduled autonomy runs (calendar view)
  - Parallel orchestrator mode toggle (localStorage: `jarvis-autonomy-parallel`)
  - Agent comparison (select 2 agents → side-by-side autonomy history)
  - Run-now button
- **Status:** ✅ Fully functional

### 4.3 `models` — AI Models (merged, 5 sub-tabs)

#### 4.3.1 `models-list` — Models
- **File:** `src/components/tabs/ModelsTab.tsx` (1127 lines)
- **Purpose:** The 464-model catalog (browse, enable/disable, configure, health-check)
- **APIs:** `GET /api/providers`
- **Writes:** `PATCH /api/models/${id}` (toggle), `PATCH /api/providers/${id}` (update provider config)
- **UI elements:**
  - Model table (464 rows) — name, provider, context window, cost, enabled
  - Filter by provider, capability (vision, code, reasoning, etc.)
  - Health check button (per model)
  - Provider config dialog
- **Status:** ✅ Fully functional

#### 4.3.2 `providers` — Providers
- **File:** `src/components/tabs/ProvidersTab.tsx` (73 lines)
- **Purpose:** List of configured LLM providers (Z-AI, Groq, NVIDIA, etc.)
- **APIs:** `GET /api/providers`
- **Writes:** None
- **UI elements:** Provider list with key configured indicator, latency, token usage
- **Status:** ✅ Functional but minimal (most provider management is in Models tab)

#### 4.3.3 `comparison` — Compare
- **File:** `src/components/tabs/ComparisonTab.tsx` (381 lines)
- **Purpose:** Side-by-side model comparison (run same prompt across 2-3 models)
- **APIs:** `GET /api/models`
- **Writes:** `POST /api/compare` (run comparison)
- **UI elements:**
  - Model selector (2-3 dropdowns)
  - Prompt input
  - Run comparison button
  - Output panels (one per model) with latency + token count
- **Status:** ✅ Fully functional

#### 4.3.4 `diversity` — Diversity
- **File:** `src/components/tabs/ModelDiversityTab.tsx` (553 lines)
- **Purpose:** Model diversity analysis (are we over-reliant on one provider?)
- **APIs:** `GET /api/agent-models?includeAgents=1`, `GET /api/models`
- **Writes:** None
- **UI elements:**
  - Provider distribution pie chart
  - Model usage heatmap (agent × model)
  - Diversity score (0-100)
  - Recommendations ("diversify by assigning Provider X to Agent Y")
- **Status:** ✅ Fully functional

#### 4.3.5 `browser` — Browser Models
- **File:** `src/components/tabs/BrowserModelsTab.tsx` (311 lines)
- **Purpose:** Models accessible via browser login sessions/playgrounds (free tier harvesting)
- **APIs:** `GET /api/models/browser`
- **Writes:** None
- **UI elements:**
  - Browser-accessible model list (with playground URL)
  - Session status indicator (logged in / out)
  - "Open playground" button
- **Status:** ✅ Fully functional

---

## Group 5: Knowledge Base (6 sidebar entries, 9 tabs)

### 5.1 `memory` — Memory (merged, 2 sub-tabs)

#### 5.1.1 `store` — Store
- **File:** `src/components/tabs/MemoryTab.tsx` (194 lines)
- **Purpose:** Key-value memory store (MemoryItem table — scope, key, value, tags, pinned)
- **APIs:** `GET /api/memory?scope=${scope}&q=${q}`
- **Writes:** `POST /api/memory` (create), `PATCH /api/memory/${id}` (update), `DELETE /api/memory/${id}`
- **UI elements:**
  - Memory item list (key, scope, value preview, pinned indicator)
  - Filter by scope + search
  - Create/edit dialog
- **Status:** ✅ Fully functional

#### 5.1.2 `graph` — Graph
- **File:** `src/components/tabs/MemoryGraphTab.tsx` (326 lines)
- **Purpose:** Knowledge graph visualization (MemoryItem nodes + semantic relationships)
- **APIs:** `GET /api/memory/graph`
- **Writes:** None
- **UI elements:**
  - Force-directed graph (memory items as nodes, relationships as edges)
  - Click node → detail panel
  - Filter by scope
- **Status:** ✅ Fully functional

### 5.2 `learning` — Learn & Earn (merged, 2 sub-tabs)

#### 5.2.1 `learning` — Learning
- **File:** `src/components/tabs/LearningTab.tsx` (579 lines)
- **Purpose:** Learning resources + auto-categorization + teach-from-source
- **APIs:** `GET /api/learning/teach`
- **Writes:** None directly (uses sub-routes)
- **UI elements:**
  - Learning resource list
  - Auto-categorize button
  - Auto-move (progress tracking)
  - Teach-from-source card
- **Status:** ✅ Fully functional

#### 5.2.2 `teach` — Teach
- **File:** `src/components/tabs/TeachSourceCard.tsx` (card component, not a full tab)
- **Purpose:** Teach ARIA from a source (URL, file, text) — extracts knowledge → MemoryItem
- **APIs:** (uses `/api/learning/teach`)
- **Writes:** `POST /api/learning/teach`
- **UI elements:**
  - Source type selector (URL, file, text)
  - Source input
  - Teach button
  - Extracted knowledge preview
- **Status:** ✅ Fully functional

### 5.3 `knowledge-daemon` — Knowledge Daemon (standalone)
- **File:** `src/components/tabs/KnowledgeDaemonTab.tsx` (1320 lines — 2nd biggest tab)
- **Purpose:** Autonomous knowledge ingestion flow — daemon continuously ingests, deduplicates, and consolidates knowledge
- **APIs:** `GET /api/knowledge-daemon/flow`
- **Writes:** `POST /api/knowledge-daemon/sync` (trigger sync), `POST /api/knowledge-daemon/contribute`
- **UI elements:**
  - Flow diagram (ingestion → dedup → consolidation → memory)
  - Sync status + trigger button
  - Contribute form (add knowledge manually)
  - Daemon stats (items ingested, deduplicated, consolidated)
- **Status:** ✅ Fully functional

### 5.4 `rules` — Operator Rules (standalone)
- **File:** `src/components/tabs/RulesTab.tsx` (257 lines)
- **Purpose:** Operator-defined rules (constraints on autonomous behavior, like "never delete files without approval")
- **APIs:** `GET /api/rules?category=${category}`
- **Writes:** `POST /api/rules`, `PATCH /api/rules/${id}`, `DELETE /api/rules/${rule.id}`
- **UI elements:**
  - Rule list (category, condition, action, enabled)
  - Filter by category
  - Create/edit dialog
- **Status:** ✅ Fully functional

### 5.5 `plugins` — Plugins (standalone)
- **File:** `src/components/tabs/PluginsTab.tsx` (268 lines)
- **Purpose:** Plugin management (install/enable/configure external plugins)
- **APIs:** `GET /api/plugins?category=${category}`
- **Writes:** `POST /api/plugins`, `PATCH /api/plugins/${id}`, `DELETE /api/plugins/${plugin.id}`
- **UI elements:**
  - Plugin list (name, category, version, enabled)
  - Filter by category
  - Install/edit dialog
- **Status:** ✅ Fully functional

### 5.6 `artifacts` — Artifacts (standalone)
- **File:** `src/components/tabs/ArtifactsTab.tsx` (73 lines)
- **Purpose:** Generated artifacts (code, documents, images, etc.) — ARIA's "artifact" system inspired by Claude
- **APIs:** `GET /api/artifacts`
- **Writes:** None (artifacts are created by other workflows)
- **UI elements:**
  - Artifact grid (type, name, preview, created)
  - Filter by type
  - Download button
- **Status:** ⚠️ Basic — only lists artifacts, no creation/edit UI (creation happens via chat/IDE)

---

## Group 6: Monitoring & Ops (6 sidebar entries, 14 tabs)

### 6.1 `system-health` — System Health (merged, 3 sub-tabs)

#### 6.1.1 `overview` — Overview
- **File:** `src/components/tabs/SystemHealthTab.tsx` (579 lines)
- **Purpose:** Overall system health — background services status, KPIs, forecasts, smart-router health, db-sync status
- **APIs:** `GET /api/agent-models`, `GET /api/db-sync`, `GET /api/forecasts`, `GET /api/kpis`, `GET /api/realtime/status`, `GET /api/smart-router`
- **Writes:** None
- **UI elements:**
  - Service status grid (7 services with health indicators)
  - KPI cards (CPU, mem, agents, tasks, revenue)
  - Forecast charts
  - Smart-router health panel
  - db-sync status panel (disabled per Rule 9.1)
- **Status:** ✅ Fully functional

#### 6.1.2 `kpi-trends` — KPI Trends
- **File:** `src/components/tabs/KpiTrendsTab.tsx` (392 lines)
- **Purpose:** Historical KPI trends (CPU, mem, agents, tasks, revenue over time)
- **APIs:** `GET /api/kpis`, `GET /api/kpis/history?limit=${limit}`, `GET /api/forecasts/history?limit=${limit}`
- **Writes:** `POST /api/kpis` (define a new KPI)
- **UI elements:**
  - KPI selector
  - Time-series chart (Recharts)
  - Forecast overlay
  - KPI definition dialog
- **Status:** ✅ Fully functional

#### 6.1.3 `realtime-log` — Realtime Log
- **File:** `src/components/tabs/RealtimeEventLogTab.tsx` (352 lines)
- **Purpose:** Live event stream (agent:heartbeat, task:update, decision:new, alert:critical, etc.)
- **APIs:** `GET /api/realtime/status`
- **Writes:** `POST /api/realtime/events` (emit a test event)
- **UI elements:**
  - Real-time event list (auto-scrolling)
  - Filter by event type
  - Connection status indicator (Socket.IO + SSE)
- **Status:** ✅ Fully functional

### 6.2 `telemetry` — Telemetry (standalone)
- **File:** `src/components/tabs/TelemetryTab.tsx` (120 lines)
- **Purpose:** Live system telemetry (CPU, mem, disk, net, latency, tokens) + historical series
- **APIs:** `GET /api/metrics` (polls every 8s)
- **Writes:** None
- **UI elements:**
  - Current metrics cards (CPU, MEM, DISK, NET, LAT, TOK)
  - Time-series charts (CPU/mem/disk over last 30 samples)
  - Agent load distribution bar chart
- **Status:** ✅ Fully functional

### 6.3 `health` — Health (merged, 3 sub-tabs)

#### 6.3.1 `fleet-health` — Fleet Health
- **File:** `src/components/tabs/HealthTab.tsx` (861 lines)
- **Purpose:** Fleet health dashboard (agent status distribution, error rates, stuck agents)
- **APIs:** `GET /api/health`
- **Writes:** None
- **UI elements:**
  - Status pie chart (idle/working/error/offline)
  - Error agent list with restart buttons
  - Stuck agent list (>10min in working state)
  - Health timeline
- **Status:** ✅ Fully functional

#### 6.3.2 `service-health` — Services
- **File:** `src/components/tabs/ServiceHealthTab.tsx` (417 lines)
- **Purpose:** External service health (LLM providers, payment gateways, Telegram, email, etc.)
- **APIs:** `GET /api/service-health`
- **Writes:** None (uses `/api/service-health/check` for manual checks)
- **UI elements:**
  - Service grid (name, status, latency, last-checked)
  - Manual check button per service
  - Health history chart
- **Status:** ✅ Fully functional

#### 6.3.3 `agent-monitor` — Agent Monitor
- **File:** `src/components/tabs/AgentMonitorTab.tsx` (864 lines)
- **Purpose:** Findings from the 8 monitoring agents (fleet-watchdog, api-sentinel, etc.)
- **APIs:** (uses `/api/agent-monitors/findings`)
- **Writes:** `PATCH /api/agent-monitors/findings/${id}` (resolve finding), `POST /api/agent-monitors/findings/${id}/create-task` (promote finding to task)
- **UI elements:**
  - Findings list (severity, monitor, title, detail, status, created)
  - Filter by severity + status
  - Resolve button
  - "Create Task" button (promotes finding to a task)
- **Status:** ✅ Fully functional

### 6.4 `logs` — Logs (merged, 3 sub-tabs)

#### 6.4.1 `system-logs` — System Logs
- **File:** `src/components/tabs/LogsTab.tsx` (90 lines)
- **Purpose:** System logs (agent logs from the AgentLog table)
- **APIs:** `GET /api/logs?level=${level}&agent=${agent}&limit=200`
- **Writes:** None
- **UI elements:**
  - Log list (timestamp, agent, level, message)
  - Filter by level (info/warn/error/debug/success) + agent
- **Status:** ✅ Fully functional

#### 6.4.2 `blackbox` — Black Box
- **File:** `src/components/tabs/BlackboxTab.tsx` (262 lines)
- **Purpose:** Flight-recorder style black box — captures every critical event for post-incident analysis
- **APIs:** (uses `/api/blackbox`)
- **Writes:** None
- **UI elements:**
  - Black box event list (timestamp, type, severity, detail)
  - Filter by type + severity
  - Export to JSON
- **Status:** ✅ Fully functional

#### 6.4.3 `action-log` — Action Log
- **File:** `src/components/tabs/ActionLogTab.tsx` (125 lines)
- **Purpose:** Reversible action audit log (every state-changing action with before/after)
- **APIs:** (uses `/api/action-log`)
- **Writes:** `POST /api/action-log/${id}/reverse` (reverse an action)
- **UI elements:**
  - Action list (actor, action, target, before, after, reversible, timestamp)
  - Reverse button (for reversible actions)
- **Status:** ✅ Fully functional

### 6.5 `governance` — Governance (merged, 3 sub-tabs)

#### 6.5.1 `approvals` — Approvals
- **File:** `src/components/tabs/ApprovalsTab.tsx` (563 lines)
- **Purpose:** Approval queue (pending approvals for risky autonomous actions)
- **APIs:** (uses `/api/approvals`)
- **Writes:** `POST /api/approvals` (create), `PATCH /api/approvals/${id}` (approve/reject), `POST /api/approvals/escalate` (manual escalate)
- **UI elements:**
  - Pending approvals list (title, description, category, requested by, timeout countdown)
  - Approve / Reject buttons
  - Escalate button
  - Approval history
- **Status:** ✅ Fully functional

#### 6.5.2 `verification` — Verification
- **File:** `src/components/tabs/VerificationTab.tsx` (161 lines)
- **Purpose:** Output verification queue (verifies agent outputs before commit)
- **APIs:** None (uses postJson)
- **Writes:** `POST /api/verifications` (create verification), `POST /api/verifications/${id}/question` (ask clarifying question)
- **UI elements:**
  - Verification queue (output, verifier, status, score)
  - Approve / Reject / Question buttons
- **Status:** ✅ Fully functional

#### 6.5.3 `change-requests` — Change Requests
- **File:** `src/components/tabs/ChangeRequestsTab.tsx` (164 lines)
- **Purpose:** Change requests (gated changes to the system — config, code, schema)
- **APIs:** `GET /api/changes?stats=1`
- **Writes:** `POST /api/changes` (create), `PATCH /api/changes/${id}` (approve/reject)
- **UI elements:**
  - Change request list (title, type, requester, status, diff preview)
  - Approve / Reject buttons
  - Diff viewer
- **Status:** ✅ Fully functional

### 6.6 `scheduler` — Scheduler (standalone)
- **File:** `src/components/tabs/SchedulerTab.tsx` (131 lines)
- **Purpose:** Cron job scheduler (view/enable/disable/run cron jobs)
- **APIs:** `GET /api/cron`
- **Writes:** `PATCH /api/cron/${id}` (toggle enable), `POST /api/cron/${id}/run` (manual run)
- **Fetches:** `GET /api/reports/schedule` (scheduled reports)
- **UI elements:**
  - Cron job list (key, schedule, enabled, last run, run count)
  - Toggle enable
  - Run-now button
  - Run history
- **Status:** ✅ Fully functional

---

## Group 7: Business & Revenue (5 sidebar entries, 12 tabs)

### 7.1 `payments` — Payments (merged, 4 sub-tabs)

#### 7.1.1 `payments-list` — Payments
- **File:** `src/components/tabs/PaymentsTab.tsx` (306 lines)
- **Purpose:** Payment list (incoming + outgoing, status: pending/confirmed/failed)
- **APIs:** `GET /api/payments`, `GET /api/payments/trend`
- **Writes:** `POST /api/payments` (manual entry)
- **UI elements:**
  - Payment table (amount, status, method, client, created)
  - Trend chart
  - Filter by status + method
  - Manual entry dialog
- **Status:** ✅ Fully functional (but payment gateway keys are empty in .env)

#### 7.1.2 `payment-methods` — Payout Methods
- **File:** `src/components/tabs/PaymentMethodsTab.tsx` (865 lines)
- **Purpose:** Payout method management (bank accounts, UPI IDs, cards — for paying out earned revenue)
- **APIs:** `GET /api/payment-methods`, `GET /api/payments`
- **Writes:** `POST /api/payment-methods`, `PATCH /api/payment-methods/${id}`, `DELETE /api/payment-methods/${id}`, `POST /api/payment-methods/${id}/verify`
- **UI elements:**
  - Method list (type, identifier, verified, default)
  - Add/edit/delete method
  - Verify button (micro-deposit verification)
- **Status:** ✅ Fully functional

#### 7.1.3 `checkout` — Checkout
- **File:** `src/components/tabs/PaymentCheckoutTab.tsx` (547 lines)
- **Purpose:** Generate checkout links for clients (Razorpay/Stripe/UPI)
- **APIs:** `GET /api/payments/gateway-status`, `GET /api/payments/orders`
- **Writes:** None (uses `/api/payments/create-order` via fetch)
- **UI elements:**
  - Gateway status indicators (Razorpay/Stripe/UPI)
  - Order list
  - Create checkout link dialog
  - QR code display (for UPI)
- **Status:** ✅ Fully functional

#### 7.1.4 `revenue` — Revenue
- **File:** `src/components/tabs/RevenueDashboardTab.tsx` (433 lines)
- **Purpose:** Revenue dashboard (confirmed vs pending, trends, forecasts)
- **APIs:** `GET /api/revenue/dashboard`
- **Writes:** None
- **UI elements:**
  - Revenue KPI cards (today, week, month, total)
  - Confirmed vs pending chart
  - Revenue trend (30-day)
  - Forecast chart
- **Status:** ✅ Fully functional

### 7.2 `earning` — Earning (merged, 3 sub-tabs)

#### 7.2.1 `earning-engine` — Earning Engine
- **File:** `src/components/tabs/EarningEngineTab.tsx` (225 lines)
- **Purpose:** Top-level earning engine status (total earned, active methods, dispatch rate)
- **APIs:** `GET /api/earning-engine`
- **Writes:** `POST /api/earning-engine` (trigger engine run)
- **UI elements:**
  - Earning KPI cards (today, week, month, total)
  - Active methods count
  - Dispatch rate gauge
  - Trigger run button
- **Status:** ✅ Fully functional

#### 7.2.2 `earning-methods` — Methods
- **File:** `src/components/tabs/EarningMethodsTab.tsx` (926 lines)
- **Purpose:** Earning methods catalog (approved methods for generating revenue)
- **APIs:** `GET /api/credentials`, `GET /api/earning-methods`
- **Writes:** `POST /api/credentials`, `PATCH /api/credentials/${id}`, `PATCH /api/earning-methods/${id}`, `POST /api/earning-methods/${id}/feedback`
- **Fetches:** `GET /api/credentials/${id}?reveal=1` (reveal secret), `GET /api/earning-methods/research` (LLM generates new methods)
- **UI elements:**
  - Method list (name, category, earning potential, enabled, last executed)
  - Filter by category + potential
  - Approve/reject method
  - Feedback button
  - "Research new methods" button (LLM-powered)
  - Credentials vault (encrypted storage for method API keys)
- **Status:** ✅ Fully functional

#### 7.2.3 `csat` — CSAT Surveys
- **File:** `src/components/tabs/CsatTab.tsx` (408 lines)
- **Purpose:** Customer satisfaction (CSAT) survey management
- **APIs:** `GET /api/csat`
- **Writes:** `POST /api/csat/schedule` (schedule a survey)
- **UI elements:**
  - CSAT score gauge (0-100)
  - Survey list (client, score, feedback, date)
  - Schedule survey dialog
- **Status:** ✅ Fully functional

### 7.3 `crm` — CRM (standalone)
- **File:** `src/components/tabs/CRMTab.tsx` (791 lines)
- **Purpose:** Customer relationship management (clients, leads, tickets)
- **APIs:** `GET /api/clients`, `GET /api/leads`, `GET /api/tickets`
- **Writes:** `POST /api/clients`, `PATCH /api/clients/${id}`, `POST /api/leads`, `PATCH /api/leads/${id}`, `POST /api/leads/${id}?action=convert` (lead→client), `POST /api/tickets`, `PATCH /api/tickets/${id}`
- **UI elements:**
  - 3-column layout: Clients | Leads | Tickets
  - Each column has list + create/edit/delete
  - Lead → Client conversion button
  - Ticket status workflow
- **Status:** ✅ Fully functional

### 7.4 `analytics` — Analytics (merged, 2 sub-tabs)

#### 7.4.1 `analytics` — Analytics
- **File:** `src/components/tabs/AnalyticsTab.tsx` (350 lines)
- **Purpose:** Agent performance analytics (success rate, task throughput, model usage)
- **APIs:** `GET /api/agents/analytics?range=${range}`
- **Writes:** None
- **UI elements:**
  - Time range selector (7d, 30d, 90d, all)
  - Agent performance leaderboard
  - Task throughput chart
  - Model usage distribution
- **Status:** ✅ Fully functional

#### 7.4.2 `reports` — Reports
- **File:** `src/components/tabs/ReportsTab.tsx` (295 lines)
- **Purpose:** Generated reports (daily diffs, scheduled reports, PDF export)
- **APIs:** `GET /api/reports/diff`, `GET /api/reports/diffs`
- **Fetches:** `GET /api/reports/daily`, `GET /api/reports/diff?a=${aId}&b=${bId}`, `GET /api/reports/diffs`
- **Writes:** None (report generation is server-side)
- **UI elements:**
  - Report list (type, generated-at, summary)
  - Diff viewer (compare two reports)
  - Schedule reports dialog
  - Download PDF button
- **Status:** ✅ Fully functional

### 7.5 `services` — Services Hub (standalone)
- **File:** `src/components/tabs/ServicesHubTab.tsx` (165 lines)
- **Purpose:** Services marketplace (services ARIA can offer to clients — QA-as-a-Service, API testing, etc.)
- **APIs:** `GET /api/services`
- **Writes:** None
- **UI elements:**
  - Service grid (name, description, price, enabled)
  - Filter by category
- **Status:** ✅ Functional but basic (no CRUD — services are seeded)

---

## Group 8: System & Admin (3 sidebar entries, 5 tabs)

### 8.1 `developer` — Developer (merged, 4 sub-tabs)

#### 8.1.1 `ide` — IDE
- **File:** `src/components/tabs/IdeTab.tsx` (668 lines)
- **Purpose:** In-browser IDE (file explorer + code editor + terminal)
- **APIs:** None (uses postJson/fetch directly)
- **Writes:** `POST /api/file/read`, `POST /api/file/write`, `POST /api/workspace/list`
- **Fetches:** `GET /api/file`
- **UI elements:**
  - File explorer tree
  - Code editor (@mdxeditor with syntax highlighting)
  - Tab bar (open files)
  - Save button
- **Status:** ✅ Fully functional

#### 8.1.2 `terminal` — Terminal
- **File:** `src/components/tabs/TerminalTab.tsx` (285 lines)
- **Purpose:** In-browser terminal (executes shell commands via `/api/terminal/exec`)
- **APIs:** None (uses fetch)
- **Writes:** None (uses `POST /api/terminal/exec` via fetch)
- **UI elements:**
  - Terminal output panel (xterm-style)
  - Command input
  - Working directory indicator
- **Status:** ✅ Fully functional (⚠️ SECURITY: dev bypass enabled — see LIMITATIONS)

#### 8.1.3 `files` — Files
- **File:** `src/components/tabs/FilesTab.tsx` (646 lines)
- **Purpose:** File browser (upload, download, mkdir, delete)
- **APIs:** None (uses fetch)
- **Fetches:** `GET /api/file`
- **Writes:** (uses `POST /api/file/write`, `POST /api/file/mkdir`, `DELETE` via fetch)
- **UI elements:**
  - File list (name, size, modified, permissions)
  - Upload button
  - Mkdir button
  - Download button
  - Delete button
- **Status:** ✅ Fully functional

#### 8.1.4 `apptree` — App Tree
- **File:** `src/components/tabs/AppTreeTab.tsx` (228 lines)
- **Purpose:** ARIA's own source tree (self-introspection — browse the app's source files)
- **APIs:** `GET /api/apptree`
- **Writes:** None
- **UI elements:**
  - Directory tree (collapsible)
  - File preview
  - Line count + size per file
- **Status:** ✅ Fully functional

### 8.2 `data-mgmt` — Data Management (standalone)
- **File:** `src/components/tabs/DataManagementTab.tsx` (790 lines)
- **Purpose:** Data management (export, import, reset, counts per table)
- **APIs:** `GET /api/admin/data`, `GET /api/admin/data/counts`
- **Fetches:** `GET /api/admin/data` (export)
- **Writes:** (uses `POST /api/admin/reset-data` via fetch for reset)
- **UI elements:**
  - Table counts grid (Agent, Task, Payment, etc.)
  - Export button (per table)
  - Import button
  - Reset data button (⚠️ destructive)
- **Status:** ✅ Fully functional

### 8.3 `branding` — Branding (standalone)
- **File:** `src/components/tabs/BrandingTab.tsx` (373 lines)
- **Purpose:** White-label branding (operator name, company name, logo, colors)
- **APIs:** `GET /api/branding`
- **Writes:** `POST /api/branding` (update branding)
- **UI elements:**
  - Branding form (operator name, company, logo URL, accent color)
  - Live preview
  - Save button
- **Status:** ✅ Fully functional

---

## Summary Statistics

| Metric | Count |
|---|---|
| Sidebar groups | 8 |
| Sidebar entries | 31 |
| Standalone tabs | 14 |
| Merged tabs | 17 (with 62 sub-tabs) |
| **Total tab components** | **76** |
| Tabs fully functional | 75 |
| Tabs basic / partial | 1 (ArtifactsTab) |
| Tabs broken | 0 |
| Total lines of tab code | ~32,000 |
| Biggest tab | FleetTab (1634 lines) |
| Smallest tab | LogsTab (90 lines) |
| API endpoints used | ~95 unique endpoints |
| Write operations | ~60 tabs have at least one POST/PATCH/DELETE |
