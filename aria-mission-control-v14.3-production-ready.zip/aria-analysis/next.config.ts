import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow access from local network IPs (e.g. http://192.168.0.10:3000)
  // without Next.js blocking the cross-origin dev resource requests.
  allowedDevOrigins: ["192.168.0.10", "192.168.0.6", "localhost", "127.0.0.1"],
};

export default nextConfig;
