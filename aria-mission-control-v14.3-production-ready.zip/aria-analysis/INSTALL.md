# ARIA Mission Control v11.4 — Complete Setup Guide

## ⚠️ CRITICAL: If upgrading from a previous version

If you have an old `db/custom.db` from a previous ARIA version, you MUST delete it first.
The old schema is incompatible with v11. Running `prisma db push` on an old DB will fail
with "cannot add required column" errors.

```powershell
# Delete old database (Windows)
del db\custom.db
del db\custom.db-journal    # if exists

# Or on Linux/Mac
rm -f db/custom.db db/custom.db-journal
```

---

## Prerequisites
- **Bun** (runtime + package manager): https://bun.sh
- **Node.js 18+** (for some tooling)

---

## Windows Setup (PowerShell)

```powershell
# 1. Extract the zip
Expand-Archive aria-v11-production.zip -DestinationPath D:\aria-v11-production
cd D:\aria-v11-production

# 2. Install main app dependencies
bun install

# 3. Install realtime service dependencies
cd mini-services\realtime
bun install
cd ..\..

# 4. Create database directory
mkdir -p db -Force

# 5. ⚠️ DELETE OLD DATABASE if upgrading (CRITICAL!)
# Skip this only if this is a fresh install with no existing db/custom.db
del db\custom.db -ErrorAction SilentlyContinue
del db\custom.db-journal -ErrorAction SilentlyContinue

# 6. Verify .env has the correct DATABASE_URL
# It should be: DATABASE_URL=file:./db/custom.db
# If it shows a Linux path like /home/z/my-project/..., fix it:
# Open .env in a text editor and change the line to:
#   DATABASE_URL=file:./db/custom.db

# 7. Push database schema (creates all 55 tables in a fresh DB)
bunx prisma db push --accept-data-loss

# 8. Generate Prisma Client
bunx prisma generate

# 9. Seed the database (run ALL scripts in this exact order)
bunx tsx scripts/seed.ts                    # Core: 64 agents, 20 skills, 29 cron jobs, memory, notifications
bunx tsx scripts/seed-add.ts                # Additional: tasks, payments, artifacts, comms, extra memory
bunx tsx scripts/seed-rules.ts              # 69 operator rules
bunx tsx scripts/seed-providers-models.ts   # LLM providers (23) + initial models (446)
bunx tsx scripts/seed-models.ts             # 60 v11 models across 16 providers (smart-router catalog)
bunx tsx scripts/seed-earning-methods.ts    # 5 earning methods
bunx tsx scripts/seed-workforce.ts          # 16 departments + 64 workforce agents (org chart)
bunx tsx scripts/seed-skill-learning.ts     # Skill proficiency for all 64 agents (408 records)
bunx tsx scripts/seed-comms.ts              # 80 inter-agent messages (for collaboration graph)
bunx tsx scripts/seed-realtime-events.ts    # 40 realtime events (for event log tab)

# 10. Fix the dev script for Windows (remove tee pipe)
(Get-Content package.json -Raw) -replace '"next dev -p 3000 2>&1 \| tee dev\.log"', '"next dev -p 3000"' | Set-Content package.json

# 11. Start the dev server
bun run dev
# → opens on http://localhost:3000

# 12. Start the realtime WebSocket service (in a SEPARATE terminal)
cd mini-services\realtime
bun run dev
cd ..\..
# → runs on port 3003
```

---

## Linux/Mac Setup

```bash
# 1. Extract
unzip aria-v11-production.zip -d aria-v11-production
cd aria-v11-production

# 2. Install deps
bun install
cd mini-services/realtime && bun install && cd ../..

# 3. Create db directory + delete old DB if upgrading
mkdir -p db
rm -f db/custom.db db/custom.db-journal

# 4. Verify .env DATABASE_URL is: file:./db/custom.db
# If it shows /home/z/my-project/..., change it to: file:./db/custom.db

# 5. Push schema + generate
bunx prisma db push --accept-data-loss
bunx prisma generate

# 6. Seed ALL data (in order)
bunx tsx scripts/seed.ts
bunx tsx scripts/seed-add.ts
bunx tsx scripts/seed-rules.ts
bunx tsx scripts/seed-providers-models.ts
bunx tsx scripts/seed-models.ts
bunx tsx scripts/seed-earning-methods.ts
bunx tsx scripts/seed-workforce.ts
bunx tsx scripts/seed-skill-learning.ts
bunx tsx scripts/seed-comms.ts
bunx tsx scripts/seed-realtime-events.ts

# 7. Start dev server
bun run dev

# 8. Start realtime service (separate terminal)
cd mini-services/realtime && bun run dev && cd ../..
```

---

## Docker (runs everything automatically)

```bash
docker compose up -d
# → app on :3000, realtime on :3003, postgres on :5432, caddy on :80
```

---

## Troubleshooting

### Error: "cannot add required column" during prisma db push
**Cause**: You have an old `db/custom.db` from a previous version.
**Fix**: Delete it and retry:
```powershell
del db\custom.db
del db\custom.db-journal -ErrorAction SilentlyContinue
bunx prisma db push --accept-data-loss
```

### Error: "column codename does not exist"
**Cause**: Same as above — old DB schema doesn't have v11 columns.
**Fix**: Delete old DB, push schema, then re-seed.

### Error: "table main.CronJob does not exist"
**Cause**: Schema push didn't complete successfully.
**Fix**: Delete db/custom.db, then:
```powershell
bunx prisma db push --accept-data-loss
bunx prisma generate
```

### DATABASE_URL points to /home/z/my-project/...
**Cause**: The .env was created on Linux. On Windows the path doesn't exist.
**Fix**: Open .env and change to:
```
DATABASE_URL=file:./db/custom.db
```

### Realtime service won't start
**Cause**: Dependencies not installed.
**Fix**:
```powershell
cd mini-services\realtime
bun install
bun run dev
```

### App starts but tabs are empty
**Cause**: Seed scripts didn't run or failed.
**Fix**: Re-run all seed scripts in order (see step 9 above).

---

## Post-Setup Verification

After setup, verify these work:

1. Open http://localhost:3000 → ARIA Mission Control dashboard loads
2. **Mission Briefing** → health score + forecasts + recommendations
3. **Agent Fleet** → 64 agents across 16 departments
4. **AI Models → Catalog** → 60+ models
5. **Skills → Matrix** → all 64 agents with proficiency data
6. **System Health** → realtime connection shows "WS" or "LIVE" in header
7. **Operator Rules** → 69 rules
8. **Payments → Revenue** → revenue/cost/profit dashboard

---

## Environment Variables

The `.env` file includes all required variables with placeholders.
On startup, 10 auth keys are auto-generated if empty.

To enable additional LLM providers, fill in:
- OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, OPENROUTER_API_KEY
- DEEPSEEK_API_KEY, COHERE_API_KEY, MISTRAL_API_KEY, TOGETHER_API_KEY

Then click "Sync Models" in AI Models tab to discover all available models.
