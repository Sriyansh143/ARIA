# RULES.md — ARIA Mission Control Permanent Rules

**Owner:** Raviteja Voruganti | Liafon Software Private Limited
**App:** ARIA (Autonomous Responsive Intelligence Assistant)
**Version:** v14.0 — Production-Grade Benchmark Edition
**Last Updated:** 2026-07-24

> **CRITICAL:** This file is APPEND-ONLY. Never delete existing rules. New rules
> are added at the bottom with a sequential Rule number. Rules are unbreakable
> constraints that every agent and every code change MUST obey.

---

## SECTION 1: CORE ARCHITECTURE & DEPLOYMENT

### Rule 1.1 — Local-First, Cloud-Ready
The app runs entirely local-first using local SQLite (`db/custom.db`) and local
file storage for maximum speed, zero latency, and zero cost. The codebase MUST
maintain cloud compatibility (Turso SQLite + Oracle Cloud VM) so it can migrate
seamlessly to a 24/7 cloud environment when ready. See `ROADMAP.md`.

### Rule 1.2 — The "Zero-Scratch" Code Law
Never invent complex UI components, tools, or orchestration systems from
scratch without checking existing resources first. Before implementing anything,
check the uploaded zip (`jarvis-mission-control-final.zip`) and open-source
reference repos (`claude-mem`, `claude-superpowers`, `open-jarvis`). Adapt
existing code to fit ARIA (the Ponytail Principle: the best code is the code
you never wrote).

### Rule 1.3 — Single-Process Singleton Services
Background services (autopilot scheduler, cron scheduler, autonomous loop,
idle-agent dispatcher, env watcher) MUST run as singletons within the server
process. The singleton contract is enforced via `globalThis` mirroring (see
`src/lib/db.ts` and `src/lib/autopilot-scheduler.ts` for the pattern).
Multiple browser clients MUST NEVER spawn multiple background loops.

---

## SECTION 2: THE 480+ MODEL OMNI-ROUTER

### Rule 2.1 — Universal Pool
ARIA utilizes 480+ models aggregated across API keys (`.env`), database vaults,
browser login sessions/playgrounds, free public endpoints, and local instances
(Ollama). The model catalog is auto-synced on startup via
`src/lib/env-watcher.ts` and persisted to the `Model` Prisma table.

### Rule 2.2 — Dynamic Smart Router
Never hardcode a model name in agent scripts. Always query `/api/smart-router`
(or use the `quickChat()` helper which routes through the multi-provider
fallback chain in `src/lib/llm.ts`) to select the optimal model based on task
type (coding, vision, reasoning, fast chat), cost ($0 preference), and latency.

### Rule 2.3 — Automatic Failover
If a provider hits rate limits (HTTP 429) or errors, instantly failover to the
next available model in the 480+ pool without breaking user sessions or
workflows. The fallback chain in `src/lib/llm.ts` covers 11 providers: z-ai,
Groq, SiliconFlow/Qwen, NVIDIA NIM, Ollama, Omniroute, Bytez, HuggingFace,
OpenAI, Anthropic, Google.

---

## SECTION 3: COMPETITIVE BENCHMARKING

### Rule 3.1 — Outperforming Market Leaders
Every feature, module, and workflow in ARIA MUST be continuously upgraded to
production-grade quality by benchmarking against the industry's best platforms:

1. **Teamly AI Benchmark** — Robust project management, crystal-clear
   multi-agent delegation, real-time task tracking, seamless team operational
   flows. Single source of truth for all shared state.
2. **Claude Benchmark** — High-precision code generation, strict structural
   reasoning, artifact support, zero-compromise logic verification.
   Deterministic outputs for identical inputs (state-hash caching).
3. **Gemini Benchmark** — Deep multimodal capabilities and massive-scale
   multi-model routing across the entire 480+ model inventory. Real-time
   push via SSE.
4. **z.ai Benchmark** — Instant app previews, lightning-fast interactive UI
   responsiveness, secure sandboxed code execution. Sub-100ms cache hits.

### Rule 3.2 — Zero Mock Data & Real-World Resilience
Eliminate placeholder states, fake metrics (`Math.random`), and dummy UI
loops. All dashboard widgets, cron telemetry, and agent outputs MUST derive
from live database state or real API responses. Build bulletproof error
handling, auto-recovery layers, and clean fallback states for every component.

---

## SECTION 4: ABSOLUTE FILE PERSISTENCE

### Rule 4.1 — Never Lose Files
Every file write MUST be immediately verified on disk using:
```bash
ls -la <filepath> && wc -l <filepath>
```

### Rule 4.2 — Verification Script
Run `bash scripts/verify-persistence.sh` at the START and END of every
session. The script verifies all critical source files, configuration,
documentation, the database, and the server endpoints. Exit code 0 = all
files persisted; exit code 1 = critical files missing.

### Rule 4.3 — Milestone Commits
Always commit code after major milestones:
```bash
git add -A && git commit -m "feat/fix: <description>"
```

---

## SECTION 5: MANDATORY DOCUMENTATION & AUDIT PROTOCOL

### Rule 5.1 — Every Run Updates the Audit Trail
No run is complete until the audit trail is updated. "I will update docs
later" is a CRITICAL SYSTEM VIOLATION. At the end of every single run, you
MUST update:

1. **`worklog.md`** — Append task ID, absolute file paths created/modified,
   and a stage summary. Append-only — never delete prior entries.
2. **`RULES.md`** — Append any new constraints or workflows established.
   Never delete existing rules.
3. **`APP_DOCUMENTATION.md`** — Reflect any new endpoints, agent capabilities,
   or schema changes.
4. **`ROADMAP.md`** — Check off completed items and update next-up goals
   (including cloud-migration and feature polish).

### Rule 5.2 — Required Run-Summary Output
Every response to the user MUST conclude with the exact markdown block defined
in the master system directive (the "📝 Run Audit Complete" block with
Worklog/Rules/Docs/Open-Source/Router/Benchmarks/Persistence/Pending fields).

---

## SECTION 6: STATE SYNCHRONIZATION (added v14.0 — Briefing Desync Fix)

### Rule 6.1 — Server-Side Source of Truth for Shared State
All shared operational state (autopilot ON/OFF, briefing content, agent
fleet status, task queue, telemetry) MUST live on the server. Browser
clients MUST NOT store shared state in `localStorage`, `sessionStorage`,
or React context. Per-browser storage is reserved for UI preferences only
(theme, sidebar collapse, recently-viewed tabs, notification settings).

### Rule 6.2 — Briefing Cache Layers
The `/api/briefing` endpoint MUST serve all clients identical JSON within
a 30-second TTL window. Three caching layers are MANDATORY:
1. **TTL cache (30s)** — every client within a 30s window gets byte-identical JSON.
2. **State-hash cache (FNV-1a)** — if state hasn't changed, skip the LLM entirely.
3. **Single-flight** — N concurrent cache-miss requests share one in-flight LLM call.

The `?force=1` query parameter bypasses the cache for the Regenerate button.

### Rule 6.3 — Real-Time Push Over Polling
Clients SHOULD subscribe to `/api/briefing/stream` (SSE) for sub-second push
updates. Polling is a fallback only — never the primary update channel.
SSE auto-reconnects after 5s on disconnect and auto-closes after 10 minutes
(clients reconnect).

### Rule 6.4 — No Hardcoded Localhost
Server-side `fetch()` calls MUST NEVER hardcode `http://localhost:3000`. Use
`process.env.DASHBOARD_BASE || 'http://127.0.0.1:3000'` instead. This ensures
the app works when hosted on any host/port (network IP, tunnel, production
domain). The only exception is `instrumentation.ts:waitForServerReady()` which
intentionally checks if the server itself is up during boot.

### Rule 6.5 — CORS Whitelist Includes Network IPs
`JARVIS_ALLOWED_ORIGINS` and `CORS_ORIGINS` MUST whitelist both localhost and
all known network IPs. Currently whitelisted:
- `http://127.0.0.1:3000`
- `http://localhost:3000`
- `http://192.168.0.10:3000`
- `http://192.168.0.6:3000`

### Rule 6.6 — Autopilot Scheduler Is a Server Singleton
The autopilot ON/OFF flag MUST live on the server (via `/api/autopilot/state`
backed by `MemoryItem` row `autopilot:state`). Exactly ONE scheduler loop runs
per server process, regardless of how many browsers are open. The flag
persists across server restarts. Clients read/toggle via the API; they MUST
NOT run their own `setTimeout` tick loops.

---

## SECTION 7: SECURITY (CRITICAL — added v14.0)

### Rule 7.1 — Rotate Committed Secrets
The `.env` file in the uploaded zip contains live plaintext secrets:
`ZAI_API_KEY`, `GROQ_API_KEY`, `NVIDIA_API_KEY`, `TELEGRAM_BOT_TOKEN`,
`AUTH_SECRET`, `ENCRYPTION_MASTER_KEY`, `JARVIS_VAULT_AUTH_TOKEN`, etc.
These MUST be rotated immediately. Anyone with the zip has full control of
the LLM billing account and the Telegram bot.

### Rule 7.2 — Move .env to .env.local
After rotation, move `.env` to `.env.local` (gitignored) and replace `.env`
with `.env.example` containing empty values. Never commit real secrets.

### Rule 7.3 — Dev Bypass Disabled in Production
`JARVIS_DEV_BYPASS_AUTH=1`, `RATE_LIMIT_DISABLED=true`, and
`JARVIS_SINGLE_USER_MODE=true` MUST be set to `0`/`false` in production.
The current `.env` ships with these enabled for local dev convenience.

---

## SECTION 8: DATABASE

### Rule 8.1 — SQLite for Dev, Postgres for Prod
The default database is SQLite at `db/custom.db` (relative to project root,
resolved to an absolute path in `.env` to avoid Prisma's relative-path
ambiguity). The Postgres schema is present at `prisma/schema-postgres.prisma`
and the db-sync ticker (`src/lib/db-sync.ts`) replicates SQLite → Postgres
when `POSTGRES_DATABASE_URL` is set.

### Rule 8.2 — Prisma Client Singleton
The Prisma client MUST be a singleton via `globalThis` (see `src/lib/db.ts`).
This prevents connection exhaustion in dev mode where Turbopack reloads
modules.

### Rule 8.3 — DATABASE_URL Must Be Absolute
In `.env`, `DATABASE_URL` MUST be an absolute path
(`file:/home/z/my-project/aria-analysis/db/custom.db`), NOT a relative path
(`file:./db/custom.db`). Relative paths break when Prisma resolves them
from different working directories (e.g. when run from a parent `.env`).

---

## SECTION 9: STRICT LOCAL-FIRST EXECUTION (added v14.1 — production freeze)

### Rule 9.1 — No Cloud / Migration / Hosting Until 1 Month Stable
The application MUST run entirely local-first. ZERO cloud deployment, ZERO
migration discussions, ZERO external hosting dependencies are permitted
until the application has undergone a minimum of **1 full month (30
consecutive days) of rigorous production testing and stability validation**
on the local machine. This is a HARD CONSTRAINT — no exceptions, no
loopholes, no "just this once" excuses.

During the 30-day stability validation window:
- The app runs only on `http://localhost:3000/` and the operator's LAN
  network IP (e.g. `http://192.168.0.10:3000/`).
- All database operations use the local SQLite file (`db/custom.db`).
- All file storage uses the local filesystem.
- All LLM calls go to external APIs (Z-AI, Groq, NVIDIA, etc.) — this is
  permitted because LLM inference is not "hosting" the app itself.
- No ngrok, no Cloudflare tunnels, no Vercel deploys, no Railway, no
  Fly.io, no Render, no Heroku, no Oracle Cloud, no AWS, no GCP, no Azure.
- The Postgres mirror (`prisma/schema-postgres.prisma`) and db-sync ticker
  MUST remain DISABLED (do not set `POSTGRES_DATABASE_URL`).
- The Socket.IO mini-service on port 3003 MAY run locally (it's a
  sub-process, not external hosting) but is optional — SSE fallback works.

### Rule 9.2 — SQLite + Local Files Only
The default database is SQLite at `db/custom.db` (absolute path
`file:/home/z/my-project/aria-analysis/db/custom.db` in `.env`). File
storage uses `/tmp/jarvis-sandbox/` (configurable via `FS_SANDBOX_ROOT`)
and `/opt/jarvis/apps/` + `/opt/jarvis/plugins/` for app/plugin installs.
No Turso, no Postgres, no Redis, no S3, no GCS, no Azure Blob, no Supabase
Storage, no Cloudflare R2 — all storage is local filesystem only.

### Rule 9.3 — No External Hosting Dependencies
The application's core runtime MUST NOT depend on any externally-hosted
service for its own operation. External API calls (LLM providers, payment
gateways, Telegram, email SMTP, FreeSWITCH) are permitted because they are
INTEGRATIONS, not hosting. The distinction:
- ✅ PERMITTED: calling `https://api.z.ai/...` for LLM inference
- ✅ PERMITTED: calling `https://api.telegram.org/...` to send a message
- ✅ PERMITTED: calling `https://api.stripe.com/...` to process a payment
- ❌ FORBIDDEN: hosting the app on `https://vercel.app/...`
- ❌ FORBIDDEN: storing the database on `https://turso.tech/...`
- ❌ FORBIDDEN: tunneling localhost via `https://ngrok.io/...`
- ❌ FORBIDDEN: running the server on `https://oraclecloud.com/...`

### Rule 9.4 — Stability Validation Criteria
Before the 30-day clock can even start, the app MUST pass ALL of these
gates on the local machine:
1. **Briefing desync fix verified** — localhost + network IP return
   identical briefings for 24 hours straight (no drift).
2. **Autopilot singleton verified** — exactly one scheduler loop runs
   regardless of how many browsers are open, for 24 hours straight.
3. **No uncaught exceptions** — server stays alive for 24 hours straight
   without crashing (the global error handlers in `instrumentation.ts`
   must not fire more than 3 times per hour).
4. **No memory leaks** — RSS memory stays below 2GB after 24 hours.
5. **All 31 sidebar entries functional** — every tab renders without
   errors, every API endpoint returns 200.
6. **All 7 background services stable** — cron-scheduler, autonomous-loop,
   idle-agent-dispatcher, autopilot-scheduler, monitoring-agents,
   env-watcher, db-sync-ticker (disabled) — all running cleanly.

Only after the 30-day window completes with zero critical incidents may
the operator consider cloud migration — and even then, the cloud migration
MUST be discussed as a separate, deliberate Phase 15+ initiative with its
own RULES.md amendment, NOT as a casual extension of v14.

### Rule 9.5 — Documentation Must Reflect Local-First
All documentation (`ROADMAP.md`, `APP_DOCUMENTATION.md`, `INSTALL.md`)
MUST clearly state the local-first constraint. Any cloud-migration
roadmap items MUST be explicitly marked as "POST-30-DAY-STABILITY — DO
NOT ATTEMPT BEFORE" and demoted to the bottom of the roadmap. This
ensures no future agent or operator accidentally starts a cloud migration
before the stability window is complete.

---

| Rule | Section | Summary |
|------|---------|---------|
| 1.1 | Architecture | Local-first, cloud-ready |
| 1.2 | Architecture | Zero-scratch code law |
| 1.3 | Architecture | Single-process singleton services |
| 2.1 | Router | 480+ model universal pool |
| 2.2 | Router | Dynamic smart router (no hardcoded models) |
| 2.3 | Router | Automatic failover |
| 3.1 | Benchmarks | Outperform Teamly/Claude/Gemini/z.ai |
| 3.2 | Benchmarks | Zero mock data |
| 4.1 | Persistence | Verify every file write |
| 4.2 | Persistence | Run verify-persistence.sh |
| 4.3 | Persistence | Milestone git commits |
| 5.1 | Docs | Update audit trail every run |
| 5.2 | Docs | Run-summary block required |
| 6.1 | State Sync | Server-side source of truth |
| 6.2 | State Sync | Briefing cache layers (TTL + hash + single-flight) |
| 6.3 | State Sync | Real-time push over polling (SSE) |
| 6.4 | State Sync | No hardcoded localhost:3000 |
| 6.5 | State Sync | CORS whitelist includes network IPs |
| 6.6 | State Sync | Autopilot scheduler is a server singleton |
| 7.1 | Security | Rotate committed secrets |
| 7.2 | Security | Move .env to .env.local |
| 7.3 | Security | Dev bypass disabled in production |
| 8.1 | Database | SQLite dev, Postgres prod |
| 8.2 | Database | Prisma client singleton via globalThis |
| 8.3 | Database | DATABASE_URL must be absolute |
| 9.1 | Local-First | No cloud/migration/hosting until 1 month stable |
| 9.2 | Local-First | SQLite + local files only |
| 9.3 | Local-First | No external hosting dependencies |
