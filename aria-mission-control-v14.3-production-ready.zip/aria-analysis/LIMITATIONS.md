# LIMITATIONS.md — ARIA Mission Control

**Version:** v14.1
**Last Updated:** 2026-07-24

> Honest inventory of what ARIA cannot do, unresolved edge cases, and
> areas requiring future automation. No aspirational features — only
> verified gaps.

---

## 1. CRITICAL LIMITATIONS (must fix before production)

### 1.1 Secrets Committed in `.env` (CRITICAL SECURITY)
- **Issue:** The `.env` file contains live plaintext secrets: `ZAI_API_KEY`, `GROQ_API_KEY`, `NVIDIA_API_KEY`, `TELEGRAM_BOT_TOKEN`, `AUTH_SECRET`, `NEXTAUTH_SECRET`, `ENCRYPTION_MASTER_KEY`, `JARVIS_VAULT_AUTH_TOKEN`, `HASH_SALT`, `REQUEST_SIGNING_SECRET`.
- **Impact:** Anyone with the zip has full control of the LLM billing account, Telegram bot, and can forge auth tokens.
- **Fix:** Rotate every key immediately. Move `.env` to `.env.local` (gitignored). Replace `.env` with `.env.example` (empty values).
- **Rule:** RULES.md Rule 7.1, 7.2

### 1.2 Dev Bypass Enabled
- **Issue:** `JARVIS_DEV_BYPASS_AUTH=1`, `RATE_LIMIT_DISABLED=true`, `JARVIS_SINGLE_USER_MODE=true` in `.env`.
- **Impact:** No authentication, no rate limiting — anyone on the LAN can access all endpoints including `/api/terminal/exec` (shell command execution).
- **Fix:** Set to `0`/`false` before any production use.
- **Rule:** RULES.md Rule 7.3

### 1.3 Terminal Exec Has No Auth
- **Issue:** `/api/terminal/exec` executes arbitrary shell commands. With dev bypass enabled, anyone on the LAN can run shell commands on the server.
- **Impact:** Remote code execution vulnerability.
- **Fix:** Add auth check + approval gate before exec. Restrict to admin role only.

### 1.4 No HTTPS
- **Issue:** App runs on `http://localhost:3000` and `http://<lan-ip>:3000` — all traffic is plaintext including auth tokens and API keys in transit.
- **Impact:** Credentials sniffable on the LAN.
- **Fix:** Terminate TLS at Caddy/Nginx (local reverse proxy — still local-first per Rule 9.1).

---

## 2. ARCHITECTURAL LIMITATIONS

### 2.1 Single-Process State (no horizontal scaling)
- **Issue:** `stateBus` (Map), `eventBus` (EventEmitter), `briefing-cache`, `autopilot-scheduler` are all in-process. Multiple Node.js workers would each have their own state.
- **Impact:** Cannot scale beyond 1 process without state divergence. Currently fine (local-first), but blocks future scaling.
- **Workaround:** Run exactly 1 Next.js process. The `globalThis` pattern in `db.ts` + `autopilot-scheduler.ts` ensures consistency within that 1 process.
- **Future:** Add Redis as the backing store (post-30-day stability, per Rule 9.1).

### 2.2 SQLite Write Contention
- **Issue:** SQLite serializes writes. Under heavy autopilot + cron + dispatcher load, write contention can cause latency spikes.
- **Impact:** Briefing generation can block on a write lock.
- **Workaround:** WAL mode is enabled by Prisma. Keep write frequency bounded (the briefings are cached 30s, autopilot ticks are 30s+).
- **Future:** Migrate to Postgres (post-30-day stability — Postgres schema already exists at `prisma/schema-postgres.prisma`).

### 2.3 No Queue (lost dispatches on failure)
- **Issue:** Autopilot dispatches to `/api/orchestrate/parallel` via in-process `fetch()`. If the dispatch fails (network, server error, timeout), the work is lost — no retry queue.
- **Impact:** A failed autopilot cycle just logs a warning and moves on.
- **Workaround:** The next autopilot tick (30-120s later) will pick up the same goal if it's still relevant.
- **Future:** Add a proper job queue (BullMQ + Redis, post-30-day stability).

### 2.4 maxDuration = 120s on Orchestrator
- **Issue:** `/api/orchestrate/parallel` has `maxDuration = 120`. Long orchestration runs (>2min) are killed.
- **Impact:** Complex goals that take >2min to decompose + execute are truncated.
- **Workaround:** Decompose into smaller sub-goals. Use the task queue for long-running work.
- **Future:** Move orchestration to a background worker (post-30-day stability).

### 2.5 In-Memory stateBus Lost on Restart
- **Issue:** The `stateBus` (in-process Map) is lost when the server restarts. Best-effort persistence to `MemoryItem` exists but reads are lazy (on cache-miss).
- **Impact:** In-flight orchestrations are lost on restart.
- **Workaround:** The autonomous-loop's `checkStaleTasks()` recovers tasks stuck in `in_progress` for >10min by resetting them to `pending`.
- **Future:** Use Redis for durable state (post-30-day stability).

---

## 3. FUNCTIONAL LIMITATIONS

### 3.1 ArtifactsTab is Read-Only
- **Issue:** `ArtifactsTab.tsx` (73 lines) only lists artifacts. No creation, editing, or deletion UI.
- **Impact:** Artifacts can only be created indirectly (via chat or IDE), not from the Artifacts tab itself.
- **Fix:** Add create/edit/delete UI to ArtifactsTab.

### 3.2 ProvidersTab is Minimal
- **Issue:** `ProvidersTab.tsx` (73 lines) just lists providers. Most provider management happens in ModelsTab.
- **Impact:** Confusing UX — two tabs for related functionality.
- **Fix:** Either merge ProvidersTab into ModelsTab, or expand it to full CRUD.

### 3.3 ServicesHubTab is Read-Only
- **Issue:** `ServicesHubTab.tsx` (165 lines) lists services but has no CRUD. Services are seeded by `scripts/seed-earning-methods.ts`.
- **Impact:** Cannot add/edit services from the UI.
- **Fix:** Add CRUD UI, or document that services are seed-only.

### 3.4 No Briefing History
- **Issue:** Only `latest-briefing` is persisted to `MemoryItem`. Historical briefings are not stored.
- **Impact:** Cannot replay past briefings or track how the headline changed over time.
- **Fix:** Add a `Briefing` table and persist every generated briefing (with state-hash for dedup).

### 3.5 No Side-by-Side Briefing Comparison
- **Issue:** Cannot compare two briefings to see what changed.
- **Impact:** Hard to diagnose "why did the headline change?"
- **Fix:** Add a comparison view (similar to ReportsTab's diff viewer).

### 3.6 Briefing LLM is Non-Deterministic
- **Issue:** Even with state-hash caching, when the state DOES change, the LLM produces a different headline/summary for the same logical state.
- **Impact:** Two briefings generated seconds apart (after a state change) can have different headlines even if the metrics are nearly identical.
- **Workaround:** State-hash caching ensures the LLM is only called when state actually changes. The 30s TTL cache means all clients within 30s see the same headline.
- **Future:** Add temperature=0 + seed control to `quickChat()` for deterministic outputs.

### 3.7 Socket.IO Mini-Service Often Missing
- **Issue:** `use-realtime.ts` tries to connect to `/?XTransformPort=3003` (Socket.IO mini-service). In typical dev setups, neither Caddy nor the mini-service is running.
- **Impact:** Real-time push silently falls back to HTTP polling. The dashboard works but loses push updates.
- **Workaround:** SSE (`/api/briefing/stream`) is the primary push channel and always works. Socket.IO is a progressive enhancement.

### 3.8 Payment Gateways Unconfigured
- **Issue:** `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `UPI_VPA` are all empty in `.env`.
- **Impact:** Payment checkout, refunds, and webhooks don't actually process payments.
- **Fix:** Configure the keys after rotating secrets (Rule 7.1).

### 3.9 SMTP Unconfigured
- **Issue:** `SMTP_USER`, `SMTP_PASS`, `IMAP_USER`, `IMAP_PASS` are empty.
- **Impact:** Email sending + IMAP sync don't work. Approval escalation Level 2 (email) silently fails.
- **Fix:** Configure SMTP credentials (Gmail App Password recommended).

### 3.10 FreeSWITCH Unconfigured
- **Issue:** `FREESWITCH_ESL_HOST=127.0.0.1` is set but FreeSWITCH is likely not installed.
- **Impact:** Voice calls (Level 3 approval escalation) silently fail.
- **Fix:** Install FreeSWITCH if voice escalation is needed, otherwise disable Level 3.

### 3.11 Telegram Chat ID is a Single User
- **Issue:** `TELEGRAM_CHAT_ID=5390514958` is one specific user's chat ID.
- **Impact:** All Telegram broadcasts go to that one user. No multi-user Telegram support.
- **Fix:** Add a `TelegramSubscriber` table for multi-user broadcasts.

### 3.12 CRM Integrations Unconfigured
- **Issue:** `TWENTY_CRM_URL`, `TWENTY_CRM_API_KEY`, `CHATWOOT_BASE_URL`, `CHATWOOT_API_KEY`, `DOCUSEAL_URL`, `DOCUSEAL_API_KEY` are all empty.
- **Impact:** CRM tab works (uses local DB) but doesn't sync to Twenty/Chatwoot/DocuSeal.
- **Fix:** Configure the integration keys if external CRM sync is needed.

---

## 4. EDGE CASES & KNOWN ISSUES

### 4.1 Race Condition: Concurrent Briefing Forecast Generation
- **Issue:** `/api/briefing` checks if `FleetForecast` is stale (>5min) and calls `generateFleetForecasts()`. Two concurrent requests at the 5-min boundary can both pass the check and both call `generateFleetForecasts()`.
- **Impact:** Wasted compute (double LLM call for forecasts).
- **Workaround:** The state-hash + single-flight caching in `briefing-cache.ts` prevents this for the briefing itself, but forecasts have their own separate cache.
- **Fix:** Add a forecast-generation lock (single-flight pattern).

### 4.2 Race Condition: ActionLog Throttle
- **Issue:** `/api/briefing` checks "last briefing.generated action log" and creates a new one if >10min old OR health changed. Two concurrent briefing calls can both pass the check and both insert.
- **Impact:** Duplicate ActionLog rows.
- **Workaround:** The 30s TTL cache means concurrent briefing calls are rare (only on cache miss).
- **Fix:** Use a DB-level unique constraint or a generation lock.

### 4.3 memoryItem.upsert Swallows Errors
- **Issue:** `/api/briefing` does `db.memoryItem.upsert(...)` in a try/catch that silently swallows unique-constraint errors.
- **Impact:** On a fresh DB without the unique constraint, every briefing overwrites with no audit trail.
- **Fix:** Ensure the `key_scope` unique constraint exists (it does in the current schema).

### 4.4 Tab-Hidden Polling Pause
- **Issue:** `use-api.ts:isTabHidden()` pauses ALL polling when the browser tab is hidden.
- **Impact:** When the operator returns to a hidden tab, the first fetch sees a stale state and may show wildly different numbers than before.
- **Workaround:** SSE (for briefing) keeps working even when the tab is hidden (EventSource auto-reconnects). Other tabs will refresh on focus.
- **Fix:** Add a "stale data" indicator when resuming from hidden state.

### 4.5 reactStrictMode: false
- **Issue:** `next.config.ts` has `reactStrictMode: false`.
- **Impact:** Masks double-mount bugs in development. Production-only double-effect bugs won't show up in dev.
- **Fix:** Enable `reactStrictMode: true` and fix any double-mount issues that surface.

### 4.6 typescript.ignoreBuildErrors: true
- **Issue:** `next.config.ts` has `typescript.ignoreBuildErrors: true`.
- **Impact:** TypeScript errors don't block the build — type bugs can ship to production.
- **Fix:** Set to `false` and fix all type errors before production.

### 4.7 Hardcoded `localhost:3000` in instrumentation.ts
- **Issue:** `instrumentation.ts:47` has `fetch('http://localhost:3000/')` in `waitForServerReady()`.
- **Impact:** If the server isn't on localhost (e.g. behind a reverse proxy), the boot wait loop fails.
- **Status:** Intentional — this is a server-internal health check during boot, not a runtime call. Left as-is per Rule 6.4 (the exception).

### 4.8 Idle-Agent Dispatcher 30s→2min Interval Change
- **Issue:** `idle-agent-dispatcher.ts` comments say "5-second ticker" but `TICK_INTERVAL_MS = 120_000` (2min).
- **Impact:** Documentation drift — the code says 5s, the constant says 2min.
- **Status:** Intentional — changed from 30s to 2min to prevent CPU spikes. Comment is stale.
- **Fix:** Update the comment to reflect the 2min interval.

### 4.9 Autonomous Loop First-Tick Delay
- **Issue:** `autonomous-loop.ts:306` has `setTimeout(..., 300_000)` (5min) for the first tick, but the comment says "60s".
- **Impact:** First autonomous loop tick is delayed 5min, not 60s as documented.
- **Fix:** Update the comment, or change the delay to 60s.

### 4.10 No Mobile-Responsive Layout
- **Issue:** Most tabs are designed for desktop (1600px+ width). On mobile, layouts break.
- **Impact:** Operator cannot use ARIA from a phone.
- **Fix:** Add mobile-responsive breakpoints to all tabs (significant effort — 76 tabs).

### 4.11 No Keyboard Shortcuts
- **Issue:** No global keyboard shortcuts (e.g. Cmd+K for command palette, R for refresh).
- **Impact:** Power users can't navigate quickly.
- **Fix:** Add a global keyboard handler + command palette.

### 4.12 No Undo/Redo for Destructive Actions
- **Issue:** While the Action Log supports reversal for some actions, most destructive operations (delete agent, delete task, reset data) have no undo.
- **Impact:** Accidental deletes are permanent.
- **Fix:** Add soft-delete + undo for all destructive operations.

---

## 5. PERFORMANCE LIMITATIONS

### 5.1 No LLM Response Caching (beyond state-hash)
- **Issue:** State-hash caching skips the LLM when state hasn't changed. But when state DOES change, the LLM is called fresh — no caching of similar prompts.
- **Impact:** Under rapid state changes, LLM costs can spike.
- **Fix:** Add prompt-hash caching (cache LLM responses by prompt hash, with TTL).

### 5.2 Per-Tab Polling
- **Issue:** Each tab polls independently via `useApi()`. With 31 sidebar entries, opening all tabs would trigger ~31 concurrent polls.
- **Impact:** CPU + network overhead.
- **Workaround:** Adaptive throttling (1x-6x based on CPU), hidden-tab pause, 15-fetch concurrency cap.
- **Fix:** Migrate more tabs to SSE push (only BriefingTab + BriefingHeadlinePill use SSE currently).

### 5.3 No ETag/Last-Modified Headers
- **Issue:** `/api/briefing` doesn't send ETag or Last-Modified headers.
- **Impact:** Browser can't do conditional requests (304 Not Modified).
- **Fix:** Add ETag based on state-hash + Last-Modified based on generatedAt.

### 5.4 No Compression
- **Issue:** API responses are not gzip-compressed.
- **Impact:** Larger transfer sizes (briefing is ~4KB, agents list is ~22KB).
- **Fix:** Enable gzip/brotli in Next.js config or reverse proxy.

---

## 6. SECURITY LIMITATIONS

### 6.1 No CSRF Protection
- **Issue:** POST routes don't have CSRF tokens.
- **Impact:** Cross-site request forgery attacks possible (if an attacker can trick an authenticated user into submitting a form).
- **Fix:** Add CSRF tokens to all state-changing routes.

### 6.2 No Per-IP Rate Limiting
- **Issue:** `RATE_LIMIT_DISABLED=true` in dev. Even when enabled, rate limiting is global, not per-IP.
- **Impact:** A single client can DoS the server by spamming requests.
- **Fix:** Add per-IP rate limiting (using the `X-Forwarded-For` header).

### 6.3 Terminal Exec Has No Sandbox
- **Issue:** `/api/terminal/exec` runs shell commands directly on the server (no sandbox).
- **Impact:** A malicious command can damage the server.
- **Fix:** Run commands in a Docker container or `chroot` sandbox.

### 6.4 File Operations Have No Path Validation
- **Issue:** `/api/file/write` and `/api/file/read` don't validate that the path is within an allowed directory.
- **Impact:** Path traversal attacks can read/write arbitrary files.
- **Fix:** Validate paths against `FS_SANDBOX_ROOT` + reject `..` sequences.

### 6.5 Code Exec Has No Resource Limits
- **Issue:** `/api/code-exec` doesn't limit CPU/memory/time for executed code.
- **Impact:** A malicious script can DoS the server.
- **Fix:** Run in a sandboxed container with resource limits (the `code-sandbox.ts` + `fugu-isolation.ts` exist but may not be fully wired).

---

## 7. AREAS REQUIRING FUTURE AUTOMATION

### 7.1 No Auto-Recovery from LLM Provider Outage
- **Issue:** When the primary LLM provider (Z-AI) goes down, the fallback chain kicks in. But there's no auto-recovery — the operator must manually verify Z-AI is back.
- **Fix:** Add a health-check cron that pings Z-AI every 5min and auto-reverts from fallback when it's back.

### 7.2 No Auto-Scale Agent Fleet
- **Issue:** The fleet is fixed at 64 agents. When load is high, no auto-scaling.
- **Fix:** Add an auto-scaler that spawns ephemeral agents when fleet load >80% for 5min.

### 7.3 No Auto-Training for Skill Gaps
- **Issue:** Skill gap analysis identifies gaps but doesn't auto-schedule training.
- **Fix:** Auto-schedule training sessions for identified gaps (with operator approval).

### 7.4 No Auto-Patch for Security Issues
- **Issue:** When a security issue is detected (e.g. dependency vulnerability), no auto-patching.
- **Fix:** Add a security scanner cron + auto-PR for patchable vulnerabilities.

### 7.5 No Auto-Backup
- **Issue:** No automated backup of `db/custom.db`.
- **Impact:** DB corruption or accidental deletion = total data loss.
- **Fix:** Add a backup cron that copies `db/custom.db` to a timestamped backup daily.

### 7.6 No Auto-Recovery from DB Corruption
- **Issue:** If `db/custom.db` becomes corrupted, the server crashes with no recovery path.
- **Fix:** Add a DB integrity check on boot + auto-restore from latest backup.

### 7.7 No Multi-Operator Support
- **Issue:** `JARVIS_SINGLE_USER_MODE=true` — only one operator.
- **Impact:** Multiple operators can't use ARIA simultaneously with separate identities.
- **Fix:** Set `JARVIS_MULTI_TENANT=true` + implement proper multi-tenant auth (post-30-day stability).

### 7.8 No Audit Log Retention Policy
- **Issue:** `ActionLog`, `AgentLog`, `Notification` tables grow unbounded.
- **Impact:** DB bloat over time.
- **Fix:** Add a retention cron that purges logs older than 90 days.

### 7.9 No Mobile App
- **Issue:** No native mobile app. Web UI is desktop-only.
- **Fix:** Build a React Native app (post-30-day stability) or make the web UI mobile-responsive.

### 7.10 No Public API for External Integrations
- **Issue:** No API key system for external apps to integrate with ARIA.
- **Fix:** Add an API key management UI + `/api/v1/*` namespace for external consumers.
