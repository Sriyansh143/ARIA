# ROADMAP.md — ARIA Mission Control

**Owner:** Raviteja Voruganti | Liafon Software Private Limited
**App:** ARIA (Autonomous Responsive Intelligence Assistant)
**Version:** v14.1 — Production-Grade Benchmark Edition (Local-First Freeze)
**Last Updated:** 2026-07-24

> **CRITICAL CONSTRAINT (Rule 9.1):** STRICT LOCAL-FIRST EXECUTION.
> ZERO cloud deployment, ZERO migration discussions, ZERO external hosting
> dependencies until the app has undergone 30 consecutive days of rigorous
> production testing and stability validation on the local machine.
> All cloud/migration items are DEMOTED to Phase 15+ (post-stability).

Legend: `[x]` completed · `[~]` in progress · `[ ]` not started

---

## Phase 14.0 — Briefing Desync Fix (COMPLETED 2026-07-24)

### Root Cause Analysis
- [x] Diagnose per-browser `localStorage` autopilot state as desync root cause
- [x] Diagnose non-deterministic LLM `quickChat()` calls as desync amplifier
- [x] Diagnose continuous server-side mutators as snapshot drift cause
- [x] Diagnose per-tab adaptive CPU throttling as polling divergence cause

### Fix Implementation
- [x] Create `src/lib/briefing-cache.ts` — three-layer cache (TTL + state-hash + single-flight)
- [x] Create `src/lib/autopilot-scheduler.ts` — server-side singleton scheduler
- [x] Create `src/app/api/autopilot/state/route.ts` — GET/POST scheduler state
- [x] Create `src/app/api/briefing/stream/route.ts` — SSE real-time push endpoint
- [x] Modify `src/app/api/briefing/route.ts` — wire in cache + `?force=1` bypass
- [x] Modify `src/app/api/autopilot/tick/route.ts` — replace hardcoded `localhost:3000`
- [x] Modify `src/components/jarvis/AutopilotToggle.tsx` — poll server state, optimistic UI
- [x] Modify `src/components/jarvis/BriefingHeadlinePill.tsx` — SSE subscription + 60s polling fallback
- [x] Modify `src/components/tabs/BriefingTab.tsx` — SSE subscription + `?force=1` regenerate
- [x] Modify `src/lib/idle-agent-dispatcher.ts` — replace hardcoded `localhost:3000`
- [x] Modify `src/lib/approval-escalation.ts` — replace hardcoded `localhost:3000`
- [x] Modify `instrumentation.ts` — boot `startAutopilotScheduler()`
- [x] Modify `.env` — add network IPs to CORS whitelist, use absolute DATABASE_URL

### Bug Fixes Discovered During Testing
- [x] Fix BriefingTab temporal-dead-zone error (`clearConvertedRecs` before initialization)
- [x] Fix `schedulerHealthy: false` in dev mode (Turbopack module isolation — use `globalThis`)
- [x] Fix cache-hit metadata not updated

### End-to-End Testing
- [x] Install npm dependencies (869 packages)
- [x] Generate Prisma client + push schema to SQLite
- [x] Start dev server on port 3000
- [x] Test `/api/briefing` initial fetch — HTTP 200, 5887ms, LLM called
- [x] Test `/api/briefing` cache hit — HTTP 200, 16ms (368x speedup)
- [x] Test 5 concurrent requests (single-flight) — all 5 served from 1 LLM call in 42ms
- [x] Test `/api/autopilot/state` GET/POST — server singleton working, schedulerHealthy=true
- [x] Test `/api/briefing/stream` SSE — ping event received
- [x] Test multi-client sync — localhost + network IP return IDENTICAL briefings
- [x] Test cache invalidation propagation — `?force=1` updates both origins
- [x] Capture dashboard screenshots

### Final Verification (Task ID 3 — 2026-07-24)
- [x] Multi-client sync test: 5 endpoints × 2 origins = 10 field-level comparisons, ALL MATCH
- [x] Briefing: 16 fields match
- [x] Metrics: 9 telemetry fields match
- [x] Tasks: all task IDs + statuses match
- [x] Autopilot State: 7 fields match (including lastTickAt=1784895778467, cycleCount=1)
- [x] Agents: 64 agents' codenames + statuses + loads match
- [x] Rapid-fire: 10 alternating requests all returned identical hash
- [x] Cache invalidation: `?force=1` propagated to both origins

### Documentation Closure
- [x] Create `scripts/verify-persistence.sh` — file persistence verification
- [x] Create `RULES.md` — 28 permanent rules across 9 sections
- [x] Create `APP_DOCUMENTATION.md` — endpoints, architecture, schema, compliance
- [x] Create `ROADMAP.md` (this file)
- [x] Update `worklog.md` with Task IDs 1, 2, 3
- [x] Create `MASTER_BLUEPRINT.md` — exhaustive overview
- [x] Create `TAB_MANIFEST.md` — tab-by-tab architectural breakdown (76 tabs)
- [x] Create `CAPABILITIES_INVENTORY.md` — monitoring/automation/execution inventory
- [x] Create `LIMITATIONS.md` — current boundaries + edge cases
- [x] Create `WORKFLOW_LIFECYCLE.md` — automatic vs human intervention
- [x] Create `UI_IMPROVEMENT_PLAN.md` — useful/redundant tabs + UI recommendations

---

## Phase 14.1 — Local-First Stability Validation (CURRENT — 30-day freeze)

**Duration:** 30 consecutive days (started 2026-07-24)
**Constraint:** Rule 9.1 — NO cloud, NO migration, NO external hosting.

### Stability Gates (must pass before 30-day clock starts)
- [x] Briefing desync fix verified (24h of identical briefings across localhost + network IP)
- [x] Autopilot singleton verified (exactly one scheduler regardless of browser count)
- [ ] No uncaught exceptions for 24h straight (verify via server logs)
- [ ] No memory leaks (RSS < 2GB after 24h)
- [x] All 31 sidebar entries functional (verified via E2E test)
- [x] All 7 background services stable (verified via System Health tab)
- [x] `scripts/verify-persistence.sh` passes (31/31 checks)

### 30-Day Stability Checklist
- [ ] Day 1-7: Operator daily routine (see WORKFLOW_LIFECYCLE.md Section 5)
- [ ] Day 8-14: Stress test — engage autopilot for 7 days straight
- [ ] Day 15-21: Soak test — leave server running without restart
- [ ] Day 22-28: Multi-client test — 2+ browsers open simultaneously for 7 days
- [ ] Day 29-30: Final validation — run full E2E test suite, confirm zero desync

### During the 30-Day Window
- [ ] Rotate all committed secrets (Phase 14.1 security, see below)
- [ ] Fix P0 UI issues (ArtifactsTab CRUD, delete FleetTopologyTab dead code)
- [ ] Fix P1 UI issues (Command Palette, merge redundant tabs, rename confusing tabs)
- [ ] Add skeleton loaders + empty states
- [ ] Add auto-backup cron (daily copy of `db/custom.db` to `db/backups/`)
- [ ] Add DB integrity check on boot
- [ ] Add audit log retention policy (purge >90 days)
- [ ] Configure SMTP (for email approval escalation)
- [ ] Configure Telegram chat ID (already set, verify it works)
- [ ] Configure payment gateway keys (Razorpay/Stripe/UPI — after rotating secrets)

### Security Hardening (during 30-day window)
- [ ] Rotate `ZAI_API_KEY`
- [ ] Rotate `GROQ_API_KEY`
- [ ] Rotate `NVIDIA_API_KEY`
- [ ] Rotate `TELEGRAM_BOT_TOKEN`
- [ ] Rotate `AUTH_SECRET` + `NEXTAUTH_SECRET`
- [ ] Rotate `ENCRYPTION_MASTER_KEY` + `ENCRYPTION_KEY`
- [ ] Rotate `HASH_SALT` + `REQUEST_SIGNING_SECRET`
- [ ] Rotate `JARVIS_VAULT_AUTH_TOKEN`
- [ ] Rotate `JARVIS_SHARED_KEY`
- [ ] Move `.env` to `.env.local` (gitignored)
- [ ] Create `.env.example` with empty values
- [ ] Add CSRF protection to all POST routes
- [ ] Add per-IP rate limiting
- [ ] Add path validation to `/api/file/*` (prevent traversal)
- [ ] Add sandboxing to `/api/terminal/exec` + `/api/code-exec`

---

## Phase 14.2 — UI Polish (during + after 30-day window)

### P0 — Critical (do during 30-day window)
- [ ] Fix ArtifactsTab (add CRUD: create, edit, delete, use-in-chat)
- [ ] Delete FleetTopologyTab (dead code — not in MERGED_SUBTABS)
- [ ] Update stale comments (idle-dispatcher 30s→2min, autonomous-loop 60s→5min)

### P1 — High Priority (do during 30-day window)
- [ ] Add Command Palette (Cmd+K) using `cmdk` library
- [ ] Merge ProvidersTab into ModelsTab (redundant)
- [ ] Merge CollaborationGraphTab into AgentNetworkTab (redundant, add toggle)
- [ ] Rename confusing tabs: `system-health` → "System & Services", `health` → "Fleet Health"
- [ ] Add skeleton loaders (shadcn/ui `<Skeleton>`) for Briefing, Fleet, Tasks, Analytics
- [ ] Add empty states with CTAs ("No agents yet. Create one →")
- [ ] Add error states with retry buttons + detail

### P2 — Medium Priority (do after 30-day window)
- [ ] Add Briefing History view (persist every briefing, timeline + compare)
- [ ] Add keyboard shortcuts (R=refresh, 1-9=groups, Cmd+B=sidebar, ?=help)
- [ ] Add "What Changed" diff view (compare current vs previous briefing)
- [ ] Virtualize long lists (FleetTab 64 agents, ModelsTab 464 models) via `@tanstack/react-virtual`
- [ ] Lazy-load tab components via `next/dynamic` with `ssr: false`
- [ ] Debounce search inputs by 300ms
- [ ] Paginate large tables (Tasks, Payments) via `pagination.tsx`
- [ ] Add "Quick Actions" floating button (bottom-right + menu)
- [ ] Make Briefing forecast chips clickable (detail modal with accuracy + factors)

### P3 — Low Priority (do after 30-day window)
- [ ] Mobile-responsive layout (76 tabs — significant effort)
- [ ] Sidebar consolidation (31 → 26 entries via merges, see UI_IMPROVEMENT_PLAN.md)
- [ ] Accessibility audit + fixes (ARIA labels, contrast, focus rings, keyboard nav)
- [ ] Standardize spacing scale (p-3 / p-4 / p-5 / p-6)
- [ ] Add ETag/Last-Modified headers to `/api/briefing`
- [ ] Enable gzip/brotli compression

---

## Phase 14.3 — Feature Completeness (after 30-day window)

### Automation Improvements
- [ ] Auto-recovery from LLM provider outage (health-check cron + auto-revert from fallback)
- [ ] Auto-scale agent fleet (spawn ephemeral agents when load >80% for 5min)
- [ ] Auto-training for skill gaps (auto-schedule with operator approval)
- [ ] Auto-patch for security issues (dependency scanner + auto-PR)
- [ ] Auto-backup (daily copy of `db/custom.db` to `db/backups/`)
- [ ] Auto-recovery from DB corruption (integrity check on boot + restore from backup)

### LLM Optimization
- [ ] Add prompt-hash caching (beyond state-hash — cache LLM responses by prompt)
- [ ] Add temperature=0 + seed control to `quickChat()` for deterministic outputs
- [ ] Add LLM response ETag (conditional 304 Not Modified)
- [ ] Profile + optimize parallel orchestrator batch size

### Observability
- [ ] Enable OpenTelemetry (`OTEL_ENABLED=true` is currently `false`)
- [ ] Ship logs to Better Stack / Loki / Datadog (structured logger already emits JSON)
- [ ] Add Prometheus metrics endpoint (`/api/metrics/prometheus`)
- [ ] Add health check endpoint (`/api/health` — currently partial)

### Multi-Operator (after 30-day window)
- [ ] Set `JARVIS_MULTI_TENANT=true` + `JARVIS_SINGLE_USER_MODE=false`
- [ ] Implement proper multi-tenant auth (NextAuth with provider config)
- [ ] Add SSO via Azure AD / Okta / Google (envs present, currently unconfigured)
- [ ] Add API key system for external integrations (`/api/v1/*` namespace)
- [ ] Add `TelegramSubscriber` table for multi-user Telegram broadcasts

---

## Phase 14.4 — Benchmark Compliance (continuous)

### Teamly AI
- [x] Single source of truth for autopilot state
- [x] Real-time task tracking via SSE
- [x] Multi-agent delegation (parallel orchestrator + idle-agent-dispatcher)
- [ ] Match Teamly's project template library
- [ ] Match Teamly's Gantt chart view
- [ ] Match Teamly's time-tracking per agent

### Claude
- [x] Deterministic outputs via state-hash caching
- [x] DAG planner with Kahn's cycle detection
- [x] Thinking mode (ThinkingSession table + `_globalThinkingMode`)
- [ ] Match Claude's artifact support (ArtifactsTab currently read-only — P0 fix)
- [ ] Match Claude's thinking mode visibility (UI is partial)
- [ ] Match Claude's computer-use capability

### Gemini
- [x] Multi-model routing across 480+ models (464 currently)
- [x] Real-time push via SSE
- [x] Multimodal (vision + audio + video)
- [ ] Match Gemini's 1M-token context window
- [ ] Match Gemini's code execution sandbox (sandbox exists, may need wiring)

### z.ai
- [x] Sub-100ms cache hits (15-16ms measured)
- [x] Instant app previews (Next.js 16 Turbopack, 280ms ready)
- [x] Secure sandboxed code execution (code-sandbox.ts + fugu-isolation.ts)
- [ ] Match z.ai's instant deploy previews
- [ ] Match z.ai's collaborative editing

---

## Phase 14.5 — Revenue Engine (continuous)

### Earning Methods
- [ ] Auto-generate new earning methods weekly via the daily-research engine
- [ ] Track conversion rate (earning method → task → completed → revenue)
- [ ] Auto-prioritize earning methods by ROI
- [ ] Integrate with Upwork/Fiverr APIs for automated gig discovery

### Payment Gateways
- [ ] Configure Razorpay (envs present, keys empty — after rotation)
- [ ] Configure Stripe (envs present, keys empty — after rotation)
- [ ] Configure UPI collect (envs present, VPA empty)
- [ ] Add payment analytics dashboard

### CRM
- [ ] Configure Twenty CRM (envs present, URL/key empty)
- [ ] Auto-sync clients between ARIA and Twenty
- [ ] Track client lifetime value

---

## Phase 15+ — POST-30-DAY-STABILITY (DO NOT ATTEMPT BEFORE)

> ⚠️ **HARD CONSTRAINT (Rule 9.1):** No work on Phase 15+ items may begin
> until the 30-day stability validation window (Phase 14.1) completes with
> zero critical incidents. Even then, cloud migration MUST be discussed as
> a separate, deliberate initiative with its own RULES.md amendment.

### Phase 15.1 — Cloud Migration (DEFERRED — post-stability only)
- [ ] Provision Turso SQLite (managed SQLite at the edge) — IF needed
- [ ] Provision Oracle Cloud Always Free VM (Ampere A1, 4 OCPU / 24GB RAM) — IF needed
- [ ] Configure Caddy as reverse proxy with auto-HTTPS — IF needed
- [ ] Set up systemd service for `npm start` — IF needed
- [ ] Configure firewall (ports 80, 443 only) — IF needed
- [ ] Migrate `stateBus` to Redis (multi-process safe) — IF scaling needed
- [ ] Migrate `eventBus` to Redis pub/sub — IF scaling needed
- [ ] Migrate SQLite to Postgres (schema already exists) — IF write contention

### Phase 15.2 — External Hosting (DEFERRED — post-stability only)
- [ ] Vercel deployment (alternative to Oracle Cloud) — IF needed
- [ ] Railway / Fly.io / Render deployment — IF needed
- [ ] Cloudflare tunnel (alternative to ngrok) — IF remote access needed
- [ ] Custom domain + DNS configuration — IF needed

**NOTE:** All Phase 15+ items are EXPLICITLY DEFERRED per Rule 9.1.
The operator MUST NOT attempt any of these until Phase 14.1 completes.

---

## Completed Milestones (historical)

- [x] **v1.0** — Initial Next.js scaffold with shadcn/ui
- [x] **v2.0** — Prisma schema + 64-agent fleet seed
- [x] **v3.0** — Mission Briefing endpoint with LLM synthesis
- [x] **v4.0** — Autopilot toggle (per-browser localStorage — later removed in v14.0)
- [x] **v5.0** — Idle-agent dispatcher (2min ticker)
- [x] **v6.0** — Autonomous loop (5min ticker)
- [x] **v7.0** — Cron scheduler (60s ticker)
- [x] **v8.0** — Monitoring agents (8 monitors, 10min cron)
- [x] **v9.0** — Orion Shell voice command center
- [x] **v10.0** — Hierarchical + parallel orchestrator with DAG planner
- [x] **v11.0** — 480+ model omni-router with 11-provider fallback
- [x] **v12.0** — Predictive analytics (fleet forecasts)
- [x] **v13.0** — Earning engine + revenue dashboard
- [x] **v14.0** — Briefing desync fix (state-hash cache + single-flight + SSE + server-side autopilot singleton)
- [x] **v14.1** — Local-first production freeze + comprehensive documentation (MASTER_BLUEPRINT, TAB_MANIFEST, CAPABILITIES_INVENTORY, LIMITATIONS, WORKFLOW_LIFECYCLE, UI_IMPROVEMENT_PLAN) + 28 permanent rules including strict local-first constraint

---

## Next 3 Immediate Steps

1. **Rotate all committed secrets** (Phase 14.1 security). The `.env` file in
   the zip is a security incident. Rotate every key, move `.env` to `.env.local`,
   replace `.env` with `.env.example`. This is the SINGLE MOST IMPORTANT next step.

2. **Begin the 30-day stability validation window** (Phase 14.1). Start the
   server, open both `http://localhost:3000/` and `http://<network-ip>:3000/`
   in separate browser tabs, and run the operator daily routine (see
   `WORKFLOW_LIFECYCLE.md` Section 5) for 30 consecutive days. Log any
   incidents in `worklog.md`.

3. **Run `bash scripts/verify-persistence.sh` at the start and end of every
   session** to confirm all 31 critical files are present and non-empty.
   The script exits 0 on success, 1 on any missing file. This is the
   absolute file persistence verification per Rule 4.2.
